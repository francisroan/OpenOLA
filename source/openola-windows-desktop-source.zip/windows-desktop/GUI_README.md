# Start the OpenOLA Windows GUI

The default launcher opens the glass desktop interface in a local Edge or Chrome app window. The bridge listens on the local computer only. It does not contact an OpenOLA cloud service.

## First launch

1. Download and extract the Windows desktop source archive from the repository's `source/` folder.
2. Install Python 3.12 x64 from [python.org](https://www.python.org/downloads/windows/) and include Tcl/Tk. The Python launcher (`py`) is recommended.
3. Double-click `SETUP_AND_LAUNCH.cmd`. On first use, it creates a `.venv` folder and installs the Python packages listed in `tool/oladiag/requirements.txt`. It then opens the GUI.
4. On later launches, double-click `30_scooter_gui.cmd`.

Internet access is needed once to install Python packages. Microsoft Edge or Google Chrome is needed to display the default glass interface. The classic Tk interface can be started by running `tools\start_scooter_gui.ps1 -Classic` from PowerShell.

## What this package contains

The archive includes the Windows GUI source, its local bridge, diagnostic support modules, and generated protocol code needed to start the application. It does not bundle Python or a preconfigured vehicle identity. The app's supported functions and known validation gaps are described in the repository's `VALIDATION_PLAN.md`.

Use only with equipment and credentials you are authorized to access. A successful launch confirms that the desktop UI starts; it does not establish compatibility with a particular scooter, firmware, or repair procedure.
