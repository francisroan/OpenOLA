# Start the OpenOLA Windows GUI

The default launcher opens the glass desktop interface in a local Edge or Chrome app window. The bridge listens on the local computer only. It does not contact an OpenOLA cloud service.

## First launch

1. Download and extract the Windows desktop source archive from the repository's `source/` folder.
2. Install Python 3.12 x64 from [python.org](https://www.python.org/downloads/windows/) and include Tcl/Tk. The Python launcher (`py`) is recommended.
3. Double-click `SETUP_AND_LAUNCH.cmd`. On first use, it creates a `.venv` folder and installs the Python packages listed in `tool/oladiag/requirements.txt`. It then opens the GUI.
4. On later launches, double-click `30_scooter_gui.cmd`.

Internet access is needed once to install Python packages. Microsoft Edge or Google Chrome is needed to display the default glass interface. The classic Tk interface can be started by running `tools\start_scooter_gui.ps1 -Classic` from PowerShell.

## What this package contains

The archive includes the Windows GUI source, its local bridge, diagnostic support modules, DBC data, and generated protocol code needed to start the application. It does not bundle Python, personal connection settings, or the external ODX data extracted from the factory app. Without a separately authorized local ODX copy, ODX-backed read catalogs, parameter/actuator definitions, and related UDS demo responses are unavailable. The app's supported functions and known validation gaps are described in the repository's `VALIDATION_PLAN.md`.

The components catalog includes the imported S1X Phase 1/2 parameter maps. CAN entries can show an exact already-decoded snapshot; UDS entries remain reference-only unless an explicit request definition exists. Browsing the catalog does not send a vehicle request.

The connection host is blank on first launch. Enter the address for your own authorized scooter in Connection settings. Use only with equipment and credentials you are authorized to access. A successful launch confirms that the desktop UI starts; it does not establish compatibility with a particular scooter, firmware, or repair procedure.
