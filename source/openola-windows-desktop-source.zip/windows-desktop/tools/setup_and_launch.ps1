$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$venvPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
$requirements = Join-Path $projectRoot 'tool\oladiag\requirements.txt'

if (-not (Test-Path -LiteralPath $venvPython)) {
    $madeVenv = $false
    $py = Get-Command 'py.exe' -ErrorAction SilentlyContinue
    if ($py) {
        try {
            & $py.Source -3.12 -m venv (Join-Path $projectRoot '.venv')
            $madeVenv = ($LASTEXITCODE -eq 0)
        } catch { $madeVenv = $false }
    }
    if (-not $madeVenv) {
        $python = Get-Command 'python.exe' -ErrorAction SilentlyContinue
        if ($python) {
            try {
                & $python.Source -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)"
                if ($LASTEXITCODE -eq 0) {
                    & $python.Source -m venv (Join-Path $projectRoot '.venv')
                    $madeVenv = ($LASTEXITCODE -eq 0)
                }
            } catch { $madeVenv = $false }
        }
    }
    if (-not $madeVenv) {
        Write-Host 'Python 3.12 x64 was not found. Install it from https://www.python.org/downloads/windows/ and enable Tcl/Tk, then run this file again.'
        exit 1
    }
}

& $venvPython -c "import tkinter" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host 'This Python installation has no Tcl/Tk support. Reinstall Python 3.12 x64 with Tcl/Tk enabled, remove the .venv folder, and run this file again.'
    exit 1
}

& $venvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $venvPython -m pip install -r $requirements
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& (Join-Path $PSScriptRoot 'start_scooter_gui.ps1')
exit $LASTEXITCODE
