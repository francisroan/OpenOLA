param([switch]$Classic)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
# Glass UI (default) opens in an Edge/Chrome app window; -Classic runs the original Tk console.
$entry = if ($Classic) { 'tool\scooter_gui.py' } else { 'tool\scooter_glass.py' }
$venvPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
$candidates = @()
if (Test-Path -LiteralPath $venvPython) { $candidates += $venvPython }
$bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$candidates += $bundledPython
foreach ($name in @('python.exe', 'py.exe', 'python3.exe')) {
    $command = Get-Command $name -ErrorAction SilentlyContinue
    if ($command) { $candidates += $command.Source }
}
foreach ($candidate in $candidates) {
    if (-not (Test-Path -LiteralPath $candidate)) { continue }
    & $candidate -c "import sys; sys.path.insert(0, r'$projectRoot\tool\gui_vendor'); import tkinter, grpc, google.protobuf" 2>$null
    if ($LASTEXITCODE -eq 0) {
        & $candidate (Join-Path $projectRoot $entry)
        exit $LASTEXITCODE
    }
}
Write-Host 'No Python with tkinter + gRPC found. Run SETUP_AND_LAUNCH.cmd or see GUI_README.md.'
exit 1
