"""
Continuous fault-bit watch for the Ola S1 - prints the instant a broadcast
fault register bit changes, for wiggle-testing a harness/connector (see
HANDOFF.md #7). No UDS, no mode change, no ADB required.

Reads the same broadcast fault registers as faults_live.py, but instead of a
one-shot summary it keeps reading and reports every SET/CLEAR transition live,
plus flags when a normally-continuous signal (e.g. MCU_Data_1, which carries
motor temp) goes quiet - useful for catching an intermittent connector that
drops a sensor without ever asserting the fault bit.

Usage:  python watch.py <host> <port> [secure]
        Ctrl+C to stop and write a transition log to captures\\watch_events.json
"""
import sys, time, json, os
from oladiag.transport import WifiCanTransport
from faults_live import load_dbc, extract, FAULT_IDS, FAULTY, BENIGN

# CAN ids whose *staleness* (no frames for a while) is itself diagnostic,
# even if no fault bit ever asserts. 0x313 carries motor temp + encoder-
# derived speed/RPM, so a dropout points straight at the shared sensor cable.
STALE_WATCH = {0x313: "MCU_Data_1 (motor temp / speed / RPM)"}
STALE_AFTER = 2.0  # seconds


def main():
    host = sys.argv[1] if len(sys.argv) > 1 else "192.168.4.1"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 50005
    secure = len(sys.argv) > 3 and sys.argv[3].lower() == "secure"
    dbc = load_dbc()

    fault_signals = {}  # cid -> (message_name, [signal, ...])
    for cid in FAULT_IDS:
        m = dbc.get(cid)
        if not m:
            continue
        sigs = [s for s in m["signals"] if s["bitlength"] == 1
                and FAULTY.search(s["name"]) and not BENIGN.search(s["name"])]
        if sigs:
            fault_signals[cid] = (m["name"], sigs)

    print(f"Watching {host}:{port} ({'mTLS' if secure else 'plaintext'}) "
          f"for fault-bit transitions. Ctrl+C to stop.")
    print("Wiggle/flex the harness or connector now and watch for SET/CLEAR lines.\n")

    t = WifiCanTransport(host, port, secure=secure)
    t.connect()
    t.start_reader(dump=True)

    state = {}       # (cid, signal_name) -> 0/1
    last_seen = {}    # cid -> monotonic time of last frame
    stale = set()     # cids currently flagged stale
    t0 = time.time()
    events = []

    def log(line):
        ts = time.time() - t0
        print(f"[{ts:7.2f}s] {line}")
        events.append({"t": round(ts, 2), "line": line})

    try:
        while True:
            drained = False
            now = time.time()
            for cid, q in list(t._queues.items()):
                data = None
                while not q.empty():
                    try:
                        data = q.get_nowait()
                        drained = True
                    except Exception:
                        break
                if data is None:
                    continue
                last_seen[cid] = now
                if cid in stale:
                    stale.discard(cid)
                    log(f"BACK  0x{cid:03X} {STALE_WATCH.get(cid, '')} resumed")
                if cid not in fault_signals:
                    continue
                mname, sigs = fault_signals[cid]
                for s in sigs:
                    key = (cid, s["name"])
                    v = 1 if extract(data, s) == 1 else 0
                    prev = state.get(key)
                    if prev is not None and prev != v:
                        word = "SET  " if v == 1 else "CLEAR"
                        log(f"{word} 0x{cid:03X} {mname} / {s['name']}")
                    state[key] = v

            for cid in STALE_WATCH:
                if cid in last_seen and cid not in stale \
                        and now - last_seen[cid] > STALE_AFTER:
                    stale.add(cid)
                    log(f"STALE 0x{cid:03X} {STALE_WATCH[cid]} - "
                        f"no frames for {STALE_AFTER:.0f}s")

            if not drained:
                time.sleep(0.02)
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        t.close()

    out_path = os.path.join("..", "captures", "watch_events.json")
    with open(out_path, "w") as f:
        json.dump({
            "events": events,
            "final_state": {f"0x{cid:03X}/{name}": v for (cid, name), v in state.items()},
        }, f, indent=2)
    print(f"\n{len(events)} transition(s) recorded. JSON written to captures\\watch_events.json")


if __name__ == "__main__":
    main()
