"""Minimal ext4 extractor: pull specific files out of a raw ext4 image by path.
Handles extent-mapped inodes (ext4) — enough for reading firmware blobs.
"""
import struct, sys, os

class Ext4:
    def __init__(self, path):
        self.f = open(path, 'rb')
        sb = self._read(1024, 1024)
        self.inodes_count = struct.unpack_from('<I', sb, 0x00)[0]
        log_bs = struct.unpack_from('<I', sb, 0x18)[0]
        self.bsize = 1024 << log_bs
        self.ipg = struct.unpack_from('<I', sb, 0x28)[0]      # inodes per group
        self.bpg = struct.unpack_from('<I', sb, 0x20)[0]      # blocks per group
        self.inode_size = struct.unpack_from('<H', sb, 0x58)[0]
        self.desc_size = struct.unpack_from('<H', sb, 0xFE)[0] or 32
        feat_incompat = struct.unpack_from('<I', sb, 0x60)[0]
        self.is64 = bool(feat_incompat & 0x80)
        # group descriptors start at block 1 (if bsize>1024) else block 2
        self.gd_block = 1 if self.bsize > 1024 else 2

    def _read(self, off, n):
        self.f.seek(off); return self.f.read(n)

    def _block(self, b):
        return self._read(b * self.bsize, self.bsize)

    def _inode_table(self, group):
        gd_off = self.gd_block * self.bsize + group * self.desc_size
        gd = self._read(gd_off, self.desc_size)
        lo = struct.unpack_from('<I', gd, 0x08)[0]
        hi = struct.unpack_from('<I', gd, 0x28)[0] if self.desc_size >= 64 and self.is64 else 0
        return (hi << 32) | lo

    def inode(self, ino):
        g = (ino - 1) // self.ipg
        idx = (ino - 1) % self.ipg
        it = self._inode_table(g)
        raw = self._read(it * self.bsize + idx * self.inode_size, self.inode_size)
        mode = struct.unpack_from('<H', raw, 0)[0]
        size = struct.unpack_from('<I', raw, 0x04)[0] | (struct.unpack_from('<I', raw, 0x6C)[0] << 32)
        i_block = raw[0x28:0x28 + 60]
        return {'mode': mode, 'size': size, 'i_block': i_block}

    def _extents(self, i_block):
        """Return list of (file_block, phys_block, count) from an extent tree node."""
        assert i_block[:2] == b'\x0a\xf3', 'not extents'
        entries = struct.unpack_from('<H', i_block, 2)[0]
        depth = struct.unpack_from('<H', i_block, 6)[0]
        out = []
        if depth == 0:
            for k in range(entries):
                e = i_block[12 + k*12: 24 + k*12]
                fb = struct.unpack_from('<I', e, 0)[0]
                cnt = struct.unpack_from('<H', e, 4)[0]
                hi = struct.unpack_from('<H', e, 6)[0]
                lo = struct.unpack_from('<I', e, 8)[0]
                out.append((fb, (hi << 32) | lo, cnt))
        else:
            for k in range(entries):
                e = i_block[12 + k*12: 24 + k*12]
                lo = struct.unpack_from('<I', e, 4)[0]
                hi = struct.unpack_from('<I', e, 8)[0]
                child = (hi << 32) | lo
                node = self._block(child)
                out += self._extents(node)  # header magic present at node start
        return out

    def read_file(self, inode):
        data = bytearray()
        for fb, pb, cnt in self._extents(inode['i_block']):
            # place at correct file offset (handle sparse)
            want = fb * self.bsize
            if len(data) < want:
                data += b'\x00' * (want - len(data))
            data += self._read(pb * self.bsize, cnt * self.bsize)
        return bytes(data[:inode['size']])

    def _dir_entries(self, inode):
        raw = self.read_file(inode)
        out = []
        off = 0
        while off < len(raw):
            ino, rec_len, name_len, ftype = struct.unpack_from('<IHBB', raw, off)
            if rec_len == 0: break
            name = raw[off+8:off+8+name_len]
            if ino: out.append((name.decode('latin1'), ino, ftype))
            off += rec_len
        return out

    def resolve(self, path):
        ino = 2  # root
        for part in [p for p in path.split('/') if p]:
            entries = dict((n, i) for n, i, t in self._dir_entries(self.inode(ino)))
            if part not in entries:
                raise FileNotFoundError(f'{part} in {path}')
            ino = entries[part]
        return self.inode(ino)


if __name__ == '__main__':
    img, outdir = sys.argv[1], sys.argv[2]
    files = sys.argv[3:]
    os.makedirs(outdir, exist_ok=True)
    fs = Ext4(img)
    for p in files:
        try:
            ino = fs.resolve(p)
            data = fs.read_file(ino)
            name = os.path.basename(p)
            open(os.path.join(outdir, name), 'wb').write(data)
            print(f'OK {p} -> {len(data)} bytes')
        except Exception as e:
            print(f'FAIL {p}: {e}')
