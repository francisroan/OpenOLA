"""GUI adapter. No ADB; all paths are relative to this workspace."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tool' / 'gui_vendor'))

import json
import queue
import time
import threading
from decimal import Decimal
from google.protobuf.empty_pb2 import Empty
from oladiag.transport import WifiCanTransport
from oladiag.uds import UdsClient, UdsError, TesterPresentKeepalive
from oladiag.isotp import IsoTpReassembler, FLOW_CONTROL, frame_type, FIRST
from oladiag.seedkey import Ecu, generate_key
from oladiag.wifican import wifican_pb2 as pb
from alldata import extract
from command_trace import message_evidence

ODX_PATH = ROOT / 'notes/apk_x/res/raw/odx.json'
ODX_AVAILABLE = ODX_PATH.is_file()
ODX = json.loads(ODX_PATH.read_text(encoding='utf-8-sig')) if ODX_AVAILABLE else {}


def _clean_actuator_name(raw):
    """'IOx0406_Front light low beam 12V supply control command' -> 'Front light low beam'."""
    name = raw.split('_', 1)[-1] if raw.startswith('IO') else raw
    for junk in (' 12V supply control command', ' supply control command',
                 ' supply command', ' control command', ' Control command',
                 ' 12V supply Control command', ' command', ' Command'):
        if name.endswith(junk):
            name = name[: -len(junk)]
    return name.strip()


# Categorise the VCU actuators (2F, ECUTest=1) for the GUI. Anything that moves a
# lock, throws a contactor, or touches HV / charging is flagged dangerous and
# needs an explicit typed confirmation before it can be pulsed.
_ACT_DANGER_KW = ('contactor', 'steering lock', 'seat lock', 'cpw', 'control pilot',
                  'charger', 'aux battery', 'alarm', 'brake supply', 'brake suppy',
                  'fault reset', 'power key', 'power boot', 'ble module reset', 'ble boot')


def _actuator_group(name):
    n = name.lower()
    if any(k in n for k in ('beam', 'indicator', 'light', 'drl', 'lamp', 'horn')):
        return 'Lights & signals'
    if any(k in n for k in ('contactor', 'cpw', 'control pilot', 'charger', 'aux battery',
                            'dc-dc', 'dcdc', '3.8v', '3v3', 'level shifter')):
        return 'Power & HV (danger)'
    if any(k in n for k in ('lock', 'alarm', 'seat occupant')):
        return 'Locks & security'
    if any(k in n for k in ('switch', 'sensor', 'stand', 'pad wear', 'brake sup', 'occupant', 'ssb')):
        return 'Switches & sensors'
    return 'System & module'


def _build_actuators():
    cat, groups, danger = {}, {}, set()
    seen = set()
    for c in ODX.get('VCU', []):
        rf = (c.get('RequestFormat') or '').replace(' ', '')
        if not (rf.upper().startswith('2F') and c.get('ECUTest') == 1):
            continue
        did = int(rf[2:6], 16)
        label = _clean_actuator_name(c.get('Command', ''))
        if not label or label in seen:
            continue
        seen.add(label)
        cat[label] = did
        grp = _actuator_group(label)
        groups.setdefault(grp, []).append(label)
        if grp == 'Power & HV (danger)' or any(k in label.lower() for k in _ACT_DANGER_KW):
            danger.add(label)
    return cat, groups, danger


ACTUATORS, ACTUATOR_GROUPS, ACTUATOR_DANGER = _build_actuators()
# Preferred display order for the groups (safe first, danger last).
ACTUATOR_GROUP_ORDER = ['Lights & signals', 'Switches & sensors', 'Locks & security',
                        'System & module', 'Power & HV (danger)']

# Only unambiguous, bounded settings are exposed for writes. B110 has conflicting
# write definitions (torque vs acceleration) in the source ODX and is excluded.
SETTINGS = {x['Description']: x for x in ODX.get('MCU', [])
            if x['RequestFormat'] in ('2E B1 0B', '2E B1 12')}


def encode_setting(definition, values, original):
    """Patch selected physical values into original bytes; preserve other fields."""
    length = int(definition['AttachedDatalength (Bytes)'])
    if len(original) != length:
        raise ValueError(f'Expected {length} current bytes, received {len(original)}')
    data = int.from_bytes(original, 'little')
    parameters = {p['Parameter']: p for p in definition['Parameters']}
    if not values or set(values) - parameters.keys():
        raise ValueError('Select at least one valid parameter')
    for name, value in values.items():
        p = parameters[name]
        value = Decimal(str(value))
        if not value.is_finite() or not Decimal(str(p['Physical Minimum'])) <= value <= Decimal(str(p['Physical Maximum'])):
            raise ValueError(f'{name}: value outside the documented range')
        scale, offset = Decimal(str(p['Resolution'])), Decimal(str(p['Offset']))
        raw = (value - offset) / scale
        bits, start = int(p['Size (Bits)']), int(p['StartBit'])
        if raw != raw.to_integral_value() or not 0 <= raw < 2 ** bits:
            raise ValueError(f'{name}: use increments of {scale}')
        mask = ((1 << bits) - 1) << start
        data = (data & ~mask) | (int(raw) << start)
    return data.to_bytes(length, 'little')


def decode_setting(definition, data):
    if len(data) != int(definition['AttachedDatalength (Bytes)']):
        raise ValueError('Response length does not match the extracted definition')
    raw = int.from_bytes(data, 'little')
    return {p['Parameter']: float(Decimal((raw >> int(p['StartBit'])) & ((1 << int(p['Size (Bits)'])) - 1))
                                * Decimal(str(p['Resolution'])) + Decimal(str(p['Offset'])))
            for p in definition['Parameters']}


class GuiTransport(WifiCanTransport):
    """Bounded queues and RPC deadlines; does not change the existing CLI layer."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.latest = {}
        self.sample_lock = threading.Lock()
        self.observer = None
        self.trace = None

    def start_reader(self, dump=False):
        from oladiag.canframe import parse_frame
        method = 'CanDumpStream' if dump else 'ReadCanStream'
        def run():
            try:
                if self.trace:
                    self.trace.event('stream_start', method=method, **message_evidence(Empty()))
                self._stream = getattr(self.stub, method)(Empty())
                self._started.set()
                for packet in self._stream:
                    if self._stop.is_set():
                        break
                    if self.trace:
                        self.trace.event('can_rx', stream=method, **message_evidence(packet))
                    try:
                        cid, data = parse_frame(packet.can_frame)
                    except Exception as exc:
                        if self.trace:
                            self.trace.event('can_parse_error', error=str(exc))
                        continue
                    self._dispatch(cid, data)
            except Exception as exc:
                if not self._stop.is_set():
                    self._err = exc
                    if self.trace:
                        self.trace.event('stream_error', stream=method, error=str(exc))
            finally:
                self._started.set()
        self._reader = threading.Thread(target=run, daemon=True)
        self._reader.start()
        self._started.wait(5)
        if self._err:
            raise RuntimeError(f'{method} failed: {self._err}')

    def _dispatch(self, can_id, data):
        stamp = time.time()
        with self.sample_lock:
            self.latest[can_id] = (stamp, data)
            observer = self.observer
        if observer:
            observer(stamp, can_id, data)
        # Dashboard snapshots do not drain diagnostic response queues anymore.
        with self._qlock:
            # HMI tests explicitly register status/ack queues as well as UDS.
            if can_id not in {ecu.resp_id for ecu in Ecu} and can_id not in self._queues:
                return
            q = self._queues.setdefault(can_id, queue.Queue(maxsize=256))
        try:
            q.put_nowait(data)
        except queue.Full:
            try:
                q.get_nowait()
            except queue.Empty:
                pass  # The dashboard consumer drained it between checks.
            try:
                q.put_nowait(data)
            except queue.Full:
                pass

    def write_frame(self, can_id, data8):
        from oladiag.canframe import build_frame
        packet = pb.CANPacket(can_frame=build_frame(can_id, data8))
        started = time.monotonic()
        if self.trace:
            self.trace.event('rpc_request', method='WriteCanFrame', can_id=f'{can_id:03X}', **message_evidence(packet))
        try:
            r = self.stub.WriteCanFrame(packet, timeout=3)
        except Exception as exc:
            if self.trace:
                self.trace.event('rpc_error', method='WriteCanFrame', elapsed=time.monotonic()-started, error=str(exc))
            raise UdsError(f'WriteCanFrame RPC failed for CAN {can_id:03X}; no ECU rejection was established: {exc}') from exc
        if self.trace:
            self.trace.event('rpc_response', method='WriteCanFrame', elapsed=time.monotonic()-started, **message_evidence(r))
        if r.status != pb.RESP_SUCCESS:
            raise UdsError(f'CAN write rejected: {r.status_msg} ({r.status})')
        return r

    def stop_stream(self):
        """Cancel the active CAN read/dump stream without tearing down the
        channel, so we can switch stream modes (dump firehose <-> filtered
        diagnostic) on the same connection."""
        if self._reader is None:
            return
        self._stop.set()
        if self._stream is not None:
            try:
                self._stream.cancel()
            except Exception:
                pass
        self._reader.join(timeout=2)
        self._reader = None
        self._stream = None
        self._err = None
        self._stop.clear()
        self._started.clear()

    def close(self):
        self._stop.set()
        if self._stream is not None:
            self._stream.cancel()
        try:
            if self.stub:
                if self.trace:
                    self.trace.event('rpc_request', method='Deinit', **message_evidence(Empty()))
                response = self.stub.Deinit(Empty(), timeout=2)
                if self.trace:
                    self.trace.event('rpc_response', method='Deinit', **message_evidence(response))
        except Exception as exc:
            if self.trace:
                self.trace.event('rpc_error', method='Deinit', error=str(exc))
        finally:
            if self.channel:
                self.channel.close()
            if self._reader:
                self._reader.join(timeout=2)


class UdsNegativeResponse(UdsError):
    def __init__(self, ecu, service, code):
        self.code = code
        self.service = service
        names = {0x33: 'security access denied; inspect the explicit session/access trace before retrying',
                 0x35: 'invalid security key; stop retrying', 0x36: 'security attempt limit reached; stop retrying',
                 0x37: 'security delay required; wait before another attempt',
                 0x31: 'request out of range / unsupported identifier', 0x22: 'conditions not correct'}
        super().__init__(f'{ecu.name}: NRC 0x{code:02X} for service 0x{service:02X}: {names.get(code, "request rejected")}')


class GuiUds(UdsClient):
    """Bounded response-pending and strict ISO-TP flow control for setting writes."""
    def _send_payload(self, ecu, payload, q):
        if len(payload) <= 7:
            return super()._send_payload(ecu, payload, q)
        if len(payload) > 4095:
            raise UdsError('UDS payload too long')
        self.t.write_frame(ecu.req_id, bytes([0x10 | (len(payload) >> 8), len(payload) & 255]) + payload[:6])
        rest, sn = payload[6:], 1
        deadline = time.monotonic() + self.timeout
        while rest:
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise UdsError('ISO-TP flow-control timeout; no further bytes sent')
                try:
                    fc = q.get(timeout=remaining)
                except queue.Empty:
                    raise UdsError('ISO-TP flow-control timeout; no further bytes sent')
                if len(fc) < 3 or frame_type(fc) != 3:
                    continue
                if fc[0] & 15 == 1:
                    continue
                if fc[0] & 15 != 0:
                    raise UdsError('ECU refused ISO-TP transfer')
                bs, stmin = fc[1], fc[2]
                if 0x80 <= stmin <= 0xF0 or stmin > 0xF9:
                    raise UdsError('Invalid ISO-TP separation time')
                break
            for _ in range(bs or 4095):
                if not rest:
                    break
                self._stmin_delay(stmin)
                chunk, rest = rest[:7], rest[7:]
                self.t.write_frame(ecu.req_id, bytes([0x20 | sn]) + chunk.ljust(7, b'\0'))
                sn = (sn + 1) & 15

    def _request(self, ecu, payload):
        trace = getattr(self.t, 'trace', None)
        started = time.monotonic()
        if trace:
            trace.event('uds_request', ecu=ecu.name, request_can_id=f'{ecu.req_id:03X}', payload_hex=payload.hex())
        try:
            response = self._exchange(ecu, payload)
            if trace:
                trace.event('uds_response', ecu=ecu.name, payload_hex=response.hex(), elapsed=time.monotonic()-started)
            return response
        except Exception as exc:
            if trace:
                trace.event('uds_error', ecu=ecu.name, request_hex=payload.hex(), error=str(exc), elapsed=time.monotonic()-started)
            raise

    def _exchange(self, ecu, payload):
        q = self.t.queue_for(ecu.resp_id)
        while not q.empty():
            q.get_nowait()
        self._send_payload(ecu, payload, q)
        deadline = time.monotonic() + self.timeout
        reasm = IsoTpReassembler()
        while time.monotonic() < deadline:
            try:
                frame = q.get(timeout=max(.001, deadline - time.monotonic()))
            except queue.Empty:
                break
            out = reasm.feed(frame)
            if frame_type(frame) == FIRST:
                self.t.write_frame(ecu.req_id, FLOW_CONTROL)
            if out is not None:
                trace = getattr(self.t, 'trace', None)
                if trace:
                    trace.event('uds_received_payload', ecu=ecu.name, payload_hex=out.hex())
                if out[:3] == bytes([0x7F, payload[0], 0x78]):
                    reasm = IsoTpReassembler()
                    continue
                if len(out) >= 3 and out[0] == 0x7F:
                    raise UdsNegativeResponse(ecu, out[1], out[2])
                self._check_positive(out, payload[0], ecu)
                # DID/session echo prevents accepting an unrelated positive reply.
                echo = 3 if payload[0] in (0x22, 0x2E, 0x2F) else 2
                if payload[0] in (0x22, 0x2E, 0x2F, 0x10, 0x27) and out[1:echo] != payload[1:echo]:
                    raise UdsError('Response identifier does not match the request')
                return out
        raise UdsError(f'{ecu.name}: response timed out; result may be unknown')

    def security_access(self, ecu):
        seed_reply = self._request(ecu, b'\x27\x01')
        seed = seed_reply[2:]
        if len(seed) not in (4, 8):
            raise UdsError('Unexpected seed length; no key sent')
        if not any(seed):
            return 'ECU already unlocked'
        key = generate_key(seed, ecu, '01')
        self._request(ecu, b'\x27\x02' + key)
        return 'Diagnostic access accepted'


class Scooter:
    def __init__(self):
        self.t = None
        dbc = json.loads((ROOT / 'tool/oladiag/config/da_can_dbc.json').read_text(encoding='utf-8-sig'))
        self.dbc = {int(m['id']): m for m in dbc['messages']}
        self.streaming = False
        self.stream_mode = None       # None | 'dump' | 'diag'
        self.security_failed = set()
        self.unlocked = set()         # ECUs unlocked on the current connection
        self.keepalive = None         # persistent 3E 80 tester-present
        self.trace = None
        self.bench_confirmed = False
        self.observed = []
        self.reload_mappings()

    def reload_mappings(self):
        self.observed = []
        path = ROOT / 'captures/gui/learning/observed_mappings.jsonl'
        if path.exists():
            for line in path.read_text(encoding='utf-8').splitlines():
                try:
                    item = json.loads(line)
                    c = item['candidate']
                    if item.get('tx_enabled') is False and c['kind'] in ('bit', 'signal') and isinstance(item['label'], str):
                        int(c['can_id'], 16)
                        self.observed.append(item)
                except (ValueError, KeyError, TypeError):
                    continue

    def connect(self, host, port, secure):
        if not host.strip() or any(c.isspace() for c in host) or not 1 <= int(port) <= 65535:
            raise ValueError('Enter a valid host and port (1–65535)')
        self.disconnect()
        self.t = GuiTransport(host.strip(), int(port), secure=secure)
        self.t.trace = self.trace
        try:
            self.t.connect()
            return self.info()
        except Exception:
            self.disconnect()
            raise

    def rpc(self, method, request=None):
        if not self.t or not self.t.stub:
            raise RuntimeError('Connect to the scooter first')
        request = request if request is not None else Empty()
        started = time.monotonic()
        if self.trace:
            self.trace.event('rpc_request', method=method, **message_evidence(request))
        try:
            response = getattr(self.t.stub, method)(request, timeout=5)
        except Exception as exc:
            if self.trace:
                self.trace.event('rpc_error', method=method, elapsed=time.monotonic()-started, error=str(exc))
            raise RuntimeError(f'{method} RPC failed: {exc}') from exc
        if self.trace:
            self.trace.event('rpc_response', method=method, elapsed=time.monotonic()-started, **message_evidence(response))
        return response

    def sw_flash(self, data, name, target, progress=None):
        """OTA firmware flash: clear cache -> metadata (SHA-256) -> stream
        chunks -> trigger. EXPERIMENTAL and brick-capable; the checksum format
        the scooter expects is UNVERIFIED. Returns the final state name."""
        import hashlib
        from oladiag.wifican import wifican_pb2 as pb
        if not self.t or not self.t.stub:
            raise RuntimeError('Connect to the scooter first')
        stub = self.t.stub
        csum = hashlib.sha256(data).hexdigest()
        stub.SwUpdateFileClearCache(Empty(), timeout=20)
        r = stub.SwUpdateFileTransferMeta(
            pb.SwUpdateFileMetadataReq(name=name, size=len(data), csum=csum), timeout=25)
        if r.status != pb.RESP_SUCCESS:
            raise RuntimeError(r.status_msg or 'Metadata rejected')

        def chunks():
            sent = 0
            ch = 64 * 1024
            while sent < len(data):
                end = min(sent + ch, len(data))
                yield pb.SwUpdateFileChunk(chunk=data[sent:end])
                sent = end
                if progress:
                    progress(sent, len(data))
        stub.SwUpdateFileTransfer(chunks(), timeout=600)
        trig = pb.SwUpdateTrigger.Value('SW_UPDATE_TRIGGER_' + target)
        r = stub.SwUpdateTriggerUpgrade(pb.SwUpdateTriggerCmd(trigger=trig), timeout=25)
        if r.status != pb.RESP_SUCCESS:
            raise RuntimeError(r.status_msg or 'Trigger rejected')
        s = stub.SwUpdateCheckStatus(Empty(), timeout=10)
        return pb.SwUpdateState.Name(s.status).replace('SW_UPDATE_STATE_', '')

    def execute_adb(self, cmd):
        """Root shell on the head unit (ExecuteADBCommand). Built as a raw unary
        call with a hand-written serializer for the single-field Command message
        ({string cmd_msg = 1}), so no proto regen is needed. Returns status_msg."""
        from oladiag.wifican import wifican_pb2 as pb
        if not self.t or not getattr(self.t, 'channel', None):
            raise RuntimeError('Connect to the scooter first')

        def _varint(n):
            out = bytearray()
            while True:
                b = n & 0x7F
                n >>= 7
                out.append(b | (0x80 if n else 0))
                if not n:
                    return bytes(out)

        def ser_command(s):
            body = s.encode('utf-8')
            return b'\x0a' + _varint(len(body)) + body  # field 1, wire type 2

        call = self.t.channel.unary_unary(
            '/wifican.WifiCanRpc/ExecuteADBCommand',
            request_serializer=ser_command,
            response_deserializer=pb.Response.FromString,
        )
        return call(cmd, timeout=30).status_msg

    def require_bench(self):
        if not self.bench_confirmed:
            raise RuntimeError('Active diagnostics are blocked until you confirm the scooter is parked and the charger is physically disconnected. A prior identifier read interrupted charging.')

    def info(self):
        mode = self.rpc('GetVehicleOperationMode')
        sw = self.rpc('GetSwVersion')
        if sw.status != pb.RESP_SUCCESS:
            raise RuntimeError(f'Firmware read failed: {sw.status_msg}')
        return {'mode': pb.VehicleOperationState.Name(mode.cur_mode).replace('VEHICLE_OP_STATE_', ''),
                'firmware': sw.status_msg.replace('\n', ' / ')}

    def mode(self, target):
        self.require_bench()
        if target not in ('CUST', 'SERVICE'):
            raise ValueError('Unsupported mode')
        # A mode change resets the ECUs' session/security; drop cached unlock.
        self.stop_keepalive()
        self.unlocked.clear()
        result = self.rpc('SetVehicleOperationMode', pb.VehicleOperationMode(cur_mode=getattr(pb, 'VEHICLE_OP_STATE_' + target)))
        if result.status != pb.RESP_SUCCESS:
            raise RuntimeError(result.status_msg or 'Mode change rejected')
        actual = self.info()
        if actual['mode'] != target:
            raise RuntimeError(f'Mode readback mismatch: {actual}')
        return actual

    def _ensure_stream(self, mode):
        """Ensure the reader is running in 'dump' (dashboard firehose) or 'diag'
        (filtered ReadCanStream on just the ECU IDs). Reused if already in that
        mode, so back-to-back UDS ops don't restart the stream."""
        if not self.t:
            raise RuntimeError('Connect first')
        if self.stream_mode == mode and self.t._reader and self.t._reader.is_alive():
            return
        self.t.stop_stream()
        if mode == 'diag':
            # UDS request/response cannot share the channel with the high-rate
            # CanDumpStream firehose: the flood starves WriteCanFrame -> the RPC
            # times out (DEADLINE_EXCEEDED). A filtered ReadCanStream is low-rate
            # and lets writes through, matching the working CLI toolkit.
            self.t.init([e.req_id for e in Ecu] + [e.resp_id for e in Ecu])
            self.t.start_reader(dump=False)
        else:
            # Leaving diagnostics for the dashboard firehose ends the session.
            self.stop_keepalive()
            self.unlocked.clear()
            self.t.start_reader(dump=True)
        self.stream_mode = mode
        self.streaming = (mode == 'dump')

    def start_live(self):
        self._ensure_stream('dump')

    def diag_stream(self):
        self._ensure_stream('diag')

    def start_keepalive(self, u, ecu):
        """Persistent 3E 80 so the diagnostic session / security access survives
        between button presses (the VCU drops the session after a few seconds
        idle, and re-requesting a seed while already unlocked just times out)."""
        self.stop_keepalive()
        self.keepalive = TesterPresentKeepalive(u, ecu, interval=2.0).start()

    def stop_keepalive(self):
        if self.keepalive:
            self.keepalive.stop()
            self.keepalive = None

    def samples(self):
        if not self.t or not self.streaming:
            return []
        if self.t._err:
            raise RuntimeError(f'CAN stream stopped: {self.t._err}')
        if self.t._reader and not self.t._reader.is_alive():
            raise RuntimeError('CAN stream ended. Disconnect and reconnect to restart it.')
        rows = []
        with self.t.sample_lock:
            samples = list(self.t.latest.items())
        for cid, (stamp, data) in samples:
            if cid in {ecu.resp_id for ecu in Ecu} or cid in {ecu.req_id for ecu in Ecu}:
                continue
            m = self.dbc.get(cid)
            if not m:
                rows.append((f'{cid:03X}', 'Unknown frame', 'Raw', data.hex(), '', stamp))
                continue
            if len(data) < int(m.get('dlc', 8)):
                continue
            for s in m['signals']:
                rows.append((f'{cid:03X}', m['name'], s['name'], extract(data, s), s.get('units', ''), stamp))
        raw_samples = dict(samples)
        for item in self.observed:
            c = item['candidate']
            cid = int(c['can_id'], 16)
            if cid not in raw_samples:
                continue
            stamp, data = raw_samples[cid]
            try:
                if c['kind'] == 'bit':
                    bit = int(c['selector'])
                    if not 0 <= bit < len(data) * 8:
                        continue
                    value = (data[bit // 8] >> (bit % 8)) & 1
                else:
                    signal = next(s for s in self.dbc[cid]['signals'] if s['name'] == c['selector'])
                    value = extract(data, signal)
                rows.append((f'{cid:03X}', 'User-observed association', f'Learned: {item["label"]} ({c["name"]})', value, '', stamp))
            except (ValueError, TypeError, KeyError, StopIteration, IndexError):
                continue
        return rows

    def capture_stage(self, learner, seconds=8, settle=3):
        self.start_live()
        learner.data['context']['capture_seconds'] = seconds
        learner.data['context']['settle_seconds'] = settle
        if self.trace:
            self.trace.event('learning_settle', seconds=settle, phase=len(learner.data['phases']))
        time.sleep(settle)
        learner.begin()
        if self.trace:
            self.trace.event('learning_record_start', seconds=seconds, phase=len(learner.data['phases']))
        with self.t.sample_lock:
            self.t.observer = learner.record
        error = None
        try:
            time.sleep(seconds)
            if self.t._err or not self.t._reader.is_alive():
                raise RuntimeError('CAN stream ended during capture')
        except Exception as exc:
            error = str(exc)
            raise
        finally:
            with self.t.sample_lock:
                self.t.observer = None
            summary = learner.finish(error)
            if self.trace:
                self.trace.event('learning_record_end', summary=summary, error=error)
        return summary

    def uds(self, ecu, require_service=True):
        self.require_bench()
        if require_service and self.rpc('GetVehicleOperationMode').cur_mode != pb.VEHICLE_OP_STATE_SERVICE:
            raise RuntimeError('Select Service mode in Scooter mode before component commands')
        # Use the filtered diagnostic stream, NOT the dump firehose, so
        # WriteCanFrame is not starved (DEADLINE_EXCEEDED).
        self.diag_stream()
        return GuiUds(self.t, timeout=5)

    def ensure_unlocked(self, ecu):
        """Enter the extended session and unlock the ECU ONCE per connection,
        then keep both alive with a persistent tester-present so later component
        commands can skip the seed/key exchange. Re-running 27 01 while already
        unlocked makes the VCU stop answering (observed: 5 s timeout that then
        poisoned the connection)."""
        u = self.uds(ecu)
        if ecu in self.unlocked and self.keepalive and self.keepalive.alive():
            return u
        u.enter_extended_session(ecu)
        if ecu in self.security_failed:
            raise RuntimeError(f'{ecu.name}: a security key was rejected on this connection. Disconnect and reconnect (power-cycle the scooter if the ECU is in a lockout delay) before retrying.')
        audit('diagnostic-access-attempt', {'ecu': ecu.name, 'level': '01'})
        try:
            u.security_access(ecu)
        except UdsNegativeResponse as exc:
            # A real key/attempt rejection blocks further keys; a transport
            # timeout does NOT (it is not an ECU verdict) so it stays retryable.
            if exc.code in (0x35, 0x36, 0x37):
                self.security_failed.add(ecu)
            raise
        audit('diagnostic-access-accepted', {'ecu': ecu.name})
        self.unlocked.add(ecu)
        self.start_keepalive(u, ecu)
        return u

    def prepare(self, ecu, unlock=False):
        self.require_bench()
        if unlock:
            return self.ensure_unlocked(ecu)
        u = self.uds(ecu)
        u.enter_extended_session(ecu)
        return u

    def read(self, ecu, did, unlock=False):
        self.require_bench()
        if unlock:
            raise ValueError('Identifier reads no longer enter an extended session or unlock automatically. Use a separate, explicit session/access step if needed.')
        if len(did) != 2:
            raise ValueError('Identifier must be exactly two bytes')
        matches = [name for name, definitions in ODX.items() if any(bytes.fromhex(d['RequestFormat'])[:3] == b'\x22' + did for d in definitions)]
        if matches and ecu.name not in matches:
            raise ValueError(f'DID {did.hex().upper()} is listed for {", ".join(matches)}, not {ecu.name}; no request sent')
        u = self.uds(ecu, require_service=False)
        return u._request(ecu, b'\x22' + did)[3:]

    def read_faults(self, ecu):
        u = self.uds(ecu, require_service=False)
        return u.read_dtcs(ecu, unlock=False)

    def open_diagnostic_session(self, ecu, unlock=False):
        self.prepare(ecu, unlock)
        return f'{ecu.name}: extended session entered' + ('; security access accepted' if unlock else '; security access not requested')

    def lock_unlock_sequence(self):
        """Start the ODX BF07 routine; retry once after re-unlock on failure."""
        self.require_bench()
        definition = next((d for d in ODX.get('VCU', [])
                           if d.get('Command') == 'ROxBF07_LockUnlockSequenceOverCAN'), None)
        if definition is None:
            raise RuntimeError('The public package does not include the ODX routine definition; no request sent')
        request = bytes.fromhex(definition['RequestFormat'])
        if request != b'\x31\x01\xbf\x07' or definition['RequestAttachedData'] != 0:
            raise ValueError('Lock/unlock routine definition changed; no request sent')
        u = self.ensure_unlocked(Ecu.VCU)
        try:
            response = u._request(Ecu.VCU, request)
        except UdsError as exc:
            # Retry once only on transport/timeout ambiguity — not on a definitive reply.
            if 'timeout' not in str(exc).lower() and 'unknown' not in str(exc).lower():
                raise
            self.unlocked.discard(Ecu.VCU)
            self.stop_keepalive()
            u = self.ensure_unlocked(Ecu.VCU)
            response = u._request(Ecu.VCU, request)
        if len(response) != 5 or response[:4] != b'\x71\x01\xbf\x07':
            raise UdsError('Unexpected lock/unlock routine reply; final state unknown. Do not repeat automatically.')
        return (f'BF07 acknowledged; routine status 0x{response[4]:02X}. '
                'Final lock state unverified — check the scooter physically. '
                'For consumer lock/unlock use the Bluetooth tab; trunk over Wi-Fi is Seat Lock 0402.')

    def wifi_lock(self):
        """Experimental: Steering Lock 0400 ON + BF07. Report replies; effect unverified."""
        self.require_bench()
        u = self.ensure_unlocked(Ecu.VCU)
        parts = []
        try:
            u.io_control(Ecu.VCU, 0x0400, 0x03, b'\x01')
            parts.append('0400 ON ok')
        except Exception as exc:
            parts.append(f'0400 ON: {exc}')
        try:
            parts.append(self.lock_unlock_sequence())
        except Exception as exc:
            parts.append(f'BF07: {exc}')
        return ' · '.join(parts)

    def wifi_unlock(self):
        """Experimental: Steering Lock 0400 OFF + BF07."""
        self.require_bench()
        u = self.ensure_unlocked(Ecu.VCU)
        parts = []
        try:
            u.io_control(Ecu.VCU, 0x0400, 0x03, b'\x00')
            try:
                u.io_control(Ecu.VCU, 0x0400, 0x00)
            except Exception:
                pass
            parts.append('0400 OFF ok')
        except Exception as exc:
            parts.append(f'0400 OFF: {exc}')
        try:
            parts.append(self.lock_unlock_sequence())
        except Exception as exc:
            parts.append(f'BF07: {exc}')
        return ' · '.join(parts)

    def wifi_trunk_pulse(self, ms=1500):
        """Trunk over Wi-Fi = Seat Lock DID 0402 pulse."""
        self.require_bench()
        u = self.ensure_unlocked(Ecu.VCU)
        u.io_control(Ecu.VCU, 0x0402, 0x03, b'\x01')
        time.sleep(max(0.2, ms / 1000.0))
        try:
            u.io_control(Ecu.VCU, 0x0402, 0x03, b'\x00')
        finally:
            try:
                u.io_control(Ecu.VCU, 0x0402, 0x00)
            except Exception:
                pass
        return f'Seat Lock 0402 pulsed ~{ms} ms (trunk over Wi-Fi)'

    def pulse(self, name):
        """Run one VCU actuator test: 2F <DID> 03 01 (ON) -> hold -> 03 00 (OFF)
        -> 2F <DID> 00 (return control). The VCU is unlocked once per connection
        (extended session + level-01 seed/key) and held open by a persistent
        tester-present, so repeated tests reuse the same session instead of
        re-running the seed/key exchange (which the VCU refuses once unlocked)."""
        self.require_bench()
        did = ACTUATORS[name]
        u = self.ensure_unlocked(Ecu.VCU)
        hold = 0.75 if name == 'Horn' else 2
        activation_possible = True
        try:
            u.io_control(Ecu.VCU, did, 0x03, b'\x01')
            time.sleep(hold)
        except UdsNegativeResponse as exc:
            activation_possible = False  # Explicit ON refusal is not an ambiguous timeout.
            if exc.code == 0x33:
                # Session/security lapsed unexpectedly: drop the cached unlock so
                # the next test re-establishes it cleanly.
                self.unlocked.discard(Ecu.VCU)
                self.stop_keepalive()
            raise
        finally:
            # Always attempt OFF, even after a timeout: activation may have arrived.
            if activation_possible:
                try:
                    u.io_control(Ecu.VCU, did, 0x03, b'\x00')
                except Exception as exc:
                    raise RuntimeError(f'{name}: OFF was not acknowledged; check the scooter physically. {exc}')
                try:
                    u.io_control(Ecu.VCU, did, 0x00)  # returnControlToECU
                except Exception:
                    pass
        return f'{name}: ON and OFF acknowledged'

    def write_setting(self, name, expected, proposed, unlock=False):
        definition = SETTINGS[name]
        did = bytes.fromhex(definition['RequestFormat'])[1:]
        current = self.read(Ecu.MCU, did)
        if current != expected:
            raise RuntimeError('Value changed since preview. Read again before writing.')
        # Revalidate payload on execution, not only in the UI.
        encode_setting(definition, decode_setting(definition, proposed), current)
        audit('write-intent', {'component': 'MCU', 'did': did.hex(), 'before': current.hex(), 'after': proposed.hex()})
        u = self.prepare(Ecu.MCU, unlock)
        u._request(Ecu.MCU, b'\x2e' + did + proposed)
        actual = self.read(Ecu.MCU, did)
        if actual != proposed:
            raise RuntimeError(f'Write acknowledged but readback differs ({actual.hex()}); no automatic retry')
        return 'Write acknowledged and immediate readback matches. Persistence across reboot is not verified.'

    def read_motor_angle(self):
        """Read MCU DID B113 (Initial angle of Synchronous motor), °, scale 0.1."""
        data = self.read(Ecu.MCU, bytes.fromhex('B113'), unlock=False)
        if len(data) < 2:
            raise RuntimeError(f'B113 short response: {data.hex()}')
        raw = int.from_bytes(data[:2], 'little')
        angle = raw * 0.1
        return {'raw': raw, 'degrees': round(angle, 1), 'hex': data.hex()}

    # Boost performance profile — three MCU DIDs from VehicleStateManager AppConstants:
    #   BOOST_TORQUE_SPEED_DID=45365 (0xB135,16B), BOOST_THROTTLE_MAP_DID=45372 (0xB13C,20B),
    #   BOOST_REGEN_DID=45373 (0xB13D,4B). Written by Ola via 2E through the same DID pipeline.
    BOOST_DIDS = [('BOOST_TORQUE_SPEED', 'B135', 16),
                  ('BOOST_THROTTLE_MAP', 'B13C', 20),
                  ('BOOST_REGEN', 'B13D', 4)]

    def read_boost_dids(self):
        """Read the three Boost MCU DIDs (0x22). Read-only; safe. Returns a list of dicts."""
        out = []
        for name, did_hex, exp_len in self.BOOST_DIDS:
            row = {'name': name, 'did': did_hex, 'expected_len': exp_len}
            try:
                data = self.read(Ecu.MCU, bytes.fromhex(did_hex), unlock=False)
                row['hex'] = data.hex().upper()
                row['len'] = len(data)
            except Exception as exc:
                row['error'] = str(exc)
            out.append(row)
        return out

    def write_boost_did(self, did_hex, payload_hex, unlock=True):
        """Write one Boost MCU DID (0x2E). REAL change to the MCU performance map —
        bench-only, caller must gate. `payload_hex` must be the full DID data (get it by
        reading the DID on an entitled bike first). Verifies readback; no retry."""
        self.require_bench()
        did_hex = did_hex.upper()
        known = {d: n for n, d, _ in self.BOOST_DIDS}
        if did_hex not in known:
            raise ValueError(f'Not a Boost DID: {did_hex}')
        did = bytes.fromhex(did_hex)
        payload = bytes.fromhex(payload_hex)
        if not payload:
            raise ValueError('Empty payload; provide the full DID data as hex')
        before = self.read(Ecu.MCU, did, unlock=False)
        audit('write-intent', {'component': 'MCU', 'did': did_hex,
                               'before': before.hex(), 'after': payload.hex()})
        u = self.ensure_unlocked(Ecu.MCU) if unlock else self.prepare(Ecu.MCU, False)
        u._request(Ecu.MCU, b'\x2e' + did + payload)
        after = self.read(Ecu.MCU, did, unlock=False)
        return {'did': did_hex, 'before': before.hex().upper(), 'wrote': payload.hex().upper(),
                'readback': after.hex().upper(), 'match': after == payload,
                'message': ('Write accepted; readback matches. Reboot persistence not verified.'
                            if after == payload else
                            'Write acknowledged but readback differs — MCU may clamp/reject. No retry.')}

    # ---- 0x660 feature-status spoof (reveal a dues-suppressed feature's UI) -------
    # 0x660 (VEHICLE_CONFIG_DATA_6) is the BCM->HU feature/entitlement broadcast that
    # decides which features the HMI shows. Bit map firmware-traced from
    # VehicleInfoParser.parseFeatureStatus (see status_monitor.FEATURE_TP_0660). The
    # HMI reveals a feature's built-in UI (e.g. Energy Insights uses libEnergyGraph.so)
    # when its field is non-zero. Energy Insights / Hyper / Fast are NORMALLY set by the
    # cloud (CCM TechPackDetailsData) and get zeroed while the owner has unpaid dues.
    # We can't set the cloud/BCM value from CAN; we can only *inject* 0x660 so the HU's
    # parser sees the feature available. This is a NON-PERSISTENT test: the real BCM keeps
    # broadcasting the true value, so we re-inject to hold it, and it reverts on reboot or
    # when we stop. For Hyper charge this only reveals UI — actual hyper charging is cloud
    # payment-gated (ProfileManagerService.getHyperChargePaymentStatus) and stays blocked.
    FEATURE_0660 = {                         # name -> (byte, low_bit, width)
        'Energy insights': (2, 2, 2),        # (data[2] >> 2) & 3
        'Hyper charger':   (2, 0, 2),        # data[2] & 3   (UI only; charging still cloud-gated)
        'Fast charger':    (1, 6, 2),        # (data[1] >> 6) & 3
    }

    def enable_feature_0660(self, name, base8, value=1, seconds=20, hz=5):
        """Reveal a 0x660-gated feature's UI by injecting the frame with its field set.

        `base8` = the latest real 0x660 bytes (the GUI has them from the live snapshot);
        every other feature bit is preserved from it, only `name`'s field is forced to
        `value`. Re-injects at `hz` for `seconds` in a background thread so it out-paces
        the BCM's own broadcast. Non-persistent by design; call stop_feature_0660() early
        to cancel. Bench-gated. Returns a status string."""
        self.require_bench()
        if name not in self.FEATURE_0660:
            raise ValueError(f'Unknown 0x660 feature: {name}')
        if not self.t or not getattr(self.t, 'stub', None):
            raise RuntimeError('Connect first')
        bi, lo, width = self.FEATURE_0660[name]
        mask = ((1 << width) - 1) << lo
        base = bytearray((bytes(base8 or b'') + bytes(8))[:8])
        prev = (base[bi] >> lo) & ((1 << width) - 1)
        base[bi] = (base[bi] & ~mask) | ((value << lo) & mask)
        frame = bytes(base)
        self.stop_feature_0660()
        stop = threading.Event()
        self._feat_spoof_stop = stop
        audit('feature-0660-spoof', {'feature': name, 'byte': bi, 'low_bit': lo,
                                     'was': prev, 'now': value, 'frame': frame.hex(),
                                     'seconds': seconds, 'hz': hz})

        def _hold():
            deadline = time.monotonic() + max(1, seconds)
            period = 1.0 / max(1, hz)
            while not stop.is_set() and time.monotonic() < deadline:
                try:
                    self.t.write_frame(0x660, frame)
                except Exception:
                    break
                stop.wait(period)

        th = threading.Thread(target=_hold, daemon=True)
        self._feat_spoof_thread = th
        th.start()
        return (f'Injecting 0x660 with "{name}" = {value} (was {prev}) at {hz} Hz for {seconds}s. '
                f'Frame {frame.hex().upper()}. Watch the head unit — if the built-in UI appears, '
                f'the feature was only dues-suppressed. NON-PERSISTENT: reverts when this stops, on '
                f'reboot, or on the next real BCM broadcast if it out-paces us. Hyper charge shows UI '
                f'only; charging stays cloud-payment gated.')

    def stop_feature_0660(self):
        """Cancel any in-progress 0x660 spoof-hold thread."""
        stop = getattr(self, '_feat_spoof_stop', None)
        if stop is not None:
            stop.set()
        th = getattr(self, '_feat_spoof_thread', None)
        if th is not None:
            th.join(timeout=1)
        self._feat_spoof_thread = None
        self._feat_spoof_stop = None
        return 'Stopped 0x660 injection; the head unit will fall back to the real BCM value.'

    # ---- Force FAST-charging DISPLAY over a real (SC) charge --------------------
    # The head unit shows the charger class from 0x62D (Charger_Connected) and the
    # charge state from 0x143 (Vehicle_Mode_Level_1 = charge mode, Level_2 = charge
    # state). A real fast SESSION can't be reproduced (the fast handshake bytes are
    # unknown), but we CAN relabel a working SC charge as FAST by injecting only these
    # two DISPLAY frames — never the control frames (0x213/0x120/0x121), so the real
    # charge loop is untouched. Bit layout from the vehicle DBC:
    #   0x62D b0: Charger_Connected(0:1)=1(Fast), Charger_Plugged_In(b2)=1  -> b0=0x05
    #   0x143 b0: Level_1(0:3)=4(Fast_Charge), Level_2(4:7)=10(FC_CHARGE ACTIVE) -> b0=0xA4
    # CRUCIAL (matches a real charger): the override is driven by a LIVE 0x213 from the
    # charger. The moment the charger CAN goes quiet or inactive (unplugged / powered
    # off / link cut), 0x213 goes stale, the loop drives the dash to "charging stopped"
    # and stops — it will NOT latch a fake charging state on a dead charger.
    FCD_ALIVE_ID = 0x213           # charger status mirror; we NEVER inject this
    FCD_FRESH_S = 1.5              # 0x213 older than this (or inactive) = charger gone

    def _fcd_charger_alive(self):
        """True only while a real charger is actively talking (fresh, active 0x213)."""
        try:
            with self.t.sample_lock:
                e = self.t.latest.get(self.FCD_ALIVE_ID)
        except Exception:
            return False
        if not e:
            return False
        stamp, data = e
        return (time.time() - stamp) < self.FCD_FRESH_S and len(data) >= 1 and bool(data[0] & 0x01)

    def _fcd_base(self, cid):
        with self.t.sample_lock:
            e = self.t.latest.get(cid)
        return bytearray(((e[1] if e else b'') + bytes(8))[:8])

    def force_fast_charge_display(self, hz=20):
        """Relabel the live charge as FAST on the dash. Requires a real charger present
        NOW (fresh, active 0x213); refuses otherwise so it never fakes charging on a dead
        bus. Auto-stops + shows 'charging stopped' when the charger CAN goes quiet."""
        self.require_bench()
        if not self.t or not getattr(self.t, 'stub', None):
            raise RuntimeError('Connect first')
        if not self.streaming:
            raise RuntimeError('Start the live dashboard (dump stream) first')
        if not self._fcd_charger_alive():
            raise RuntimeError('No live charger on 0x213 — start/arm the (SC) charger first. '
                               'This overlay only relabels a REAL charge session as Fast; it will '
                               'not fake charging on a dead bus.')
        self.stop_fast_charge_display()
        stop = threading.Event()
        self._fcd_stop = stop
        audit('force-fast-charge-display', {'hz': hz, 'frames': ['62D=Fast+plugged', '143=FC_CHARGE_ACTIVE']})

        def _loop():
            period = 1.0 / max(1, hz)
            while not stop.is_set():
                if not self._fcd_charger_alive():
                    break                       # charger gone -> fall through to release
                b62 = self._fcd_base(0x62D); b62[0] = (b62[0] & ~0x07) | 0x05   # Fast + plugged
                b143 = self._fcd_base(0x143); b143[0] = 0xA4                    # Fast_Charge + FC_CHARGE ACTIVE
                try:
                    self.t.write_frame(0x62D, bytes(b62))
                    self.t.write_frame(0x143, bytes(b143))
                except Exception:
                    break
                stop.wait(period)
            self._fcd_release()

        th = threading.Thread(target=_loop, daemon=True)
        self._fcd_thread = th
        th.start()
        return ('Forcing FAST-charging display (0x62D=Fast+plugged, 0x143 Level-2=FC_CHARGE ACTIVE) '
                'over the live charge. It follows the charger: the moment 0x213 goes quiet/inactive '
                '(unplugged, powered off, or CAN cut) the dash shows charging STOPPED and the overlay '
                'ends. Non-persistent; press Stop to hand the display back to the real state.')

    def _fcd_release(self):
        """Drive the dash to 'charging stopped' for ~0.6 s, then stop injecting so the
        vehicle's own 0x62D/0x143 broadcast owns the display again."""
        try:
            for _ in range(6):
                b62 = self._fcd_base(0x62D); b62[0] = (b62[0] & ~0x07)          # Connected=None, unplugged
                b143 = self._fcd_base(0x143); b143[0] = (b143[0] & 0x00) | 0x01  # Level_1=Idle, Level_2=off
                self.t.write_frame(0x62D, bytes(b62))
                self.t.write_frame(0x143, bytes(b143))
                time.sleep(0.1)
        except Exception:
            pass

    def stop_fast_charge_display(self):
        """Stop the FAST-display override; the release burst shows 'charging stopped' and
        then the dashboard reverts to the real charge state."""
        stop = getattr(self, '_fcd_stop', None)
        if stop is not None:
            stop.set()
        th = getattr(self, '_fcd_thread', None)
        if th is not None and th is not threading.current_thread():
            th.join(timeout=2)
        self._fcd_thread = None
        self._fcd_stop = None
        return 'Stopped FAST-charging display; dashboard reverts to the real charge state.'

    def read_odometer(self):
        """Read the VCU odometer via UDS 22 0103 — exactly the factory diag app's
        readOdometerValue() request. Value is 4-byte little-endian, unit km."""
        u = self.uds(Ecu.VCU, require_service=False)
        data = u._request(Ecu.VCU, b'\x22\x01\x03')[3:]
        if len(data) < 4:
            raise RuntimeError(f'0103 short response: {data.hex()}')
        km = int.from_bytes(data[:4], 'little')
        return {'km': km, 'hex': data.hex()}

    def write_odometer(self, km):
        """Write the VCU odometer via UDS 2E 0103 + 4-byte little-endian km — the exact
        payload the factory app builds in setUpOdometerReading(int). REAL change to the
        vehicle: this exists to test whether the VCU accepts the value or rejects it
        (UDS negative response) offline. Legitimate only for restoring the correct
        mileage to a replacement VCU board on your own scooter; falsifying an odometer
        is illegal in most jurisdictions."""
        km = int(km)
        if km < 0 or km > 0xFFFFFFFF:
            raise ValueError('odometer out of range (0 .. 4294967295 km)')
        le = km.to_bytes(4, 'little')
        audit('write-intent', {'component': 'VCU', 'did': '0103', 'after_km': km, 'after': le.hex()})
        u = self.ensure_unlocked(Ecu.VCU)              # extended session + 27 security access
        u._request(Ecu.VCU, b'\x2e\x01\x03' + le)      # raises UdsNegativeResponse if the VCU rejects
        back = self.read_odometer()
        match = back['km'] == km
        return {
            'wrote_km': km,
            'readback_km': back['km'],
            'match': match,
            'message': ('Odometer write ACCEPTED; readback matches. Reboot persistence not verified.'
                        if match else
                        f"Write acknowledged (6E) but readback {back['km']} km != {km} km (ECU may clamp/store differently)."),
        }

    # ---- Raw memory access probe (firmware dump over CAN, non-invasive) ----------
    # Tests whether an ECU will serve its flash/RAM via UDS 0x23 ReadMemoryByAddress
    # or 0x35/0x36/0x37 RequestUpload. Read-only. Most production ECUs refuse (NRC
    # 0x33 securityAccessDenied / 0x31 requestOutOfRange / 0x22 conditionsNotCorrect);
    # a positive response is a firmware dump path with no soldering.
    _ECU_BY_NAME = {'BMS': Ecu.BMS, 'VCU': Ecu.VCU, 'MCU': Ecu.MCU}

    def _ecu(self, name):
        e = self._ECU_BY_NAME.get((name or '').upper())
        if not e:
            raise ValueError(f'Unknown ECU {name!r}; use BMS/VCU/MCU')
        return e

    def uds_read_memory(self, ecu_name, address, size, addr_bytes=4, size_bytes=4, unlock=True):
        """UDS 0x23 ReadMemoryByAddress. Returns {'hex','len'} or raises UdsNegativeResponse.

        addr_bytes/size_bytes set the addressAndLengthFormatIdentifier (high nibble=size,
        low nibble=address). size is capped at 256 (single-frame-ish; use uds_upload for bulk).
        """
        self.require_bench()
        ecu = self._ecu(ecu_name)
        if not (1 <= addr_bytes <= 4 and 1 <= size_bytes <= 4):
            raise ValueError('addr_bytes/size_bytes must be 1..4')
        if size < 1 or size > 256:
            raise ValueError('size 1..256 for 0x23; use uds_upload for larger')
        alfid = (size_bytes << 4) | addr_bytes
        payload = (bytes([0x23, alfid]) + int(address).to_bytes(addr_bytes, 'big')
                   + int(size).to_bytes(size_bytes, 'big'))
        u = self.ensure_unlocked(ecu) if unlock else self.prepare(ecu, False)
        audit('mem-read', {'ecu': ecu.name, 'addr': hex(address), 'size': size})
        resp = u._request(ecu, payload)          # raises UdsNegativeResponse on refusal
        data = resp[1:] if resp[:1] == b'\x63' else resp
        return {'hex': data.hex().upper(), 'len': len(data), 'addr': hex(address)}

    def uds_upload(self, ecu_name, address, size, addr_bytes=4, size_bytes=4,
                   unlock=True, progress=None):
        """UDS 0x35 RequestUpload → loop 0x36 TransferData → 0x37 exit. Returns raw bytes.

        For bulk firmware dumping. `progress(done,total)` optional. Read-only.
        """
        self.require_bench()
        ecu = self._ecu(ecu_name)
        alfid = (size_bytes << 4) | addr_bytes
        req = (bytes([0x35, 0x00, alfid]) + int(address).to_bytes(addr_bytes, 'big')
               + int(size).to_bytes(size_bytes, 'big'))
        u = self.ensure_unlocked(ecu) if unlock else self.prepare(ecu, False)
        audit('mem-upload', {'ecu': ecu.name, 'addr': hex(address), 'size': size})
        resp = u._request(ecu, req)              # 0x75 lengthFormatId maxNumberOfBlockLength
        if resp[:1] != b'\x75':
            raise RuntimeError(f'RequestUpload not accepted: {resp.hex()}')
        lfi = resp[1] >> 4                        # #bytes of maxNumberOfBlockLength
        max_block = int.from_bytes(resp[2:2 + lfi], 'big') if lfi else 0
        chunk = max(1, (max_block - 2) if max_block > 2 else 256)   # minus 0x76+bsc overhead
        out = bytearray()
        bsc = 1
        while len(out) < size:
            r = u._request(ecu, bytes([0x36, bsc & 0xFF]))
            if r[:1] != b'\x76':
                raise RuntimeError(f'TransferData failed at {len(out)}: {r.hex()}')
            out += r[2:]
            bsc += 1
            if progress:
                progress(len(out), size)
        try:
            u._request(ecu, b'\x37')              # RequestTransferExit
        except Exception:
            pass
        return bytes(out[:size])

    def mcu_cal(self, action):
        """gRPC RemoteRunTestCmd RMT_CMD_MCU_CAL start|stop — motor AutoTune wrapper.

        ODX equivalent: 31 01 05 F1 (start) / 31 02 06 F1 (stop). Centre-stand only.
        """
        self.require_bench()
        action = (action or '').lower().strip()
        if action not in ('start', 'stop'):
            raise ValueError("mcu_cal action must be 'start' or 'stop'")
        sub = pb.RMT_SUB_CMD_MCU_CAL_START if action == 'start' else pb.RMT_SUB_CMD_MCU_CAL_STOP
        req = pb.RmtCmdReq(cmd_id=pb.RMT_CMD_MCU_CAL, sub_cmd_mcu_cal=sub)
        audit('mcu-cal', {'action': action})
        # Prefer diag stream so WriteCanFrame/UDS aren't starved if we follow with reads.
        self.diag_stream()
        started = time.monotonic()
        if self.trace:
            self.trace.event('rpc_request', method='RemoteRunTestCmd', action=action, **message_evidence(req))
        try:
            resp = self.t.stub.RemoteRunTestCmd(req, timeout=30)
        except Exception as exc:
            if self.trace:
                self.trace.event('rpc_error', method='RemoteRunTestCmd', error=str(exc))
            raise RuntimeError(f'mcu-cal {action} RPC failed: {exc}') from exc
        if self.trace:
            self.trace.event('rpc_response', method='RemoteRunTestCmd', elapsed=time.monotonic()-started,
                             **message_evidence(resp))
        status = pb.RmtCmdRespStatus.Name(resp.resp_status)
        msg = (resp.resp_str or '').strip() or status
        if resp.resp_status != pb.RMT_CMD_RESP_SUCCESS:
            raise RuntimeError(f'mcu-cal {action} rejected: {msg}')
        return f'mcu-cal {action}: {msg}'

    def disconnect(self):
        self.stop_keepalive()
        if self.t:
            try:
                self.t.close()
            finally:
                self.t = None
                self.streaming = False
                self.stream_mode = None
                self.security_failed.clear()
                self.unlocked.clear()


def audit(event, details):
    directory = ROOT / 'captures/gui'
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / 'actions.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps({'time': time.strftime('%Y-%m-%dT%H:%M:%S%z'), 'event': event, 'details': details}) + '\n')
