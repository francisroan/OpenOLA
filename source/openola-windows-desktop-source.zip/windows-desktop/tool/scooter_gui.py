"""Desktop entry point: run via 30_scooter_gui.cmd."""
import csv
import json
import os
import queue
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from pathlib import Path
from scooter_backend import (ROOT, ODX, SETTINGS, ACTUATORS, ACTUATOR_GROUPS,
                             ACTUATOR_GROUP_ORDER, ACTUATOR_DANGER, Ecu, Scooter,
                             encode_setting, decode_setting, audit)
from command_trace import CommandTrace
from status_monitor import (SessionLog, ChargeSessionRecorder, active_faults,
                            decode_battery, decode_charge, decode_charge_extra,
                            decode_feature_status, decode_vehicle_notification,
                            enrich_power)

# Bluetooth (proximity) control -- consumer BLE path, independent of Wi-Fi/gRPC.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ble'))
try:
    import gui_backend as ble
except Exception:                     # keep the GUI usable if BLE stack absent
    ble = None

# Palette (light, calm, one teal accent + a red for danger).
BG      = '#eef1f6'   # window background
CARD    = '#ffffff'   # card surface
INK     = '#1f2a37'   # primary text
MUTED   = '#6b7280'   # secondary text
ACCENT  = '#0e7c86'   # teal accent
ACCENTD = '#0a5e66'   # teal accent (dark/hover)
DANGER  = '#b42318'   # danger red
LINE    = '#dbe1ea'   # hairline borders
PANEL   = '#0f2733'   # dark footer/log panel


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Ola • Scooter console')
        self.geometry('1200x840')
        self.minsize(1000, 720)
        self.configure(bg=BG)
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', font=('Segoe UI', 10), background=BG, foreground=INK)
        style.configure('TFrame', background=BG)
        style.configure('Card.TFrame', background=CARD)
        style.configure('TLabel', background=BG, foreground=INK)
        style.configure('Card.TLabel', background=CARD, foreground=INK)
        style.configure('Muted.TLabel', background=BG, foreground=MUTED)
        style.configure('CardMuted.TLabel', background=CARD, foreground=MUTED)
        style.configure('Title.TLabel', font=('Segoe UI Semibold', 22), foreground=INK)
        style.configure('H2.TLabel', font=('Segoe UI Semibold', 15), foreground=INK)
        style.configure('CardH2.TLabel', font=('Segoe UI Semibold', 13), foreground=INK, background=CARD)
        style.configure('Metric.TLabel', font=('Segoe UI', 21, 'bold'), foreground=ACCENT, background=CARD)
        style.configure('MetricCap.TLabel', font=('Segoe UI', 9), foreground=MUTED, background=CARD)
        style.configure('TButton', padding=(12, 8), background=CARD, foreground=INK, borderwidth=1)
        style.map('TButton', background=[('active', '#e8eef2')])
        style.configure('Accent.TButton', padding=(14, 9), background=ACCENT, foreground='white', borderwidth=0)
        style.map('Accent.TButton', background=[('active', ACCENTD)])
        style.configure('Nav.TButton', padding=(14, 9), background=BG, foreground=INK, borderwidth=0)
        style.map('Nav.TButton', background=[('active', '#e2e8f0')])
        style.configure('Selected.Nav.TButton', background=ACCENT, foreground='white', padding=(14, 9), borderwidth=0)
        style.map('Selected.Nav.TButton', background=[('active', ACCENTD)], foreground=[('active', 'white')])
        style.configure('Selected.Chip.TButton', background=ACCENT, foreground='white', padding=(10, 5), borderwidth=0)
        style.map('Selected.Chip.TButton', background=[('active', ACCENTD)], foreground=[('active', 'white')])
        style.configure('Chip.TButton', padding=(10, 5), background='#eaf3f4', foreground=ACCENTD, borderwidth=0)
        style.map('Chip.TButton', background=[('active', '#d6e9eb')])
        style.configure('Act.TButton', padding=(10, 8), background='#f3f6f9', foreground=INK, borderwidth=1)
        style.map('Act.TButton', background=[('active', '#e3edf0')])
        style.configure('Danger.TButton', padding=(10, 8), background='#fbeceb', foreground=DANGER, borderwidth=1)
        style.map('Danger.TButton', background=[('active', '#f6dcd9')])
        style.configure('TCheckbutton', background=BG, foreground=INK)
        style.configure('Card.TCheckbutton', background=CARD, foreground=INK)
        style.configure('TLabelframe', background=CARD, foreground=INK, borderwidth=1, relief='solid')
        style.configure('TLabelframe.Label', background=CARD, foreground=ACCENTD, font=('Segoe UI Semibold', 11))
        style.configure('Treeview', rowheight=26, background=CARD, fieldbackground=CARD, borderwidth=0)
        style.configure('Treeview.Heading', font=('Segoe UI Semibold', 9), background='#eef2f6', foreground=MUTED)
        style.configure('TEntry', fieldbackground=CARD)
        style.configure('TCombobox', fieldbackground=CARD)
        self.scooter = Scooter()
        self.scooter.trace = CommandTrace(ROOT / 'captures/gui/protocol')
        self.busy = False
        self.connected = False
        self.live = False
        self.replay = False
        self.closing = False
        self.closed = False
        self.next_poll = 0
        self.results = queue.Queue()
        self.rows = {}
        self.current = None
        self.fields = []
        self.host = tk.StringVar(value='')
        self.port = tk.StringVar(value='50005')
        self.secure = tk.BooleanVar()
        self.unlock_access = tk.BooleanVar(value=False)
        self.bench = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='Disconnected • No commands sent')
        self.mode_text = tk.StringVar(value='Mode: unknown  |  Firmware: unknown')
        # Status tab (APK parity) + charge-session snoop
        self.status_on = False
        self.auto_log_vitals = tk.BooleanVar(value=False)
        self._logged_faults = set()
        self._last_vitals_log = 0.0
        self._log_prefs = ROOT / 'captures/gui/log_folders.json'
        self._default_activity = ROOT / 'captures/gui/activity'
        self._default_charge = ROOT / 'captures/charging'
        activity_dir, charge_dir = self._load_log_folders()
        self._status_log = SessionLog(activity_dir)
        self._charge_rec = ChargeSessionRecorder(charge_dir, self.scooter.dbc)
        self._charge_snoop = False
        self._status_vars = {}
        self._build()
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.after(100, self.tick)

    def _load_log_folders(self):
        activity, charge = self._default_activity, self._default_charge
        try:
            if self._log_prefs.exists():
                data = json.loads(self._log_prefs.read_text(encoding='utf-8'))
                if data.get('activity'):
                    activity = Path(data['activity'])
                if data.get('charge'):
                    charge = Path(data['charge'])
        except (OSError, json.JSONDecodeError, TypeError):
            pass
        return activity, charge

    def _save_log_folders(self):
        self._log_prefs.parent.mkdir(parents=True, exist_ok=True)
        data = {
            'activity': str(self._status_log.root),
            'charge': str(self._charge_rec.root),
        }
        self._log_prefs.write_text(json.dumps(data, indent=2), encoding='utf-8')

    def _refresh_log_folder_labels(self):
        if hasattr(self, 'activity_dir_var'):
            self.activity_dir_var.set(str(self._status_log.root))
        if hasattr(self, 'charge_dir_var'):
            self.charge_dir_var.set(str(self._charge_rec.root))

    def choose_activity_folder(self):
        path = filedialog.askdirectory(
            title='Activity log folder',
            initialdir=str(self._status_log.root))
        if not path:
            return
        self._status_log.set_root(Path(path))
        self._save_log_folders()
        self._refresh_log_folder_labels()
        self._status_log.log('SYS', f'activity folder → {path}')
        self._refresh_status_log_view()
        self.report(f'Activity logs → {path}')

    def choose_charge_folder(self):
        if self._charge_snoop:
            messagebox.showwarning('Charge folder', 'Stop charge recording first.')
            return
        path = filedialog.askdirectory(
            title='Charge session folder',
            initialdir=str(self._charge_rec.root))
        if not path:
            return
        try:
            self._charge_rec.set_root(Path(path))
        except RuntimeError as exc:
            messagebox.showerror('Charge folder', str(exc))
            return
        self._save_log_folders()
        self._refresh_log_folder_labels()
        self._status_log.log('SYS', f'charge folder → {path}')
        self._refresh_status_log_view()
        self.report(f'Charge logs → {path}')

    def reset_log_folders(self):
        if self._charge_snoop:
            messagebox.showwarning('Log folders', 'Stop charge recording first.')
            return
        self._status_log.set_root(self._default_activity)
        self._charge_rec.set_root(self._default_charge)
        self._save_log_folders()
        self._refresh_log_folder_labels()
        self.report('Log folders reset to defaults')
        self._refresh_status_log_view()

    def _build(self):
        outer = ttk.Frame(self, padding=(24, 18))
        outer.pack(fill='both', expand=True)
        header = ttk.Frame(outer)
        header.pack(fill='x')
        left = ttk.Frame(header)
        left.pack(side='left', anchor='w')
        ttk.Label(left, text='Scooter console', style='Title.TLabel').pack(anchor='w')
        ttk.Label(left, text='Ola S1 Pro · 2022  /  Diagnostics workspace',
                  style='Muted.TLabel').pack(anchor='w')
        conn = ttk.Frame(header)
        conn.pack(side='right', anchor='e')
        ttk.Button(conn, text='Connection settings', command=self.connection_settings).pack(side='left', padx=(0, 8))
        self.connect_button = ttk.Button(conn, text='Connect', style='Accent.TButton', command=self.connect)
        self.connect_button.pack(side='left', padx=(0, 6))
        self.disconnect_button = ttk.Button(conn, text='Disconnect', command=self.disconnect)
        self.disconnect_button.pack(side='left')

        self.connection_summary = tk.StringVar()
        self.update_connection_summary()
        ttk.Label(outer, textvariable=self.connection_summary, style='Muted.TLabel').pack(anchor='e', pady=(4, 0))

        statusbar = ttk.Frame(outer)
        statusbar.pack(fill='x', pady=(8, 6))
        ttk.Label(statusbar, textvariable=self.mode_text, style='H2.TLabel').pack(side='left')
        ttk.Checkbutton(outer, variable=self.bench,
                        text='Enable active tests — scooter parked and charger unplugged'
                        ).pack(anchor='w')

        nav = ttk.Frame(outer)
        nav.pack(fill='x', pady=(12, 12))
        self.pages = {}
        self.nav_buttons = {}
        self.body = ttk.Frame(outer)
        for name, label in [('Home', 'Overview'), ('Status', 'Status'), ('Charging', 'Charging'),
                            ('Calibration', 'Calibration'),
                            ('1. Scooter mode', 'ECU tests'),
                            ('2. Live Data', 'Live signals'), ('Diagnostics', 'Diagnostics'), ('Update', 'Update'),
                            ('3. Write components', 'Components'), ('Bluetooth', 'Bluetooth')]:
            button = ttk.Button(nav, text=label, style='Nav.TButton', command=lambda n=name: self.show(n))
            button.pack(side='left', padx=(0, 4))
            self.nav_buttons[name] = button
            self.pages[name] = ttk.Frame(self.body)
        self.home_page()
        self.status_page()
        self.charging_page()
        self.calibration_page()
        self.mode_page()
        self.live_page()
        self.write_page()
        self.ble_page()
        from diagnostic_pages import build_pages
        build_pages(self)
        footer = ttk.Frame(outer)
        footer.pack(side='bottom', fill='x')
        ttk.Separator(footer).pack(fill='x', pady=(10, 8))
        line = ttk.Frame(footer)
        line.pack(fill='x')
        self.activity_button = ttk.Button(line, text='Show activity', style='Chip.TButton', command=self.toggle_activity)
        self.activity_button.pack(side='right')
        ttk.Label(line, textvariable=self.status, style='Muted.TLabel', wraplength=740).pack(side='left', fill='x', expand=True)
        self.log = tk.Text(footer, height=5, font=('Consolas', 9), bg=PANEL, fg='#cfe6ea',
                           relief='flat', padx=10, pady=6, state='disabled')
        self.body.pack(fill='both', expand=True)
        self.show('Home')

    def toggle_activity(self):
        if self.log.winfo_manager():
            self.log.pack_forget()
            self.activity_button.configure(text='Show activity')
        else:
            self.log.pack(fill='x', pady=(8, 0))
            self.activity_button.configure(text='Hide activity')
            self.log.see('end')

    def update_connection_summary(self):
        self.connection_summary.set(f'{self.host.get()}:{self.port.get()}  ·  ' + ('mTLS' if self.secure.get() else 'Wi-Fi'))

    def connection_settings(self):
        if self.busy:
            return
        window = tk.Toplevel(self)
        window.title('Connection settings')
        window.transient(self)
        window.resizable(False, False)
        conn = ttk.Frame(window, padding=22)
        conn.pack(fill='both', expand=True)
        ttk.Label(conn, text='Scooter Wi-Fi connection', style='H2.TLabel').pack(anchor='w', pady=(0, 14))
        for label, var, width in [('Host', self.host, 28), ('Port', self.port, 28)]:
            ttk.Label(conn, text=label, style='Muted.TLabel').pack(anchor='w', pady=(0, 5))
            ttk.Entry(conn, textvariable=var, width=width).pack(fill='x', pady=(0, 12))
        ttk.Checkbutton(conn, text='Use certificate authentication (mTLS)', variable=self.secure).pack(anchor='w')
        ttk.Label(conn, text='Changes apply on your next connection.', style='Muted.TLabel').pack(anchor='w', pady=12)
        def close():
            self.update_connection_summary()
            window.destroy()
        ttk.Button(conn, text='Done', style='Accent.TButton', command=close).pack(anchor='e')
        window.protocol('WM_DELETE_WINDOW', close)
        window.grab_set()

    def show(self, name):
        for page in self.pages.values():
            page.pack_forget()
        self.pages[name].pack(fill='both', expand=True)
        for key, button in self.nav_buttons.items():
            button.configure(style='Selected.Nav.TButton' if key == name else 'Nav.TButton')

    def _scroll_body(self, page):
        """Wrap a page in a vertical-scroll Canvas and return the inner content frame.
        Cards packed into the returned frame scroll when they overflow the window."""
        canvas = tk.Canvas(page, bg=BG, highlightthickness=0, bd=0)
        bar = ttk.Scrollbar(page, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=bar.set)
        bar.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        inner = ttk.Frame(canvas)
        window = canvas.create_window((0, 0), window=inner, anchor='nw')

        def _on_inner(_=None):
            canvas.configure(scrollregion=canvas.bbox('all'))
        def _on_canvas(event):
            canvas.itemconfigure(window, width=event.width)   # stretch inner to width
        inner.bind('<Configure>', _on_inner)
        canvas.bind('<Configure>', _on_canvas)

        def _wheel(event):
            if canvas.winfo_exists():
                canvas.yview_scroll(int(-event.delta / 120), 'units')
        # Only scroll while the pointer is over this page (avoid hijacking other pages).
        canvas.bind('<Enter>', lambda e: canvas.bind_all('<MouseWheel>', _wheel))
        canvas.bind('<Leave>', lambda e: canvas.unbind_all('<MouseWheel>'))
        return inner

    def _card(self, parent, title=None):
        wrap = tk.Frame(parent, bg=LINE)          # 1px hairline via bg
        wrap.pack(fill='x', pady=7)
        card = ttk.Frame(wrap, style='Card.TFrame', padding=16)
        card.pack(fill='both', expand=True, padx=1, pady=1)
        if title:
            ttk.Label(card, text=title, style='CardH2.TLabel').pack(anchor='w', pady=(0, 8))
        return card

    def home_page(self):
        p = self.pages['Home']
        ttk.Label(p, text='Choose a workspace', style='H2.TLabel').pack(anchor='w', pady=(6, 6))
        for name, icon, description in [
            ('Status', '00', 'Battery, live faults, vehicle notifications and features (Wi‑Fi vehicle CAN).'),
            ('Charging', '⚡', 'Live charge path, session recorder, charge commands, and stuck-state / paywall recovery.'),
            ('Calibration', '01', 'MCU motor AutoTune / angle (B113). Centre-stand only — RED.'),
            ('1. Scooter mode', '02', 'Choose an operating mode, then test horns, lights and other components.'),
            ('2. Live Data', '03', 'Monitor battery and motor values, find signals, or review a saved recording.'),
            ('3. Write components', '04', 'Read component identifiers and inspect settings. Parameter writes remain disabled.')]:
            card = self._card(p)
            row = ttk.Frame(card, style='Card.TFrame'); row.pack(fill='x')
            ttk.Label(row, text=icon, style='Card.TLabel', font=('Segoe UI', 20)).pack(side='left', padx=(0, 12))
            txt = ttk.Frame(row, style='Card.TFrame'); txt.pack(side='left', fill='x', expand=True)
            ttk.Label(txt, text=name, style='CardH2.TLabel').pack(anchor='w')
            ttk.Label(txt, text=description, style='CardMuted.TLabel', wraplength=600).pack(anchor='w')
            ttk.Button(row, text='Open →', style='Accent.TButton',
                       command=lambda n=name: self.show(n)).pack(side='right')
        ttk.Label(p, text='Nothing connects or changes automatically. '
                          'Log folders are choosable on Status (defaults: captures/gui/activity · captures/charging).',
                  style='Muted.TLabel').pack(anchor='w', pady=14)

    def calibration_page(self):
        """MCU AutoTune / B113 — verified against ODX + mcu-cal gRPC (not yet run on-vehicle)."""
        p = self._scroll_body(self.pages['Calibration'])
        ttk.Label(p, text='MCU calibration', style='H2.TLabel').pack(anchor='w', pady=(6, 2))
        ttk.Label(
            p,
            text='Motor AutoTune (resolver/encoder angle). Same path as CLI mcu-cal / ODX routine '
                 '31 01 05 F1 start · 31 02 06 F1 stop · DID B113 angle. '
                 'Wrong or skipped cal → overcurrent / bad commutation. See '
                 'reverse_engineering/COMPONENT_PAIRING_CALIBRATION.md.',
            style='Muted.TLabel', wraplength=920,
        ).pack(anchor='w', pady=(0, 10))

        angle_card = self._card(p, 'Stored motor angle (DID B113)')
        row = ttk.Frame(angle_card, style='Card.TFrame')
        row.pack(fill='x')
        self.motor_angle = tk.StringVar(value='—')
        ttk.Label(row, textvariable=self.motor_angle, style='Metric.TLabel').pack(side='left')
        ttk.Label(row, text='degrees (0–360, 0.1°)', style='CardMuted.TLabel').pack(side='left', padx=12)
        ttk.Button(row, text='Read B113', style='Accent.TButton',
                   command=self.read_motor_angle).pack(side='right')

        cal = self._card(p, 'Motor AutoTune (gRPC RMT_CMD_MCU_CAL) · RED')
        ttk.Label(
            cal,
            text='Parked · centre stand · wheel clear · charger unplugged · top checkbox enabled. '
                 'SERVICE mode recommended. Start runs the learn; Stop forcefully ends it. '
                 'Re-read B113 after a successful run.',
            style='CardMuted.TLabel', wraplength=860,
        ).pack(anchor='w', pady=(0, 10))
        brow = ttk.Frame(cal, style='Card.TFrame')
        brow.pack(fill='x')
        ttk.Button(brow, text='Start AutoTune…', style='Danger.TButton',
                   command=lambda: self.mcu_cal('start')).pack(side='left', padx=(0, 8))
        ttk.Button(brow, text='Stop AutoTune…', style='Danger.TButton',
                   command=lambda: self.mcu_cal('stop')).pack(side='left', padx=(0, 8))
        self.cal_status = tk.StringVar(value='Not run this session')
        ttk.Label(cal, textvariable=self.cal_status, style='CardMuted.TLabel').pack(anchor='w', pady=(10, 0))

        odo = self._card(p, 'Odometer (VCU DID 0103) · RED')
        ttk.Label(
            odo,
            text='Reads/writes the VCU odometer exactly as the factory app: 22 0103 read · '
                 '2E 0103 + 4-byte little-endian km write (security access). Write is a REAL change '
                 'to the vehicle — intended for restoring the correct mileage to a replacement VCU '
                 'board on your own scooter. Falsifying an odometer is illegal in most places. '
                 'A rejection shows as a UDS negative response (e.g. 0x33 / 0x31 / 0x22).',
            style='CardMuted.TLabel', wraplength=860, justify='left',
        ).pack(anchor='w', pady=(0, 10))
        orow = ttk.Frame(odo, style='Card.TFrame'); orow.pack(fill='x')
        self.odo_value = tk.StringVar(value='—')
        ttk.Label(orow, textvariable=self.odo_value, style='Metric.TLabel').pack(side='left')
        ttk.Label(orow, text='km', style='CardMuted.TLabel').pack(side='left', padx=8)
        ttk.Button(orow, text='Read', style='Accent.TButton',
                   command=self.read_odometer).pack(side='right')
        wrow = ttk.Frame(odo, style='Card.TFrame'); wrow.pack(fill='x', pady=(10, 0))
        ttk.Label(wrow, text='New km:', style='Card.TLabel').pack(side='left')
        self.odo_new = tk.StringVar(value='')
        ttk.Entry(wrow, textvariable=self.odo_new, width=12).pack(side='left', padx=8)
        ttk.Button(wrow, text='Write…', style='Danger.TButton',
                   command=self.write_odometer).pack(side='left')
        self.odo_status = tk.StringVar(value='Not read this session')
        ttk.Label(odo, textvariable=self.odo_status, style='CardMuted.TLabel').pack(anchor='w', pady=(10, 0))

        boost = self._card(p, 'Boost profile DIDs (MCU: B135 / B13C / B13D)')
        ttk.Label(
            boost,
            text='Reads the three MCU DIDs that define the Boost performance profile '
                 '(speed-torque · throttle map · regen). Read is safe. Writing them changes '
                 'the MCU performance map — RED, bench-only. Provide the full DID bytes as hex '
                 '(read them from an entitled bike first). No default payload is shipped.',
            style='CardMuted.TLabel', wraplength=860, justify='left',
        ).pack(anchor='w', pady=(0, 10))
        ttk.Button(boost, text='Read Boost DIDs', style='Accent.TButton',
                   command=self.read_boost_dids).pack(anchor='w')
        self.boost_dids = tk.StringVar(value='—')
        ttk.Label(boost, textvariable=self.boost_dids, style='CardMuted.TLabel',
                  font=('Consolas', 9), justify='left').pack(anchor='w', pady=(6, 8))
        wrow = ttk.Frame(boost, style='Card.TFrame'); wrow.pack(fill='x')
        ttk.Label(wrow, text='DID:', style='Card.TLabel').pack(side='left')
        self.boost_did_sel = tk.StringVar(value='B135')
        ttk.Combobox(wrow, textvariable=self.boost_did_sel, width=7, state='readonly',
                     values=['B135', 'B13C', 'B13D']).pack(side='left', padx=6)
        ttk.Label(wrow, text='payload hex:', style='Card.TLabel').pack(side='left')
        self.boost_payload = tk.StringVar(value='')
        ttk.Entry(wrow, textvariable=self.boost_payload, width=44).pack(side='left', padx=6)
        ttk.Button(wrow, text='Write…', style='Danger.TButton',
                   command=self.write_boost_did).pack(side='left')

        ftog = self._card(p, 'Feature toggles (0x6BC) · one-shot, echo-confirmed')
        ttk.Label(
            ftog,
            text='Sends the CommandFromHMI enable/disable for a feature. Works only if the '
                 'feature is entitled (see Status → Features enabled). If not, watch Status → '
                 'Vehicle notifications for an UPGRADE_FOR_* / *_NA reason. Requires the top '
                 '“Enable active tests” checkbox. Unverified on MoveOS 5.',
            style='CardMuted.TLabel', wraplength=860, justify='left',
        ).pack(anchor='w', pady=(0, 10))
        for feat, en, dis in [('Boost mode', 48, 49), ('Hill hold', 66, 67),
                              ('Vacation mode', 68, 69), ('Proximity lock', 54, 55),
                              ('Motor cutoff delay', 64, 65), ('Park assist', 103, 104)]:
            frow = ttk.Frame(ftog, style='Card.TFrame'); frow.pack(fill='x', pady=1)
            ttk.Label(frow, text=feat, style='Card.TLabel', width=20).pack(side='left')
            ttk.Button(frow, text='Enable', command=lambda o=en: self._feature_toggle(o)).pack(side='left', padx=3)
            ttk.Button(frow, text='Disable', command=lambda o=dis: self._feature_toggle(o)).pack(side='left', padx=3)
        rrow = ttk.Frame(ftog, style='Card.TFrame'); rrow.pack(fill='x', pady=(6, 1))
        ttk.Label(rrow, text='Regen type', style='Card.TLabel', width=20).pack(side='left')
        for lbl, o in [('Default', 41), ('City', 42), ('Highway', 43)]:
            ttk.Button(rrow, text=lbl, command=lambda oo=o: self._feature_toggle(oo)).pack(side='left', padx=3)

        mem = self._card(p, 'Raw memory read (UDS 0x23 / 0x35) · firmware-dump probe · RED')
        ttk.Label(
            mem,
            text='Tests whether an ECU serves its flash/RAM over CAN — no soldering. '
                 '0x23 reads one block; “Dump” uses 0x35/0x36 upload to pull a range to a .bin. '
                 'Read-only, but needs security-access unlock. Most ECUs refuse (NRC 0x33/0x31/'
                 '0x22) — a success is a non-invasive dump path. Addresses are guesses until a '
                 'chip is identified; start small.',
            style='CardMuted.TLabel', wraplength=860, justify='left',
        ).pack(anchor='w', pady=(0, 10))
        mrow = ttk.Frame(mem, style='Card.TFrame'); mrow.pack(fill='x')
        ttk.Label(mrow, text='ECU', style='Card.TLabel').pack(side='left')
        self.mem_ecu = tk.StringVar(value='MCU')
        ttk.Combobox(mrow, textvariable=self.mem_ecu, width=6, state='readonly',
                     values=['MCU', 'VCU', 'BMS']).pack(side='left', padx=6)
        ttk.Label(mrow, text='addr 0x', style='Card.TLabel').pack(side='left')
        self.mem_addr = tk.StringVar(value='00000000')
        ttk.Entry(mrow, textvariable=self.mem_addr, width=12).pack(side='left', padx=4)
        ttk.Label(mrow, text='size', style='Card.TLabel').pack(side='left')
        self.mem_size = tk.StringVar(value='64')
        ttk.Entry(mrow, textvariable=self.mem_size, width=8).pack(side='left', padx=4)
        ttk.Button(mrow, text='Probe 0x23', style='Danger.TButton',
                   command=self.uds_mem_read).pack(side='left', padx=6)
        ttk.Button(mrow, text='Dump 0x35→file…', style='Danger.TButton',
                   command=self.uds_mem_dump).pack(side='left', padx=2)
        self.mem_result = tk.StringVar(value='—')
        ttk.Label(mem, textvariable=self.mem_result, style='CardMuted.TLabel',
                  font=('Consolas', 9), justify='left', wraplength=860).pack(anchor='w', pady=(8, 0))

        note = self._card(p, 'Also in ODX (not exposed as buttons yet)')
        ttk.Label(
            note,
            text='• UDS AutoTune Result 31 03 06 F1 → attempted + success counters\n'
                 '• Torque slots B110 (excluded from GUI writes — conflicting ODX defs)\n'
                 '• BMS cell-balance 31 01 05 F8 · identity/capacity DIDs — see calibration MD',
            style='CardMuted.TLabel', justify='left',
        ).pack(anchor='w')

    def read_motor_angle(self):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('B113', 'Connect over Wi‑Fi first.')
            return
        def done(r):
            self.motor_angle.set(f"{r['degrees']:.1f}")
            self.cal_status.set(f"B113 read OK · raw=0x{r['raw']:04X} · {r['hex']}")
            self.report(f"Motor angle {r['degrees']:.1f}°")
        self.run('Read motor angle B113', self.scooter.read_motor_angle, done)

    def read_boost_dids(self):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Boost DIDs', 'Connect over Wi‑Fi first.')
            return
        def done(rows):
            lines = []
            for r in rows:
                if 'error' in r:
                    lines.append(f"{r['name']} ({r['did']}): ERROR {r['error']}")
                else:
                    lines.append(f"{r['name']} ({r['did']}, {r['len']}B): {r['hex']}")
            self.boost_dids.set('\n'.join(lines))
            self.report('Boost DIDs read')
        self.run('Read Boost DIDs', self.scooter.read_boost_dids, done)

    def write_boost_did(self):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Boost DID', 'Connect over Wi‑Fi first.')
            return
        if not self.bench.get():
            messagebox.showwarning('Boost DID', 'Tick “Enable active tests — parked and charger unplugged” first.')
            return
        did = self.boost_did_sel.get().strip().upper()
        payload = self.boost_payload.get().strip().replace(' ', '')
        if not payload:
            messagebox.showerror('Boost DID', 'Enter the full DID payload as hex first '
                                 '(read it from an entitled bike). No default is provided.')
            return
        if simpledialog.askstring(
                'Confirm Boost DID write',
                f'REAL change to the MCU performance map.\n\n'
                f'Write DID {did} = {payload}\n\n'
                'Bench only, centre stand, wheel clear. Wrong values can cause bad torque/'
                'commutation. No retry. Type WRITE to proceed:',
                parent=self) != 'WRITE':
            return
        self.scooter.bench_confirmed = self.bench.get()
        def done(r):
            self.boost_dids.set(f"{r['did']}: before={r['before']} wrote={r['wrote']} "
                                f"readback={r['readback']} match={r['match']}\n{r['message']}")
            self.report(r['message'])
        self.run(f'Write Boost DID {did}',
                 lambda: self.scooter.write_boost_did(did, payload, unlock=True), done)

    def _mem_params(self):
        ecu = self.mem_ecu.get().strip().upper()
        addr = int(self.mem_addr.get().strip().replace('0x', ''), 16)
        size = int(self.mem_size.get().strip())
        return ecu, addr, size

    def uds_mem_read(self):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Memory read', 'Connect over Wi‑Fi first.')
            return
        if not self.bench.get():
            messagebox.showwarning('Memory read', 'Tick “Enable active tests” first.')
            return
        try:
            ecu, addr, size = self._mem_params()
        except ValueError:
            messagebox.showerror('Memory read', 'Bad address (hex) or size (int).')
            return
        if not messagebox.askyesno('Memory read', f'Read {size} bytes @ 0x{addr:08X} from {ecu} '
                                   '(UDS 0x23, needs unlock)?\nRead-only; may return a UDS refusal.'):
            return
        self.scooter.bench_confirmed = self.bench.get()
        def done(r):
            self.mem_result.set(f"{ecu} @0x{addr:08X} ({r['len']}B): {r['hex']}")
            self.report(f'Memory read OK ({r["len"]}B)')
        self.run('UDS read memory', lambda: self.scooter.uds_read_memory(ecu, addr, size), done)

    def uds_mem_dump(self):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Memory dump', 'Connect over Wi‑Fi first.')
            return
        if not self.bench.get():
            messagebox.showwarning('Memory dump', 'Tick “Enable active tests” first.')
            return
        try:
            ecu, addr, size = self._mem_params()
        except ValueError:
            messagebox.showerror('Memory dump', 'Bad address (hex) or size (int).')
            return
        if simpledialog.askstring('Confirm dump', f'Bulk-upload {size} bytes @ 0x{addr:08X} from '
                                  f'{ecu} via UDS 0x35/0x36. Read-only but long. Type DUMP:',
                                  parent=self) != 'DUMP':
            return
        out_dir = ROOT / 'captures' / 'dumps'
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f'{ecu}_{addr:08X}_{size}.bin'
        self.scooter.bench_confirmed = self.bench.get()
        def work():
            data = self.scooter.uds_upload(ecu, addr, size)
            out.write_bytes(data)
            return {'path': str(out), 'len': len(data)}
        def done(r):
            self.mem_result.set(f"Dumped {r['len']} B → {r['path']}")
            self.report(f'Memory dump saved: {r["path"]}')
        self.run('UDS memory dump', work, done)

    def _feature_toggle(self, ordinal):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Feature toggle', 'Connect over Wi‑Fi first.')
            return
        if not self.bench.get():
            messagebox.showwarning('Feature toggle', 'Tick “Enable active tests” first.')
            return
        if self.replay:
            messagebox.showerror('Offline', 'Connect to a live scooter first.')
            return
        import hmi_commands
        label = hmi_commands._LABEL_BY_ORDINAL.get(ordinal)
        if not label:
            messagebox.showerror('Feature toggle', f'Unknown command ordinal {ordinal}')
            return
        if not messagebox.askyesno('Feature toggle', f'Send "{label}" once?\n\n'
                                   'Unverified on MoveOS 5 — check the scooter / notifications after.'):
            return
        self.scooter.bench_confirmed = self.bench.get()
        self.run('HMI ' + label, lambda: hmi_commands.send_once(self.scooter, label),
                 lambda r: messagebox.showinfo('Feature toggle result', r))

    def mcu_cal(self, action):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('MCU cal', 'Connect over Wi‑Fi first.')
            return
        if not self.bench.get():
            messagebox.showwarning('MCU cal', 'Tick “Enable active tests — parked and charger unplugged” first.')
            return
        word = 'START' if action == 'start' else 'STOP'
        if simpledialog.askstring(
                'Confirm MCU AutoTune',
                f'This will {word} motor AutoTune (RMT_CMD_MCU_CAL).\n\n'
                'Centre stand only — the motor may spin / learn angle.\n'
                'Wrong use can cause overcurrent or runaway torque.\n\n'
                f'Type {word} to proceed:',
                parent=self) != word:
            return
        def done(msg):
            self.cal_status.set(msg)
            if action == 'stop':
                # Offer a follow-up angle read
                if messagebox.askyesno('AutoTune stopped', f'{msg}\n\nRead B113 angle now?'):
                    self.read_motor_angle()
        self.run(f'mcu-cal {action}', lambda: self.scooter.mcu_cal(action), done)

    def read_odometer(self):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Odometer', 'Connect over Wi‑Fi first.')
            return
        def done(r):
            self.odo_value.set(str(r['km']))
            self.odo_status.set(f"Read OK · {r['km']} km · raw {r['hex']}")
            self.report(f"Odometer {r['km']} km")
        self.run('Read odometer 0103', self.scooter.read_odometer, done)

    def write_odometer(self):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Odometer', 'Connect over Wi‑Fi first.')
            return
        if not self.bench.get():
            messagebox.showwarning('Odometer', 'Tick “Enable active tests — parked and charger unplugged” first.')
            return
        raw = (self.odo_new.get() or '').strip()
        if not raw.isdigit():
            messagebox.showwarning('Odometer', 'Enter the new odometer value in whole km.')
            return
        km = int(raw)
        if simpledialog.askstring(
                'Confirm odometer write',
                f'This will WRITE the VCU odometer to {km} km (2E 0103).\n\n'
                'This is a real change to the vehicle. Legitimate only for restoring the\n'
                'correct reading to a replacement VCU board on your own scooter.\n'
                'Falsifying an odometer is illegal in most jurisdictions.\n\n'
                'Type WRITE to proceed:',
                parent=self) != 'WRITE':
            return
        def done(r):
            self.odo_value.set(str(r['readback_km']))
            self.odo_status.set(r['message'])
            self.report(r['message'])
        self.run(f'Write odometer {km} km', lambda: self.scooter.write_odometer(km), done)

    def status_page(self):
        """APK Status tab parity: battery, live faults, auto-log, charge snoop."""
        p = self._scroll_body(self.pages['Status'])
        ttk.Label(p, text='Status', style='H2.TLabel').pack(anchor='w', pady=(6, 2))
        ttk.Label(p, text='Battery, faults, vehicle notifications and features over Wi‑Fi (vehicle '
                          'bus). Charging lives on its own tab. Choose log folders below '
                          '(defaults: captures/gui/activity · captures/charging).',
                  style='Muted.TLabel', wraplength=900).pack(anchor='w', pady=(0, 8))

        folders = self._card(p, 'Log folders')
        self.activity_dir_var = tk.StringVar(value=str(self._status_log.root))
        self.charge_dir_var = tk.StringVar(value=str(self._charge_rec.root))
        arow = ttk.Frame(folders, style='Card.TFrame'); arow.pack(fill='x', pady=2)
        ttk.Label(arow, text='Activity', style='Card.TLabel', width=10).pack(side='left')
        ttk.Label(arow, textvariable=self.activity_dir_var, style='CardMuted.TLabel').pack(side='left', fill='x', expand=True)
        ttk.Button(arow, text='Choose…', command=self.choose_activity_folder).pack(side='right', padx=2)
        crow = ttk.Frame(folders, style='Card.TFrame'); crow.pack(fill='x', pady=2)
        ttk.Label(crow, text='Charging', style='Card.TLabel', width=10).pack(side='left')
        ttk.Label(crow, textvariable=self.charge_dir_var, style='CardMuted.TLabel').pack(side='left', fill='x', expand=True)
        ttk.Button(crow, text='Choose…', command=self.choose_charge_folder).pack(side='right', padx=2)
        ttk.Button(folders, text='Reset both to defaults', command=self.reset_log_folders).pack(anchor='e', pady=(6, 0))

        bar = ttk.Frame(p)
        bar.pack(fill='x', pady=(0, 8))
        ttk.Button(bar, text='▶ Start monitor', style='Accent.TButton',
                   command=self.start_status_monitor).pack(side='left', padx=(0, 6))
        ttk.Button(bar, text='Stop monitor', command=self.stop_status_monitor).pack(side='left', padx=(0, 6))
        self.status_mon_label = tk.StringVar(value='Monitor off')
        ttk.Label(bar, textvariable=self.status_mon_label, style='Muted.TLabel').pack(side='left', padx=8)

        bat = self._card(p, 'Battery')
        brow = ttk.Frame(bat, style='Card.TFrame')
        brow.pack(fill='x')
        for key, cap in [('soc', 'SOC %'), ('range', 'Range km'), ('volts', 'Pack V'),
                         ('amps', 'Current A'), ('power', 'Power W'), ('chg', 'Charger')]:
            cell = ttk.Frame(brow, style='Card.TFrame', padding=(6, 2))
            cell.pack(side='left', expand=True, fill='x')
            ttk.Label(cell, text=cap.upper(), style='MetricCap.TLabel').pack(anchor='w')
            var = tk.StringVar(value='—')
            self._status_vars[key] = var
            ttk.Label(cell, textvariable=var, style='Metric.TLabel').pack(anchor='w')

        chg = self._card(p, 'Charge path')
        ttk.Label(chg, text='Charge path metrics, the session recorder, charge commands and '
                            'stuck-state recovery now live on the dedicated Charging tab.',
                  style='CardMuted.TLabel', wraplength=880).pack(anchor='w')
        ttk.Button(chg, text='Open Charging →', style='Accent.TButton',
                   command=lambda: self.show('Charging')).pack(anchor='w', pady=(8, 0))

        faults = self._card(p, 'Active faults')
        self.fault_list = tk.Text(faults, height=5, font=('Consolas', 9), bg='#f8fafc', fg=DANGER,
                                  relief='flat', wrap='word', state='disabled')
        self.fault_list.pack(fill='x')

        notif = self._card(p, 'Vehicle notifications (0x6D0 — why derating / mode / charge)')
        ttk.Label(notif, text='Read-only VCU→HU feed decoded via CommandFromVehicle. '
                              'Newest first; red = derate/fault/access/charge block.',
                  style='CardMuted.TLabel', wraplength=900).pack(anchor='w', pady=(0, 4))
        self.notif_list = tk.Text(notif, height=7, font=('Consolas', 9), bg='#f8fafc',
                                  relief='flat', wrap='word', state='disabled')
        self.notif_list.tag_configure('alert', foreground=DANGER)
        self.notif_list.tag_configure('info', foreground=ACCENT)
        self.notif_list.pack(fill='x')
        ttk.Button(notif, text='Clear', command=self._clear_notifications).pack(anchor='e', pady=(4, 0))

        feat = self._card(p, 'Features enabled (0x660)')
        ttk.Label(feat, text='Read-only entitlement/feature flags. Green = on/entitled, grey = off. '
                             'TP = paid tech-pack (0=not entitled). A few bits are tentative — '
                             'verify by toggling in the app.', style='CardMuted.TLabel',
                  wraplength=900).pack(anchor='w', pady=(0, 4))
        self.feature_list = tk.Text(feat, height=7, font=('Consolas', 9), bg='#f8fafc',
                                    relief='flat', wrap='word', state='disabled')
        self.feature_list.tag_configure('on', foreground=ACCENT)
        self.feature_list.tag_configure('off', foreground='#94a3b8')
        self.feature_list.pack(fill='x')

        # Reveal a dues-suppressed feature's built-in UI by injecting 0x660 (test only).
        frow = ttk.Frame(feat, style='Card.TFrame')
        frow.pack(fill='x', pady=(6, 0))
        ttk.Label(frow, text='Enable (0x660 test):', style='CardMuted.TLabel').pack(side='left')
        self.feat_enable_choice = tk.StringVar(value='Energy insights')
        ttk.OptionMenu(frow, self.feat_enable_choice, 'Energy insights',
                       'Energy insights', 'Hyper charger', 'Fast charger').pack(side='left', padx=6)
        ttk.Button(frow, text='Reveal UI', command=self._enable_feature_0660).pack(side='left')
        ttk.Button(frow, text='Stop', command=self._stop_feature_0660).pack(side='left', padx=6)

        logc = self._card(p, 'Activity log (always-on while connected)')
        row = ttk.Frame(logc, style='Card.TFrame')
        row.pack(fill='x')
        ttk.Checkbutton(row, style='Card.TCheckbutton', variable=self.auto_log_vitals,
                        text='Extra vitals heartbeat (30 s) — CMD/FAULT always logged',
                        command=self._toggle_vitals_log).pack(side='left')
        ttk.Button(row, text='Open log folder', command=self.open_status_logs).pack(side='right', padx=4)
        ttk.Button(row, text='Clear log', command=self.clear_status_log).pack(side='right', padx=4)
        ttk.Button(row, text='Export…', command=self.export_status_log).pack(side='right', padx=4)
        ttk.Label(logc, text='Tags: [CMD] actuators/tests · [FAULT] · [LIVE] · [CAL] · [CHARGE] markers · [CONN]',
                  style='CardMuted.TLabel').pack(anchor='w', pady=(4, 0))
        self.status_log_view = tk.Text(logc, height=10, font=('Consolas', 9), bg=PANEL, fg='#cfe6ea',
                                       relief='flat', state='disabled')
        self.status_log_view.pack(fill='both', expand=True, pady=(8, 0))

    def charging_page(self):
        """All charging in one place: live charge path, session recorder, charge
        commands (0x6BC), and the stuck-state / paywall-bug recovery."""
        import hmi_commands as hc
        p = self._scroll_body(self.pages['Charging'])
        ttk.Label(p, text='Charging', style='H2.TLabel').pack(anchor='w', pady=(6, 2))
        ttk.Label(p, text='Live charge path (vehicle-CAN mirror over Wi‑Fi), session recorder, '
                          'charge commands and stuck-state recovery. Charge-CAN auth / full Hyper '
                          'need the Arduino charge-port tap (tool/charge_can_sniff).',
                  style='Muted.TLabel', wraplength=900).pack(anchor='w', pady=(0, 8))

        # --- recorder controls -------------------------------------------------
        rec = self._card(p, 'Charge-session recorder')
        bar = ttk.Frame(rec, style='Card.TFrame'); bar.pack(fill='x')
        ttk.Button(bar, text='▶ Start monitor', style='Accent.TButton',
                   command=self.start_status_monitor).pack(side='left', padx=(0, 6))
        ttk.Button(bar, text='Stop monitor', command=self.stop_status_monitor).pack(side='left', padx=(0, 6))
        self.charge_btn2 = ttk.Button(bar, text='● Record charge session', style='Danger.TButton',
                                      command=self.toggle_charge_snoop)
        self.charge_btn2.pack(side='left', padx=(12, 6))
        frow = ttk.Frame(rec, style='Card.TFrame'); frow.pack(fill='x', pady=(8, 0))
        ttk.Label(frow, text='Folder', style='Card.TLabel', width=8).pack(side='left')
        ttk.Label(frow, textvariable=self.charge_dir_var, style='CardMuted.TLabel').pack(side='left', fill='x', expand=True)
        ttk.Button(frow, text='Choose…', command=self.choose_charge_folder).pack(side='right')

        # --- live charge path (bound to the shared status vars) ----------------
        self._status_vars.setdefault('billing', tk.StringVar(value='—'))
        self._status_vars.setdefault('evse', tk.StringVar(value='—'))
        live = self._card(p, 'Live charge path')
        g = ttk.Frame(live, style='Card.TFrame'); g.pack(fill='x')
        cells = [('soc', 'SOC %'), ('volts', 'Pack V'), ('amps', 'Current A'), ('power', 'Power W'),
                 ('ctype', 'Type'), ('vl1', 'Mode L1'), ('vl2', 'Mode L2'), ('cmode', 'CC/CV'),
                 ('ilim', 'BMS I lim A'), ('vlim', 'BMS V lim'), ('avail_i', 'Chg avail A'),
                 ('crate', 'C-rate'), ('billing', 'Billing'), ('evse', 'EVSE id')]
        for i, (key, cap) in enumerate(cells):
            cell = ttk.Frame(g, style='Card.TFrame', padding=(4, 3))
            cell.grid(row=i // 4, column=i % 4, sticky='w', padx=4, pady=2)
            ttk.Label(cell, text=cap, style='MetricCap.TLabel').pack(anchor='w')
            ttk.Label(cell, textvariable=self._status_vars.setdefault(key, tk.StringVar(value='—')),
                      style='Card.TLabel', font=('Segoe UI Semibold', 11)).pack(anchor='w')
        ttk.Label(live, text='Start monitor to populate. Billing = 0x213 b6.2 (paid-session flag); '
                             'a home/slow charger leaves it clear.', style='CardMuted.TLabel',
                  wraplength=880).pack(anchor='w', pady=(6, 0))

        # --- show-as-fast display overlay --------------------------------------
        fc = self._card(p, 'Show as FAST charging (display overlay)')
        ttk.Label(fc, text='Relabels a REAL charge as Fast on the dash by injecting only the '
                           'display frames 0x62D (charger=Fast) and 0x143 (Level-2=FC_CHARGE '
                           'ACTIVE). The charge control frames (0x213/0x120/0x121) are never '
                           'touched, so the real SC charge is unaffected. It follows the charger: '
                           'the moment the charger CAN goes quiet/inactive (unplugged, powered off, '
                           'or link cut) the dash shows charging STOPPED and the overlay ends — it '
                           'will not fake charging on a dead bus. Start a real charge first '
                           '(SLOW + I 960 on the emulator), then Start monitor.',
                  style='CardMuted.TLabel', wraplength=880).pack(anchor='w', pady=(0, 6))
        fcrow = ttk.Frame(fc, style='Card.TFrame'); fcrow.pack(fill='x')
        ttk.Button(fcrow, text='Show as Fast charging', style='Accent.TButton',
                   command=self._force_fast_display).pack(side='left', padx=(0, 6))
        ttk.Button(fcrow, text='Stop overlay', command=self._stop_fast_display).pack(side='left')

        # --- charge commands (0x6BC) -------------------------------------------
        cmd = self._card(p, 'Charge commands (0x6BC → BCM, ack on 0x6C0)')
        ttk.Label(cmd, text='UNVERIFIED writes to a live vehicle (only high-beam / Ride_Now are '
                            'proven). Each sends ONE frame, no retry. Scooter in Park, charger '
                            'unplugged, active-tests enabled.', style='CardMuted.TLabel',
                  wraplength=880).pack(anchor='w', pady=(0, 6))
        crow = ttk.Frame(cmd, style='Card.TFrame'); crow.pack(fill='x')
        ttk.Button(crow, text='Stop Charge (13)', style='Danger.TButton',
                   command=lambda: self._charge_cmd(13)).pack(side='left', padx=(0, 6))
        ttk.Button(crow, text='Boost Disable (49)', style='Danger.TButton',
                   command=lambda: self._charge_cmd(49)).pack(side='left', padx=(0, 6))
        ttk.Button(crow, text='Boost Enable (48)', style='Danger.TButton',
                   command=lambda: self._charge_cmd(48)).pack(side='left', padx=(0, 6))

        # --- recovery ----------------------------------------------------------
        rc = self._card(p, 'Recover from stuck "charging" / paywall bug')
        ttk.Label(rc, text='If the HMI is stuck showing charging or "payment due" after emulation '
                           '(no real charge occurred), this sends Boost Disable (49) then Stop '
                           'Charge (13) to terminate the phantom session. If it does not clear, '
                           'the state is cloud-latched → use the Ola app force-reboot, or Ola '
                           'support (diagnostic session logged in error).',
                  style='CardMuted.TLabel', wraplength=880).pack(anchor='w', pady=(0, 6))
        ttk.Button(rc, text='Attempt recovery (49 → 13)…', style='Danger.TButton',
                   command=self._charge_recover).pack(anchor='w')

        # --- emulator reference ------------------------------------------------
        emu = self._card(p, 'Charger emulator (Arduino)')
        ttk.Label(emu, text='Emulating a charger is done on the charge-port CAN with '
                            'tool/charge_can_emulator/charger_emulator.ino (serial: SLOW / FAST / '
                            'BOOST / STOP). BOOST triggers the paid-session flag — expect the '
                            'paywall state and use recovery above afterwards.',
                  style='CardMuted.TLabel', wraplength=880).pack(anchor='w')

    def _force_fast_display(self):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Show as Fast', 'Connect over Wi‑Fi first.')
            return
        if not getattr(self.scooter, 'streaming', False):
            messagebox.showinfo('Show as Fast', 'Start the monitor (live dashboard) first so the '
                                'charger‑liveness signal (0x213) is available.')
            return
        if not self.bench.get():
            messagebox.showwarning('Show as Fast', 'Tick “Enable active tests — parked and charger '
                                   'unplugged” first.')
            return
        if not messagebox.askyesno('Show as Fast charging',
                'Inject the display frames 0x62D / 0x143 so the dash shows FAST charging over the '
                'real charge.\n\nDisplay only — the charge control frames are not touched. It '
                'auto‑stops and shows "charging stopped" the moment the charger CAN goes quiet.\n\n'
                'Proceed?', parent=self):
            return
        self.scooter.bench_confirmed = self.bench.get()
        self.run('Show as Fast charging',
                 lambda: self.scooter.force_fast_charge_display(hz=20),
                 lambda r: self.report(r))

    def _stop_fast_display(self):
        if not self.connected:
            return
        self.run('Stop Fast display',
                 lambda: self.scooter.stop_fast_charge_display(),
                 lambda r: self.report(r))

    def _charge_cmd(self, ordinal):
        import hmi_commands as hc
        if self.busy:
            return
        label = hc._LABEL_BY_ORDINAL.get(ordinal)
        if not label:
            messagebox.showerror('Charge command', f'Unknown command {ordinal}')
            return
        if not self.connected:
            messagebox.showinfo('Charge command', 'Connect over Wi‑Fi first.')
            return
        if not self.scooter.bench_confirmed:
            messagebox.showerror('Bench setup', 'Enable active tests (scooter parked, charger '
                                 'unplugged) in the main window first.')
            return
        if simpledialog.askstring('Confirm', f'{label}\n\nRED, UNVERIFIED — sends once, no undo.\n'
                                  'Type SEND to proceed:') != 'SEND':
            return
        self.run('HMI ' + label, lambda: hc.send_once(self.scooter, label),
                 lambda result: messagebox.showinfo('Charge command', result))

    def _charge_recover(self):
        import hmi_commands as hc
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Recovery', 'Connect over Wi‑Fi first.')
            return
        if not self.scooter.bench_confirmed:
            messagebox.showerror('Bench setup', 'Enable active tests (scooter parked) first.')
            return
        if simpledialog.askstring('Confirm recovery', 'Sends Boost Disable (49) then Stop Charge '
                                  '(13) — two RED, UNVERIFIED writes.\nType SEND to proceed:') != 'SEND':
            return
        def seq():
            out = []
            for o in (49, 13):
                lbl = hc._LABEL_BY_ORDINAL[o]
                try:
                    out.append(hc.send_once(self.scooter, lbl))
                except Exception as exc:
                    out.append(f'{lbl}: {exc}')
            return '\n\n'.join(out)
        self.run('Charge recovery', seq,
                 lambda result: messagebox.showinfo('Recovery result', result))

    def start_status_monitor(self):
        if not self.connected:
            messagebox.showinfo('Status', 'Connect over Wi‑Fi first.')
            return
        def done(_):
            self.status_on = True
            self.live = True  # reuse dump poll path
            self.replay = False
            self._logged_faults.clear()
            self._status_log.log('SYS', f'monitor start (mode={self.mode_text.get()})')
            self.status_mon_label.set('Monitor ON · vehicle CAN dump')
            self._refresh_status_log_view()
        self.run('Start status monitor', self.scooter.start_live, done)

    def stop_status_monitor(self):
        if self._charge_snoop:
            self.toggle_charge_snoop()
        self.status_on = False
        self.status_mon_label.set('Monitor off')
        self._status_log.log('SYS', 'monitor stop')
        self._refresh_status_log_view()

    def _clear_notifications(self):
        self._notif_seen = None
        if hasattr(self, 'notif_list'):
            self.notif_list.configure(state='normal')
            self.notif_list.delete('1.0', 'end')
            self.notif_list.configure(state='disabled')

    def _update_vehicle_notifications(self, snap):
        """Append a line to the 0x6D0 feed when the notification code changes."""
        if not hasattr(self, 'notif_list'):
            return
        result = decode_vehicle_notification(snap)
        code = None if not result else result[0]
        # Only act on a *change* of code (0x6D0 holds the last code until it changes).
        if code == getattr(self, '_notif_seen', None):
            return
        self._notif_seen = code
        if not result:
            return
        _, name, is_alert = result
        stamp = time.strftime('%H:%M:%S')
        line = f'{stamp}  [{code:>3}] {name}\n'
        self.notif_list.configure(state='normal')
        self.notif_list.insert('1.0', line, ('alert' if is_alert else 'info'))
        # Cap at ~200 lines.
        if int(self.notif_list.index('end-1c').split('.')[0]) > 200:
            self.notif_list.delete('200.0', 'end')
        self.notif_list.configure(state='disabled')
        self._status_log.log('NOTE', f'0x6D0 {name} ({code})')

    def _update_feature_status(self, snap):
        """Render the 0x660 feature/entitlement flags (only when they change)."""
        if not hasattr(self, 'feature_list'):
            return
        fs = decode_feature_status(snap)
        if not fs:
            return
        if fs['raw'] == getattr(self, '_feat_raw', None):
            return
        self._feat_raw = fs['raw']
        self._feat_bytes = fs.get('raw_bytes')
        self.feature_list.configure(state='normal')
        self.feature_list.delete('1.0', 'end')
        for name, on in fs['features'].items():
            self.feature_list.insert('end', f'{"●" if on else "○"} {name}\n',
                                     'on' if on else 'off')
        self.feature_list.insert('end', '\n')
        for name, val in fs['tech_packs'].items():
            self.feature_list.insert('end', f'{"●" if val else "○"} {name} = {val}\n',
                                     'on' if val else 'off')
        self.feature_list.configure(state='disabled')

    def _enable_feature_0660(self):
        if self.busy:
            return
        if not self.connected:
            messagebox.showinfo('Enable feature', 'Connect over Wi‑Fi first.')
            return
        if not self.bench.get():
            messagebox.showwarning('Enable feature', 'Tick “Enable active tests — parked and charger unplugged” first.')
            return
        name = self.feat_enable_choice.get()
        base = getattr(self, '_feat_bytes', None)
        if not base:
            messagebox.showwarning('Enable feature', 'No 0x660 frame seen yet — wait for the '
                                   'feature card to populate, then retry.')
            return
        hyper_note = ('\n\nNote: Hyper charge shows the UI only — actual hyper charging stays '
                      'cloud/payment-gated and will NOT be authorised by this.'
                      if name == 'Hyper charger' else '')
        if simpledialog.askstring(
                'Reveal feature UI (0x660 test)',
                f'Inject 0x660 so the head unit sees "{name}" available, to test whether its '
                f'built-in UI appears (it is normally suppressed only while dues are unpaid).\n\n'
                'This is a NON-PERSISTENT test: it re-injects for ~20 s, fights the real BCM '
                'broadcast, and reverts on stop/reboot. It does not change the cloud/BCM value.'
                f'{hyper_note}\n\nType SHOW to proceed:',
                parent=self) != 'SHOW':
            return
        self.scooter.bench_confirmed = self.bench.get()
        self.run(f'Reveal {name} UI (0x660)',
                 lambda: self.scooter.enable_feature_0660(name, base, value=1, seconds=20, hz=5),
                 lambda r: self.report(r))

    def _stop_feature_0660(self):
        if not self.connected:
            return
        self.run('Stop 0x660 injection',
                 lambda: self.scooter.stop_feature_0660(),
                 lambda r: self.report(r))

    def _toggle_vitals_log(self):
        on = self.auto_log_vitals.get()
        self._status_log.log('LIVE', 'vitals heartbeat ON' if on else 'vitals heartbeat OFF')
        self._refresh_status_log_view()

    def toggle_charge_snoop(self):
        if not self.connected:
            messagebox.showinfo('Charge snoop', 'Connect over Wi‑Fi first.')
            return
        if self._charge_snoop:
            path = self._charge_rec.stop()
            self._detach_charge_observer()
            self._charge_snoop = False
            if getattr(self, 'charge_btn', None):
                self.charge_btn.configure(text='● Record charge session')
            if getattr(self, 'charge_btn2', None):
                self.charge_btn2.configure(text='● Record charge session')
            self._status_log.log(
                'CHARGE',
                f'session stop → {path} frames={self._charge_rec.frames} vitals={self._charge_rec.vitals}',
            )
            self.report(f'Charge session saved: {path}')
            self._refresh_status_log_view()
            return
        if not self.status_on and not self.live:
            self.start_status_monitor()
        path = self._charge_rec.start()
        self._attach_charge_observer()
        self._charge_snoop = True
        if getattr(self, 'charge_btn', None):
            self.charge_btn.configure(text='■ Stop charge recording')
        if getattr(self, 'charge_btn2', None):
            self.charge_btn2.configure(text='■ Stop charge recording')
        self._status_log.log('CHARGE', f'session start → {path}')
        messagebox.showinfo(
            'Charge session',
            f'Recording charge-related IDs + vitals (SOC/V/A/contactor) to:\n{path}\n\n'
            'Plug Bolt Blaze (or Hyper) now. Keep Wi‑Fi connected.\n'
            'This is vehicle CAN — SC demand/status usually appear; '
            'SC auth 0x080 and full Hyper may need a charge-port tap.')
        self._refresh_status_log_view()

    def _attach_charge_observer(self):
        t = self.scooter.t
        if not t:
            return
        prev = t.observer
        rec = self._charge_rec
        def combined(stamp, cid, data):
            if prev:
                try:
                    prev(stamp, cid, data)
                except Exception:
                    pass
            try:
                rec.on_frame(stamp, cid, data)
            except Exception:
                pass
        with t.sample_lock:
            t.observer = combined
            t._charge_prev_observer = prev

    def _detach_charge_observer(self):
        t = self.scooter.t
        if not t:
            return
        with t.sample_lock:
            prev = getattr(t, '_charge_prev_observer', None)
            t.observer = prev
            if hasattr(t, '_charge_prev_observer'):
                del t._charge_prev_observer

    def open_status_logs(self):
        folder = Path(self._status_log.root)
        folder.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(folder))
        except OSError as exc:
            messagebox.showinfo('Logs', f'{folder}\n({exc})')

    def clear_status_log(self):
        if messagebox.askyesno('Clear log', 'Clear the current activity log session?'):
            self._status_log.clear()
            self._refresh_status_log_view()

    def export_status_log(self):
        path = filedialog.asksaveasfilename(
            initialdir=str(self._status_log.root), defaultextension='.txt',
            filetypes=[('Text', '*.txt'), ('All', '*.*')])
        if not path:
            return
        Path(path).write_text(self._status_log.export_text(), encoding='utf-8')
        self.report(f'Activity log exported: {path}')

    def _refresh_status_log_view(self):
        if not hasattr(self, 'status_log_view'):
            return
        self.status_log_view.configure(state='normal')
        self.status_log_view.delete('1.0', 'end')
        for ln in self._status_log.lines()[-200:]:
            self.status_log_view.insert('end', ln + '\n')
        self.status_log_view.see('end')
        self.status_log_view.configure(state='disabled')

    def _tick_status(self):
        if not self.status_on or not self.scooter.t:
            return
        with self.scooter.t.sample_lock:
            snap = dict(self.scooter.t.latest)
        if not snap:
            return
        dbc = self.scooter.dbc
        faults = active_faults(dbc, snap)
        for f in faults:
            if f not in self._logged_faults:
                self._status_log.log('FAULT', f'SET   {f}')
        for f in self._logged_faults:
            if f not in faults:
                self._status_log.log('FAULT', f'CLEAR {f}')
        self._logged_faults = set(faults)

        batt = decode_battery(dbc, snap)
        chg = enrich_power(decode_charge(dbc, snap), batt)
        extra = decode_charge_extra(snap)   # MoveOS 5 raw fields (billing, latch, EVSE id)
        # Prefer DBC-decoded type; fall back to the raw 0x62D 4-state decode (adds Boost).
        if not chg.get('charger_type') and extra.get('charger_type') not in (None, 'None'):
            chg['charger_type'] = extra['charger_type']
        if chg.get('plugged') is None:
            chg['plugged'] = extra.get('plugged')
        if batt:
            self._status_vars['soc'].set('—' if batt['soc'] is None else f"{batt['soc']:.0f}")
            self._status_vars['range'].set('—' if batt['range_km'] is None else f"{batt['range_km']:.0f}")
            self._status_vars['volts'].set('—' if batt['volts'] is None else f"{batt['volts']:.1f}")
            self._status_vars['amps'].set('—' if batt['amps'] is None else f"{batt['amps']:.1f}")
            label = '—'
            if batt['charger_connected']:
                label = 'Charging' if batt['charging'] else 'Connected'
            if chg.get('charger_type'):
                label = chg['charger_type'] + ('' if not batt['charging'] else ' · ON')
            if extra.get('billing'):
                label += ' · BILLED'
            if extra.get('connector_latched'):
                label += ' · latched'
            self._status_vars['chg'].set(label)
        if chg.get('power_w') is not None:
            self._status_vars['power'].set(f"{chg['power_w']:.0f}")
        else:
            self._status_vars['power'].set('—')

        self._status_vars['ctype'].set(chg.get('charger_type') or '—')
        self._status_vars['vl1'].set(chg.get('veh_l1') or '—')
        self._status_vars['vl2'].set(chg.get('veh_l2') or '—')
        self._status_vars['ilim'].set('—' if chg.get('charge_i_lim') is None else f"{chg['charge_i_lim']:.1f}")
        self._status_vars['vlim'].set('—' if chg.get('charge_v_lim') is None else f"{chg['charge_v_lim']:.2f}")
        self._status_vars['avail_i'].set('—' if chg.get('chg_avail_i') is None else f"{chg['chg_avail_i']:.1f}")
        self._status_vars['cmode'].set(chg.get('chg_mode') or '—')
        self._status_vars['crate'].set(chg.get('chg_rate') or '—')
        if 'billing' in self._status_vars:
            self._status_vars['billing'].set('YES (paid session)' if extra.get('billing') else 'no')
        if 'evse' in self._status_vars:
            self._status_vars['evse'].set(extra.get('evse_id') or '—')

        self.fault_list.configure(state='normal')
        self.fault_list.delete('1.0', 'end')
        if not faults:
            self.fault_list.insert('end', 'No active faults')
            self.fault_list.configure(fg=ACCENT)
        else:
            self.fault_list.configure(fg=DANGER)
            for f in sorted(faults):
                self.fault_list.insert('end', f'• {f}\n')
        self.fault_list.configure(state='disabled')

        self._update_vehicle_notifications(snap)
        self._update_feature_status(snap)

        if self._charge_snoop:
            fields = {
                'soc': None if not batt else batt.get('soc'),
                'range_km': None if not batt else batt.get('range_km'),
                'pack_v': None if not batt else batt.get('volts'),
                'pack_a': None if not batt else batt.get('amps'),
                'power_w': chg.get('power_w'),
                'charging': False if not batt else batt.get('charging'),
                'charger_connected': False if not batt else batt.get('charger_connected'),
                'charger_type': chg.get('charger_type'),
                'plugged': chg.get('plugged'),
                'contactor': chg.get('contactor'),
                'charge_v_lim': chg.get('charge_v_lim'),
                'charge_i_lim': chg.get('charge_i_lim'),
                'chg_avail_v': chg.get('chg_avail_v'),
                'chg_avail_i': chg.get('chg_avail_i'),
                'chg_mode': chg.get('chg_mode'),
                'chg_rate': chg.get('chg_rate'),
                'veh_l1': chg.get('veh_l1'),
                'veh_l2': chg.get('veh_l2'),
                'auth_err': chg.get('auth_err'),
                'sc_fault': chg.get('sc_fault'),
                'billing': extra.get('billing'),
                'connector_latched': extra.get('connector_latched'),
                'evse_id': extra.get('evse_id'),
                'motor_t': None if not batt else batt.get('motor_t'),
                'mcu_t': None if not batt else batt.get('mcu_t'),
                'active_faults': len(faults),
            }
            try:
                self._charge_rec.on_vitals(fields)
            except Exception:
                pass

        now = time.time()
        if self.auto_log_vitals.get() and batt and now - self._last_vitals_log > 30:
            self._last_vitals_log = now
            self._status_log.log(
                'LIVE',
                f"soc={batt.get('soc')} range={batt.get('range_km')} "
                f"V={batt.get('volts')} A={batt.get('amps')} chg={batt.get('charging')} "
                f"type={chg.get('charger_type')} ilim={chg.get('charge_i_lim')} "
                f"mode={chg.get('veh_l2')} faults={len(faults)}")
            self._refresh_status_log_view()
        elif faults != getattr(self, '_prev_fault_view', None):
            self._prev_fault_view = set(faults)
            self._refresh_status_log_view()

    def ble_page(self):
        p = self.pages['Bluetooth']
        ttk.Label(p, text='Bluetooth proximity control', style='H2.TLabel').pack(anchor='w', pady=(6, 2))
        ttk.Label(p, text='Consumer BLE path (seed/key + AES-CTR), independent of the Wi-Fi/gRPC link. '
                          'Pairs Just Works, then sends the same lock / unlock / trunk / flash commands as the phone app. '
                          'Own-vehicle use only.',
                  style='CardMuted.TLabel', wraplength=800).pack(anchor='w', pady=(0, 8))

        if ble is None or not ble.available():
            card = self._card(p, 'Bluetooth unavailable')
            ttk.Label(card, text='The WinRT Bluetooth stack is not importable in this Python.\n'
                                 'Install it with:  py -3 -m pip install bleak',
                      style='CardMuted.TLabel').pack(anchor='w')
            return

        dev = self._card(p, 'Device')
        self._ble_rows = []
        # Scanned-device picker (name — MAC (rssi)).
        pick = ttk.Frame(dev, style='Card.TFrame'); pick.pack(fill='x')
        ttk.Label(pick, text='Nearby device', style='Card.TLabel').pack(side='left')
        self.ble_combo = ttk.Combobox(pick, state='readonly', width=44)
        self.ble_combo.pack(side='left', padx=8)
        self.ble_combo.bind('<<ComboboxSelected>>', self._ble_pick)
        ttk.Button(pick, text='Scan', style='Chip.TButton', command=self._ble_scan).pack(side='left')
        # Manual address + pair.
        row = ttk.Frame(dev, style='Card.TFrame'); row.pack(fill='x', pady=(8, 0))
        ttk.Label(row, text='Address', style='Card.TLabel').pack(side='left')
        self.ble_mac = tk.StringVar(value=ble.DEFAULT_MAC)
        ttk.Entry(row, textvariable=self.ble_mac, width=22).pack(side='left', padx=8)
        ttk.Button(row, text='Pair', style='Accent.TButton', command=self._ble_pair).pack(side='left')
        self.ble_status = ttk.Label(dev, text='Close the Ola app and the phone’s Bluetooth so this PC can hold the link.',
                                    style='CardMuted.TLabel')
        self.ble_status.pack(anchor='w', pady=(8, 0))

        cmds = self._card(p, 'Commands')
        grid = ttk.Frame(cmds, style='Card.TFrame'); grid.pack(fill='x')
        buttons = [('Unlock', 'UNLOCK', 'Accent.TButton'), ('Lock', 'LOCK', 'Accent.TButton'),
                   ('Open trunk', 'TRUNK_OPEN', 'Accent.TButton'), ('Flash lights', 'FLASH', 'Chip.TButton'),
                   ('Flash + horn', 'FLASH_HORN', 'Chip.TButton')]
        for i, (label, cmd, style) in enumerate(buttons):
            ttk.Button(grid, text=label, style=style,
                       command=lambda c=cmd, l=label: self._ble_cmd(l, c)
                       ).grid(row=i // 3, column=i % 3, padx=6, pady=6, sticky='ew')
        for c in range(3):
            grid.columnconfigure(c, weight=1)
        ttk.Label(cmds, text='Unlock / lock / trunk / flash are verified on MY2022. Rapid clicks queue. '
                  'Silent unlock is not a tap command on this firmware. Snapshot: apk/BLE_CHECKPOINT.md.',
                  style='CardMuted.TLabel', wraplength=800).pack(anchor='w', pady=(8, 0))

    def _ble_pick(self, *_):
        i = self.ble_combo.current()
        if not (0 <= i < len(getattr(self, '_ble_rows', []))):
            return
        name, mac, rssi = self._ble_rows[i]
        self.ble_mac.set(mac)
        self.ble_status.config(
            text=f'Selected {name or "(unnamed)"} · {mac} · {rssi} dBm')

    def _ble_scan(self):
        self.ble_status.config(text='Scanning…')
        self.run('BLE scan', lambda: ble.scan_list(6.0), self._ble_scan_done)

    def _ble_scan_done(self, rows):
        self._ble_rows = list(rows or [])
        labels = []
        olas1_index = None
        for i, (name, mac, rssi) in enumerate(self._ble_rows):
            labels.append(f'{name or "(unnamed)"} — {mac} ({rssi} dBm)')
            if olas1_index is None and (name or '').lower() == 'olas1':
                olas1_index = i
        self.ble_combo['values'] = labels
        if olas1_index is not None:
            self.ble_combo.current(olas1_index)
            self._ble_pick()
            self.ble_status.config(text=f'Found OLAS1 at {self.ble_mac.get()}')
        elif self._ble_rows:
            self.ble_combo.current(0)
            self._ble_pick()
            self.ble_status.config(
                text=f'Found {len(self._ble_rows)} device(s) — pick one, or type the address')
        else:
            self.ble_combo.set('')
            self.ble_status.config(
                text='No BLE devices found (scooter awake? phones’ BT off?)')

    def _ble_pair(self):
        self.run('BLE pair', lambda: ble.pair(self.ble_mac.get().strip()),
                 lambda r: self.ble_status.config(text=f'Pair: {r}'))

    def _ble_cmd(self, label, cmd):
        if cmd in ('UNLOCK', 'LOCK', 'TRUNK_OPEN'):
            if not messagebox.askyesno(label, f'Send {label} to the scooter over Bluetooth?', parent=self):
                return
        if not hasattr(self, '_ble_q'):
            self._ble_q = []
        self._ble_q.append((label, cmd))
        waiting = len(self._ble_q) - 1
        if self.busy:
            self.ble_status.config(text=f'{label} queued' + (f' ({waiting} ahead)' if waiting else ''))
            return
        self._ble_drain()

    def _ble_drain(self):
        q = getattr(self, '_ble_q', None)
        if not q or self.busy:
            return
        label, cmd = q.pop(0)
        extra = f' · {len(q)} waiting' if q else ''
        self.ble_status.config(text=f'{label}…{extra}')
        mac = self.ble_mac.get().strip()
        self.run(f'BLE {label}',
                 lambda: ble.command(cmd, mac),
                 lambda r: self._ble_cmd_done(r))

    def _ble_cmd_done(self, result):
        self.ble_status.config(text=result)
        self.after(50, self._ble_drain)

    def mode_page(self):
        p = self.pages['1. Scooter mode']
        top = self._card(p, 'Operating mode')
        bar = ttk.Frame(top, style='Card.TFrame')
        bar.pack(fill='x')
        for label, style, fn in [
                ('Refresh', 'Act.TButton', lambda: self.run('Read mode', self.scooter.info, self.info)),
                ('Enter Service', 'Accent.TButton', lambda: self.set_mode('SERVICE')),
                ('Return to Customer', 'Act.TButton', lambda: self.set_mode('CUST'))]:
            ttk.Button(bar, text=label, style=style, command=fn).pack(side='left', padx=(0, 8))
        ttk.Label(top, style='CardMuted.TLabel', wraplength=1040,
                  text='Use Service mode for component tests. Confirm the physical response after each test. '
                       'Return to Customer mode when finished.'
                  ).pack(anchor='w', pady=(10, 0))

        extra = ttk.Frame(top)
        extra.pack(anchor='w', pady=(8, 0))
        ttk.Button(extra, text='Wi‑Fi Lock…', style='Act.TButton',
                   command=self.test_wifi_lock).pack(side='left', padx=(0, 8))
        ttk.Button(extra, text='Wi‑Fi Unlock…', style='Act.TButton',
                   command=self.test_wifi_unlock).pack(side='left', padx=(0, 8))
        ttk.Button(extra, text='Trunk (Seat Lock)…', style='Act.TButton',
                   command=self.test_wifi_trunk).pack(side='left', padx=(0, 8))
        ttk.Button(extra, text='BF07 sequence…', style='Act.TButton',
                   command=self.test_lock_sequence).pack(side='left', padx=(0, 8))
        ttk.Button(extra, text='Experimental HMI commands…', style='Act.TButton',
                   command=self.hmi_panel).pack(side='left')

        picker = ttk.Frame(p)
        picker.pack(fill='x', pady=(10, 8))
        self.actuator_group = tk.StringVar(value='Lights & signals')
        self.actuator_search = tk.StringVar()
        ttk.Label(picker, text='Test group', style='Muted.TLabel').pack(side='left', padx=(0, 8))
        group = ttk.Combobox(picker, textvariable=self.actuator_group,
                             values=['All groups', *ACTUATOR_GROUP_ORDER], state='readonly', width=25)
        group.pack(side='left')
        group.bind('<<ComboboxSelected>>', lambda _: self.filter_actuators())
        ttk.Label(picker, text='Search tests', style='Muted.TLabel').pack(side='left', padx=(20, 8))
        ttk.Entry(picker, textvariable=self.actuator_search).pack(side='left', fill='x', expand=True)
        self.actuator_search.trace_add('write', lambda *_: self.filter_actuators())

        content = ttk.Frame(p)
        content.pack(fill='both', expand=True)
        listing = ttk.Frame(content)
        listing.pack(side='left', fill='both', expand=True, padx=(0, 16))
        self.actuator_table = ttk.Treeview(listing, columns=('name', 'type'), show='headings', selectmode='browse', height=7)
        self.actuator_table.heading('name', text='Component test')
        self.actuator_table.heading('type', text='Confirmation')
        self.actuator_table.column('name', width=340, minwidth=170)
        self.actuator_table.column('type', width=110, minwidth=95, stretch=False)
        scroll = ttk.Scrollbar(listing, command=self.actuator_table.yview)
        self.actuator_table.configure(yscrollcommand=scroll.set)
        self.actuator_table.pack(side='left', fill='both', expand=True)
        scroll.pack(side='right', fill='y')
        self.actuator_table.tag_configure('danger', foreground=DANGER)
        self.actuator_table.bind('<<TreeviewSelect>>', self.select_actuator)
        detail = ttk.Frame(content, style='Card.TFrame', padding=18, width=300)
        detail.pack(side='right', fill='y')
        detail.pack_propagate(False)
        ttk.Label(detail, text='SELECTED TEST', style='MetricCap.TLabel').pack(anchor='w')
        self.selected_actuator = None
        self.actuator_title = tk.StringVar(value='Choose a component')
        self.actuator_detail = tk.StringVar(value='Select a test from the list. Selecting never sends a command.')
        ttk.Label(detail, textvariable=self.actuator_title, style='CardH2.TLabel', wraplength=264).pack(anchor='w', pady=(12, 8))
        ttk.Label(detail, textvariable=self.actuator_detail, style='CardMuted.TLabel', wraplength=264).pack(anchor='w')
        self.test_button = ttk.Button(detail, text='Run selected test…', style='Accent.TButton', command=self.run_selected_test, state='disabled')
        self.test_button.pack(side='bottom', fill='x', pady=(12, 0))
        self.actuator_count = tk.StringVar()
        bottom = ttk.Frame(p)
        bottom.pack(fill='x', pady=(10, 0))
        ttk.Label(bottom, textvariable=self.actuator_count, style='Muted.TLabel').pack(side='left')
        ttk.Button(bottom, text='Observe brake / side stand…', style='Chip.TButton', command=self.learn_signals).pack(side='right')
        self.filter_actuators()

    def filter_actuators(self):
        group, query = self.actuator_group.get(), self.actuator_search.get().strip().casefold()
        names = ACTUATORS if group == 'All groups' else ACTUATOR_GROUPS.get(group, [])
        previous = self.selected_actuator
        self.actuator_table.delete(*self.actuator_table.get_children())
        self.actuator_items = {}
        for i, name in enumerate(sorted(names)):
            if query not in f'{name} {ACTUATORS[name]:04X}'.casefold():
                continue
            iid = str(i)
            self.actuator_items[iid] = name
            self.actuator_table.insert('', 'end', iid=iid, values=(name, 'Type TEST' if name in ACTUATOR_DANGER else 'Confirm'),
                                       tags=('danger',) if name in ACTUATOR_DANGER else ())
            if name == previous:
                self.actuator_table.selection_set(iid)
        self.actuator_count.set(f'{len(self.actuator_items)} of {len(ACTUATORS)} tests · VCU')
        self.select_actuator()

    def select_actuator(self, event=None):
        selection = self.actuator_table.selection()
        name = self.actuator_items.get(selection[0]) if selection else None
        self.selected_actuator = name
        if not name:
            self.actuator_title.set('Choose a component')
            self.actuator_detail.set('Select a test from the list. Selecting never sends a command.')
            self.test_button.configure(state='disabled', style='Accent.TButton')
            return
        self.actuator_title.set(name)
        duration = '0.75 seconds' if name == 'Horn' else '2 seconds'
        note = ('Extra care: this test can switch power or move hardware. A typed confirmation is required.'
                if name in ACTUATOR_DANGER else 'You will confirm before the test runs. Check the physical response on the scooter.')
        self.actuator_detail.set(f'ON for {duration}, then OFF.\n\n{note}\n\nVCU · identifier {ACTUATORS[name]:04X}')
        self.test_button.configure(state='normal', style='Danger.TButton' if name in ACTUATOR_DANGER else 'Accent.TButton')

    def run_selected_test(self):
        if self.selected_actuator:
            self.test(self.selected_actuator)

    # Category -> lowercase keyword matchers for the Live Data quick filters.
    CATEGORIES = {
        'All': None,
        'Battery': ('soc', 'cell', 'pack', 'bms', 'contactor', 'charge', 'battery'),
        'Motor': ('mcu', 'motor', 'rpm', 'speed', 'torque', 'throttle', 'drive'),
        'Power': ('voltage', 'current', 'dcdc', 'dc_dc', 'bus', 'power'),
        'Temperature': ('temp',),
        'Faults': ('fault', 'error', 'warn', 'protect', 'abnormal', 'fail', 'inhibit', 'derate', 'timeout', 'disconnect', 'overcurrent', 'undervolt', 'overvolt'),
        'Vehicle': ('odom', 'mode', 'indicator', 'brake', 'light', 'horn', 'lamp', 'stand', 'lock'),
    }

    def live_page(self):
        p = self.pages['2. Live Data']
        bar = ttk.Frame(p)
        bar.pack(fill='x', pady=(2, 6))
        ttk.Button(bar, text='▶ Start live', style='Accent.TButton', command=self.start_live).pack(side='left', padx=(0, 6))
        for text, fn in [('Pause', self.pause_live), ('Open capture', self.replay_capture),
                         ('Export CSV', self.export), ('Learn signals…', self.learn_signals), ('App details…', self.app_details)]:
            ttk.Button(bar, text=text, style='Act.TButton', command=fn).pack(side='left', padx=(0, 6))
        self.live_status = tk.StringVar(value='Not streaming — press Start live')
        ttk.Label(p, textvariable=self.live_status, style='Muted.TLabel').pack(anchor='w', pady=(0, 3))

        cards = self._card(p)
        row = ttk.Frame(cards, style='Card.TFrame')
        row.pack(fill='x')
        self.metrics = {}
        for i, (key, label, unit) in enumerate([
                ('Overall_SOC', 'Battery SOC', '%'), ('MCU_Voltage', 'Bus voltage', 'V'),
                ('BMS0_Cell_Min_Voltage', 'Min cell', 'V'), ('BMS0_Cell_Max_Voltage', 'Max cell', 'V'),
                ('Motor_Temprature', 'Motor temp', '°C'), ('MCU_Temperatute', 'MCU temp', '°C')]):
            cell = ttk.Frame(row, style='Card.TFrame', padding=(6, 2))
            cell.grid(row=0, column=i, sticky='ew')
            row.columnconfigure(i, weight=1)
            ttk.Label(cell, text=label.upper(), style='MetricCap.TLabel').pack(anchor='w')
            var = tk.StringVar(value='—')
            self.metrics[key] = var
            ttk.Label(cell, textvariable=var, style='Metric.TLabel').pack(anchor='w')

        filt = ttk.Frame(p)
        filt.pack(fill='x', pady=(10, 4))
        self.category = tk.StringVar(value='All')
        self.category_buttons = {}
        for cat in self.CATEGORIES:
            button = ttk.Button(filt, text=cat, style='Selected.Chip.TButton' if cat == 'All' else 'Chip.TButton',
                                 command=lambda c=cat: self.set_category(c))
            button.pack(side='left', padx=(0, 5))
            self.category_buttons[cat] = button
        searchbar = ttk.Frame(p)
        searchbar.pack(fill='x', pady=(5, 8))
        self.search = tk.StringVar()
        ent = ttk.Entry(searchbar, textvariable=self.search, width=26)
        ttk.Label(searchbar, text='Find a signal', style='Muted.TLabel').pack(side='left', padx=(0, 8))
        ent.pack(side='left', fill='x', expand=True)
        self.search.trace_add('write', lambda *_: self.render_rows())

        frame = ttk.Frame(p)
        frame.pack(fill='both', expand=True)
        self.table = ttk.Treeview(frame, columns=('id', 'message', 'signal', 'value', 'unit', 'age'), show='headings')
        for col, label, width, anchor in [('id', 'CAN ID', 62, 'center'), ('message', 'Message', 220, 'w'),
                                          ('signal', 'Signal', 300, 'w'), ('value', 'Value', 100, 'e'),
                                          ('unit', 'Unit', 60, 'center'), ('age', 'Freshness', 95, 'center')]:
            self.table.heading(col, text=label)
            self.table.column(col, width=width, minwidth=55, anchor=anchor)
        scroll = ttk.Scrollbar(frame, command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side='left', fill='both', expand=True)
        scroll.pack(side='right', fill='y')
        self.table.tag_configure('stale', foreground='#9aa4b0')
        self.table.tag_configure('odd', background='#f6f8fb')

    def app_details(self):
        from diagnostic_pages import DetailsBrowser
        DetailsBrowser(self)

    def set_category(self, category):
        self.category.set(category)
        for name, button in self.category_buttons.items():
            button.configure(style='Selected.Chip.TButton' if name == category else 'Chip.TButton')
        self.render_rows()

    def write_page(self):
        p = self.pages['3. Write components']
        readc = self._card(p, 'Read a component identifier')
        bar = ttk.Frame(readc, style='Card.TFrame')
        bar.pack(fill='x', pady=(0, 2))
        self.ecu = tk.StringVar(value='MCU')
        self.did = tk.StringVar(value='B112')
        ttk.Label(bar, text='ECU', style='CardMuted.TLabel').pack(side='left')
        ttk.Combobox(bar, textvariable=self.ecu, values=['BMS', 'VCU', 'MCU'], state='readonly', width=7).pack(side='left', padx=8)
        ttk.Label(bar, text='DID (hex)', style='CardMuted.TLabel').pack(side='left')
        ttk.Entry(bar, textvariable=self.did, width=8).pack(side='left', padx=8)
        ttk.Button(bar, text='Read identifier', style='Accent.TButton', command=self.read_did).pack(side='left')
        ttk.Button(bar, text='Read faults', command=self.faults).pack(side='left', padx=(8, 0))
        ttk.Button(bar, text='Explicit session…', style='Act.TButton', command=self.open_session).pack(side='left', padx=8)
        ttk.Checkbutton(readc, style='Card.TCheckbutton', variable=self.unlock_access,
                        text='Request security access (seed/key) on the explicit session').pack(anchor='w', pady=(8, 0))
        setting_names = list(SETTINGS)
        self.setting = tk.StringVar(value=setting_names[0] if setting_names else '')
        chooser = ttk.Combobox(p, textvariable=self.setting, values=setting_names,
                               state='readonly' if setting_names else 'disabled')
        chooser.pack(fill='x', pady=8)
        chooser.bind('<<ComboboxSelected>>', lambda _: self.setting_changed())
        self.setting_note = tk.StringVar()
        ttk.Label(p, textvariable=self.setting_note, wraplength=1040).pack(anchor='w')
        self.form = ttk.Frame(p)
        self.form.pack(fill='x', pady=8)
        actions = ttk.Frame(p)
        actions.pack(fill='x')
        ttk.Button(actions, text='1. Read current MCU setting', command=self.read_setting).pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='Performance writes deferred', command=self.preview, state='disabled').pack(side='left')
        self.current_label = tk.StringVar(value='Read-only during basic control verification. Performance writes are deferred to the next phase.')
        ttk.Label(p, textvariable=self.current_label, wraplength=1030).pack(anchor='w', pady=8)
        ttk.Label(p, text='Performance writes and firmware flashing are not enabled in this console.',
                  style='Muted.TLabel', wraplength=820).pack(anchor='w', pady=(12, 0))
        if setting_names:
            self.setting_changed()
        else:
            self.setting_note = tk.StringVar(value='No repair parameter definitions are bundled with this public archive. The source metadata must be supplied separately before these controls are available.')
            ttk.Label(p, textvariable=self.setting_note, wraplength=900).pack(anchor='w', pady=8)

    def setting_changed(self):
        self.current = None
        for child in self.form.winfo_children():
            child.destroy()
        name = self.setting.get()
        d = SETTINGS[name]
        self.setting_note.set(f'MCU • {d["RequestFormat"]} • Extracted definition, not bench-validated. ' +
                              ('Limp-home percentage only; this is not the road-speed limit.' if 'Limp' in name else
                               'Regen current limits are percentages, not kW. Unselected fields retain their current bytes.'))
        self.fields = []
        for i, par in enumerate(d['Parameters']):
            selected, value = tk.BooleanVar(), tk.StringVar()
            ttk.Checkbutton(self.form, text=par['Parameter'].strip(), variable=selected, state='disabled').grid(row=i, column=0, sticky='w', pady=5)
            ttk.Entry(self.form, textvariable=value, width=12, state='readonly').grid(row=i, column=1, padx=12)
            ttk.Label(self.form, text=f'{par["Unit"]}  |  source range {par["Physical Minimum"]}–{par["Physical Maximum"]}').grid(row=i, column=2, sticky='w')
            self.fields.append((par['Parameter'], selected, value))
        if hasattr(self, 'current_label'):
            self.current_label.set('Read-only during basic control verification. Source ranges are not verified vehicle operating limits.')

    def report(self, text):
        self.status.set(text)
        self.log.configure(state='normal')
        self.log.insert('end', time.strftime('%H:%M:%S ') + text + '\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def run(self, label, fn, done=None, quiet=False):
        if self.busy:
            if not quiet:
                self.report('Wait for the current operation to finish.')
            return
        self.busy = True
        self.scooter.bench_confirmed = self.bench.get()
        if not quiet:
            self.report(label + '…')
            self._status_log.log('CMD', f'START  {label}')
            self._refresh_status_log_view()
        def work():
            tracked = not quiet or label.startswith('Analyze')
            trace_path = None
            try:
                if tracked:
                    trace_path = self.scooter.trace.begin(label)
                    audit('operation-start', label)
                result = fn()
                if tracked:
                    summary = {'items': len(result)} if isinstance(result, list) else result
                    if isinstance(result, dict) and 'changed_unverified' in result:
                        summary = {'candidates': len(result['candidates']), 'changed_unverified': len(result['changed_unverified']),
                                   'quality': result['quality'], 'issues': result['issues']}
                    self.scooter.trace.end(result=str(summary))
                    audit('operation-result', {'operation': label, 'result': str(summary), 'protocol_trace': trace_path})
                self.results.put((label, result, None, done, quiet))
            except Exception as exc:
                error = str(exc) or type(exc).__name__
                if tracked and self.scooter.trace.active:
                    try:
                        self.scooter.trace.end(error=error)
                    except Exception as trace_error:
                        error += '; trace error: ' + str(trace_error)
                try:
                    audit('operation-error', {'operation': label, 'error': error, 'protocol_trace': trace_path})
                except OSError:
                    pass
                self.results.put((label, None, error, done, quiet))
        threading.Thread(target=work, daemon=True).start()

    def tick(self):
        try:
            label, result, error, done, quiet = self.results.get_nowait()
            self.busy = False
            if error:
                self.live = False
                self.report(f'{label} failed: {error}')
                if not quiet:
                    self._status_log.log('CMD', f'FAIL  {label} → {error}')
                    self._refresh_status_log_view()
                    messagebox.showerror(label, error)
                if getattr(self, '_ble_q', None):
                    self.after(50, self._ble_drain)
            else:
                if done:
                    try:
                        done(result)
                    except Exception as exc:
                        self.report(f'{label}: display error: {exc}')
                if self.closed:
                    return
                if not quiet:
                    summary = result if isinstance(result, str) else 'completed'
                    self.report(f'{label}: {summary}')
                    self._status_log.log('CMD', f'OK    {label} → {summary}')
                    self._refresh_status_log_view()
        except queue.Empty:
            pass
        if self.closed:
            return
        if self.closing and not self.busy:
            self.closing = False
            self.run('Disconnect', self.scooter.disconnect, lambda _: self.finish_close())
            self.after(100, self.tick)
            return
        if self.live and not self.busy and time.monotonic() >= self.next_poll:
            self.next_poll = time.monotonic() + 1.5
            self.run('Live stream', self.scooter.samples, self.accept_rows, quiet=True)
        try:
            self._tick_status()
        except Exception:
            pass
        self.render_rows()
        self.after(500, self.tick)

    def info(self, data):
        self.connected = True
        self.mode_text.set(f'Mode: {data["mode"]}  |  Firmware: {data["firmware"]}')

    def connect(self):
        if self.busy:
            return
        host, port, secure = self.host.get(), self.port.get(), self.secure.get()
        if not host.strip():
            messagebox.showinfo('Scooter Wi-Fi connection', 'Enter the scooter Wi-Fi host in Connection settings before connecting.')
            return
        self.live = False
        self.current = None
        self.connected = False
        self.mode_text.set('Connecting • mode and firmware unknown')
        self._status_log.begin_session(f'{host}:{port}')
        self._refresh_status_log_view()
        def after_connect(data):
            self.info(data)
            self._status_log.log('CONN', f"connected mode={data.get('mode')} fw={data.get('firmware')}")
            self._refresh_status_log_view()
        self.run('Connect', lambda: self.scooter.connect(host, port, secure), after_connect)

    def disconnect(self):
        if self.busy:
            self.report('Wait for the operation and test cleanup before disconnecting.')
            return
        if self._charge_snoop:
            self.toggle_charge_snoop()
        self.status_on = False
        self.live = False
        def done(_):
            self.connected = False
            self.current = None
            self.mode_text.set('Disconnected • mode unknown')
            self.status_mon_label.set('Monitor off')
            self._status_log.end_session('disconnect')
            self._refresh_status_log_view()
        self.run('Disconnect', self.scooter.disconnect, done)

    def set_mode(self, mode):
        if self.busy:
            return
        if messagebox.askyesno('Change scooter mode', f'Set the scooter to {mode}?\nPark the scooter. Service mode changes diagnostic access and vehicle behaviour.'):
            self.current = None
            self.run('Set ' + mode, lambda: self.scooter.mode(mode), self.info)

    def hmi_panel(self):
        from hmi_commands import open_panel
        open_panel(self)

    def test_lock_sequence(self):
        if self.busy:
            return
        if not messagebox.askyesno('BF07 lock/unlock sequence',
                'Run VCU routine BF07 over Wi‑Fi?\n\n'
                'Undirected sequence (not separate Lock/Unlock). Final state unverified.\n'
                'Prefer Wi‑Fi Lock / Unlock / Trunk buttons, or the Bluetooth tab for consumer lock.',
                parent=self):
            return
        self.run('BF07 sequence', self.scooter.lock_unlock_sequence)

    def test_wifi_lock(self):
        if self.busy:
            return
        if not messagebox.askyesno('Wi‑Fi Lock',
                'Send experimental Wi‑Fi Lock (Steering Lock 0400 ON + BF07)?\n'
                'Check the scooter physically afterward.', parent=self):
            return
        self.run('Wi‑Fi Lock', self.scooter.wifi_lock)

    def test_wifi_unlock(self):
        if self.busy:
            return
        if not messagebox.askyesno('Wi‑Fi Unlock',
                'Send experimental Wi‑Fi Unlock (Steering Lock 0400 OFF + BF07)?\n'
                'Check the scooter physically afterward.', parent=self):
            return
        self.run('Wi‑Fi Unlock', self.scooter.wifi_unlock)

    def test_wifi_trunk(self):
        if self.busy:
            return
        if not messagebox.askyesno('Trunk (Wi‑Fi)',
                'Pulse Seat Lock 0402 over Wi‑Fi (trunk)?\n'
                'Same path as the Scooter Seat Lock actuator.', parent=self):
            return
        self.run('Trunk Wi‑Fi', self.scooter.wifi_trunk_pulse)

    def test(self, name):
        if self.busy:
            return
        did = ACTUATORS[name]
        if name in ACTUATOR_DANGER:
            if simpledialog.askstring('Confirm risky actuator',
                    f'{name}  (VCU DID {did:04X})\n\n'
                    'This drives a contactor, lock, charger or power rail — it can move hardware '
                    'or switch power even with the scooter parked. Only proceed if you know exactly '
                    'what this output does.\n\nType the word TEST to pulse it:', parent=self) != 'TEST':
                return
        elif not messagebox.askyesno('Actuator test',
                f'Test {name} on the VCU now?  (DID {did:04X})\n\n'
                'Needs Service mode and a parked scooter. The VCU is unlocked automatically and held '
                'open by a keepalive; the test sends ON, holds ~2 s, then OFF.\n\n'
                'An acknowledgement confirms a command response, not that the part physically moved.'):
            return
        self.run(name + ' test', lambda: self.scooter.pulse(name))

    def learn_signals(self):
        from learning_gui import LearningWindow
        LearningWindow(self)

    def faults(self):
        ecu = Ecu[self.ecu.get()]
        def read():
            return json.dumps(self.scooter.read_faults(ecu), indent=2)
        self.run(f'{ecu.name} faults', read, lambda r: messagebox.showinfo('Stored faults', r))

    def start_live(self):
        def done(_):
            self.live, self.replay = True, False
            self.rows.clear()
        self.run('Start live data', self.scooter.start_live, done)

    def pause_live(self):
        self.live = False
        self.report('Display paused. Received values age; CAN reader remains available for diagnostics.')

    def accept_rows(self, rows):
        for row in rows:
            self.rows[(row[0], row[2])] = row

    def render_rows(self):
        if not hasattr(self, 'table'):
            return
        now = time.time()
        fresh = 0
        for var in self.metrics.values():
            var.set('—')
        query = self.search.get().lower()
        cat_kw = self.CATEGORIES.get(self.category.get()) if hasattr(self, 'category') else None
        desired = set()
        shown = 0
        for key, row in self.rows.items():
            cid, msg, signal, value, unit, stamp = row
            stale = self.replay or now - stamp > 3
            fresh += int(not stale)
            if signal in self.metrics:
                self.metrics[signal].set(f'{value} {unit}' if not stale else ('OFFLINE' if self.replay else 'STALE'))
            hay = f'{cid} {msg} {signal}'.lower()
            if cat_kw and not any(k in hay for k in cat_kw):
                continue
            if query and query not in hay:
                continue
            iid = cid + ':' + signal
            desired.add(iid)
            stripe = 'odd' if shown % 2 else 'even'
            shown += 1
            tags = ('stale', stripe) if stale else (stripe,)
            vals = (cid, msg, signal, value, unit, 'OFFLINE' if self.replay else f'{now - stamp:.1f}s' + (' stale' if stale else ''))
            if self.table.exists(iid):
                self.table.item(iid, values=vals, tags=tags)
            else:
                self.table.insert('', 'end', iid=iid, values=vals, tags=tags)
        for iid in self.table.get_children():
            if iid not in desired:
                self.table.delete(iid)
        state = 'OFFLINE CAPTURE' if self.replay else 'LIVE' if self.live else 'PAUSED'
        cat = self.category.get() if hasattr(self, 'category') else 'All'
        self.live_status.set(f'{state} · {shown} shown ({cat}) · {fresh} fresh / {len(self.rows)} signals')

    def replay_capture(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(initialdir=ROOT / 'captures', filetypes=[('Capture JSON', '*.json')])
        if not path:
            return
        try:
            with open(path, encoding='utf-8-sig') as f:
                data = json.load(f)
            rows = []
            for cid, msg in data['decoded'].items():
                for name, signal in msg['signals'].items():
                    rows.append((cid.replace('0x', ''), msg['message'], name, signal['value'], signal.get('units', ''), 0))
            self.live, self.replay = False, True
            self.rows.clear()
            self.accept_rows(rows)
        except Exception as exc:
            messagebox.showerror('Capture', str(exc))

    def export(self):
        path = filedialog.asksaveasfilename(initialdir=ROOT / 'captures', defaultextension='.csv', filetypes=[('CSV', '*.csv')])
        if not path:
            return
        try:
            with open(path, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)
                writer.writerow(['CAN ID', 'Message', 'Signal', 'Value', 'Unit', 'Received Unix time', 'Source'])
                writer.writerows([*row, 'offline capture' if self.replay else 'live session'] for row in self.rows.values())
            self.report('Exported ' + path)
        except OSError as exc:
            messagebox.showerror('Export', str(exc))

    def read_did(self):
        try:
            did = bytes.fromhex(self.did.get())
            if len(did) != 2:
                raise ValueError('DID must contain exactly four hex digits')
            ecu = Ecu[self.ecu.get()]
            self.run(f'Read {ecu.name} {did.hex().upper()} (no session change)', lambda: self.scooter.read(ecu, did),
                     lambda r: messagebox.showinfo('Component response', f'{ecu.name} / {did.hex().upper()}\nData bytes: {r.hex(" ")}'))
        except ValueError as exc:
            messagebox.showerror('Identifier', str(exc))

    def read_setting(self):
        name = self.setting.get()
        definition = SETTINGS[name]
        did = bytes.fromhex(definition['RequestFormat'])[1:]
        def done(raw):
            if self.setting.get() != name:
                return
            try:
                values = decode_setting(definition, raw)
                self.current = (name, raw)
                for key, selected, var in self.fields:
                    var.set(str(values[key]))
                    selected.set(False)
                self.current_label.set(f'Current MCU bytes: {raw.hex(" ")} • Performance editing is deferred until basic controls are verified.')
            except ValueError as exc:
                self.current = None
                messagebox.showerror('Definition mismatch', str(exc))
        self.run('Read ' + name + ' (no session change)', lambda: self.scooter.read(Ecu.MCU, did), done)

    def open_session(self):
        if self.busy:
            return
        ecu, unlock = Ecu[self.ecu.get()], self.unlock_access.get()
        if not messagebox.askyesno('State-changing diagnostic session',
                f'Enter extended diagnostic session on {ecu.name}?\nSecurity access: {"requested" if unlock else "not requested"}.\n'
                'This sends 10 03 before any security request. Previous identifier reads interrupted charging. '
                'Charger must be disconnected and scooter parked. The session may affect contactors or vehicle operation.\n'
                'Ordinary Read identifier / Read faults buttons no longer send this request.'):
            return
        self.run(f'Explicit {ecu.name} session', lambda: self.scooter.open_diagnostic_session(ecu, unlock))

    def preview(self):
        messagebox.showinfo('Deferred phase', 'Performance writes are disabled in this GUI until horn, lights and physical input checks are verified.')

    def _preview_performance_setting_next_phase(self):
        """Retained implementation; not wired to any current GUI control."""
        if self.busy:
            return
        try:
            name = self.setting.get()
            if self.current is None or self.current[0] != name:
                raise ValueError('Read the current setting first')
            before = self.current[1]
            values = {key: var.get() for key, selected, var in self.fields if selected.get()}
            after = encode_setting(SETTINGS[name], values, before)
            if after == before:
                raise ValueError('No value changed')
            old = decode_setting(SETTINGS[name], before)
            unlock = self.unlock_access.get()
            changes = '\n'.join(f'{key.strip()}: {old[key]} → {value}' for key, value in values.items())
            detail = (f'MCU • {name}\n{changes}\n\nBefore: {before.hex(" ")}\nAfter: {after.hex(" ")}\n\n'
                      'This changes vehicle behaviour and may persist. Regen affects braking; limp-home changes fault-mode behaviour. '
                      'The extracted ranges are not validated vehicle limits. Park the scooter. '
                      f'No automatic retry or rollback will be sent. Diagnostic access: {"enabled" if unlock else "disabled"}.\n\nType WRITE MCU to send this exact change:')
            if simpledialog.askstring('Review critical write', detail, parent=self) != 'WRITE MCU':
                return
            self.current = None
            self.run('Write ' + name, lambda: self.scooter.write_setting(name, before, after, unlock),
                     lambda r: messagebox.showinfo('Write result', r))
        except (ValueError, ArithmeticError) as exc:
            messagebox.showerror('Write preview', str(exc))

    def close(self):
        self.live = False
        self.status_on = False
        if self._charge_snoop:
            try:
                self._charge_rec.stop()
                self._detach_charge_observer()
            except Exception:
                pass
            self._charge_snoop = False
        self.closing = True
        self.report('Closing after the current command and actuator OFF attempt finish…')

    def finish_close(self):
        self.scooter.trace.close()
        self.closed = True
        self.destroy()


if __name__ == '__main__':
    App().mainloop()
