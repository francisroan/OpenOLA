"""
Read-only probe of the wifican gRPC service beyond raw CAN. Tells us the
vehicle operation mode and software identity, and whether the high-level
command surface responds. NOTHING here changes vehicle state.

Usage:  python probe_grpc.py <host> <port> [secure]
"""
import sys
from oladiag.transport import WifiCanTransport
from google.protobuf import empty_pb2

def E(): return empty_pb2.Empty()

def main():
    host = sys.argv[1] if len(sys.argv) > 1 else "192.168.4.1"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 50005
    secure = len(sys.argv) > 3 and sys.argv[3].lower() == "secure"
    t = WifiCanTransport(host, port, secure=secure); t.connect()
    stub = t.stub
    print(f"Probing {host}:{port} (read-only)\n" + "="*56)

    def call(label, fn):
        try:
            r = fn()
            print(f"[ok]   {label}:\n       {str(r).strip() or '(empty)'}")
        except Exception as e:
            print(f"[fail] {label}: {type(e).__name__}: {str(e)[:120]}")
        print("-"*56)

    call("GetVehicleOperationMode", lambda: stub.GetVehicleOperationMode(E()))
    call("GetSwVersion",           lambda: stub.GetSwVersion(E()))
    call("GetAospVersion",         lambda: stub.GetAospVersion(E()))
    call("GetVehicleIdentifiers",  lambda: stub.GetVehicleIdentifiers(E()))
    t.close()
    print("\nDone. If GetVehicleOperationMode returned a mode, we can (carefully)")
    print("set SERVICE mode next to try to unlock UDS. If these all failed, the")
    print("server only speaks the raw-CAN endpoints and we stay on broadcast reads.")

if __name__ == "__main__":
    main()
