"""
Ola S1 command toolkit - full read/write over the wifican gRPC bridge.
No ADB, no Ola servers. Reuses the verified transport + UDS layers.

    python olacmd.py <host> <port> [--secure] <command> [args...]

Commands are grouped by RISK. Amber/red commands require typing a confirm
phrase (or passing --yes-i-am-sure) so nothing destructive happens by accident.

  READ (green):
    info                 mode + versions + VIN/identifiers
    mode                 current vehicle operation mode
    sniff [secs]         count live CAN frames (bus alive?)
    faults [secs]        active broadcast fault bits
    watch                 live fault-bit transitions, Ctrl+C to stop
    dump [secs]          decode every signal -> captures\alldata.*

  TESTS (green - actuator/self tests, momentary):
    test <lcd|gps|bt|ble|wifi|spkr|mic|esim> <start|stop>
    vin-get              read VIN via test channel

  MODE / DIAG (amber - reversible, needed to unlock UDS):
    set-mode <mfg|cust|service>     switch operation mode
    read-dtc [bms|vcu|mcu]          UDS stored DTCs (needs service mode)
    clear-dtc <bms|vcu|mcu>         clear stored DTCs
    ecu-reset <bms|vcu|mcu>         UDS hard reset (11 01)
    actuate <name> [ms]             pulse a VCU output (horn/lights) on then off
                                    names: horn headunit lowbeam highbeam rind
                                    lind brake poslight boot  (needs service mode)

  RAW / DANGER (red - can brick or lock the vehicle):
    can-send <canid_hex> <data_hex>     inject one raw CAN frame
    set-mode decommissioned             permanently retires the vehicle
    sw-update <all|bms|mcu|...> trigger  start a firmware update
    mcu-cal <start|stop>                 motor recalibration

Green runs immediately. Amber needs --yes. Red needs --yes AND the exact
--confirm "<phrase>" the tool prints.
"""
import sys, time, json, os
from oladiag.transport import WifiCanTransport
from oladiag.uds import UdsClient, UdsError, TesterPresentKeepalive
from oladiag.seedkey import Ecu
from oladiag.wifican import wifican_pb2 as pb
from google.protobuf import empty_pb2

def E(): return empty_pb2.Empty()

RISK = {}  # filled by decorator
def cmd(name, risk):
    def deco(fn): RISK[name] = (risk, fn); return fn
    return deco

# ---------------- argument plumbing ----------------
class Ctx:
    def __init__(self, args):
        self.host = ""; self.port = 50005; self.secure = False
        self.yes = "--yes" in args or "--yes-i-am-sure" in args
        self.confirm = None
        if "--confirm" in args:
            i = args.index("--confirm"); self.confirm = args[i+1] if i+1 < len(args) else None
        # positional (strip flags + their values)
        pos = []
        skip = False
        for i, a in enumerate(args):
            if skip: skip = False; continue
            if a == "--confirm": skip = True; continue
            if a.startswith("--"): continue
            pos.append(a)
        # host/port if they look like it
        if pos and (pos[0].count(".") == 3 or pos[0] == "localhost"):
            self.host = pos.pop(0)
            if pos and pos[0].isdigit(): self.port = int(pos.pop(0))
        if "--secure" in args: self.secure = True
        self.pos = pos
        self.cmd = pos[0] if pos else "info"
        self.rest = pos[1:]
    def connect(self):
        self.t = WifiCanTransport(self.host, self.port, secure=self.secure); self.t.connect()
        return self.t

def need_confirm(ctx, risk, phrase):
    if risk == "green": return True
    if not ctx.yes:
        print(f"  [{risk.upper()}] This needs confirmation. Re-run with --yes", end="")
        if risk == "red": print(f' --confirm "{phrase}"')
        else: print()
        return False
    if risk == "red" and ctx.confirm != phrase:
        print(f'  [RED] Also pass exactly: --confirm "{phrase}"'); return False
    return True

# ---------------- READ ----------------
@cmd("info", "green")
def c_info(ctx):
    t = ctx.connect(); s = t.stub
    print("mode      :", s.GetVehicleOperationMode(E()).cur_mode)
    print("sw        :", s.GetSwVersion(E()).status_msg.replace("\n", " / "))
    print("aosp      :", s.GetAospVersion(E()).status_msg)
    print("identity  :", s.GetVehicleIdentifiers(E()).manifest_json)
    t.close()

@cmd("mode", "green")
def c_mode(ctx):
    t = ctx.connect(); m = t.stub.GetVehicleOperationMode(E())
    print("current mode:", m.cur_mode, "| set", m.modified_ts_str, "| by", m.modified_by)
    t.close()

@cmd("faults", "green")
def c_faults(ctx):
    secs = int(ctx.rest[0]) if ctx.rest else 10
    os.system(f'"{sys.executable}" faults_live.py {ctx.host} {ctx.port} {secs} '
              f'{"secure" if ctx.secure else ""}')

@cmd("dump", "green")
def c_dump(ctx):
    secs = int(ctx.rest[0]) if ctx.rest else 12
    os.system(f'"{sys.executable}" alldata.py {ctx.host} {ctx.port} {secs} '
              f'{"secure" if ctx.secure else ""}')

@cmd("watch", "green")
def c_watch(ctx):
    os.system(f'"{sys.executable}" watch.py {ctx.host} {ctx.port} '
              f'{"secure" if ctx.secure else ""}')

@cmd("sniff", "green")
def c_sniff(ctx):
    secs = int(ctx.rest[0]) if ctx.rest else 8
    os.system(f'"{sys.executable}" sniff.py {ctx.host} {ctx.port} {secs} '
              f'{"secure" if ctx.secure else ""}')

# ---------------- TESTS ----------------
_TESTMAP = {
    "lcd":  (pb.RMT_CMD_LCD_TEST,  "sub_cmd_lcd",  pb.RMT_SUB_CMD_LCD_TEST_START,  pb.RMT_SUB_CMD_LCD_TEST_STOP),
    "gps":  (pb.RMT_CMD_GPS_TEST,  "sub_cmd_gps",  pb.RMT_SUB_CMD_GPS_TEST_START,  pb.RMT_SUB_CMD_GPS_TEST_STOP),
    "bt":   (pb.RMT_CMD_BT_TEST,   "sub_cmd_bt",   pb.RMT_SUB_CMD_BT_TEST_START,   pb.RMT_SUB_CMD_BT_TEST_STOP),
    "ble":  (pb.RMT_CMD_BLE_TEST,  "sub_cmd_ble",  pb.RMT_SUB_CMD_BLE_TEST_START,  pb.RMT_SUB_CMD_BLE_TEST_STOP),
    "wifi": (pb.RMT_CMD_WIFI_TEST, "sub_cmd_wifi", pb.RMT_SUB_CMD_WIFI_TEST_START, pb.RMT_SUB_CMD_WIFI_TEST_STOP),
    "spkr": (pb.RMT_CMD_SPKR_TEST, "sub_cmd_spkr", pb.RMT_SUB_CMD_SPKR_TEST_START, pb.RMT_SUB_CMD_SPRK_TEST_STOP),
    "mic":  (pb.RMT_CMD_MIC_TEST,  "sub_cmd_mic",  pb.RMT_SUB_CMD_MIC_TEST_START,  pb.RMT_SUB_CMD_MIC_TEST_STOP),
    "esim": (pb.RMT_CMD_ESIM_TEST, "sub_cmd_esim", pb.RMT_SUB_CMD_ESIM_TEST_START, pb.RMT_SUB_CMD_ESIM_TEST_STOP),
}
@cmd("test", "green")
def c_test(ctx):
    if len(ctx.rest) < 2 or ctx.rest[0] not in _TESTMAP:
        print("usage: test <lcd|gps|bt|ble|wifi|spkr|mic|esim> <start|stop>"); return
    name, action = ctx.rest[0], ctx.rest[1]
    cid, field, start, stop = _TESTMAP[name]
    req = pb.RmtCmdReq(cmd_id=cid)
    setattr(req, field, start if action == "start" else stop)
    t = ctx.connect(); r = t.stub.RemoteRunTestCmd(req)
    print(f"{name} {action}: status={r.resp_status} {r.resp_str}"); t.close()

@cmd("vin-get", "green")
def c_vinget(ctx):
    req = pb.RmtCmdReq(cmd_id=pb.RMT_CMD_VIN, sub_cmd_vin=pb.RMT_SUB_CMD_VIN_GET)
    t = ctx.connect(); r = t.stub.RemoteRunTestCmd(req)
    print("VIN:", r.resp_str or r.resp_bytes); t.close()

# ---------------- MODE / UDS (amber) ----------------
_MODE = {"mfg": pb.VEHICLE_OP_STATE_MFG, "cust": pb.VEHICLE_OP_STATE_CUST,
         "service": pb.VEHICLE_OP_STATE_SERVICE, "decommissioned": pb.VEHICLE_OP_STATE_DECOMMISSIONED}
@cmd("set-mode", "amber")
def c_setmode(ctx):
    if not ctx.rest or ctx.rest[0] not in _MODE:
        print("usage: set-mode <mfg|cust|service|decommissioned>"); return
    target = ctx.rest[0]
    risk = "red" if target == "decommissioned" else "amber"
    if not need_confirm(ctx, risk, "DECOMMISSION THIS VEHICLE"): return
    t = ctx.connect()
    r = t.stub.SetVehicleOperationMode(pb.VehicleOperationMode(cur_mode=_MODE[target]))
    print(f"set-mode {target}: {r.status} {r.status_msg}")
    print("now:", t.stub.GetVehicleOperationMode(E()).cur_mode)
    t.close()

def _ecu(name): return {"bms": Ecu.BMS, "vcu": Ecu.VCU, "mcu": Ecu.MCU}[name.lower()]

@cmd("read-dtc", "amber")
def c_readdtc(ctx):
    if not need_confirm(ctx, "amber", ""): return
    t = ctx.connect()
    try: t.init([e.req_id for e in Ecu] + [e.resp_id for e in Ecu])
    except Exception: pass
    t.start_reader(dump=False)
    u = UdsClient(t)
    ecus = [_ecu(ctx.rest[0])] if ctx.rest else list(Ecu)
    for ecu in ecus:
        try:
            u.enter_extended_session(ecu); f = u.read_dtcs(ecu)
            print(f"{ecu.name}: {len(f)} DTC(s)")
            for x in f: print(f"   {x['code']}  {x['description']}  {x['status_flags']}")
        except UdsError as e: print(f"{ecu.name}: {e}")
    t.close()

@cmd("clear-dtc", "amber")
def c_cleardtc(ctx):
    if not ctx.rest: print("usage: clear-dtc <bms|vcu|mcu>"); return
    if not need_confirm(ctx, "amber", ""): return
    ecu = _ecu(ctx.rest[0]); t = ctx.connect(); t.start_reader(dump=False)
    u = UdsClient(t)
    try:
        u.enter_extended_session(ecu); u.clear_dtcs(ecu); print(f"{ecu.name}: cleared")
    except UdsError as e: print(f"{ecu.name}: {e}")
    t.close()

@cmd("ecu-reset", "amber")
def c_reset(ctx):
    if not ctx.rest: print("usage: ecu-reset <bms|vcu|mcu>"); return
    if not need_confirm(ctx, "amber", ""): return
    ecu = _ecu(ctx.rest[0]); t = ctx.connect(); t.start_reader(dump=False)
    u = UdsClient(t)
    try:
        u.enter_extended_session(ecu); u.ecu_reset(ecu); print(f"{ecu.name}: reset sent")
    except UdsError as e: print(f"{ecu.name}: {e}")
    t.close()

# ---------------- ACTUATOR / COMPONENT TESTS (amber - IOControl 0x2F) ----------------
# VCU IOControlByIdentifier DIDs, verified from the diagnostic app's ODX
# (notes/apk_x/res/raw/odx.json). Each is "2F <DID> 03 <state>" (state 01=on,
# 00=off), positive response 6F <DID>. All on the VCU.
_ACTUATORS = {
    "horn":     0x0410,  # Horn 12V supply
    "headunit": 0x0403,  # Head unit 12V supply
    "lowbeam":  0x0406,  # Front light low beam
    "highbeam": 0x0407,  # Front light high beam
    "rind":     0x0408,  # Right indicators
    "lind":     0x0409,  # Left indicators
    "brake":    0x040A,  # Rear brake light
    "poslight": 0x040B,  # Rear position light
    "boot":     0x040C,  # Boot light
}

@cmd("actuate", "amber")
def c_actuate(ctx):
    """actuate <name> [ms]  - unlock the VCU and pulse an output on then off.

    Runs the exact sequence recovered from the diagnostic app:
      10 03 -> 27 01/02 (level 01) -> 2F <DID> 03 01 -> hold -> 2F <DID> 03 00,
    with a 3E 80 tester-present keepalive so the unlock does not expire.
    Requires SERVICE mode (the ECUs ignore UDS in CUST mode)."""
    if not ctx.rest or ctx.rest[0] not in _ACTUATORS:
        print("usage: actuate <" + "|".join(_ACTUATORS) + "> [ms]")
        return
    name = ctx.rest[0]
    did = _ACTUATORS[name]
    ms = int(ctx.rest[1]) if len(ctx.rest) > 1 else 800
    if not need_confirm(ctx, "amber", ""):
        return
    ecu = Ecu.VCU
    t = ctx.connect()
    try:
        t.init([e.req_id for e in Ecu] + [e.resp_id for e in Ecu])
    except Exception:
        pass
    t.start_reader(dump=False)
    # Guard: ECUs only answer UDS in SERVICE mode.
    mode = t.stub.GetVehicleOperationMode(E()).cur_mode
    if str(mode) != str(pb.VEHICLE_OP_STATE_SERVICE):
        print(f"vehicle is not in SERVICE mode (cur={mode}).")
        print("  run:  20_cmd.cmd set-mode service --yes   first, then retry.")
        t.close()
        return
    u = UdsClient(t)
    try:
        u.enter_extended_session(ecu)
        print("session : 50 03 ok")
        u.security_access(ecu, "01")
        print("security: 67 02 ok (level 01 unlocked)")
        with TesterPresentKeepalive(u, ecu):
            r_on = u.io_control(ecu, did, 0x03, b"\x01")
            print(f"{name} ON  : {r_on.hex()}  ({ms} ms)")
            time.sleep(ms / 1000.0)
            r_off = u.io_control(ecu, did, 0x03, b"\x00")
            print(f"{name} OFF : {r_off.hex()}")
            try:
                u.io_control(ecu, did, 0x00)  # returnControlToECU
                print(f"{name} returned control to ECU")
            except UdsError:
                pass
    except UdsError as e:
        print(f"{ecu.name}: {e}")
        print("  (NRC 0x33 here = security access not granted; NRC 0x31 = DID not "
              "supported; timeout = wrong mode or session expired)")
    t.close()

# ---------------- RAW / DANGER (red) ----------------
@cmd("can-send", "red")
def c_cansend(ctx):
    if len(ctx.rest) < 2:
        print("usage: can-send <canid_hex> <data_hex up to 16 chars>"); return
    if not need_confirm(ctx, "red", "SEND RAW CAN"): return
    cid = int(ctx.rest[0], 16); data = bytes.fromhex(ctx.rest[1])
    t = ctx.connect(); r = t.write_frame(cid, data)
    print(f"sent 0x{cid:03X} {data.hex()}: {r.status} {r.status_msg}"); t.close()

@cmd("sw-update", "red")
def c_swupdate(ctx):
    trig = {"all": pb.SW_UPDATE_TRIGGER_ALL, "bms": pb.SW_UPDATE_TRIGGER_BMS,
            "mcu": pb.SW_UPDATE_TRIGGER_MCU, "bcm": pb.SW_UPDATE_TRIGGER_BCM,
            "ble": pb.SW_UPDATE_TRIGGER_BLE, "aosp": pb.SW_UPDATE_TRIGGER_AOSP,
            "hu": pb.SW_UPDATE_TRIGGER_HU}
    if not ctx.rest or ctx.rest[0] not in trig:
        print("usage: sw-update <all|bms|mcu|bcm|ble|aosp|hu>"); return
    if not need_confirm(ctx, "red", "TRIGGER FIRMWARE UPDATE"): return
    t = ctx.connect()
    r = t.stub.SwUpdateTriggerUpgrade(pb.SwUpdateTriggerCmd(trigger=trig[ctx.rest[0]]))
    print("sw-update:", r.status, r.status_msg); t.close()

@cmd("mcu-cal", "red")
def c_mcucal(ctx):
    if not ctx.rest: print("usage: mcu-cal <start|stop>"); return
    if not need_confirm(ctx, "red", "RECALIBRATE MOTOR"): return
    a = ctx.rest[0]
    req = pb.RmtCmdReq(cmd_id=pb.RMT_CMD_MCU_CAL,
                       sub_cmd_mcu_cal=pb.RMT_SUB_CMD_MCU_CAL_START if a == "start"
                       else pb.RMT_SUB_CMD_MCU_CAL_STOP)
    t = ctx.connect(); r = t.stub.RemoteRunTestCmd(req)
    print("mcu-cal:", r.resp_status, r.resp_str); t.close()

def main():
    args = sys.argv[1:]
    ctx = Ctx(args)
    entry = RISK.get(ctx.cmd)
    if not entry:
        print(__doc__); return
    risk, fn = entry
    banner = {"green": "", "amber": "  (amber: reversible change)", "red": "  *** RED: DANGEROUS ***"}
    if banner[risk]: print(banner[risk])
    fn(ctx)

if __name__ == "__main__":
    main()
