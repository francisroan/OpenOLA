"""Scooter console — glass UI entry point (run via 30_scooter_gui.cmd).

Starts the local-only bridge (tool/glass/server.py) and opens the page in a
chromeless Edge / Chrome / Chromium app window with its own throwaway profile.
Closing the window disconnects cleanly (actuator OFF + keepalive stop) and exits.

    python tool/scooter_glass.py            # open the app window
    python tool/scooter_glass.py --no-window [--port 8765]   # print the URL only
"""
import argparse
import os
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'glass'))
sys.path.insert(0, str(HERE))

from server import App, ROOT  # noqa: E402


def find_browser():
    """A Chromium-family browser that supports --app (Edge ships with Windows 10/11)."""
    env = os.environ.get('SCOOTER_BROWSER')
    if env and Path(env).exists():
        return env
    cands = []
    if sys.platform.startswith('win'):
        for base in (os.environ.get('PROGRAMFILES(X86)'), os.environ.get('PROGRAMFILES'),
                     os.environ.get('LOCALAPPDATA')):
            if base:
                cands += [Path(base) / 'Microsoft/Edge/Application/msedge.exe',
                          Path(base) / 'Google/Chrome/Application/chrome.exe',
                          Path(base) / 'BraveSoftware/Brave-Browser/Application/brave.exe']
    elif sys.platform == 'darwin':
        cands += [Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'),
                  Path('/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'),
                  Path('/Applications/Chromium.app/Contents/MacOS/Chromium'),
                  Path('/Applications/Brave Browser.app/Contents/MacOS/Brave Browser')]
    for c in cands:
        if c.exists():
            return str(c)
    for name in ('microsoft-edge', 'google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser',
                 'brave-browser', 'msedge', 'chrome'):
        found = shutil.which(name)
        if found:
            return found
    return None


def open_window(url):
    browser = find_browser()
    if not browser:
        webbrowser.open(url)
        return None
    profile = ROOT / 'captures/gui/window_profile'
    profile.mkdir(parents=True, exist_ok=True)
    args = [browser, f'--app={url}', f'--user-data-dir={profile}', '--window-size=1340,900',
            '--no-first-run', '--no-default-browser-check', '--disable-sync', '--disable-extensions',
            '--disable-component-update', '--disable-background-networking',
            # Under critical memory pressure Edge/Chrome discard the app's only tab, which
            # closes the window (and so the console). Observed on a 16 GB PC with 0.5 GB free.
            '--disable-features=Translate,msEdgeSidebarV2,msSleepingTabs,msEfficiencyMode,'
            'AutomaticTabDiscarding,TabDiscarding,IntensiveWakeUpThrottling',
            # keep the poll alive while minimised/hidden (we use it as a heartbeat)
            '--disable-background-timer-throttling', '--disable-renderer-backgrounding',
            '--disable-backgrounding-occluded-windows']
    proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if sys.platform.startswith('win'):
        import threading
        threading.Thread(target=_bring_to_front, args=(proc.pid,), daemon=True).start()
    return proc


def _bring_to_front(pid, timeout=25):
    """Edge restores the last saved window state, which can be minimised. Show it."""
    import ctypes
    import wincapture
    user32 = ctypes.windll.user32
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        hwnd = wincapture.find_window(pid=pid)
        if hwnd:
            if user32.IsIconic(hwnd):
                user32.ShowWindow(hwnd, 9)            # SW_RESTORE
            user32.SetForegroundWindow(hwnd)
            return
        time.sleep(0.3)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument('--no-window', action='store_true', help='only print the local URL')
    ap.add_argument('--port', type=int, default=0)
    args = ap.parse_args()

    app = App()
    url = app.serve(args.port)
    print('Scooter console running at', url, flush=True)
    proc = None if args.no_window else open_window(url)
    app.browser_pid = proc.pid if proc is not None else None
    started = time.monotonic()
    reason = 'interrupted'
    try:
        while True:
            time.sleep(0.5)
            now = time.monotonic()
            if app.ctl.closed.is_set():
                reason = 'controller closed'
                break
            seen = app.last_seen
            # Window closed: the page said goodbye and did not come back (a reload would).
            if app.bye_at and now - app.bye_at > 4 and seen < app.bye_at:
                reason = 'window closed'
                break
            # Our own browser process exited and the page stopped polling. Give a cold
            # browser start plenty of time before concluding the window never opened.
            if proc is not None and proc.poll() is not None and (not seen or now - seen > 6) \
                    and now - started > 45:
                reason = 'browser exited'
                break
            # Fallback heartbeat (system browser or a handed-off window).
            if seen and now - seen > 90:
                reason = 'no heartbeat'
                break
    except KeyboardInterrupt:
        pass
    print(f'Window gone ({reason}).', flush=True)
    print('Closing — finishing the current command, then disconnecting…', flush=True)
    app.shutdown()
    if proc is not None and proc.poll() is None:
        try:
            proc.terminate()
        except OSError:
            pass


if __name__ == '__main__':
    main()
