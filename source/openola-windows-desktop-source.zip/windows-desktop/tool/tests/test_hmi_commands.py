import sys, unittest, queue
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hmi_commands import send_once, COMMANDS, _LABEL_BY_ORDINAL, PARK_REQUIRED
HB_ON, HB_OFF, RIDE = _LABEL_BY_ORDINAL[26], _LABEL_BY_ORDINAL[27], _LABEL_BY_ORDINAL[83]

class Transport:
    stub = True
    def __init__(self, park=True, echo=True):
        self.queues = {0x143: queue.Queue(), 0x6c0: queue.Queue()}
        self.sent = []
        self.park, self.echo = park, echo
    def stop_stream(self): pass
    def init(self, ids): self.ids = ids
    def queue_for(self, cid): return self.queues[cid]
    def start_reader(self, dump=False): self.queues[0x143].put(bytes([0xb5 if self.park else 0xc5])+bytes(7))
    def write_frame(self, cid, data):
        self.sent.append((cid, data))
        self.queues[0x6c0].put(bytes([99])+bytes(7))
        if self.echo: self.queues[0x6c0].put(data)

class Scooter:
    def __init__(self, **kwargs):
        self.t = Transport(**kwargs)
        self.stream_mode = 'dump'
        self.unlocked = {1}
        self.restored = None
    def require_bench(self): pass
    def stop_keepalive(self): pass
    def _ensure_stream(self, mode): self.restored = mode

class Tests(unittest.TestCase):
    def test_real_transport_dispatches_registered_hmi_queues(self):
        from scooter_backend import GuiTransport
        t = GuiTransport('127.0.0.1', 50005, secure=False)
        q = t.queue_for(0x6c0)
        t._dispatch(0x6c0, bytes([26])+bytes(7))
        self.assertEqual(q.get_nowait(), bytes([26])+bytes(7))
        t._dispatch(0x143, bytes(8))
        self.assertNotIn(0x143, t._queues)
    def test_exact_single_command_and_echo(self):
        for name, command in COMMANDS.items():
            if command == 99:          # the fake transport's unrelated ack byte
                continue
            s = Scooter()
            self.assertIn('matching echo', send_once(s, name))
            self.assertEqual(s.t.sent, [(0x6bc, bytes([command])+bytes(7))])
            self.assertEqual(s.restored, 'dump')
    def test_drive_blocks_ride(self):
        s = Scooter(park=False)
        with self.assertRaisesRegex(RuntimeError, 'not in Park'): send_once(s, RIDE)
        self.assertEqual(s.t.sent, [])
        self.assertEqual(s.restored, 'dump')
    def test_off_available_in_drive(self):
        self.assertNotIn(27, PARK_REQUIRED)
        self.assertIn('matching echo', send_once(Scooter(park=False), HB_OFF))
    def test_timeout_does_not_retry(self):
        s = Scooter(echo=False)
        with self.assertRaisesRegex(RuntimeError, 'Outcome unknown'): send_once(s, HB_ON)
        self.assertEqual(len(s.t.sent), 1)
        self.assertEqual(s.restored, 'dump')
    def test_invalid_and_bench_block(self):
        s = Scooter()
        with self.assertRaises(ValueError): send_once(s, 'Normal')
        with patch.object(s, 'require_bench', side_effect=RuntimeError('bench')):
            with self.assertRaisesRegex(RuntimeError, 'bench'): send_once(s, HB_ON)
        self.assertEqual(s.t.sent, [])

if __name__ == '__main__': unittest.main()
