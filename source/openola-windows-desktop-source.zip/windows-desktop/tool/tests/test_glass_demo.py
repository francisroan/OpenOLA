"""End-to-end test of the glass console controller against the built-in demo scooter.

Drives the real Controller (same code the UI uses) through the simulated gRPC scooter:
connect, monitor, reads (with monitor auto-resume), ECU report, actuator test, HMI command,
head-unit self-test, routines, clear codes, module restart, odometer, charge recording,
and the safety guards. Run:  python tool/tests/test_glass_demo.py
"""
import sys
import time
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE.parent / 'glass'), str(HERE.parent)]

from controller import Controller, NeedConfirm, Notice  # noqa: E402


class GlassDemoTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c = Controller()
        cls.c.start()

    @classmethod
    def tearDownClass(cls):
        cls.c.request_close()
        cls.c.closed.wait(20)

    # helpers ---------------------------------------------------------------
    def act(self, _action, **p):
        """Call an action, auto-answering confirmations and waiting out a transient busy."""
        for _ in range(40):
            try:
                return self.c.call(lambda: self.c.act(_action, p))
            except NeedConfirm as nc:
                p['confirm'] = nc.payload['word'] or True
            except Notice as n:
                if 'current operation' not in n.payload['text']:
                    raise
                time.sleep(0.2)
        self.fail(f"{_action}: stuck")

    def wait_idle(self, timeout=30):
        deadline = time.time() + timeout
        while time.time() < deadline:
            if not self.c.call(lambda: self.c.busy):
                time.sleep(0.3)
                if not self.c.call(lambda: self.c.busy):
                    return
            time.sleep(0.1)
        self.fail('operation did not finish')

    def events(self):
        return list(self.c.events)

    def last_error(self):
        errs = [e for e in self.c.events if e['kind'] == 'error']
        return errs[-1] if errs else None

    # tests (ordered by name) ---------------------------------------------------
    def test_01_guards_before_connect(self):
        with self.assertRaises(Notice):
            self.c.call(lambda: self.c.act('read_did', {'ecu': 'BMS', 'did': 'F191'}))
        with self.assertRaises(NeedConfirm):          # bench mode always asks first
            self.c.call(lambda: self.c.act('set_bench', {'on': True}))
        with self.assertRaises(Notice):
            self.c.call(lambda: self.c.act('demo_charger', {'on': True}))

    def test_02_demo_connect(self):
        self.act('demo_start')
        self.wait_idle()
        st = self.c.call(lambda: self.c.state(0, ['status']))
        self.assertTrue(st['conn']['connected'], self.last_error())
        self.assertTrue(st['conn']['demo'])
        self.assertEqual(st['conn']['mode'], 'CUST')

    def test_03_monitor_and_status(self):
        self.act('monitor_start')
        self.wait_idle()
        time.sleep(2.5)
        st = self.c.call(lambda: self.c.state(0, ['status']))
        self.assertTrue(st['monitor']['on'])
        self.assertNotEqual(st['sv']['soc'], '—', 'battery SOC should decode from the demo bus')
        self.assertNotEqual(st['sv']['volts'], '—')
        self.assertIsNotNone(st['features'], '0x660 feature flags should decode')
        self.assertEqual(st['faults'], [])

    def test_04_read_requires_bench(self):
        with self.assertRaises(Notice) as cm:
            self.c.call(lambda: self.c.act('read_did', {'ecu': 'BMS', 'did': 'F191'}))
        self.assertIn('Bench mode', cm.exception.payload['text'])
        self.act('set_bench', on=True)
        self.assertTrue(self.c.call(lambda: self.c.bench))

    def test_05_read_resumes_monitor(self):
        before = len(self.events())
        self.act('read_did', ecu='BMS', did='F191')
        self.wait_idle()
        new = self.events()[before:]
        self.assertTrue(any(e['kind'] == 'sheet' and 'Component response' in e['title'] for e in new), new)
        time.sleep(1.0)
        self.wait_idle()
        self.assertEqual(self.c.scooter.stream_mode, 'dump', 'monitor must get the bus back after a read')
        st = self.c.call(lambda: self.c.state(0, []))
        self.assertFalse(st['monitor']['paused'])

    def test_06_stored_dtcs_and_clear(self):
        self.act('read_dtc', ecu='BMS')
        self.wait_idle()
        self.assertEqual(len(self.c.health_stored['BMS']['faults']), 2)
        self.act('clear_dtc', ecu='BMS')
        self.wait_idle()
        self.assertEqual(self.c.health_stored['BMS']['faults'], [], self.last_error())

    def test_07_quick_report(self):
        self.act('report_start', quick=True, ecus=['BMS', 'VCU', 'MCU'])
        self.wait_idle(60)
        rep = self.c.last_report
        self.assertIsNotNone(rep, self.last_error())
        ok = [r for r in rep['items'] if not r.get('error')]
        self.assertEqual(len(ok), len(rep['items']))
        self.assertTrue(rep['summary']['cells'])
        self.assertTrue(any('Cell 9' in f['text'] for f in rep['summary']['findings']))
        self.assertTrue(Path(self.c.report_files[1]).exists())
        self.assertEqual(self.c.scooter.stream_mode, 'dump')

    def test_08_service_mode_and_actuator(self):
        self.act('set_mode', mode='SERVICE')
        self.wait_idle()
        self.assertEqual(self.c.mode, 'SERVICE')
        before = len(self.events())
        self.act('actuator_test', name='Horn')
        self.wait_idle()
        self.assertIsNone(next((e for e in self.events()[before:] if e['kind'] == 'error'), None))
        self.assertIn('ON and OFF acknowledged', self.c.status_text)

    def test_09_red_actuator_needs_word(self):
        self.wait_idle()
        with self.assertRaises(NeedConfirm) as cm:
            self.c.call(lambda: self.c.act('actuator_test', {'name': 'Alarm', 'confirm': True}))
        self.assertEqual(cm.exception.payload['word'], 'TEST')

    def test_10_hmi_echo(self):
        before = len(self.events())
        self.act('hmi_send', ordinal=26, ready=True)
        self.wait_idle()
        sheets = [e for e in self.events()[before:] if e['kind'] == 'sheet']
        self.assertTrue(sheets and 'matching echo' in sheets[-1]['text'], self.events()[before:])

    def test_11_head_unit_tests(self):
        self.act('hu_test', key='lcd', action='start')
        self.wait_idle()
        self.act('hu_test', key='vin')
        self.wait_idle()
        log = list(self.c.workshop_log)
        self.assertIn('MD9S1PRODEMO00042', log[0]['result'])
        self.assertIn('Success', log[1]['result'])

    def test_12_routines_and_reset(self):
        self.act('routine', key='tune')
        self.wait_idle()
        self.assertIn('attempted 2', self.c.workshop_log[0]['result'])
        self.act('routine', key='bf02')
        self.wait_idle()
        self.assertIn('status 0x00', self.c.workshop_log[0]['result'])
        self.act('ecu_reset', ecu='VCU', kind='soft')
        self.wait_idle()
        self.assertIn('restart acknowledged', self.c.workshop_log[0]['result'])

    def test_13_odometer_and_angle(self):
        self.act('read_odometer')
        self.wait_idle()
        self.assertEqual(self.c.cal['odo_value'], '8421')
        self.act('write_odometer', km='8421')
        self.wait_idle()
        self.assertIn('ACCEPTED', self.c.cal['odo_status'])
        self.act('read_motor_angle')
        self.wait_idle()
        self.assertEqual(self.c.cal['motor_angle'], '187.4')

    def test_14_charging_demo(self):
        self.act('monitor_resume')
        self.wait_idle()
        self.act('demo_charger', on=True)
        time.sleep(3)
        st = self.c.call(lambda: self.c.state(0, ['charging']))
        self.assertIn('Slow', st['sv']['ctype'])
        self.act('charge_record')
        time.sleep(2)
        self.act('charge_record')
        self.assertFalse(self.c._charge_snoop)
        self.act('demo_charger', on=False)

    def test_14b_firmware_and_config(self):
        self.wait_idle()
        self.act('read_firmware')
        self.wait_idle()
        fw = self.c.fw_report
        self.assertIsNotNone(fw, self.last_error())
        self.assertIn('BMS', fw['versions'])
        self.assertTrue(any(r.get('value') for r in fw['versions']['MCU']))
        cfg = self.c.vcu_config
        self.assertEqual(cfg['variant'], 'Ola S1 Pro')
        self.assertEqual(len(cfg['features']), 6)
        self.assertTrue(any(f['on'] for f in cfg['features']))
        self.assertTrue([t for t in cfg['thresholds'] if t.get('value') is not None])
        st = self.c.call(lambda: self.c.state(0, []))
        self.assertEqual(st['conn']['model'], 'Ola S1 Pro')

    def test_14c_battery_hyper_som_autotest(self):
        self.wait_idle()
        self.act('battery_health')
        self.wait_idle()
        self.assertEqual(self.c.battery_health['soh'], 96)
        self.assertEqual(self.c.battery_health['cycles'], 212)
        self.act('som_test')
        self.wait_idle()
        self.assertIn('SOM', self.c.workshop_log[0]['label'])
        # hyper charge needs Service mode (same unlock path as writes)
        self.act('set_mode', mode='SERVICE')
        self.wait_idle()
        self.act('hyper_charge', action='enable')
        self.wait_idle()
        self.assertIn('enabled', self.c.workshop_log[0]['result'])
        self.act('monitor_start')
        self.wait_idle()
        time.sleep(1.5)
        self.act('auto_test')
        self.wait_idle()
        steps = self.c.auto_test['steps']
        self.assertEqual(len(steps), 5)
        self.assertTrue(all(s['detail'] for s in steps[:3]))        # all three DTC reads ran
        self.assertTrue(steps[3]['ok'] and steps[4]['ok'])          # charge + drive inputs reporting
        self.act('set_mode', mode='CUST')
        self.wait_idle()

    def test_14d_battery_section(self):
        self.wait_idle()
        self.act('monitor_start')
        self.wait_idle()
        time.sleep(2.5)
        self.assertTrue(len(self.c.graph['soc']) >= 3, 'graph should record points while monitoring')
        self.act('bms_config')
        self.wait_idle()
        rows = self.c.bms_config
        self.assertGreater(len(rows), 100)
        checked = [r for r in rows if 'stock' in r]
        self.assertTrue(checked)
        dev = [r for r in checked if r.get('deviates')]
        self.assertEqual([r['name'] for r in dev], ['Drive over-temp warning'])
        self.assertTrue(self.c.bms_findings)
        # restore the deviating value to stock (needs Service)
        self.act('set_mode', mode='SERVICE')
        self.wait_idle()
        self.act('bms_write', did='E467', payload='6737')
        self.wait_idle()
        self.assertIn('matches', self.c.workshop_log[0]['result'])
        self.act('set_mode', mode='CUST')
        self.wait_idle()

    def test_14e_cells(self):
        self.wait_idle()
        self.act('read_cells')
        self.wait_idle()
        cl = self.c.cells
        self.assertEqual(cl['count'], 14)
        self.assertEqual(cl['weak_cell'], 9)
        for c in cl['cells']:
            self.assertTrue(0 <= c['pct'] <= 100)
            self.assertIsNotNone(c['mv'])
            self.assertIsNotNone(c['temp'])
        weak = cl['cells'][8]
        self.assertLess(weak['pct'], cl['cells'][0]['pct'])
        self.assertIsNotNone(cl['total_ah'])

    def test_14f_recorder(self):
        import os
        import session_recorder as SR
        self.wait_idle()
        self.act('monitor_start')
        self.wait_idle()
        r = self.act('session_record')                       # start
        self.assertTrue(self.c.recorder.active)
        time.sleep(3)
        r = self.act('session_record')                       # stop
        path = self.c.recorder.path
        self.assertFalse(self.c.recorder.active)
        summ = SR.summarize(path)
        self.assertGreater(summ['samples'], 2)
        self.assertGreater(len(summ['signals']), 50)
        self.assertTrue(any(s['name'] == 'batt_soc' for s in summ['signals']))
        csv = str(path).replace('.jsonl', '.csv')
        _, rows, cols = SR.export_csv(path, csv)
        self.assertTrue(os.path.exists(csv) and cols > 50)
        self.act('session_open', path=str(path))
        self.wait_idle()
        self.assertEqual(self.c.loaded_recording['samples'], summ['samples'])
        self.act('session_plot', names=['batt_soc', 'batt_volts'])
        self.wait_idle()
        self.assertIn('batt_soc', self.c.loaded_series)

    def test_15_end_demo(self):
        self.act('set_mode', mode='CUST')
        self.wait_idle()
        self.act('disconnect')
        self.wait_idle()
        st = self.c.call(lambda: self.c.state(0, []))
        self.assertFalse(st['conn']['connected'])
        self.assertFalse(st['conn']['demo'])
        self.assertNotEqual(st['conn']['host'], '127.0.0.1', 'real connection settings restored')


if __name__ == '__main__':
    unittest.main(verbosity=2)
