"""Run without contacting a scooter: python tool/tests/test_gui_backend.py."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import queue
import unittest
from unittest.mock import patch
from scooter_backend import (SETTINGS, Scooter, GuiUds, Ecu, pb,
                             encode_setting, decode_setting, UdsError)
from oladiag.isotp import encode_single


class Wire:
    def __init__(self, reply=None, flow=True):
        self.q = queue.Queue()
        self.writes = []
        self.reply = reply
        self.flow = flow

    def queue_for(self, _):
        return self.q

    def write_frame(self, cid, data):
        self.writes.append((cid, data))
        if data[0] >> 4 == 1 and self.flow:
            self.q.put(b'\x30\x00\x00' + b'\0' * 5)
        elif self.reply:
            self.q.put(encode_single(self.reply))


class BackendTests(unittest.TestCase):
    def test_regen_patches_only_selected_field(self):
        d = SETTINGS['Regen Current Limit']
        before = bytes.fromhex('6400f401e803')
        actual = encode_setting(d, {'brake regen current limit': '25.1'}, before)
        self.assertEqual(actual.hex(), '6400fb00e803')
        self.assertEqual(decode_setting(d, actual)['brake regen current limit'], 25.1)

    def test_bad_values_rejected(self):
        d = SETTINGS['LimpHome Speed Limit']
        for value in ['-1', '100.1', 'NaN', 'Infinity', '0.01']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                encode_setting(d, {'LimpHome Speed Limit': value}, b'\0\0')

    def test_missing_selection_and_bad_length(self):
        d = SETTINGS['LimpHome Speed Limit']
        for values, before in [({}, b'\0\0'), ({'unknown': 2}, b'\0\0'), ({'LimpHome Speed Limit': 2}, b'\0')]:
            with self.assertRaises(ValueError):
                encode_setting(d, values, before)

    def test_no_torque_alias(self):
        self.assertEqual(len(SETTINGS), 2)
        self.assertFalse(any(x['RequestFormat'] == '2E B1 10' for x in SETTINGS.values()))

    def test_negative_reply(self):
        with self.assertRaisesRegex(UdsError, 'NRC'):
            GuiUds(Wire(b'\x7f\x22\x33'), .02)._request(Ecu.MCU, b'\x22\xb1\x12')

    def test_wrong_did(self):
        with self.assertRaisesRegex(UdsError, 'identifier'):
            GuiUds(Wire(b'\x62\xb1\x13\0\0'), .02)._request(Ecu.MCU, b'\x22\xb1\x12')

    def test_multiframe_waits_for_flow_control(self):
        wire = Wire(flow=False)
        with self.assertRaisesRegex(UdsError, 'flow-control timeout'):
            GuiUds(wire, .02)._request(Ecu.MCU, b'\x2e\xb1\x0b' + b'\0' * 6)
        self.assertEqual(len(wire.writes), 1)

    def test_multiframe_setting(self):
        wire = Wire(b'\x6e\xb1\x0b')
        result = GuiUds(wire, .02)._request(Ecu.MCU, b'\x2e\xb1\x0b' + b'\0' * 6)
        self.assertEqual(result, b'\x6e\xb1\x0b')
        self.assertEqual(wire.writes[1][1][0], 0x21)

    def test_pending_is_bounded(self):
        with self.assertRaisesRegex(UdsError, 'timed out'):
            GuiUds(Wire(b'\x7f\x22\x78'), .02)._request(Ecu.MCU, b'\x22\xb1\x12')

    def test_actuator_off_after_on_failure(self):
        """An ambiguous ON (timeout) must still be followed by OFF and return-control."""
        s = Scooter()
        s.bench_confirmed = True
        class U:
            calls = []
            def io_control(self, ecu, did, option=3, state=b''):
                self.calls.append((did, option, state))
                if state == b'\x01':
                    raise UdsError('ON timed out')
        u = U()
        with patch.object(s, 'ensure_unlocked', return_value=u), self.assertRaises(UdsError):
            s.pulse('Horn')
        self.assertEqual(u.calls, [(0x410, 3, b'\x01'), (0x410, 3, b'\x00'), (0x410, 0, b'')])

    def test_compare_before_write(self):
        s = Scooter()
        s.bench_confirmed = True
        with patch.object(s, 'read', return_value=b'\x01\0'), patch.object(s, 'uds') as uds:
            with self.assertRaisesRegex(RuntimeError, 'changed since preview'):
                s.write_setting('LimpHome Speed Limit', b'\0\0', b'\x64\0')
            uds.assert_not_called()

    def test_write_readback_mismatch_and_success(self):
        for final, expected in [(b'\x32\0', False), (b'\x64\0', True)]:
            s = Scooter()
            s.bench_confirmed = True
            with patch.object(s, 'read', side_effect=[b'\0\0', final]), patch.object(s, 'uds'), patch('scooter_backend.audit'):
                if expected:
                    self.assertIn('matches', s.write_setting('LimpHome Speed Limit', b'\0\0', b'\x64\0'))
                else:
                    with self.assertRaisesRegex(RuntimeError, 'readback differs'):
                        s.write_setting('LimpHome Speed Limit', b'\0\0', b'\x64\0')

    def test_service_required(self):
        s = Scooter()
        s.bench_confirmed = True
        with patch.object(s, 'rpc', return_value=pb.VehicleOperationMode(cur_mode=pb.VEHICLE_OP_STATE_CUST)):
            with self.assertRaisesRegex(RuntimeError, 'Service'):
                s.uds(Ecu.MCU)


if __name__ == '__main__':
    unittest.main(verbosity=2)
