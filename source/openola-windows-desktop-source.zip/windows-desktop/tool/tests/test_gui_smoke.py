"""Windows UI smoke check; no physical scooter connection."""
import sys
import time
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scooter_gui import App, ROOT
from scooter_backend import ACTUATORS, ACTUATOR_DANGER

app = App()
callback_errors = []
app.report_callback_exception = lambda *args: callback_errors.append(args)
app.update()
for size in ('1180x820', '1000x720'):
    app.geometry(size)
    for name in app.pages:
        app.show(name)
        app.update()
        page = app.pages[name]
        assert page.winfo_height() > 100, name
        assert app.log.winfo_rooty() + app.log.winfo_height() <= app.winfo_rooty() + app.winfo_height(), name
        assert str(app.nav_buttons[name]['style']) == 'Selected.Nav.TButton'
app.show('1. Scooter mode')
app.actuator_group.set('All groups')
app.filter_actuators()
assert len(app.actuator_items) == len(ACTUATORS)
with patch.object(app.scooter, 'pulse') as pulse:
    for name in [next(n for n in ACTUATORS if n not in ACTUATOR_DANGER), next(iter(ACTUATOR_DANGER))]:
        app.actuator_search.set(f'{ACTUATORS[name]:04X}')
        app.update()
        iid = next(i for i, n in app.actuator_items.items() if n == name)
        app.actuator_table.selection_set(iid)
        app.select_actuator()
        assert app.selected_actuator == name
        pulse.assert_not_called()  # Selection itself never transmits.
        with patch('scooter_gui.messagebox.askyesno', return_value=False), patch('scooter_gui.simpledialog.askstring', return_value=None):
            app.run_selected_test()
        pulse.assert_not_called()  # Both confirmation cancellation paths remain intact.
    app.actuator_search.set('no-such-test-zzzzz')
    app.update()
    assert not app.actuator_items and app.selected_actuator is None
    assert str(app.test_button['state']) == 'disabled'
app.toggle_activity()
app.update()
assert app.log.winfo_ismapped()
app.toggle_activity()
app.update()
assert not app.log.winfo_ismapped()
app.show('2. Live Data')
with patch('scooter_gui.filedialog.askopenfilename', return_value=str(ROOT / 'captures/alldata.json')):
    app.replay_capture()
app.render_rows()
app.update()
assert app.replay and len(app.rows) > 100
assert 'OFFLINE' in app.live_status.get()
app.search.set('temp')
app.set_category('Temperature')
app.update()
assert len(app.table.get_children()) > 0
assert str(app.category_buttons['Temperature']['style']) == 'Selected.Chip.TButton'
app.show('3. Write components')
app.setting.set('LimpHome Speed Limit')
app.setting_changed()
assert len(app.fields) == 1
app.setting.set('Regen Current Limit')
app.setting_changed()
assert len(app.fields) == 3
assert not app.unlock_access.get()
from learning_gui import LearningWindow
from signal_learning import LearningSession
from test_signal_learning import fixture, DBC
import tempfile
with tempfile.TemporaryDirectory() as directory:
    learning = LearningWindow(app)
    app.update()
    learning.session = LearningSession('Right indicator', directory)
    learning.session.data = fixture(blink=True)
    original_dbc = app.scooter.dbc
    app.scooter.dbc = DBC
    learning.update_stage()
    deadline = time.monotonic() + 5
    while app.busy and time.monotonic() < deadline:
        app.update()
        time.sleep(.02)
    assert len(learning.table.get_children()) == 2
    assert 'complete' in learning.instructions.get()
    learning.close()
    app.scooter.dbc = original_dbc
app.show('Home')
app.close()
deadline = time.monotonic() + 5
while time.monotonic() < deadline:
    try:
        app.update()
        if not app.winfo_exists():
            break
    except Exception:
        break
    time.sleep(.02)
else:
    raise AssertionError('Window failed to close after disconnect')
import traceback
for _err in callback_errors:
    traceback.print_exception(*_err)
assert app.closed and not callback_errors, callback_errors
print('PASS: all pages at two sizes; offline capture; filtering; settings; learning analysis; clean close')
