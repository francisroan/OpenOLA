"""Exercise dashboard rendering, DTC error preservation and JSON export offline."""
import sys,json,tempfile,time
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from scooter_gui import App
from scooter_backend import Ecu
app=App();app.show('Diagnostics');app.update()
h=app.health_dashboard
assert len(h.tabs.tabs())==6
app.connected=True;app.live=True
app.rows={('333','Motor_fault'):('333','MCU','Motor_fault',1,'',time.time())}
from test_health_dashboard import DBC
with patch.object(app.scooter,'dbc',DBC):
    h.refresh()
    assert '1 asserted' in h.summary.get()
    app.rows[('333','Motor_fault')]=('333','MCU','Motor_fault',0,'',time.time())
    h.refresh();assert len(h.events)==1
    app.live=False;h.refresh();assert 'unavailable' in h.summary.get()
def run(label,fn,done=None,**kwargs):
    result=fn()
    if done:done(result)
with patch.object(app,'run',side_effect=run),patch.object(app.scooter,'read_faults',return_value=[]):
    h.read_dtc(Ecu.VCU)
    assert h.stored['VCU']['faults']==[]
with patch.object(app,'run',side_effect=run),patch.object(app.scooter,'read_faults',side_effect=RuntimeError('Timed out')):
    h.read_dtc(Ecu.VCU)
    assert h.stored['VCU']['faults'] is None
    assert h.stored['VCU']['error']=='Timed out'
with tempfile.TemporaryDirectory() as directory:
    path=Path(directory)/'report.json'
    with patch('health_dashboard.filedialog.asksaveasfilename',return_value=str(path)):h.export()
    report=json.loads(path.read_text())
    assert report['stored_dtcs']['VCU']['error']=='Timed out'
    assert report['events']
app.destroy()
print('PASS: six tabs; fault transitions; paused data; DTC failure replaces old result; JSON export')
