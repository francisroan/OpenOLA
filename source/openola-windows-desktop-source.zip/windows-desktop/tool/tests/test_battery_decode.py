"""Desktop battery-decode tests — guards the SoC source fix and the imported
226-message DBC. Run:  python tool/tests/test_battery_decode.py
"""
import json
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE.parent / 'glass'), str(HERE.parent)]

from status_monitor import decode_battery  # noqa: E402

DBC_PATH = HERE.parent / 'oladiag' / 'config' / 'da_can_dbc.json'


class BatteryDecodeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dbc = {
            int(m['id']): m
            for m in json.loads(DBC_PATH.read_text(encoding='utf-8-sig'))['messages']
        }

    def test_dbc_imported_and_display_soc_moved(self):
        # Production DBC: Display_SoC is on 0x352 (moved from 0x353), range on 0x353.
        self.assertIn(0x352, self.dbc, 'expected the 226-message production DBC')
        self.assertIn('Display_SoC', [s['name'] for s in self.dbc[0x352]['signals']])
        self.assertIn('Vehicle_Range', [s['name'] for s in self.dbc[0x353]['signals']])

    def test_soc_from_0x352(self):
        # snap is {cid: (timestamp, data)}. Display_SoC @ 0x352, 16-bit LE, ×1 → 83%.
        snap = {0x352: (0.0, [83, 0, 0, 0, 0, 0, 0, 0])}
        self.assertEqual(round(decode_battery(self.dbc, snap)['soc']), 83)

    def test_soc_fallback_pack(self):
        # No 0x352; Pack_SOC_00 @ 0x11C startbit 24 (byte 3), ×0.01 → 8300 = 83%.
        data = [0, 0, 0] + list((8300).to_bytes(2, 'little')) + [0, 0, 0]
        self.assertAlmostEqual(
            decode_battery(self.dbc, {0x11C: (0.0, data)})['soc'], 83, delta=1
        )

    def test_no_soc_when_absent(self):
        result = decode_battery(self.dbc, {})
        self.assertTrue(result is None or result.get('soc') is None)


if __name__ == '__main__':
    unittest.main()
