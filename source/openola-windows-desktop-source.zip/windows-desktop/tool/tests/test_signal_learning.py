import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json
import tempfile
import time
import unittest
from unittest.mock import patch, Mock
from scooter_backend import Scooter, GuiTransport, GuiUds, UdsNegativeResponse, Ecu, UdsError
from signal_learning import LearningSession, rank_candidates, PHASES


def fixture(blink=False, broken_return=False):
    phases = []
    for phase in range(5):
        frames = []
        for n in range(20):
            active = phase in (1, 3) or (broken_return and phase == 4)
            bit = int(active and (not blink or n % 2 == 0))
            # Byte 0 bit 2 follows the control, byte 1 is a counter/noise.
            frames.append([phase * 5 + n / 10, 0x143, bytes([bit << 2, n % 16] + [0] * 6).hex()])
        phases.append({'name': PHASES[phase], 'frames': frames, 'dropped': 0, 'error': None})
    return {'schema': 1, 'label': 'Right indicator', 'passive': True, 'phases': phases}


DBC = {0x143: {'signals': [{'name': 'Existing_name', 'startbit': 2, 'bitlength': 1}], 'dlc': 8}}


class LearningTests(unittest.TestCase):
    def test_repeated_bit_and_named_signal_detected(self):
        results = rank_candidates(fixture(), DBC)
        self.assertEqual(len(results), 2)
        self.assertTrue(all(r['score'] == 100 for r in results))
        self.assertEqual({r['kind'] for r in results}, {'signal', 'bit'})

    def test_blinking_indicator_detected(self):
        results = rank_candidates(fixture(blink=True), DBC)
        self.assertTrue(results)
        self.assertTrue(all(r['score'] == 50 for r in results))

    def test_failed_return_excluded(self):
        self.assertEqual(rank_candidates(fixture(broken_return=True), DBC), [])

    def test_missing_id_in_any_phase_excluded(self):
        data = fixture()
        data['phases'][4]['frames'] = []
        self.assertEqual(rank_candidates(data, DBC), [])

    def test_incomplete_and_dropped_fail(self):
        data = fixture()
        data['phases'][1]['dropped'] = 1
        with self.assertRaises(ValueError):
            rank_candidates(data, DBC)
        with self.assertRaises(ValueError):
            rank_candidates({'phases': []}, DBC)

    def test_short_sample_excluded(self):
        data = fixture()
        for phase in data['phases']:
            phase['frames'] = phase['frames'][:1]
        self.assertEqual(rank_candidates(data, DBC), [])

    def test_raw_record_and_mapping_provenance(self):
        with tempfile.TemporaryDirectory() as directory:
            session = LearningSession('Indicator', directory)
            session.begin()
            session.record(1.0, 0x123, b'\x04')
            session.finish()
            self.assertEqual(json.loads(session.path.read_text())['phases'][0]['frames'][0], [1.0, 0x123, '04'])
            session.data = fixture()
            session.save()
            session.save_mapping(rank_candidates(session.data, DBC)[0])
            mapping = json.loads((Path(directory) / 'observed_mappings.jsonl').read_text())
            self.assertFalse(mapping['tx_enabled'])
            self.assertEqual(len(mapping['sha256']), 64)

    def test_dashboard_never_steals_uds_and_timestamp_is_receive_time(self):
        s = Scooter()
        s.bench_confirmed = True
        t = GuiTransport()
        s.t, s.streaming = t, True
        with patch('scooter_backend.time.time', return_value=123.0):
            t._dispatch(0x143, b'\0' * 8)
            t._dispatch(Ecu.VCU.resp_id, b'\x03\x7f\x2f\x33\0\0\0\0')
        rows = s.samples()
        self.assertTrue(rows)
        self.assertTrue(all(row[-1] == 123.0 for row in rows))
        self.assertEqual(t.queue_for(Ecu.VCU.resp_id).qsize(), 1)

    def test_record_observer_gets_all_frames_without_tx(self):
        t = GuiTransport()
        observer = Mock()
        t.observer = observer
        t._dispatch(0x123, b'\x01')
        self.assertEqual(observer.call_count, 1)
        self.assertEqual(t.latest[0x123][1], b'\x01')

    def test_explicit_rejection_does_not_send_misleading_off(self):
        s = Scooter()
        s.bench_confirmed = True
        u = Mock()
        u.io_control.side_effect = UdsNegativeResponse(Ecu.VCU, 0x2F, 0x33)
        s.unlocked.add(Ecu.VCU)
        with patch.object(s, 'ensure_unlocked', return_value=u), self.assertRaises(UdsNegativeResponse):
            s.pulse('Horn')
        self.assertEqual(u.io_control.call_count, 1)
        self.assertNotIn(Ecu.VCU, s.unlocked)          # lapsed access is re-established next time

    def test_failed_access_blocks_repeat_keys(self):
        s = Scooter()
        s.bench_confirmed = True
        u = Mock()
        u.security_access.side_effect = UdsNegativeResponse(Ecu.VCU, 0x27, 0x35)
        with patch.object(s, 'uds', return_value=u), patch('scooter_backend.audit'):
            with self.assertRaises(UdsNegativeResponse):
                s.prepare(Ecu.VCU, True)
            with self.assertRaisesRegex(RuntimeError, 'security key was rejected'):
                s.prepare(Ecu.VCU, True)
        self.assertEqual(u.security_access.call_count, 1)

    def test_access_before_on_and_cleanup(self):
        s = Scooter()
        s.bench_confirmed = True
        u = Mock()
        with patch.object(s, 'uds', return_value=u), patch.object(s, 'start_keepalive'),                 patch('scooter_backend.audit'), patch('scooter_backend.time.sleep'):
            s.pulse('Horn')
        self.assertEqual([c[0] for c in u.method_calls],
                         ['enter_extended_session', 'security_access', 'io_control', 'io_control', 'io_control'])

    def test_bad_seed_no_key_sent(self):
        u = GuiUds(Mock())
        with patch.object(u, '_request', return_value=b'\x67\x01') as request, self.assertRaisesRegex(UdsError, 'seed length'):
            u.security_access(Ecu.VCU)
        self.assertEqual(request.call_count, 1)

    def test_zero_seed_no_key_sent(self):
        u = GuiUds(Mock())
        with patch.object(u, '_request', return_value=b'\x67\x01' + b'\0' * 8) as request:
            self.assertIn('already', u.security_access(Ecu.VCU))
        self.assertEqual(request.call_count, 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
