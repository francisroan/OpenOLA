"""
Offline mock of the scooter's wifican gRPC server, for testing oladiag with no
hardware. It emulates BMS/VCU/MCU: extended session, seed/key security access,
and a multi-frame ReadDTCInformation (19 02) response carrying a few real DTC
codes from the bundled table.

It implements just enough ISO-TP: single-frame requests in, single- or
multi-frame responses out, and it honours the tester's flow-control frame.
"""

import queue
import threading
import time

import grpc

from oladiag.wifican import wifican_pb2 as pb
from oladiag.wifican import wifican_pb2_grpc as pbg
from oladiag.canframe import build_frame, parse_frame
from oladiag.seedkey import Ecu, generate_key
from oladiag.isotp import frame_type, FIRST

# a canned fault list per ECU: (dtc 3-byte code hex, status)
CANNED = {
    Ecu.BMS: [("110109", 0x09), ("11011C", 0x08)],   # cell1 volt sensor fail; cell1 volt out of range
    Ecu.VCU: [("920711", 0x09)],   # Head lamp low Short
    Ecu.MCU: [],  # no faults
}
SEED = bytes([0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88])


def _iso_tp_frames(payload: bytes):
    """Yield 8-byte data fields for a UDS payload (single or first+consecutive)."""
    if len(payload) <= 7:
        yield bytes([len(payload)]) + payload + bytes(7 - len(payload))
        return
    # first frame
    yield bytes([0x10 | ((len(payload) >> 8) & 0x0F), len(payload) & 0xFF]) + payload[:6]
    rest = payload[6:]
    sn = 1
    while rest:
        chunk = rest[:7]
        rest = rest[7:]
        yield bytes([0x20 | (sn & 0x0F)]) + chunk + bytes(7 - len(chunk))
        sn += 1


class MockWifiCan(pbg.WifiCanRpcServicer):
    def __init__(self):
        self._subs = set()
        self._out = queue.Queue()          # frames to push to readers
        self._unlocked = {e: False for e in Ecu}
        self._pending_seed = {e: None for e in Ecu}
        self._rx = {e: None for e in Ecu}  # in-progress multi-frame request reassembly

    def Init(self, request, context):
        self._subs = set(request.can_ids)
        return pb.Response(status=pb.RESP_SUCCESS, status_msg="ok")

    def Deinit(self, request, context):
        return pb.Response(status=pb.RESP_SUCCESS, status_msg="bye")

    def _push_raw(self, can_id, data8):
        self._out.put(build_frame(can_id, data8))

    def _push(self, can_id, payload):
        """Push a UDS payload as proper ISO-TP frame(s), like a real ECU."""
        for f in _iso_tp_frames(payload):
            self._out.put(build_frame(can_id, f))

    def _ecu_for_req(self, can_id):
        for e in Ecu:
            if e.req_id == can_id:
                return e
        return None

    def WriteCanFrame(self, request, context):
        can_id, data8 = parse_frame(request.can_frame)
        ecu = self._ecu_for_req(can_id)
        if ecu is None:
            return pb.Response(status=pb.RESP_SUCCESS, status_msg="ignored")
        ft = frame_type(data8)
        if ft == 0x3:  # flow control from tester -> nothing to do
            return pb.Response(status=pb.RESP_SUCCESS, status_msg="fc")
        if ft == 0x0:  # single frame
            length = data8[0] & 0x0F
            self._handle(ecu, data8[1:1 + length])
        elif ft == 0x1:  # first frame of a multi-frame request
            total = ((data8[0] & 0x0F) << 8) | data8[1]
            self._rx[ecu] = {"total": total, "buf": bytearray(data8[2:8])}
            self._push_raw(ecu.resp_id, bytes([0x30, 0x00, 0x00, 0, 0, 0, 0, 0]))  # FC CTS
        elif ft == 0x2:  # consecutive frame
            st = self._rx.get(ecu)
            if st:
                st["buf"].extend(data8[1:8])
                if len(st["buf"]) >= st["total"]:
                    payload = bytes(st["buf"][:st["total"]])
                    self._rx[ecu] = None
                    self._handle(ecu, payload)
        return pb.Response(status=pb.RESP_SUCCESS, status_msg="ok")

    def _handle(self, ecu, payload):
        if not payload:
            return
        svc = payload[0]
        if svc == 0x10:      # session control
            self._push(ecu.resp_id, bytes([0x50, payload[1]]))
        elif svc == 0x27 and payload[1] == 0x01:   # request seed
            self._pending_seed[ecu] = SEED
            self._push(ecu.resp_id, bytes([0x67, 0x01]) + SEED)
        elif svc == 0x27 and payload[1] == 0x02:   # send key
            expected = generate_key(self._pending_seed[ecu], ecu, "01")
            if payload[2:] == expected:
                self._unlocked[ecu] = True
                self._push(ecu.resp_id, bytes([0x67, 0x02]))
            else:
                self._push(ecu.resp_id, bytes([0x7F, 0x27, 0x35]))  # invalidKey
        elif svc == 0x19 and payload[1] == 0x02:   # read DTC by status mask
            body = bytearray([0x59, 0x02, 0xFF])
            for code_hex, status in CANNED[ecu]:
                body += bytes.fromhex(code_hex) + bytes([status])
            self._push(ecu.resp_id, bytes(body))
        elif svc == 0x14:   # clear
            self._push(ecu.resp_id, bytes([0x54]))
        else:
            self._push(ecu.resp_id, bytes([0x7F, svc, 0x11]))  # serviceNotSupported

    def _stream(self, context):
        while context.is_active():
            try:
                frame = self._out.get(timeout=0.2)
            except queue.Empty:
                continue
            yield pb.CANPacket(can_frame=frame)

    def ReadCanStream(self, request, context):
        yield from self._stream(context)

    def CanDumpStream(self, request, context):
        yield from self._stream(context)

    # unused RPCs
    def WriteCanStream(self, request_iterator, context):
        return pb.Response(status=pb.RESP_SUCCESS, status_msg="ok")


def serve(port=0):
    server = grpc.server(_pool())
    pbg.add_WifiCanRpcServicer_to_server(MockWifiCan(), server)
    port = server.add_insecure_port(f"127.0.0.1:{port}")
    server.start()
    return server, port


def _pool():
    from concurrent import futures
    return futures.ThreadPoolExecutor(max_workers=8)


if __name__ == "__main__":
    s, port = serve(50051)
    print(f"mock wifican on 127.0.0.1:{port}")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        s.stop(0)
