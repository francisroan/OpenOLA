"""Real local gRPC + GUI UDS adapter authentication; never uses physical hardware."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scooter_backend import GuiTransport, GuiUds, Ecu
from tests.mock_vehicle import serve

server, port = serve(0)
t = GuiTransport('127.0.0.1', port)
try:
    t.connect()
    t.init([e.resp_id for e in Ecu] + [e.req_id for e in Ecu])
    t.start_reader()
    u = GuiUds(t)
    for ecu, count in zip(Ecu, (2, 1, 0)):
        u.enter_extended_session(ecu)
        u.security_access(ecu)
        assert len(u.read_dtcs(ecu, unlock=False)) == count
    print('PASS: GUI adapter seed/key and DTC response exchange for all three mock ECUs')
finally:
    t.close()
    server.stop(0)
