"""End-to-end test against the mock vehicle: read DTCs from all three ECUs."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.mock_vehicle import serve
from oladiag.seedkey import Ecu
from oladiag.transport import WifiCanTransport
from oladiag.uds import UdsClient


def main():
    server, port = serve(0)
    print(f"mock on :{port}")
    t = WifiCanTransport("127.0.0.1", port, secure=False)
    t.connect()
    ids = []
    for e in Ecu:
        ids += [e.req_id, e.resp_id]
    t.init(ids)
    t.start_reader()
    c = UdsClient(t, timeout=5.0)

    ok = True
    expected = {"BMS": 2, "VCU": 1, "MCU": 0}
    for ecu in Ecu:
        c.enter_extended_session(ecu)
        c.security_access(ecu)          # exercise seed/key round-trip
        faults = c.read_dtcs(ecu)
        print(f"\n{ecu.name}: {len(faults)} fault(s)")
        for f in faults:
            print(f"  {f['code']}  {f['description']}  known={f['known']}  "
                  f"status={f['status']:#04x} {f['status_flags']}")
        if len(faults) != expected[ecu.name]:
            print(f"  FAIL expected {expected[ecu.name]}")
            ok = False
        for f in faults:
            if not f["known"]:
                print("  FAIL unmapped code"); ok = False

    t.close()
    server.stop(0)
    print("\nRESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    import os as _os; _rc=main(); _os._exit(_rc)
