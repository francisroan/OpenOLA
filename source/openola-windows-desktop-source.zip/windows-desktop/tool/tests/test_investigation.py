"""Offline regressions for the charging incident, traces and failed learning."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json
import tempfile
import unittest
from unittest.mock import Mock, patch
from scooter_backend import Scooter, Ecu, GuiUds, GuiTransport, UdsError, pb, ROOT
from command_trace import CommandTrace
from signal_learning import analysis_report, LearningSession
from test_signal_learning import fixture, DBC
from test_gui_backend import Wire


class InvestigationTests(unittest.TestCase):
    def test_bench_guard_precedes_network(self):
        s = Scooter()
        with patch.object(s, 'rpc') as rpc, patch.object(s, 'start_live') as stream:
            for fn in (lambda: s.read(Ecu.MCU, b'\xb1\x12'), lambda: s.mode('SERVICE'),
                       lambda: s.read_faults(Ecu.VCU), lambda: s.pulse('Horn')):
                with self.assertRaisesRegex(RuntimeError, 'charger'):
                    fn()
            rpc.assert_not_called()
            stream.assert_not_called()

    def test_plain_read_has_no_session_or_key(self):
        s = Scooter()
        s.bench_confirmed = True
        u = Mock()
        u._request.return_value = b'\x62\xb1\x12\x01\x00'
        with patch.object(s, 'uds', return_value=u) as uds:
            self.assertEqual(s.read(Ecu.MCU, b'\xb1\x12'), b'\x01\x00')
            uds.assert_called_once_with(Ecu.MCU, require_service=False)
        self.assertEqual([c[0] for c in u.method_calls], ['_request'])

    def test_wrong_component_and_implicit_unlock_blocked(self):
        s = Scooter()
        s.bench_confirmed = True
        with patch.object(s, 'uds') as uds:
            with self.assertRaisesRegex(ValueError, 'not VCU'):
                s.read(Ecu.VCU, b'\xb1\x12')
            with self.assertRaisesRegex(ValueError, 'automatically'):
                s.read(Ecu.MCU, b'\xb1\x12', True)
            uds.assert_not_called()

    def test_trace_exact_negative_payload_and_wire_reply(self):
        with tempfile.TemporaryDirectory() as directory:
            trace = CommandTrace(directory)
            path = trace.begin('Mock rejected horn')
            wire = Wire(b'\x7f\x2f\x33')
            wire.trace = trace
            with self.assertRaises(UdsError):
                GuiUds(wire, .02)._request(Ecu.VCU, b'\x2f\x04\x10\x03\x01')
            t = GuiTransport()
            t.trace = trace
            t.stub = Mock()
            response = pb.Response(status=pb.RESP_SUCCESS, status_msg='mock only')
            t.stub.WriteCanFrame.return_value = response
            t.write_frame(Ecu.VCU.req_id, b'\x02\x27\x01' + b'\0' * 5)
            t.stub.WriteCanFrame.side_effect = RuntimeError('mock deadline')
            with self.assertRaisesRegex(UdsError, 'no ECU rejection'):
                t.write_frame(Ecu.VCU.req_id, b'\0' * 8)
            trace.end(error='expected mock rejection')
            trace.close()
            events = [json.loads(line) for line in Path(path).read_text().splitlines()]
            self.assertTrue(any(e.get('payload_hex') == '7f2f33' for e in events))
            self.assertTrue(any(e.get('payload_hex') == '2f04100301' for e in events))
            self.assertEqual(events[-1]['dropped_events'], 0)
            request = next(e for e in events if e['event'] == 'rpc_request')
            packet = pb.CANPacket.FromString(bytes.fromhex(request['protobuf_hex']))
            self.assertEqual(packet.can_frame[-8:], b'\x02\x27\x01' + b'\0' * 5)
            self.assertTrue(any(e.get('protobuf_hex') == response.SerializeToString().hex() for e in events))
            self.assertTrue(any(e['event'] == 'rpc_error' for e in events))

    def test_report_explains_failed_return_without_accepting_it(self):
        report = analysis_report(fixture(broken_return=True), DBC)
        self.assertEqual(report['candidates'], [])
        signal = next(c for c in report['changed_unverified'] if c['kind'] == 'signal')
        self.assertEqual(signal['phase_counts'][4], [(1, 20)])
        with tempfile.TemporaryDirectory() as directory:
            session = LearningSession('Brake', directory)
            session.data = fixture()
            with self.assertRaisesRegex(ValueError, 'unverified'):
                session.save_mapping(signal)

    def test_incomplete_report_still_shows_evidence(self):
        data = fixture()
        data['phases'].pop()
        report = analysis_report(data, DBC)
        self.assertFalse(report['candidates'])
        self.assertTrue(report['changed_unverified'])
        self.assertTrue(report['issues'])

    def test_real_brake_capture_has_changes_but_no_repeated_mapping(self):
        path = ROOT / 'captures/gui/learning/20260910_210916_5178fe9b.json'
        data = json.loads(path.read_text())
        report = analysis_report(data, Scooter().dbc)
        self.assertEqual(report['candidates'], [])
        signal = next(c for c in report['changed_unverified'] if c['name'] == 'Rear_Brake_Light_POS_12V_supply_control_command')
        self.assertEqual(dict(signal['phase_counts'][2]), {1: 6})


if __name__ == '__main__':
    unittest.main(verbosity=2)
