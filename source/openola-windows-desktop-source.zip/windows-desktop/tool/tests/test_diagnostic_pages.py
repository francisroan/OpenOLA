"""Offline UI regression: catalogs never send requests until explicitly read."""
import json
import sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scooter_gui import App
from diagnostic_pages import DetailsBrowser, catalog
from scooter_backend import ODX, ROOT, ODX_AVAILABLE

entries = catalog()
expected = sum(1 for definitions in ODX.values() for d in definitions if bytes.fromhex(d['RequestFormat']).startswith(b'\x22'))
assert sum(1 for e in entries if e[1].startswith('UDS ')) == expected
s1x_expected = 0
for phase in (1, 2):
    data = json.loads((ROOT / f'tool/oladiag/config/live_parameters_s1x_phase{phase}.json').read_text(encoding='utf-8-sig'))
    s1x_expected += sum(len(data.get(ecu, [])) for ecu in ('BMS', 'MCU', 'VCU'))
s1x_entries = [e for e in entries if e[1].startswith('S1X phase ')]
assert len(s1x_entries) == s1x_expected
assert all(e[4] is None for e in s1x_entries), 'S1X reference rows must not infer a read address'
brakes = [e for e in s1x_entries if e[2] == 'BRAKE_L_SIGNAL']
assert {e[3].get('DBC Name') for e in brakes} == {'Rear_Brake_Press', 'Front_Brake_Press'}
app = App()
with patch.object(app.scooter, 'read', return_value=b'\x01') as read:
    browser = DetailsBrowser(app)
    app.update()
    assert len(browser.table.get_children()) == len(entries)
    readable = next((i for i,e in enumerate(entries) if e[4]), None)
    if readable is not None:
        browser.table.selection_set(str(readable)); browser.select()
        assert str(browser.read_button['state']) == 'normal'
        read.assert_not_called()
    else:
        assert not ODX_AVAILABLE
        assert str(browser.read_button['state']) == 'disabled'
    browser.query.set('no-such-parameter-xyz')
    assert not browser.table.get_children()
    assert str(browser.read_button['state']) == 'disabled'
    browser.destroy()
app.destroy()
print(f'PASS: {len(entries)} entries; ODX available={ODX_AVAILABLE}; selection sends nothing')
