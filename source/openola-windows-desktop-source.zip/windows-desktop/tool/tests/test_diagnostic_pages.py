"""Offline UI regression: catalogs never send requests until explicitly read."""
import sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scooter_gui import App
from diagnostic_pages import DetailsBrowser, catalog
from scooter_backend import ODX

entries = catalog()
expected = sum(1 for definitions in ODX.values() for d in definitions if bytes.fromhex(d['RequestFormat']).startswith(b'\x22'))
assert sum(1 for e in entries if e[1].startswith('UDS ')) == expected
app = App()
with patch.object(app.scooter, 'read', return_value=b'\x01') as read:
    browser = DetailsBrowser(app)
    app.update()
    assert len(browser.table.get_children()) == len(entries)
    i = next(i for i,e in enumerate(entries) if e[4])
    browser.table.selection_set(str(i)); browser.select()
    assert str(browser.read_button['state']) == 'normal'
    read.assert_not_called()
    browser.query.set('no-such-parameter-xyz')
    assert not browser.table.get_children()
    assert str(browser.read_button['state']) == 'disabled'
    browser.destroy()
app.destroy()
print(f'PASS: {len(entries)} entries; every ODX read retained; selection sends nothing')
