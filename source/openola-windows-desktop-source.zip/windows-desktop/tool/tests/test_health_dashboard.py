"""Offline checks: missing/stale data must never become a healthy verdict."""
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from health_dashboard import snapshot

DBC={0x333:{'name':'MCU_Fault_Data','signals':[{'name':'Motor_fault','bitlength':1}]},
     0x15b:{'name':'Vehicle','signals':[{'name':'Front_Brake_Status','bitlength':1}]}}

class HealthTests(unittest.TestCase):
    def test_missing_is_unknown(self):
        s=snapshot(DBC,[],100,True,True,False)
        self.assertEqual(s['Fault signals'][0]['flag'],'Unknown')
        self.assertEqual(s['Drive inputs'][0]['state'],'Not received')
    def test_asserted_requires_fresh_live_data(self):
        rows=[('333','MCU','Motor_fault',1,'',99)]
        self.assertEqual(snapshot(DBC,rows,100,True,True,False)['Fault signals'][0]['flag'],'Asserted')
        for connected,live,replay in [(False,True,False),(True,False,False),(True,True,True)]:
            self.assertEqual(snapshot(DBC,rows,100,connected,live,replay)['Fault signals'][0]['flag'],'Unknown')
        self.assertEqual(snapshot(DBC,rows,105,True,True,False)['Fault signals'][0]['state'],'Stale')
    def test_clear_and_nonbinary(self):
        rows=[('333','MCU','Motor_fault',0,'',99)]
        self.assertEqual(snapshot(DBC,rows,100,True,True,False)['Fault signals'][0]['flag'],'Not asserted')
        rows=[('333','MCU','Motor_fault',2,'',99)]
        self.assertEqual(snapshot(DBC,rows,100,True,True,False)['Fault signals'][0]['flag'],'Unexpected value')

if __name__=='__main__':unittest.main()
