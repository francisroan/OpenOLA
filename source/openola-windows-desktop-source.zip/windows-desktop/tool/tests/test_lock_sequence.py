import unittest
from unittest.mock import Mock

from scooter_backend import Scooter, Ecu, UdsError


class LockSequenceTests(unittest.TestCase):
    def scooter(self, response):
        scooter = Scooter()
        scooter.bench_confirmed = True
        uds = Mock()
        uds._request.return_value = response
        scooter.ensure_unlocked = Mock(return_value=uds)
        return scooter, uds

    def test_exact_request_and_no_claim_of_completion(self):
        scooter, uds = self.scooter(bytes.fromhex('7101bf0700'))
        result = scooter.lock_unlock_sequence()
        uds._request.assert_called_once_with(Ecu.VCU, bytes.fromhex('3101bf07'))
        self.assertIn('unverified', result)

    def test_wrong_routine_and_missing_status_rejected(self):
        for response in ('7101bf0800', '7102bf0700', '7101bf07'):
            scooter, uds = self.scooter(bytes.fromhex(response))
            with self.assertRaises(UdsError):
                scooter.lock_unlock_sequence()
            self.assertEqual(uds._request.call_count, 1)

    def test_timeout_retried_once(self):
        scooter, uds = self.scooter(b'')
        uds._request.side_effect = UdsError('timeout; result unknown')
        with self.assertRaises(UdsError):
            scooter.lock_unlock_sequence()
        self.assertEqual(uds._request.call_count, 2)
        self.assertEqual(scooter.ensure_unlocked.call_count, 2)

    def test_bench_required_before_unlock(self):
        scooter, _ = self.scooter(b'')
        scooter.bench_confirmed = False
        with self.assertRaises(RuntimeError):
            scooter.lock_unlock_sequence()
        scooter.ensure_unlocked.assert_not_called()


if __name__ == '__main__':
    unittest.main()
