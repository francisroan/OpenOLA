"""Verify a packaged GUI in isolation, without network or vehicle actions."""
from pathlib import Path
import sys
root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root/'tool'))
from scooter_gui import App
from hmi_commands import open_panel
from diagnostic_pages import catalog
app = App()
app.withdraw()
errors = []
app.report_callback_exception = lambda *args: errors.append(args)
app.update()
assert not app.connected
assert len(catalog()) == 504
open_panel(app)
app.update()
assert not errors
for child in app.winfo_children():
    if child.winfo_class() == 'Toplevel': child.destroy()
app.closed = True
app.scooter.disconnect()
app.scooter.trace.close()
app.destroy()
print('PASS portable runtime: GUI, HMI panel, 504 catalog entries, disconnected; no network actions')
