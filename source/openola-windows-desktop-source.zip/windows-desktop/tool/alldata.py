"""
Full data dump - decode EVERY CAN message seen on the bus using the DBC,
write a structured JSON and a flat CSV. Read-only.

Usage:  python alldata.py <host> <port> [seconds] [secure]
"""
import sys, time, json, os, csv
from oladiag.transport import WifiCanTransport

def load_dbc():
    p = os.path.join(os.path.dirname(__file__), "oladiag", "config", "da_can_dbc.json")
    d = json.load(open(p))
    return {int(m["id"]): m for m in d["messages"]}

def extract(data, s):
    raw = int.from_bytes(data, "little")
    if s.get("endianess", "intel").lower() == "intel":
        v = (raw >> s["startbit"]) & ((1 << s["bitlength"]) - 1)
    else:
        v = 0; idx = s["startbit"]
        for _ in range(s["bitlength"]):
            byte, bit = idx // 8, idx % 8
            b = (data[byte] >> bit) & 1 if byte < len(data) else 0
            v = (v << 1) | b
            idx = idx + 15 if bit == 0 else idx - 1
    if s.get("signed") and s["bitlength"] < 64:
        sb = 1 << (s["bitlength"] - 1)
        if v & sb: v -= (1 << s["bitlength"])
    val = v * s.get("scaling", 1) + s.get("offset", 0)
    return round(val, 4) if isinstance(val, float) else val

def main():
    host = sys.argv[1] if len(sys.argv) > 1 else "192.168.4.1"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 50005
    secs = int(sys.argv[3]) if len(sys.argv) > 3 else 12
    secure = len(sys.argv) > 4 and sys.argv[4].lower() == "secure"
    dbc = load_dbc()

    print(f"Capturing all signals from {host}:{port} for {secs}s ...")
    t = WifiCanTransport(host, port, secure=secure)
    t.connect(); t.start_reader(dump=True)
    time.sleep(secs)
    latest = {}
    for cid, q in list(t._queues.items()):
        d = None
        while not q.empty():
            try: d = q.get_nowait()
            except Exception: break
        if d is not None: latest[cid] = d
    t.close()

    decoded = {}       # id -> {message, raw, signals:{name:{value,units}}}
    rows = []
    unknown = []
    for cid, data in sorted(latest.items()):
        m = dbc.get(cid)
        if not m:
            unknown.append({"can_id": f"0x{cid:03X}", "raw": data.hex()})
            continue
        sig = {}
        for s in m["signals"]:
            v = extract(data, s)
            sig[s["name"]] = {"value": v, "units": s.get("units", "")}
            rows.append([f"0x{cid:03X}", m["name"], s["name"], v, s.get("units", "")])
        decoded[f"0x{cid:03X}"] = {"message": m["name"], "raw": data.hex(), "signals": sig}

    capdir = os.path.join("..", "captures")
    os.makedirs(capdir, exist_ok=True)
    with open(os.path.join(capdir, "alldata.json"), "w") as f:
        json.dump({"decoded": decoded, "unknown_ids": unknown,
                   "distinct_ids": len(latest)}, f, indent=2)
    with open(os.path.join(capdir, "alldata.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["can_id", "message", "signal", "value", "units"])
        w.writerows(rows)

    print(f"\nDecoded {len(decoded)} known messages, {len(rows)} signals; "
          f"{len(unknown)} unknown IDs.")
    print("Wrote captures\\alldata.json  and  captures\\alldata.csv")
    print("\nA few key readings:")
    def show(cid, name):
        e = decoded.get(cid)
        if e and name in e["signals"]:
            s = e["signals"][name]; print(f"   {name:<32} {s['value']!s:>12} {s['units']}")
    show("0x120", "Overall_SOC"); show("0x11C", "Battery_voltage_OCV_00")
    show("0x170", "BMS0_Cell_Min_Voltage"); show("0x170", "BMS0_Cell_Max_Voltage")
    show("0x143", "Odometer"); show("0x113", "MCU_Voltage")

if __name__ == "__main__":
    main()
