/*
 * Ola S1 charge-CAN sniffer (ESP32 or Arduino Uno/Nano + MCP2515)
 *
 * v2 (multi-session):
 * - Baud is now CONFIRMED 500k/8MHz from the first real capture, so we start
 *   LISTEN-ONLY at 500k IMMEDIATELY and stream — no blind boot probe that used
 *   to eat the first ~9 s and miss the connect/auth handshake.
 * - If the bus is silent for STARTUP_SILENCE_MS at startup (e.g. a future 3 kW
 *   charger on a different rate), THEN we fall back to auto-probing 500/250/125.
 * - Auto-marks every PLUG (bus wakes) and UNPLUG (bus goes idle) so you can do
 *   several plug/unplug cycles into ONE log and split them later. Each connect
 *   gets an incrementing session number — line up 0x080/081/083 auth bytes
 *   across sessions to prove static-vs-rolling auth.
 * - Listen-only (no ACK / no TX). CSV on Serial 115200.
 *
 * Library: "mcp_can" by coryjfowler (Library Manager)
 * Wiring: reverse_engineering/CHARGE_CAN_CAPTURE.md
 */

#include <SPI.h>
#include <mcp_can.h>

#if defined(ARDUINO_ARCH_ESP32)
static const int PIN_CS  = 5;
static const int PIN_INT = 4;  // unused; sketch polls
#else
// Uno / Nano hardware SPI: 11=MOSI, 12=MISO, 13=SCK
static const int PIN_CS  = 10;
static const int PIN_INT = 2;
#endif

MCP_CAN CAN(PIN_CS);

// Confirmed operating point (17 Sep 2026 capture on the stock slow charger).
static const long DEFAULT_BAUD_ENUM = CAN_500KBPS;
static const long DEFAULT_BPS       = 500000L;
static const byte DEFAULT_CRYSTAL   = MCP_8MHZ;

// Fallback probe (only runs if the bus is silent at startup).
static const long CANDIDATE_BAUDS[] = { CAN_500KBPS, CAN_250KBPS, CAN_125KBPS };
static const long CANDIDATE_BPS[]   = { 500000L,     250000L,     125000L };
static const int  NUM_BAUDS = 3;
static const unsigned long PROBE_MS = 3000;

// Bus is "asleep/unplugged" once we've heard nothing for this long.
static const unsigned long IDLE_MS = 800;
// If nothing at all arrives this soon after boot, run the auto-probe.
static const unsigned long STARTUP_SILENCE_MS = 4000;

long selectedBaudEnum = DEFAULT_BAUD_ENUM;
long selectedBps      = DEFAULT_BPS;
byte selectedCrystal  = DEFAULT_CRYSTAL;

bool busActive = false;              // are we currently in a plugged/charging session?
unsigned long lastRxMs = 0;          // millis() of last valid frame
unsigned long lastActiveTag = 0;     // millis() of session start
unsigned int  sessionNum = 0;        // increments on each PLUG

bool isInteresting(unsigned long id) {
  if (id == 0x00B || id == 0x040) return true;
  if (id >= 0x080 && id <= 0x083) return true;
  if (id == 0x120 || id == 0x121 || id == 0x213) return true;
  if (id == 0x014) return true;
  if (id >= 0x500 && id <= 0x510) return true;
  if (id >= 0x530 && id <= 0x536) return true;
  if (id == 0x543 || id == 0x553 || id == 0x563) return true;
  if (id >= 0x580 && id <= 0x587) return true;
  return false;
}

bool frameLooksValid(unsigned long id, byte len) {
  if (len > 8) return false;
  if (id > 0x1FFFFFFFUL) return false;
  return true;
}

bool startCan(long baudEnum, byte crystal) {
  if (CAN.begin(MCP_ANY, baudEnum, crystal) != CAN_OK) {
    return false;
  }
  CAN.setMode(MCP_LISTENONLY);
  return true;
}

bool startCanTryCrystals(long baudEnum, byte *usedCrystal) {
  if (startCan(baudEnum, MCP_8MHZ))  { *usedCrystal = MCP_8MHZ;  return true; }
  if (startCan(baudEnum, MCP_16MHZ)) { *usedCrystal = MCP_16MHZ; return true; }
  return false;
}

// Only used when the bus is silent at 500k (e.g. a different charger/rate).
void probeBauds() {
  unsigned long bestScore = 0;
  int bestIdx = -1;
  byte bestCrystal = MCP_8MHZ;

  Serial.println(F("# PROBE_START (bus was silent at 500k default)"));

  for (int i = 0; i < NUM_BAUDS; i++) {
    byte crystal = MCP_8MHZ;
    if (!startCanTryCrystals(CANDIDATE_BAUDS[i], &crystal)) {
      Serial.print(F("# INIT_FAIL bps=")); Serial.println(CANDIDATE_BPS[i]);
      continue;
    }
    unsigned long t0 = millis(), good = 0, junk = 0, err = 0;
    while (millis() - t0 < PROBE_MS) {
      if (CAN.checkReceive() != CAN_MSGAVAIL) continue;
      unsigned long id = 0; byte len = 0; byte buf[8];
      if (CAN.readMsgBuf(&id, &len, buf) != CAN_OK) { err++; continue; }
      if (frameLooksValid(id, len)) good++; else junk++;
    }
    unsigned long dirty = junk + err, score = 0;
    if (good > 0 && dirty * 5UL <= good) score = good;

    Serial.print(F("# PROBE bps=")); Serial.print(CANDIDATE_BPS[i]);
    Serial.print(F(" xtal=")); Serial.print(crystal == MCP_16MHZ ? 16 : 8);
    Serial.print(F(" good=")); Serial.print(good);
    Serial.print(F(" junk=")); Serial.print(junk);
    Serial.print(F(" err="));  Serial.print(err);
    Serial.print(F(" score=")); Serial.println(score);

    if (score > bestScore) { bestScore = score; bestIdx = i; bestCrystal = crystal; }
  }

  if (bestIdx < 0) {
    bestIdx = 0; bestCrystal = MCP_8MHZ;
    Serial.println(F("# WARN no clean baud — locking 500000; check CAN_H/L/GND, wake, terminator, 8 vs 16 MHz crystal"));
  }
  selectedBaudEnum = CANDIDATE_BAUDS[bestIdx];
  selectedBps      = CANDIDATE_BPS[bestIdx];
  selectedCrystal  = bestCrystal;

  if (!startCan(selectedBaudEnum, selectedCrystal)) {
    if (!startCanTryCrystals(selectedBaudEnum, &selectedCrystal)) {
      Serial.println(F("# FATAL CAN init failed after probe"));
    }
  }
}

void printHeader() {
  Serial.print(F("SELECTED_BAUD=")); Serial.println(selectedBps);
  Serial.print(F("# SELECTED_XTAL_MHZ=")); Serial.println(selectedCrystal == MCP_16MHZ ? 16 : 8);
  Serial.println(F("# PLUG/UNPLUG markers auto-emitted; session counter resets each PLUG"));
  Serial.println(F("t_ms,id_hex,dlc,b0,b1,b2,b3,b4,b5,b6,b7,tag"));
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println(F("# charge_can_sniff v2 ready — instant 500k listen-only"));
  SPI.begin();

  if (!startCan(DEFAULT_BAUD_ENUM, DEFAULT_CRYSTAL)) {
    if (!startCanTryCrystals(DEFAULT_BAUD_ENUM, &selectedCrystal)) {
      Serial.println(F("# FATAL CAN init failed at 500k"));
    }
  }
  printHeader();

  // If the bus is dead-silent at 500k for a few seconds, fall back to probing.
  unsigned long t0 = millis();
  bool heard = false;
  while (millis() - t0 < STARTUP_SILENCE_MS) {
    if (CAN.checkReceive() == CAN_MSGAVAIL) { heard = true; break; }
  }
  if (!heard) {
    probeBauds();
    printHeader();
  }
}

void emitPlug() {
  sessionNum++;
  busActive = true;
  lastActiveTag = millis();
  Serial.print(F("# PLUG session=")); Serial.print(sessionNum);
  Serial.print(F(" t_ms=")); Serial.println(lastActiveTag);
}

void emitUnplug() {
  busActive = false;
  Serial.print(F("# UNPLUG session=")); Serial.print(sessionNum);
  Serial.print(F(" t_ms=")); Serial.print(millis());
  Serial.print(F(" duration_ms=")); Serial.println(millis() - lastActiveTag);
}

void loop() {
  // Idle detection: if we were active and the bus has gone quiet -> UNPLUG.
  if (busActive && (millis() - lastRxMs > IDLE_MS)) {
    emitUnplug();
  }

  if (CAN.checkReceive() != CAN_MSGAVAIL) {
    return;
  }

  unsigned long id = 0;
  byte len = 0;
  byte buf[8] = {0};
  if (CAN.readMsgBuf(&id, &len, buf) != CAN_OK) {
    return;
  }
  if (!frameLooksValid(id, len)) {
    return;
  }

  // First frame after silence -> PLUG (new session).
  if (!busActive) {
    emitPlug();
  }
  lastRxMs = millis();

  Serial.print(lastRxMs);
  Serial.print(',');
  Serial.print(id, HEX);
  Serial.print(',');
  Serial.print(len);
  for (byte i = 0; i < 8; i++) {
    Serial.print(',');
    if (i < len) {
      if (buf[i] < 16) Serial.print('0');
      Serial.print(buf[i], HEX);
    } else {
      Serial.print(F("--"));
    }
  }
  Serial.print(',');
  Serial.println(isInteresting(id) ? F("CHG") : F("RX"));
}
