#!/usr/bin/env python3
"""
Split a charge_can_sniff v2 log into per-session decoded CSVs + an auth diff.

Handles the v2 format (with '# PLUG session=N' / '# UNPLUG' markers) and the
old single-session format (no markers -> treated as one session).
Input may be UTF-16 (PowerShell redirect) or UTF-8.

Usage:
    python split_sessions.py <logfile> [out_dir]

Outputs, in out_dir (default: <logfile_dir>/decoded/):
    session_01.csv ...   raw frames per session
    summary.txt          per-session stats + physical decode of 0x120/0x121
    auth_diff.txt        0x080/0x081/0x083 first-frames across sessions (static vs rolling?)
"""
import sys, os, collections

def read_text(path):
    raw = open(path, "rb").read()
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16", errors="replace")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("utf-16", errors="replace")

def le16(b, i):
    return b[i] | (b[i + 1] << 8)

def parse(path):
    """Return list of sessions; each = {'num','frames':[(t,id,[bytes])],'markers':[...]}"""
    sessions = []
    cur = None
    def new_session(num):
        return {"num": num, "frames": [], "meta": []}
    auto_num = 0
    for line in read_text(path).splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith("# PLUG"):
            auto_num += 1
            cur = new_session(auto_num)
            sessions.append(cur)
            cur["meta"].append(line)
            continue
        if line.startswith("# UNPLUG"):
            if cur:
                cur["meta"].append(line)
            continue
        if not line[0].isdigit():
            continue  # other comments / headers
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 3:
            continue
        try:
            t = int(parts[0]); idv = int(parts[1], 16); dlc = int(parts[2])
        except ValueError:
            continue
        payload = []
        for x in parts[3:3 + dlc]:
            try:
                payload.append(int(x, 16))
            except ValueError:
                payload.append(0)
        if cur is None:  # old format, no PLUG marker
            auto_num += 1
            cur = new_session(auto_num)
            sessions.append(cur)
        cur["frames"].append((t, idv, payload))
    return sessions

# IDs known to belong to the charge message set (SC + FC + charge housekeeping).
# Any ID seen OUTSIDE this set on the socket tap is evidence the charge socket
# CAN is the SHARED vehicle bus, not a dedicated charge bus.
CHARGE_IDS = set()
CHARGE_IDS |= {0x00B, 0x040, 0x014, 0x120, 0x121, 0x213}
CHARGE_IDS |= set(range(0x080, 0x084))          # auth
CHARGE_IDS |= set(range(0x500, 0x511))          # FC EV/charger params
CHARGE_IDS |= set(range(0x530, 0x537)) | {0x543, 0x553, 0x563}  # keepalive/auth
CHARGE_IDS |= set(range(0x580, 0x588))          # identification / EVSE ID
CHARGE_IDS |= {0x62D, 0x143, 0x130, 0x180, 0x190, 0x640, 0x411, 0x431, 0x6BF, 0x6C2}
CHARGE_IDS |= {0x7BE, 0x7B7}                     # SC diag

def decode_120(b):
    if len(b) < 7: return None
    return dict(I=le16(b,0)*0.01-300, SOC=le16(b,2)*0.01,
                Vlim=le16(b,4)*0.001, modereq=b[6] & 0x07)

def decode_121(b):
    if len(b) < 2: return None
    return dict(Ilim=le16(b,0)*0.01)

def hexs(b):
    return " ".join(f"{x:02X}" for x in b)

def main():
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    path = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(path)), "decoded")
    os.makedirs(out, exist_ok=True)
    sessions = parse(path)
    if not sessions:
        print("no frames parsed"); sys.exit(1)

    summ = []
    authrows = []
    all_non_charge = collections.Counter()
    for s in sessions:
        n = s["num"]; fr = s["frames"]
        # raw csv
        with open(os.path.join(out, f"session_{n:02d}.csv"), "w") as f:
            f.write("t_ms,id_hex,dlc,b0,b1,b2,b3,b4,b5,b6,b7\n")
            for t, idv, b in fr:
                cells = [f"{x:02X}" for x in b] + ["--"] * (8 - len(b))
                f.write(f"{t},{idv:X},{len(b)},{','.join(cells)}\n")
        if not fr:
            summ.append(f"session {n}: (no frames)\n"); continue
        t0, t1 = fr[0][0], fr[-1][0]
        ids = collections.Counter(idv for _, idv, _ in fr)
        # Full time series (endpoints sit at plug/unplug where values are ~0/transient,
        # so report the range across the session, not first/last).
        d120 = [decode_120(b) for _,i,b in fr if i==0x120 and decode_120(b)]
        ilims = [decode_121(b)["Ilim"] for _,i,b in fr if i==0x121 and decode_121(b)]
        lines = [f"=== session {n}: {len(fr)} frames, {(t1-t0)/1000:.1f}s ===",
                 "  meta: " + " | ".join(s["meta"]) if s["meta"] else "  meta: (none)",
                 "  IDs: " + ", ".join(f"{k:X}({v})" for k,v in sorted(ids.items()))]
        if d120:
            I = sorted(x["I"] for x in d120)
            soc = [x["SOC"] for x in d120]
            vl = [x["Vlim"] for x in d120]
            med = I[len(I)//2]
            lines.append(f"  0x120  I: min {I[0]:.2f} / median {med:.2f} / max {I[-1]:.2f} A   "
                         f"SOC {soc[0]:.2f}->{soc[-1]:.2f}%   Vlim {min(vl):.2f}->{max(vl):.2f}V")
        if ilims:
            si = sorted(ilims)
            lines.append(f"  0x121  ChargeCurrentLimit: min {si[0]:.2f} / median {si[len(si)//2]:.2f} / max {si[-1]:.2f} A "
                         f"(start {ilims[0]:.2f} -> end {ilims[-1]:.2f})")
        non_charge = {k: v for k, v in ids.items() if k not in CHARGE_IDS}
        for k, v in non_charge.items():
            all_non_charge[k] += v
        if non_charge:
            lines.append("  NON-CHARGE IDs (shared-bus evidence): "
                         + ", ".join(f"{k:X}({v})" for k, v in sorted(non_charge.items())))
        summ.append("\n".join(lines) + "\n")

        # auth: first frame of each auth id
        row = {"session": n}
        for aid in (0x080, 0x081, 0x083):
            fb = next((b for _,i,b in fr if i==aid), None)
            row[f"{aid:03X}"] = hexs(fb) if fb else "(absent)"
        authrows.append(row)

    # Shared-vs-dedicated bus verdict.
    scope = ["=== BUS SCOPE (shared vehicle CAN vs dedicated charge bus) ==="]
    if all_non_charge:
        scope.append("Non-charge IDs seen on the socket tap (evidence of a SHARED vehicle bus):")
        for k, v in sorted(all_non_charge.items(), key=lambda kv: -kv[1]):
            scope.append(f"  0x{k:03X}  x{v}")
        strong = any(v >= 20 for v in all_non_charge.values())
        scope.append("  => " + ("LIKELY SHARED bus: sustained non-charge traffic present."
                                if strong else
                                "WEAK hint only (few one-off frames); need more / sustained non-charge IDs to conclude."))
    else:
        scope.append("Only charge-set IDs seen. Consistent with a DEDICATED bus OR a gated tap of a")
        scope.append("shared bus (silence/charge-only when idle does NOT prove dedicated).")
    scope_txt = "\n".join(scope) + "\n"

    with open(os.path.join(out, "summary.txt"), "w") as f:
        f.write("\n".join(summ) + "\n" + scope_txt)
    print(scope_txt)

    with open(os.path.join(out, "auth_diff.txt"), "w") as f:
        f.write("Auth frames (FIRST occurrence per session). Identical across sessions => STATIC/replayable.\n")
        f.write("Different each session => rolling challenge/response (crypto, not sniffable).\n\n")
        for aid in ("080", "081", "083"):
            f.write(f"--- 0x{aid} ---\n")
            vals = set()
            for r in authrows:
                f.write(f"  session {r['session']}: {r[aid]}\n")
                if r[aid] != "(absent)":
                    vals.add(r[aid])
            verdict = "STATIC (all identical)" if len(vals) <= 1 else f"VARIES across {len(vals)} distinct values -> likely rolling"
            f.write(f"  => {verdict}\n\n")

    print(f"{len(sessions)} session(s) -> {out}")
    print("  summary.txt, auth_diff.txt, session_NN.csv")

if __name__ == "__main__":
    main()
