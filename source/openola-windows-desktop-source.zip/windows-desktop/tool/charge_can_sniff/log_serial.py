#!/usr/bin/env python3
"""
Reliable serial logger for the charge-CAN sniffer.

Writes every line straight to a UTF-8 file and flushes immediately, so an
unplug / crash / closed window never loses data (unlike a PuTTY scrollback).
Echoes to the console too so you can watch the capture live.

Usage:
    python log_serial.py                 # COM3 @ 115200, auto-named file
    python log_serial.py COM4            # different port
    python log_serial.py COM3 mylog.txt  # explicit output file

Stop with Ctrl+C — the file is already fully written.
Requires: pip install pyserial
"""
import sys, os, time, datetime

try:
    import serial
except ImportError:
    print("pyserial not installed. Run:  pip install pyserial")
    sys.exit(1)

DEFAULT_PORT = "COM3"
BAUD = 115200
CAP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "..", "..", "captures", "charging")

def main():
    port = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PORT
    if len(sys.argv) > 2:
        outpath = sys.argv[2]
    else:
        os.makedirs(CAP_DIR, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        outpath = os.path.join(CAP_DIR, f"ch_can_{stamp}.txt")

    print(f"# opening {port} @ {BAUD}  ->  {outpath}")
    print("# Ctrl+C to stop\n")
    try:
        ser = serial.Serial(port, BAUD, timeout=1)
    except serial.SerialException as e:
        print(f"could not open {port}: {e}")
        print("  - close PuTTY / Arduino Serial Monitor first (port is single-user)")
        print("  - check the port name with:  python -m serial.tools.list_ports")
        sys.exit(1)

    n = 0
    t_start = time.time()
    # newline='' + write raw text; flush every line.
    with open(outpath, "w", encoding="utf-8", newline="") as f:
        try:
            while True:
                raw = ser.readline()
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
                f.write(line + "\n")
                f.flush()
                n += 1
                # Echo markers loudly, thin out the data spam.
                if line.startswith("#") or line.startswith("SELECTED") or n % 200 == 0:
                    print(f"[{n:6d}] {line}")
        except KeyboardInterrupt:
            pass
        finally:
            ser.close()
    dur = time.time() - t_start
    print(f"\n# stopped. {n} lines in {dur:.0f}s -> {outpath}")
    print(f"# decode with:  python {os.path.join(os.path.dirname(__file__),'split_sessions.py')} \"{outpath}\"")

if __name__ == "__main__":
    main()
