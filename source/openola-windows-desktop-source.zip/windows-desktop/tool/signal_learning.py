"""Passive OFF/ON/OFF association analysis. Results never become TX commands."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import threading
import time
import uuid
from alldata import extract

PHASES = ('OFF baseline', 'ON first', 'OFF return', 'ON repeat', 'OFF final')


class LearningSession:
    def __init__(self, label, directory, context=None):
        label = label.strip()
        if not label or len(label) > 100:
            raise ValueError('Enter a function label of 1–100 characters')
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / (time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:8] + '.json')
        self.data = {'schema': 1, 'label': label, 'context': context or {}, 'passive': True, 'phases': []}
        self.lock = threading.Lock()
        self.active = None

    def begin(self):
        with self.lock:
            if self.active or len(self.data['phases']) >= len(PHASES):
                raise ValueError('Start a new session for another sequence')
            self.active = {'name': PHASES[len(self.data['phases'])], 'started': time.time(), 'frames': [], 'dropped': 0}

    def record(self, stamp, cid, data):
        with self.lock:
            if self.active is None:
                return
            if len(self.active['frames']) >= 50000:
                self.active['dropped'] += 1
                return
            self.active['frames'].append([stamp, cid, data.hex()])

    def finish(self, error=None):
        with self.lock:
            if self.active is None:
                raise ValueError('No capture active')
            phase = self.active
            self.active = None
            phase['ended'] = time.time()
            phase['error'] = error
            self.data['phases'].append(phase)
        self.save()
        return f'{phase["name"]}: {len(phase["frames"])} frames saved to {self.path.name}'

    def save(self):
        temporary = self.path.with_suffix('.tmp')
        temporary.write_text(json.dumps(self.data), encoding='utf-8')
        temporary.replace(self.path)

    def save_mapping(self, candidate):
        if candidate.get('unverified'):
            raise ValueError('Phase evidence is unverified and cannot be saved as an association')
        if len(self.data['phases']) != 5:
            raise ValueError('Complete both repetitions before saving an association')
        record = {'label': self.data['label'], 'kind': 'observed_status_only', 'tx_enabled': False,
                  'candidate': candidate, 'evidence': str(self.path),
                  'sha256': hashlib.sha256(self.path.read_bytes()).hexdigest(), 'saved': time.time()}
        with (self.directory / 'observed_mappings.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(record) + '\n')
        return 'Saved observed status association. No transmit command was created.'


def rank_candidates(session, dbc):
    phases = session['phases']
    if len(phases) != 5:
        raise ValueError('Complete OFF → ON → OFF → ON → OFF before analysis')
    if any(p.get('error') or p.get('dropped') for p in phases):
        raise ValueError('Capture is incomplete or dropped frames; repeat the session')
    summaries = []
    labels = {}
    for phase in phases:
        counters = defaultdict(Counter)
        spans = {}
        for stamp, cid, raw_hex in phase['frames']:
            data = bytes.fromhex(raw_hex)
            # UDS exchanges can reflect our tooling rather than physical switches.
            if cid in (0x78E, 0x7B1, 0x786, 0x7B0, 0x7A6, 0x7B4):
                continue
            for bit in range(len(data) * 8):
                key = (cid, 'bit', bit)
                counters[key][(data[bit // 8] >> (bit % 8)) & 1] += 1
                labels[key] = f'Byte {bit // 8}, bit {bit % 8} (LSB=0)'
                spans.setdefault(key, [stamp, stamp])[1] = stamp
            message = dbc.get(cid)
            if message and len(data) >= int(message.get('dlc', 8)):
                for signal in message['signals']:
                    key = (cid, 'signal', signal['name'])
                    counters[key][extract(data, signal)] += 1
                    labels[key] = signal['name']
                    spans.setdefault(key, [stamp, stamp])[1] = stamp
        summaries.append({k: c for k, c in counters.items() if c.total() >= 3 and spans[k][1] - spans[k][0] >= .2})
    common = set(summaries[0]).intersection(*(set(s) for s in summaries[1:]))
    results = []
    for key in common:
        counts = [s[key] for s in summaries]
        baseline = counts[0].most_common(1)[0][0]
        off_purity = [counts[i][baseline] / counts[i].total() for i in (0, 2, 4)]
        contrast = [1 - counts[i][baseline] / counts[i].total() for i in (1, 3)]
        # Steady switches rank highly; flashing lamps can still rank at ~50%.
        # Counters/noisy bits generally fail the repeated OFF stability check.
        if min(off_purity) < .9 or min(contrast) < .2:
            continue
        active = [set(counts[i]) - {baseline} for i in (1, 3)]
        if not active[0].intersection(active[1]):
            continue
        score = round(100 * min(off_purity) * min(contrast), 1)
        results.append({'can_id': f'{key[0]:03X}', 'kind': key[1], 'selector': key[2], 'name': labels[key],
                        'score': score, 'off': baseline,
                        'on': [counts[i].most_common(4) for i in (1, 3)],
                        'samples': [c.total() for c in counts],
                        'note': 'Repeated association; may be switch input, output status, or a correlated signal. Not proof of a command.'})
    return sorted(results, key=lambda c: (-c['score'], c['can_id'], c['name']))


def analysis_report(session, dbc):
    """Explain failures without promoting delayed/noisy changes to associations."""
    phases = session['phases']
    issues = []
    try:
        candidates = rank_candidates(session, dbc)
    except ValueError as exc:
        candidates = []
        issues.append(str(exc))
    counters = []
    quality = []
    for phase in phases:
        counts = defaultdict(Counter)
        frames = phase['frames']
        for stamp, cid, raw in frames:
            if cid in (0x78E, 0x7B1, 0x786, 0x7B0, 0x7A6, 0x7B4):
                continue
            data = bytes.fromhex(raw)
            for bit in range(len(data) * 8):
                counts[(cid, 'bit', bit)][(data[bit // 8] >> (bit % 8)) & 1] += 1
            message = dbc.get(cid)
            if message and len(data) >= int(message.get('dlc', 8)):
                for signal in message['signals']:
                    counts[(cid, 'signal', signal['name'])][extract(data, signal)] += 1
        counters.append(counts)
        quality.append({'phase': phase['name'], 'frames': len(frames),
                        'receive_span_seconds': round(frames[-1][0] - frames[0][0], 3) if frames else 0,
                        'dropped': phase.get('dropped', 0), 'error': phase.get('error')})
    changed = []
    keys = set().union(*(set(c) for c in counters))
    accepted = {(int(c['can_id'], 16), c['kind'], c['selector']) for c in candidates}
    for key in keys - accepted:
        values = [c.get(key, Counter()) for c in counters]
        if len(set().union(*(set(c) for c in values))) <= 1:
            continue
        changed.append({'can_id': f'{key[0]:03X}', 'kind': key[1], 'selector': key[2],
                        'name': key[2] if key[1] == 'signal' else f'Byte {key[2] // 8}, bit {key[2] % 8}',
                        'phase_counts': [c.most_common(8) for c in values],
                        'unverified': True})
    changed.sort(key=lambda c: (c['kind'] != 'signal', c['can_id'], str(c['name'])))
    if not candidates:
        issues.append('No signal passed repeated OFF stability and ON contrast. Inspect phase distributions; changed data alone does not establish a mapping.')
    return {'candidates': candidates, 'changed_unverified': changed, 'quality': quality, 'issues': issues,
            'timestamp_limit': 'Times are PC receive times. Transport buffering or source delay cannot be measured from these captures.'}
