# oladiag — self-hosted Ola S1 fault-code reader

Reads Diagnostic Trouble Codes (DTCs) from the scooter's BMS, VCU and MCU over
the scooter's own wifican gRPC bridge, and decodes them with the fault table
extracted from the Ola Diagnostic app. No Ola backend required.

See `../reverse_engineering/PROTOCOL.md` for how it works.

## Install (once)

```
cd tool
python -m pip install -r oladiag/requirements.txt
```

The gRPC stubs (`oladiag/wifican/wifican_pb2*.py`) are pre-generated. To
regenerate after editing the proto:
```
python -m grpc_tools.protoc -I oladiag --python_out=oladiag/wifican \
    --grpc_python_out=oladiag/wifican oladiag/wifican.proto
# then in wifican_pb2_grpc.py change "import wifican_pb2" to "from . import wifican_pb2"
```

## Prove it works with no scooter

```
python -m oladiag selftest          # seed/key + DTC table load
python tests/test_e2e.py            # full read against a built-in mock vehicle
```

## Use it with the scooter

1. Scooter in diagnostic mode, USB connected, `adb devices` shows it.
2. Find the wifican gRPC port on the scooter (from the step-01 capture, e.g.
   `netstat -tlnp` on the SOM) and forward it:
   ```
   adb forward tcp:50051 tcp:<vehicle-grpc-port>
   ```
3. Read faults:
   ```
   python -m oladiag --host 127.0.0.1 --port 50051 read
   python -m oladiag --host 127.0.0.1 --port 50051 read --json faults.json
   python -m oladiag --host 127.0.0.1 --port 50051 --secure read   # if TLS
   python -m oladiag --host 127.0.0.1 --port 50051 read --ecu BMS --ecu VCU
   ```
4. Clear faults (destructive — only when you mean it):
   ```
   python -m oladiag --host 127.0.0.1 --port 50051 clear --ecu BMS
   ```

If connect fails: check the `adb forward`, and try with/without `--secure`
(the server is either plaintext or mTLS — the capture will tell us which).
`--dump` switches from the filtered stream to CanDumpStream if `Init` filtering
misbehaves.

## Layout

```
oladiag/
  __main__.py     CLI (read / clear / selftest)
  transport.py    gRPC channel + CAN stream reader/writer
  uds.py          UDS session, security access, read/clear DTC, ISO-TP TX
  isotp.py        ISO-TP framing + reassembly
  canframe.py     16-byte can_frame <-> (id, data) codec
  seedkey.py      seed→key security algorithm (ported from the app)
  dtc.py          DTC response parser + description lookup
  wifican.proto   gRPC contract
  wifican/        generated protobuf/grpc stubs
  config/         dtc_ecu_list.json, da_can_dbc.json
  certs/          ecos.crt, ecos.key, OLA_DIAG_root.crt (mTLS)
tests/
  mock_vehicle.py fake wifican server (3 ECUs) for offline testing
  test_e2e.py     end-to-end read test -> prints PASS/FAIL
```

## Status

Verified end-to-end against the mock vehicle: session control, seed/key
round-trip, ISO-TP multi-frame both directions, `19 02` DTC read, and decode
with real descriptions + status flags. Not yet run against the physical scooter
— the only unknowns are the wifican **port** and **plaintext-vs-mTLS**, both of
which the bench capture resolves.
