"""Status + charge-session helpers for the desktop GUI (APK Status parity).

Decodes broadcast battery/fault registers and optionally records a charge-CAN
session log under captures/charging/ for later protocol work.
"""
from __future__ import annotations

import json
import re
import threading
import time
from collections import deque
from datetime import datetime
from pathlib import Path

from alldata import extract

FAULT_IDS = [0x410, 0x411, 0x122, 0x430, 0x431, 0x333, 0x334, 0x66E, 0x213, 0x210, 0x642, 0x11C, 0x353, 0x640]
BATTERY_IDS = [0x353, 0x120, 0x121, 0x11C, 0x62D, 0x640, 0x313, 0x130, 0x213, 0x143, 0x180, 0x190]

# Vehicle-CAN IDs that matter for SC/FC sniff (charge-port may have more).
CHARGE_IDS = sorted(set(
    [0x00B, 0x014, 0x080, 0x081, 0x083, 0x11C, 0x120, 0x121, 0x130, 0x143, 0x180, 0x190,
     0x213, 0x411, 0x62D, 0x640, 0x353]
    + list(range(0x500, 0x511))
    + list(range(0x530, 0x537))
    + [0x543, 0x553, 0x563]
    + list(range(0x580, 0x588))
))

FAULTY = re.compile(
    r'fault|error|fail|warn|protect|abnormal|overcurrent|overvolt|undervolt|'
    r'overtemp|short|disconnect|timeout|corrupt|stall|deviation', re.I)
BENIGN = re.compile(r'demand|status_signal|counter|calibration|balancing|indicator_ttl', re.I)

# 0x62D Charger_Connected — 4 states per MoveOS 5 ChargerTypes enum (adds Boost).
CHARGER_CONNECTED = {0: 'None', 1: 'Fast Charger', 2: 'Slow Charger', 3: 'Boost Charger'}
# 0x143 Vehicle_Mode_Level_1 / ChargingModes — MoveOS 5 adds 6 Boost Charge.
VEH_L1 = {0: 'SNA', 1: 'Idle', 2: 'Safe', 3: 'Slow Charge', 4: 'Fast Charge',
          5: 'Discharge', 6: 'Boost Charge'}
VEH_L2 = {
    0: 'SNA', 1: 'OFF', 2: 'VACATION', 3: 'SLEEP', 4: 'VEHICLE IDLE',
    5: 'SC_CHARGE IDLE', 6: 'SC_CHARGE FAULT', 7: 'SC_CHARGE ACTIVE',
    8: 'FC_CHARGE IDLE', 9: 'FC_CHARGE FAULT', 10: 'FC_CHARGE ACTIVE',
    11: 'PARK', 12: 'DRIVE', 13: 'ALARM',
}
CHG_MODE = {
    0: 'Disabled', 1: 'CC', 2: 'CV', 3: 'Complete', 4: 'CC End',
    5: 'CV End', 6: 'Balancing', 7: 'Standby',
}
CHG_RATE = {
    0: 'SC_C_RATE_01', 1: 'SC_C_RATE_02', 2: 'SC_C_RATE_03',
    3: 'FC_C_RATE_01', 4: 'FC_C_RATE_02', 5: 'FC_C_RATE_03',
}


def _load_vehicle_notifications():
    """0x6D0 CommandFromVehicle ordinal -> name, from moveos5_catalog.json."""
    try:
        data = json.loads((Path(__file__).with_name('moveos5_catalog.json'))
                          .read_text(encoding='utf-8'))
        raw = data.get('CommandFromVehicle', {})
        return {int(k): v for k, v in raw.items() if not k.startswith('_')}
    except Exception:
        return {}


COMMAND_FROM_VEHICLE = _load_vehicle_notifications()

# Notifications worth flagging red (derate / fault / charge-block / access-revoke).
NOTIF_ALERT = re.compile(
    r'DERATE|DISABLED|FAULT|FAIL|ERROR|THERMAL|ACCIDENT|FALL_DETECT|REVOKED|CUTOFF|'
    r'OVER_|OOR|UNPLUG|PAYMENT|MISMATCH|NOT_DELIVER|RESTRICTED|BRAKE_FAILURE|GRADE[234]|'
    r'CONTACT_CS|CANT_|CANNOT|RUNAWAY|_NA\b|EXHAUST|UPGRADE_FOR', re.I)


# 0x660 VEHICLE_CONFIG_DATA_6 / feature status. Bit map reconstructed from
# VehicleInfoParser.parseFeatureStatus (bytes 0-4). Boolean features = 1 bit;
# tech-pack (TP) entitlements = 2-bit fields (0 = not entitled, >0 = entitled/active).
# A few bits marked '?' were ambiguous in the decompile — verify live by toggling.
FEATURE_BOOL_0660 = [   # (name, byte, bit)
    ('Boost mode', 0, 0), ('Fall detection', 0, 1), ('Tow/tamper detect', 0, 2),
    ('Proximity lock', 0, 3), ('Hill hold', 0, 4), ('Smart headlight', 0, 5),
    ('Smart DRL', 0, 6), ('Auto headlight', 0, 7),
    ('Hazard light', 1, 0), ('Auto-indicator off', 1, 1),
    ('Motor cutoff delay?', 1, 2), ('Vacation mode', 1, 3),
]
FEATURE_TP_0660 = [     # (name, byte, low_bit) — 2-bit value
    ('Advanced regen (TP)', 1, 4), ('Fast charger (TP)', 1, 6),
    ('Hyper charger (TP)', 2, 0), ('Energy insights (TP)', 2, 2),
    ('Proximity L/U (TP)', 2, 4), ('Geo-fencing (TP)', 2, 6),
    ('Time-fencing (TP)', 3, 0), ('Mode-fencing (TP)', 3, 2),
    ('New upgrades (TP)', 3, 4), ('Hill-hold (TP)?', 3, 6),
    ('Early-beta (TP)?', 4, 0), ('Tow protection (TP)', 4, 2),
    ('Smart park (TP)', 4, 4),
]


def decode_feature_status(snap):
    """Decode 0x660 into {name: bool} (features) and {name: int} (tech-packs).

    Returns None if 0x660 isn't present. See FEATURE_*_0660 for the bit map.
    """
    d = _raw(snap, 0x660)
    if not d or len(d) < 5:
        return None
    feats = {}
    for name, bi, bit in FEATURE_BOOL_0660:
        feats[name] = bool((d[bi] >> bit) & 1)
    tps = {}
    for name, bi, lo in FEATURE_TP_0660:
        tps[name] = (d[bi] >> lo) & 3
    return {'features': feats, 'tech_packs': tps, 'raw': d[:5].hex().upper(),
            'raw_bytes': bytes(d[:8])}


def decode_vehicle_notification(snap):
    """Decode 0x6D0 byte0 -> (code, name, is_alert), or None if absent / NO_COMMAND."""
    d = _raw(snap, 0x6D0)
    if not d:
        return None
    code = d[0]
    if code == 0:                       # NO_COMMAND
        return None
    name = COMMAND_FROM_VEHICLE.get(code, f'UNKNOWN_{code}')
    return code, name, bool(NOTIF_ALERT.search(name))


def _raw(snap, cid):
    """Return the raw 8-byte payload for a CAN id from a snapshot, or None.

    Snapshot values are either (ts, data) or bare data (bytes/list).
    """
    pair = snap.get(cid)
    if not pair:
        return None
    if isinstance(pair, tuple):
        data = pair[1]
    elif pair and isinstance(pair[0], (int, float)) and len(pair) == 2 \
            and not isinstance(pair[1], (int, float)):
        data = pair[1]
    else:
        data = pair
    try:
        return bytes(data)
    except (TypeError, ValueError):
        return None


def _sig(dbc, snap, cid, *names):
    pair = snap.get(cid)
    if not pair:
        return None
    _, data = pair if isinstance(pair[0], (int, float)) else (None, pair)
    msg = dbc.get(cid)
    if not msg or len(data) < int(msg.get('dlc', 8)):
        return None
    by_name = {s['name']: s for s in msg['signals']}
    for n in names:
        s = by_name.get(n)
        if s:
            return extract(data, s)
    lower = {k.lower(): v for k, v in by_name.items()}
    for n in names:
        s = lower.get(n.lower())
        if s:
            return extract(data, s)
        for k, s in lower.items():
            if n.lower() in k:
                return extract(data, s)
    return None


def active_faults(dbc, snap):
    """Return set of '0xXXX / SignalName' for asserted fault bits."""
    out = set()
    for cid in FAULT_IDS:
        pair = snap.get(cid)
        if not pair:
            continue
        data = pair[1] if isinstance(pair, tuple) else pair
        msg = dbc.get(cid)
        if not msg or len(data) < int(msg.get('dlc', 8)):
            continue
        for s in msg['signals']:
            if s.get('bitlength') != 1:
                continue
            name = s['name']
            if not FAULTY.search(name) or BENIGN.search(name):
                continue
            if extract(data, s) == 1:
                out.add(f'0x{cid:03X} / {name}')
    return out


_HW_FIELDS = ['BCM', 'BMS', 'BMS DipSwitch', 'MCU', 'Charger', 'Motor']


def decode_hardware(snap):
    """Per-ECU hardware-variant codes: 0x610 (BCM/BMS/MCU/Charger/Motor) and
    0x678 (SOM/Display). Used to match firmware to the controller generation."""
    out = {}
    d = _raw(snap, 0x610)
    if d:
        for i, name in enumerate(_HW_FIELDS):
            if i < len(d):
                out[name] = d[i]
    d2 = _raw(snap, 0x678)
    if d2:
        if len(d2) > 0:
            out['SOM'] = d2[0]
        if len(d2) > 1:
            out['Display'] = d2[1]
    return out


def decode_dcir(snap):
    """Per-cell DC internal resistance in mOhm (0x1AB-0x1AE, uohm, 14 cells)."""
    out = []
    for cid, count in [(0x1AB, 4), (0x1AC, 4), (0x1AD, 4), (0x1AE, 2)]:
        d = _raw(snap, cid)
        for i in range(count):
            if d and i * 2 + 1 < len(d):
                out.append((d[i * 2] | d[i * 2 + 1] << 8) / 1000.0)
            else:
                out.append(None)
    return out


def _plausible(v, lo, hi):
    """Return v only when it is a finite number inside [lo, hi], else None.

    Filters sentinel / disconnected-sensor / stale-frame values (e.g. a raw 0xFFFF
    temperature that decodes to hundreds of °C) so the UI shows '—' instead of garbage.
    """
    if v is None:
        return None
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    if v != v:  # NaN
        return None
    return v if lo <= v <= hi else None


def _temp_313(snap, byte_lo):
    """Firmware-exact 0x313 temperature: LE16 at byte_lo * 0.01 degC, plausibility-bounded."""
    d = _raw(snap, 0x313)
    if not d or len(d) < byte_lo + 2:
        return None
    raw = d[byte_lo] | (d[byte_lo + 1] << 8)
    return _plausible(raw * 0.01, -40.0, 200.0)


def decode_battery(dbc, snap):
    soc = _sig(dbc, snap, 0x352, 'Display_SoC') or _sig(dbc, snap, 0x11C, 'Pack_SOC_00') \
        or _sig(dbc, snap, 0x120, 'Overall_SOC')  # Display_SoC moved 0x353->0x352
    range_km = _sig(dbc, snap, 0x353, 'Vehicle_Range')
    amps = _sig(dbc, snap, 0x120, 'Overall_Battery_Current')
    volts = _sig(dbc, snap, 0x640, 'Bus_Voltage_00_10ms') or _sig(dbc, snap, 0x11C, 'Battery_voltage_OCV_00')
    # Temps/speed decoded straight from 0x313 (MCU_Data_1) per firmware parserMcuData:
    #   speed = LE16(b0:2)*0.1, MCU_temp = LE16(b2:4)*0.01, motor_temp = LE16(b4:6)*0.01.
    # Bounded so a fault/sentinel raw shows '—', not e.g. 386 degC.
    mcu_t = _temp_313(snap, 2)
    motor_t = _temp_313(snap, 4)
    speed = _plausible(_sig(dbc, snap, 0x313, 'Vehicle_speed_in_kmph', 'Vehicle_Speed'), 0.0, 200.0)
    soc = _plausible(soc, 0.0, 100.0)
    range_km = _plausible(range_km, 0.0, 400.0)
    volts = _plausible(volts, 0.0, 200.0)
    chg_conn_raw = _sig(dbc, snap, 0x62D, 'Charger_Connected')
    plugged = _sig(dbc, snap, 0x62D, 'Charger_Plugged_In')
    connected = (chg_conn_raw or 0) > 0.5 or (plugged or 0) > 0.5
    charging = connected and (amps or 0) > 0.5
    if soc is None and volts is None and range_km is None and amps is None:
        return None
    return {
        'soc': soc, 'range_km': range_km, 'volts': volts, 'amps': amps,
        'motor_t': motor_t, 'mcu_t': mcu_t, 'speed': speed,
        'charging': charging, 'charger_connected': connected,
        'charger_connected_raw': chg_conn_raw, 'plugged': plugged,
        'ts': time.time(),
    }


def decode_charge(dbc, snap):
    """High-signal charge fields for the Status / Charge snoop UI."""
    def enum(raw, table):
        if raw is None:
            return None
        try:
            return table.get(int(raw), f'?{int(raw)}')
        except (TypeError, ValueError):
            return str(raw)

    l1 = _sig(dbc, snap, 0x143, 'Vehicle_Mode_Level_1')
    l2 = _sig(dbc, snap, 0x143, 'Vehicle_Mode_Level_2')
    return {
        'charger_type': enum(_sig(dbc, snap, 0x62D, 'Charger_Connected'), CHARGER_CONNECTED),
        'plugged': _sig(dbc, snap, 0x62D, 'Charger_Plugged_In'),
        'veh_l1': enum(l1, VEH_L1),
        'veh_l2': enum(l2, VEH_L2),
        'charge_v_lim': _sig(dbc, snap, 0x120, 'Overall_Charge_Voltage_limit'),
        'charge_i_lim': _sig(dbc, snap, 0x121, 'Overall_Charge_current_limit'),
        'pack_amps': _sig(dbc, snap, 0x120, 'Overall_Battery_Current'),
        'chg_avail_v': _sig(dbc, snap, 0x213, 'Charging_Voltage_Available_range'),
        'chg_avail_i': _sig(dbc, snap, 0x213, 'Charging_Current_Available_range'),
        'chg_mode': enum(_sig(dbc, snap, 0x130, 'Charging_Mode_00'), CHG_MODE),
        'chg_rate': enum(_sig(dbc, snap, 0x180, 'Charging_Rate'), CHG_RATE),
        'auth_err': _sig(dbc, snap, 0x213, 'Authentication_Error'),
        'sc_fault': _sig(dbc, snap, 0x213, 'Slow_Charger_Fault_Information'),
        'contactor': _sig(dbc, snap, 0x11C, 'Contactor_state_00'),
        'power_w': None,
    }


def decode_charge_extra(snap):
    """MoveOS 5 charge fields decoded from raw bytes (absent from da_can_dbc.json).

    From ChargerInfoParser (com.olaelectric.vehicleparser):
      0x213 byte6 bit2  -> charger billing / paid-session flag
      0x508 byte1 bit2  -> vehicle connector latched
      0x62D byte0 bit2  -> charger plugged; bits0-1 -> charger type (enum above)
      0x584 / 0x585     -> EVSE identification low / high 8 bytes (station id)
    """
    out = {'billing': None, 'connector_latched': None, 'evse_id': None,
           'charger_type': None, 'plugged': None}
    d213 = _raw(snap, 0x213)
    if d213 and len(d213) > 6:
        out['billing'] = bool(d213[6] & 0x04)
    d508 = _raw(snap, 0x508)
    if d508 and len(d508) > 1:
        out['connector_latched'] = bool((d508[1] >> 2) & 1)
    d62d = _raw(snap, 0x62D)
    if d62d:
        out['charger_type'] = CHARGER_CONNECTED.get(d62d[0] & 0x03, f'?{d62d[0] & 3}')
        out['plugged'] = bool((d62d[0] >> 2) & 1)
    lo, hi = _raw(snap, 0x584), _raw(snap, 0x585)
    if lo or hi:
        parts = []
        if lo:
            parts.append(lo.hex().upper())
        if hi:
            parts.append(hi.hex().upper())
        out['evse_id'] = ':'.join(parts) if parts else None
    return out


def enrich_power(chg: dict, batt=None):
    v = None
    if batt:
        v = batt.get('volts')
    v = v or chg.get('charge_v_lim') or chg.get('chg_avail_v')
    a = None
    if batt:
        a = batt.get('amps')
    a = a if a is not None else chg.get('pack_amps')
    if v is not None and a is not None and a > 0:
        chg['power_w'] = round(float(v) * float(a), 1)
    return chg


class SessionLog:
    """Append-only tagged activity log (one file per Wi-Fi session).

    Tags: CMD, FAULT, LIVE, CHARGE, CONN, CAL, SYS — same as APK AutoLog.
    Charging frames/vitals live in ChargeSessionRecorder (separate JSONL).
    """

    def __init__(self, root: Path, max_bytes=2_000_000, tail=500):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.max_bytes = max_bytes
        self.tail = deque(maxlen=tail)
        self._lock = threading.Lock()
        self.path = None
        self._prev = None

    def set_root(self, root: Path):
        """Change output folder; takes effect on the next begin_session()."""
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def begin_session(self, host: str = ''):
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.path = self.root / f'activity_{stamp}.log'
        self._prev = self.path.with_suffix(self.path.suffix + '.1')
        self.path.touch(exist_ok=True)
        self.log('CONN', f'session start host={host} dir={self.root}'.strip())
        return self.path

    def end_session(self, reason: str = 'disconnect'):
        if self.path:
            self.log('CONN', f'session end ({reason})')

    def log(self, cat_or_msg, msg=None):
        if msg is None:
            cat, text = 'SYS', cat_or_msg
        else:
            cat, text = cat_or_msg, msg
        line = f'{datetime.now().strftime("%m-%d %H:%M:%S.%f")[:-3]}  [{cat}]  {text}'
        with self._lock:
            try:
                if self.path and self.path.exists() and self.path.stat().st_size > self.max_bytes:
                    try:
                        self.path.replace(self._prev)
                    except OSError:
                        self.path.write_text('', encoding='utf-8')
                if self.path:
                    with self.path.open('a', encoding='utf-8') as f:
                        f.write(line + '\n')
            except OSError:
                pass
            self.tail.append(line)
        return line

    def lines(self):
        with self._lock:
            return list(self.tail)

    def export_text(self):
        parts = []
        for p in (self._prev, self.path):
            if p and p.exists():
                try:
                    parts.append(p.read_text(encoding='utf-8'))
                except OSError:
                    pass
        return ''.join(parts) or '\n'.join(self.lines())

    def clear(self):
        with self._lock:
            try:
                if self.path:
                    self.path.write_text('', encoding='utf-8')
                if self._prev and self._prev.exists():
                    self._prev.unlink()
            except OSError:
                pass
            self.tail.clear()
        self.log('SYS', 'log cleared')


class ChargeSessionRecorder:
    """While active, write every CHARGE_IDS frame + decoded summary + vitals to JSONL."""

    def __init__(self, root: Path, dbc: dict):
        self.root = Path(root)
        self.dbc = dbc
        self.active = False
        self.path = None
        self._lock = threading.Lock()
        self._last_raw = {}
        self.frames = 0
        self.vitals = 0
        self.started_at = None
        self._last_vitals_at = 0.0

    def set_root(self, root: Path):
        """Change output folder; takes effect on the next start()."""
        if self.active:
            raise RuntimeError('Stop the charge session before changing the folder')
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def start(self):
        self.root.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.path = self.root / f'charge_session_{stamp}.jsonl'
        self.active = True
        self.frames = 0
        self.vitals = 0
        self.started_at = time.time()
        self._last_raw.clear()
        self._last_vitals_at = 0.0
        self._write({
            'event': 'session_start',
            't': self.started_at,
            'note': 'Vehicle-CAN sniff via Wi-Fi CanDumpStream. Auth/FC on ch_can may be absent.',
            'watch_ids': [f'{i:03X}' for i in CHARGE_IDS],
        })
        return self.path

    def stop(self):
        if not self.active:
            return self.path
        self._write({
            'event': 'session_stop',
            't': time.time(),
            'frames': self.frames,
            'vitals': self.vitals,
            'duration_s': round(time.time() - (self.started_at or time.time()), 1),
        })
        self.active = False
        return self.path

    def _write(self, obj: dict):
        if not self.path:
            return
        with self._lock:
            with self.path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(obj, separators=(',', ':'), default=str) + '\n')

    def on_frame(self, stamp, cid, data: bytes):
        if not self.active or cid not in CHARGE_IDS:
            return
        prev = self._last_raw.get(cid)
        if prev == data:
            return  # de-dupe identical payloads
        self._last_raw[cid] = data
        self.frames += 1
        signals = {}
        msg = self.dbc.get(cid)
        if msg and len(data) >= int(msg.get('dlc', 8)):
            for s in msg['signals']:
                name = s['name']
                if 'spare' in name.lower() or 'reserved' in name.lower():
                    continue
                try:
                    signals[name] = extract(data, s)
                except Exception:
                    pass
        self._write({
            't': stamp,
            'id': f'{cid:03X}',
            'data': data.hex(),
            'signals': signals or None,
        })

    def on_vitals(self, fields: dict, min_interval=2.0):
        """Periodic SOC/V/A/contactor/limits snapshot (rate-limited)."""
        if not self.active:
            return
        now = time.time()
        if now - self._last_vitals_at < min_interval:
            return
        self._last_vitals_at = now
        self.vitals += 1
        row = {'event': 'vitals', 't': now}
        for k, v in fields.items():
            if v is not None:
                row[k] = v
        self._write(row)
