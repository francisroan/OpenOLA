"""Passive learning window owned by the main Tk app."""
import json
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from signal_learning import LearningSession, PHASES, analysis_report


class LearningWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.session = None
        self.candidates = []
        self.title('Learn a scooter signal • passive capture')
        self.geometry('980x650')
        self.minsize(840, 580)
        p = ttk.Frame(self, padding=18)
        p.pack(fill='both', expand=True)
        ttk.Label(p, text='Operate the scooter. Find what changes.', font=('Segoe UI', 18, 'bold')).pack(anchor='w')
        ttk.Label(p, text='Only records incoming CAN. No control packets, access unlocks or mode changes are sent.', wraplength=900).pack(anchor='w', pady=6)
        line = ttk.Frame(p)
        line.pack(fill='x', pady=8)
        self.label = tk.StringVar(value='Right indicator')
        ttk.Combobox(line, textvariable=self.label, values=['Right indicator', 'Left indicator', 'Horn', 'Left brake lever',
                     'Right brake lever', 'Side stand down', 'Low beam', 'High beam', 'Brake light'], width=30).pack(side='left')
        ttk.Button(line, text='New session', command=self.new_session).pack(side='left', padx=8)
        ttk.Button(line, text='Open saved session', command=self.open_session).pack(side='left')
        self.instructions = tk.StringVar(value='Connect in the main window, enter a function label, then click New session.')
        ttk.Label(p, textvariable=self.instructions, font=('Segoe UI', 12, 'bold'), wraplength=900).pack(anchor='w', pady=9)
        ttk.Label(p, text='Change only the named control. Hold brake levers during ON; let indicators flash.\n'
                  'For horn, use short repeated taps throughout each ON capture. Keep other controls untouched.\n'
                  'Side stand down: OFF = stand raised, ON = stand lowered. Keep the scooter securely supported.', wraplength=900).pack(anchor='w')
        controls = ttk.Frame(p)
        controls.pack(fill='x', pady=10)
        self.capture_button = ttk.Button(controls, text='Record • 3s settling + 8s capture', command=self.capture)
        self.capture_button.pack(side='left')
        ttk.Button(controls, text='Save selected association', command=self.save_mapping).pack(side='left', padx=8)
        ttk.Button(controls, text='View phase evidence', command=self.show_evidence).pack(side='left')
        self.report = None
        self.status = tk.StringVar(value='No session yet')
        ttk.Label(p, textvariable=self.status, wraplength=900).pack(anchor='w', pady=4)
        frame = ttk.Frame(p)
        frame.pack(fill='both', expand=True)
        self.table = ttk.Treeview(frame, columns=('score', 'cid', 'kind', 'name', 'off', 'on'), show='headings')
        for key, title, width in [('score', 'Score*', 55), ('cid', 'CAN ID', 65), ('kind', 'Type', 65), ('name', 'Candidate', 360),
                                  ('off', 'OFF value', 85), ('on', 'ON values', 150)]:
            self.table.heading(key, text=title)
            self.table.column(key, width=width, minwidth=45)
        scroll = ttk.Scrollbar(frame, command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side='left', fill='both', expand=True)
        scroll.pack(side='right', fill='y')
        ttk.Label(p, text='*Correlation score, not confidence that this is a command. Switch inputs, lamp status and other effects may all correlate.\n'
                  'Saved associations appear as “Learned:” rows in Live Data. They never become write commands.', wraplength=900).pack(anchor='w', pady=8)
        self.protocol('WM_DELETE_WINDOW', self.close)

    def close(self):
        if self.app.busy:
            self.status.set('Wait for the current capture or analysis to finish before closing this window.')
            return
        self.destroy()

    def new_session(self):
        if self.app.busy:
            return
        try:
            from scooter_backend import ROOT
            self.session = LearningSession(self.label.get(), ROOT / 'captures/gui/learning',
                                           {'endpoint': self.app.host.get() + ':' + self.app.port.get(),
                                            'mode_and_firmware': self.app.mode_text.get()})
            self.clear_results()
            self.update_stage()
        except ValueError as exc:
            messagebox.showerror('New session', str(exc), parent=self)

    def clear_results(self):
        self.candidates = []
        self.report = None
        for iid in self.table.get_children():
            self.table.delete(iid)

    def update_stage(self):
        if not self.winfo_exists():
            return
        index = len(self.session.data['phases'])
        if index < 5:
            state = 'ON / active' if index in (1, 3) else 'OFF / released'
            self.instructions.set(f'{index + 1}/5 • {self.session.data["label"]}: set {state}, then record.')
            self.capture_button.configure(state='normal')
        else:
            self.instructions.set('Sequence complete. Review the repeated associations below.')
            self.capture_button.configure(state='disabled')
            self.analyze()

    def capture(self):
        if self.app.busy or self.session is None:
            return
        if not self.app.connected:
            messagebox.showerror('Capture', 'Connect to the scooter in the main window first.', parent=self)
            return
        if len(self.session.data['phases']) >= 5:
            return
        session = self.session
        self.app.live = False
        self.status.set('Hold the selected state: settling for 3 seconds, then recording for 8 seconds.')
        self.capture_button.configure(state='disabled')
        def done(result):
            self.status.set(result)
            self.update_stage()
        self.app.run('Passive capture: ' + PHASES[len(session.data['phases'])],
                     lambda: self.app.scooter.capture_stage(session), done)
        self.after(500, self.check_failure)

    def check_failure(self):
        if not self.winfo_exists():
            return
        if self.app.busy:
            self.after(500, self.check_failure)
        elif self.capture_button['state'] == 'disabled' and len(self.session.data['phases']) < 5:
            self.status.set('Capture stopped. If it failed, start a new session; see the main window error.')
            self.update_stage()

    def analyze(self):
        self.clear_results()
        self.status.set('Comparing all raw bits and named signals across five stages…')
        def done(report):
            self.report = report
            self.candidates = report['candidates']
            for i, c in enumerate(self.candidates):
                on = ', '.join(str(pair[0]) for pair in c['on'][0])
                self.table.insert('', 'end', iid=str(i), values=(c['score'], c['can_id'], c['kind'], c['name'], c['off'], on))
            self.status.set(f'{len(self.candidates)} candidates. Raw evidence: {self.session.path.name}' if self.candidates else
                            f'0 repeatable candidates; {len(report["changed_unverified"])} changing signals/bits. Click View phase evidence for OFF/ON distributions.')
        def analyze():
            report = analysis_report(self.session.data, self.app.scooter.dbc)
            report_path = self.session.path.with_suffix('.analysis.json')
            report_path.write_text(json.dumps(report, indent=2), encoding='utf-8')
            return report
        self.app.run('Analyze observed signals', analyze, done, quiet=True)

    def show_evidence(self):
        if not self.report:
            return
        window = tk.Toplevel(self)
        window.title('Phase evidence — changing signals are UNVERIFIED')
        window.geometry('1000x650')
        text = tk.Text(window, wrap='word')
        scroll = ttk.Scrollbar(window, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        text.pack(fill='both', expand=True)
        text.insert('end', self.report['timestamp_limit'] + '\n\n' + '\n'.join(self.report['issues']) + '\n\n')
        for phase in self.report['quality']:
            text.insert('end', str(phase) + '\n')
        for item in self.report['changed_unverified']:
            text.insert('end', f'\nUNVERIFIED {item["can_id"]} {item["name"]}\n')
            for phase, counts in zip(self.session.data['phases'], item['phase_counts']):
                text.insert('end', f'  {phase["name"]}: ' + ', '.join(f'{value} × {count}' for value, count in counts) + '\n')
        text.configure(state='disabled')

    def save_mapping(self):
        chosen = self.table.selection()
        if not chosen or not self.session:
            return
        candidate = self.candidates[int(chosen[0])]
        if not messagebox.askyesno('Save observed association', f'Label {candidate["can_id"]} / {candidate["name"]} as {self.session.data["label"]}?\n'
                                  'This labels observed data only. It does not establish a transmit command.', parent=self):
            return
        try:
            self.status.set(self.session.save_mapping(candidate))
            self.app.scooter.reload_mappings()
        except (ValueError, OSError) as exc:
            messagebox.showerror('Save mapping', str(exc), parent=self)

    def open_session(self):
        if self.app.busy:
            return
        from scooter_backend import ROOT
        filename = filedialog.askopenfilename(parent=self, initialdir=ROOT / 'captures/gui/learning', filetypes=[('Learning sessions', '*.json')])
        if not filename:
            return
        try:
            from pathlib import Path
            path = Path(filename)
            if path.stat().st_size > 100_000_000:
                raise ValueError('Session file is too large')
            data = json.loads(path.read_text(encoding='utf-8'))
            if data.get('schema') != 1 or not data.get('passive') or not 1 <= len(data['phases']) <= 5:
                raise ValueError('Choose a passive learning session with 1–5 stages')
            self.session = LearningSession(data['label'], ROOT / 'captures/gui/learning', data.get('context'))
            # Save a local copy before allowing annotation; original import stays untouched.
            self.session.data = data
            self.session.save()
            self.label.set(data['label'])
            self.instructions.set('Imported evidence: review only. Start a new session for a fresh sequence.')
            self.capture_button.configure(state='disabled')
            self.analyze()
        except (ValueError, KeyError, TypeError, OSError) as exc:
            messagebox.showerror('Session', str(exc), parent=self)
