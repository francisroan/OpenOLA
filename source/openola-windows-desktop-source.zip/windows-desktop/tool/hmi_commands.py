"""HMI body-control commands (0x6BC) — catalog-driven, bounded, no retries.

Command ordinals come from the MoveOS 5 / S2 `CommandFromHMI` enum recovered by
decompiling the head-unit apps (see tool/moveos5_catalog.json and
reverse_engineering/SYSTEM_APPS_MOVEOS5_FINDINGS.md).

Verified send path (unchanged): write byte0 = ordinal on 0x6BC; the vehicle echoes
byte0 on 0x6C0 COMMAND_ACK. Only High_Beam_ON=26 / OFF=27 and Ride_Now=83 have been
exercised on a live scooter (MoveOS 3). **Every other ordinal is firmware-named and
UNVERIFIED** — it is an untested write to a live vehicle, so the panel gates them by
risk tier and never retries.
"""
import json
import queue
import time
from pathlib import Path

_CATALOG = Path(__file__).with_name('moveos5_catalog.json')

# --- load ordinal -> name from the catalog (single source of truth) ------------
def _load_commands():
    try:
        data = json.loads(_CATALOG.read_text(encoding='utf-8'))
        raw = data.get('CommandFromHMI', {})
        out = {}
        for k, v in raw.items():
            if k.startswith('_'):
                continue
            out[int(k)] = v
        if out:
            return out
    except Exception:
        pass
    # Fallback to the three verified commands if the catalog is missing.
    return {26: 'High_Beam_ON', 27: 'High_Beam_OFF', 83: 'Ride_Now'}

ORDINALS = _load_commands()                         # ordinal -> raw enum name
NAMES = {v: k for k, v in ORDINALS.items()}         # raw enum name -> ordinal

# Backward-compatible name->ordinal map (pretty label -> ordinal) for callers.
def _label(ordinal, name):
    return f'{name.replace("_", " ")}  [{ordinal}]'
COMMANDS = {_label(o, n): o for o, n in ORDINALS.items()}
_LABEL_BY_ORDINAL = {o: _label(o, n) for o, n in ORDINALS.items()}

# --- risk model ----------------------------------------------------------------
# DANGER: can enable drive, move parts, reboot an ECU, stop charging, or change a
#         paid entitlement. PARK_REQUIRED (subset) also needs fresh Park status.
DANGER = {4, 13, 14, 18, 19, 48, 49, 64, 65, 66, 67, 83, 84, 90, 91, 97, 99, 105, 106}
PARK_REQUIRED = {4, 13, 48, 66, 83, 90, 99}         # motion / charge / hill-hold / drive-enable
# CAUTION: mode / feature / security / alarm / calibration toggles.
CAUTION = {1, 2, 3, 6, 7, 9, 38, 39, 41, 42, 43, 44, 45, 46, 47, 50, 51, 52, 53, 54,
           55, 56, 57, 58, 59, 60, 61, 62, 63, 68, 69, 70, 71, 72, 73, 77, 78, 87,
           88, 89, 100, 101, 102, 103, 104}
# Everything else (lights, indicators, rear/DRL, hazards, acks, info) = SAFE.

def risk(ordinal):
    if ordinal in DANGER:
        return 'danger'
    if ordinal in CAUTION:
        return 'caution'
    return 'safe'

# --- UI grouping (ordinal lists; anything not listed lands in "Other") ----------
GROUPS = [
    ('Lights & signals', [5, 10, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37,
                          44, 45, 46, 47, 74, 75, 82, 85, 86]),
    ('Ride modes & performance', [4, 6, 7, 41, 42, 43, 48, 49, 64, 65, 66, 67,
                                  83, 84, 99]),
    ('Security & detection', [1, 2, 3, 9, 50, 51, 52, 53, 54, 55, 68, 69, 76, 77,
                              78, 79, 87, 90, 91, 100, 101, 102, 103, 104]),
    ('System, OTA & calibration', [14, 15, 16, 17, 18, 19, 20, 21, 25, 72, 73, 80,
                                    81, 97, 98, 105, 106]),
    ('Charging', [13]),
]

def grouped():
    """Yield (group_title, [(ordinal, label, risk), ...]) covering every command."""
    seen = set()
    for title, ords in GROUPS:
        rows = []
        for o in ords:
            if o in ORDINALS:
                rows.append((o, _LABEL_BY_ORDINAL[o], risk(o)))
                seen.add(o)
        if rows:
            yield title, rows
    other = [(o, _LABEL_BY_ORDINAL[o], risk(o)) for o in sorted(ORDINALS) if o not in seen]
    if other:
        yield 'Other', other


def send_once(scooter, name):
    """Send one 0x6BC command (name = a COMMANDS label) and wait for a 0x6C0 echo.

    Bounded: one frame, 2 s echo window, no retry. Motion/charge/drive-enable
    commands require a fresh Park status first.
    """
    if name not in COMMANDS:
        raise ValueError('Unsupported HMI command')
    command = COMMANDS[name]
    scooter.require_bench()
    if not scooter.t or not scooter.t.stub:
        raise RuntimeError('Connect first')
    t = scooter.t
    previous = scooter.stream_mode
    scooter.stop_keepalive()
    scooter.unlocked.clear()
    scooter.streaming = False
    scooter.stream_mode = None
    try:
        t.stop_stream()
        t.init([0x143, 0x6C0])
        ack = t.queue_for(0x6C0)
        status = t.queue_for(0x143)
        for q in (ack, status):
            while True:
                try: q.get_nowait()
                except queue.Empty: break
        t.start_reader(dump=False)
        if command in PARK_REQUIRED:
            try: state = status.get(timeout=3)
            except queue.Empty: raise RuntimeError('No fresh vehicle status; nothing sent')
            # Level 2 lives in bits 4..7 of byte0. Observed Park=11, Drive=12.
            if len(state) != 8 or (state[0] >> 4) != 11:
                raise RuntimeError('Vehicle is not in Park (Level 2=11); nothing sent')
        while True:
            try: ack.get_nowait()
            except queue.Empty: break
        t.write_frame(0x6BC, bytes([command]) + bytes(7))
        deadline = time.monotonic() + 2
        while time.monotonic() < deadline:
            try: data = ack.get(timeout=max(0.001, deadline - time.monotonic()))
            except queue.Empty: break
            if len(data) == 8 and data[0] == command:
                return (f'{name}: matching echo on 0x6C0. This is NOT proof the action '
                        f'completed or that this client caused it — check the scooter. No retry sent.')
        raise RuntimeError(f'{name}: frame submitted, no matching 0x6C0 echo within 2 s. '
                           f'Outcome unknown; check scooter before repeating. No retry sent.')
    finally:
        t.stop_stream()
        scooter.stream_mode = None
        if previous in ('dump', 'diag'):
            scooter._ensure_stream(previous)


def open_panel(app):
    import tkinter as tk
    from tkinter import ttk, messagebox, simpledialog
    window = tk.Toplevel(app)
    window.title('HMI body-control commands (0x6BC)')
    window.geometry('760x620')

    outer = ttk.Frame(window, padding=(16, 12))
    outer.pack(fill='both', expand=True)
    ttk.Label(outer, text='HMI command tests — 0x6BC', style='H2.TLabel').pack(anchor='w')
    ttk.Label(outer, wraplength=710, text=(
        f'{len(ORDINALS)} commands from the MoveOS 5 CommandFromHMI enum. Only High beam '
        'ON/OFF and Ride_Now are verified on a live scooter — every other command is '
        'firmware-named and UNVERIFIED, i.e. an untested write. Each click sends ONE frame '
        'with no retry; a green/amber/red tag marks the risk. Red commands (drive, moving '
        'parts, reboot, stop-charge, entitlement) need typed confirmation, and '
        'motion/charge ones also require a fresh Park status.')).pack(anchor='w', pady=(6, 8))

    ready = tk.BooleanVar(value=False)
    ttk.Checkbutton(outer, variable=ready,
                    text='Driven wheel clear, scooter secured, charger unplugged'
                    ).pack(anchor='w', pady=(0, 8))

    # scrollable body
    canvas = tk.Canvas(outer, highlightthickness=0)
    scroll = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
    body = ttk.Frame(canvas)
    body.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
    canvas.create_window((0, 0), window=body, anchor='nw')
    canvas.configure(yscrollcommand=scroll.set)
    canvas.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')

    TAG = {'safe': '🟢', 'caution': '🟠', 'danger': '🔴'}

    def execute(ordinal, label, tier):
        if app.busy:
            return
        if not ready.get() or not app.scooter.bench_confirmed:
            messagebox.showerror('Bench setup', 'Confirm the bench setup here and enable '
                                 'active tests in the main window.', parent=window)
            return
        if getattr(app, 'replay', False):
            messagebox.showerror('Offline capture', 'Exit replay and connect to a live '
                                 'scooter first.', parent=window)
            return
        if tier == 'danger':
            word = 'SEND'
            msg = (f'{label}\n\nThis is a RED command (drive / moving part / reboot / '
                   f'charge / entitlement) and is UNVERIFIED on this firmware. It sends '
                   f'once with no automatic undo. Keep the throttle untouched.\n\n'
                   f'Type {word} to send once:')
            if simpledialog.askstring('Confirm red command', msg, parent=window) != word:
                return
        elif tier == 'caution':
            if not messagebox.askyesno('Confirm', f'Send "{label}" once?\n\nUnverified '
                                       'command — check the scooter afterwards.', parent=window):
                return
        else:
            if not messagebox.askyesno('Send', f'Send "{label}" once?', parent=window):
                return
        app.run('HMI ' + label, lambda: send_once(app.scooter, label),
                lambda result: messagebox.showinfo('HMI result', result, parent=window))

    for title, rows in grouped():
        lf = ttk.LabelFrame(body, text=title, padding=(10, 6))
        lf.pack(fill='x', expand=True, padx=4, pady=6)
        for ordinal, label, tier in rows:
            style = 'Danger.TButton' if tier == 'danger' else 'TButton'
            btn = ttk.Button(lf, text=f'{TAG[tier]}  {label}', style=style,
                             command=lambda o=ordinal, l=label, t=tier: execute(o, l, t))
            btn.pack(fill='x', pady=2)

    ttk.Label(outer, wraplength=710, text=(
        'Park status is re-checked before motion/charge/drive commands. A matching 0x6C0 '
        'echo is not proof this client caused it or that the action completed. These tests '
        'end any active diagnostic-unlock session.')).pack(anchor='w', pady=(8, 0))
