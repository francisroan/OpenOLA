"""
Live fault reader for the Ola S1 - reads faults straight off the broadcast CAN
bus via wifican. No UDS, no diagnostic mode, no ADB required.

The vehicle continuously broadcasts dedicated fault registers whose bits are
named in the DBC extracted from the Ola diagnostic app:
    0x410 BMS00_Fault_1     0x411 BMS00_Fault_2      0x122 Overall_Battery_Fault
    0x430 VCU_Fault_1       0x431 VCU_Fault_2        0x333 MCU_Fault_Data
    0x213 Charger_Status    0x210 Throttle_Status    0x642 HU_DIGITAL_INPUT
plus 0x11C / 0x353 which carry a few fault bits too.

Usage:  python faults_live.py <host> <port> [seconds] [secure]
"""
import sys, time, json, os, re
from oladiag.transport import WifiCanTransport

FAULT_IDS = [0x410, 0x411, 0x122, 0x430, 0x431, 0x333, 0x213, 0x210, 0x642, 0x11C, 0x353, 0x640]
FAULTY = re.compile(r'fault|error|fail|warn|protect|abnormal|overcurrent|overvolt|undervolt|'
                    r'overtemp|short|disconnect|timeout|corrupt|stall|deviation', re.I)
# bits that are normal operating state, not problems
BENIGN = re.compile(r'demand|status_signal|counter|calibration|balancing|indicator_ttl', re.I)

VITALS = {
    0x11C: ["Pack_SOC_00", "Battery_voltage_OCV_00", "Contactor_state_00", "BMS_Mode_00"],
    0x120: ["Overall_SOC", "Overall_Battery_Current"],
    0x170: ["BMS0_Cell_Min_Voltage", "BMS0_Cell_Max_Voltage"],
    0x113: ["MCU_Voltage", "MCU_Power_Status", "Throttle_Value1"],
    0x153: ["DCDC_Output_Voltage"],
    0x143: ["Odometer", "Vehicle_Mode_Level_1", "Drive_Request"],
    0x640: ["Bus_Voltage_00_10ms"],
    0x1A4: ["BMS00_Pack_Temperature_01", "BMS00_Pack_Temperature_02"],
}

def load_dbc():
    p = os.path.join(os.path.dirname(__file__), "oladiag", "config", "da_can_dbc.json")
    d = json.load(open(p))
    return {int(m["id"]): m for m in d["messages"]}

def extract(data, s):
    raw = int.from_bytes(data, "little")
    if s.get("endianess", "intel").lower() == "intel":
        v = (raw >> s["startbit"]) & ((1 << s["bitlength"]) - 1)
    else:
        v = 0; idx = s["startbit"]
        for _ in range(s["bitlength"]):
            byte, bit = idx // 8, idx % 8
            b = (data[byte] >> bit) & 1 if byte < len(data) else 0
            v = (v << 1) | b
            idx = idx + 15 if bit == 0 else idx - 1
    if s.get("signed") and s["bitlength"] < 64:
        sb = 1 << (s["bitlength"] - 1)
        if v & sb: v -= (1 << s["bitlength"])
    return v * s.get("scaling", 1) + s.get("offset", 0)

def main():
    host = sys.argv[1] if len(sys.argv) > 1 else ""
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 50005
    secs = int(sys.argv[3]) if len(sys.argv) > 3 else 10
    secure = len(sys.argv) > 4 and sys.argv[4].lower() == "secure"
    dbc = load_dbc()

    print(f"Reading faults from {host}:{port} for {secs}s "
          f"({'mTLS' if secure else 'plaintext'}) ...\n")
    t = WifiCanTransport(host, port, secure=secure)
    t.connect()
    t.start_reader(dump=True)
    time.sleep(secs)

    latest = {}
    for cid, q in list(t._queues.items()):
        d = None
        while not q.empty():
            try: d = q.get_nowait()
            except Exception: break
        if d is not None: latest[cid] = d
    t.close()

    print(f"Captured {len(latest)} distinct CAN IDs.\n")

    # ---------- ACTIVE FAULTS ----------
    active = []
    for cid, data in sorted(latest.items()):
        m = dbc.get(cid)
        if not m: continue
        for s in m["signals"]:
            if s["bitlength"] != 1: continue
            if not FAULTY.search(s["name"]) or BENIGN.search(s["name"]): continue
            if extract(data, s) == 1:
                active.append({"can_id": f"0x{cid:03X}", "message": m["name"],
                               "signal": s["name"], "raw": data.hex()})

    print("=" * 68)
    if active:
        print(f"ACTIVE FAULTS: {len(active)}")
        print("=" * 68)
        cur = None
        for f in active:
            if f["message"] != cur:
                cur = f["message"]; print(f"\n  [{f['can_id']}] {cur}")
            print(f"     * {f['signal']}")
    else:
        print("NO ACTIVE FAULT BITS SET on any fault register received.")
    print("=" * 68)

    # which fault registers did we actually see?
    seen = [f"0x{c:03X}" for c in FAULT_IDS if c in latest]
    missing = [f"0x{c:03X}" for c in FAULT_IDS if c not in latest]
    print(f"\nFault registers received : {', '.join(seen) or 'none'}")
    if missing:
        print(f"Not broadcast this run   : {', '.join(missing)}")
        print("  (some registers are only sent when a fault is present, or at low rate")
        print("   - re-run with a longer window, e.g. 30s, to be sure)")

    # ---------- VITALS ----------
    print("\n" + "=" * 68)
    print("VITALS")
    print("=" * 68)
    for cid, wanted in VITALS.items():
        if cid not in latest: continue
        m = dbc.get(cid)
        if not m: continue
        for s in m["signals"]:
            if s["name"] in wanted:
                v = extract(latest[cid], s)
                if isinstance(v, float): v = round(v, 3)
                print(f"  {s['name']:<34} {v!s:>12} {s.get('units','')}")

    out = {"active_faults": active,
           "fault_registers_seen": seen,
           "fault_registers_missing": missing,
           "captured_ids": len(latest)}
    with open(os.path.join("..", "captures", "faults_live.json"), "w") as f:
        json.dump(out, f, indent=2)
    print("\nJSON written to captures\\faults_live.json")

if __name__ == "__main__":
    main()
