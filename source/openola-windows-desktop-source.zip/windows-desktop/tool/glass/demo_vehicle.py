"""Demo scooter — an in-process, offline simulation of the scooter's Wi-Fi CAN gRPC bridge.

Demo mode connects the REAL console pipeline (gRPC transport, ISO-TP, UDS, seed/key,
DBC + status decoders) to this server, so every page behaves exactly as it would on a
scooter, without one. Nothing here talks to a vehicle.

* Broadcast CAN: replays a real 84-message bus snapshot (captures/alldata.json, from the
  owner's S1 Pro) with gently animated battery / temperature values, plus synthesised
  0x660 feature flags and a rotating 0x6D0 notification feed. A virtual charger can be
  plugged in (slow charge, SOC rises).
* UDS: sessions, seed/key (same algorithm as the real ECUs), 0x22 reads for every ODX
  identifier (plausible values encoded from the ODX parameter definitions), 0x2F I/O
  control, 0x31 routines, 0x2E writes with readback, 0x19/0x14 stored DTCs, 0x3E, 0x11;
  0x23 / 0x35 memory access is refused like on the real ECUs.
* RPCs: operation mode, software versions, identifiers, update status, remote self-tests,
  and the 0x6BC → 0x6C0 HMI command echo.
"""
import json
import math
import queue
import random
import re
import threading
import time
from pathlib import Path

import grpc

from oladiag.wifican import wifican_pb2 as pb
from oladiag.wifican import wifican_pb2_grpc as pbg
from oladiag.canframe import build_frame, parse_frame
from oladiag.seedkey import Ecu, generate_key
from oladiag.isotp import frame_type

ROOT = Path(__file__).resolve().parents[2]
SNAPSHOT = ROOT / 'captures/alldata.json'
DBC_PATH = ROOT / 'tool/oladiag/config/da_can_dbc.json'
ODX_PATH = ROOT / 'notes/apk_x/res/raw/odx.json'

SEED = bytes([0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88])
DEMO_VIN = 'MD9S1PRODEMO00042'
# Stored DTCs per ECU (3-byte code, status) — codes exist in the bundled DTC table.
DEMO_DTCS = {Ecu.BMS: [('110109', 0x09), ('11011C', 0x08)], Ecu.VCU: [('920711', 0x09)], Ecu.MCU: []}
NOTIFICATION_CYCLE = [60, 113, 34, 59, 23, 24, 129]   # side stand, normal mode, low battery, …


# ----------------------------------------------------------------------------- DBC encode
def encode_signal(data: bytearray, s: dict, value):
    """Inverse of alldata.extract(): write a physical value into a frame."""
    scale = s.get('scaling', 1) or 1
    raw = int(round((value - s.get('offset', 0)) / scale))
    n = s['bitlength']
    if raw < 0:
        raw += 1 << n
    raw &= (1 << n) - 1
    if s.get('endianess', 'intel').lower() == 'intel':
        v = int.from_bytes(data, 'little')
        mask = ((1 << n) - 1) << s['startbit']
        v = (v & ~mask) | (raw << s['startbit'])
        data[:] = v.to_bytes(len(data), 'little')
        return
    idx = s['startbit']
    for i in range(n):
        bit = (raw >> (n - 1 - i)) & 1
        byte, b = idx // 8, idx % 8
        if byte < len(data):
            data[byte] = (data[byte] & ~(1 << b)) | (bit << b)
        idx = idx + 15 if b == 0 else idx - 1


# ----------------------------------------------------------------------------- ODX demo values
def _demo_value(name, unit, p, ecu, did):
    n = (name or '').lower()
    def num(v):
        try:
            return float(v)
        except (TypeError, ValueError):
            return None
    lo, hi = num(p.get('Physical Minimum')), num(p.get('Physical Maximum'))
    rnd = random.Random(f'{ecu}{did}{name}')
    u = (unit or '').strip().lower()
    m = re.search(r'cell\s*-?\s*(\d+)', n)
    cell = int(m.group(1)) if m else 0
    weak = cell == 9                                   # the demo pack has one tired cell
    if 'control status' in n:
        return 0
    def mv(v):
        return round(v * 1000) if u.startswith('mv') else round(v, 3)
    if 'deviation' in n:
        return mv(0.044)
    if ('cell' in n and 'volt' in n) or n.startswith('ocv'):
        if 'minimum' in n:
            return mv(3.868)
        if 'maximum' in n:
            return mv(3.912)
        return mv(3.905 + rnd.uniform(-0.006, 0.006) - (0.037 if weak else 0))
    if 'ir of cell' in n or 'resistance' in n:
        return round(rnd.uniform(1.6, 1.9) * (1.7 if weak else 1), 2)
    if 'capacity of cell' in n:
        return round(rnd.uniform(4.9, 5.1) * (0.9 if weak else 1), 2)
    if 'kwhr' in n or 'kwh' in u:
        return 2.1
    if 'amphr' in n:
        return 38.4
    if 'dc-dc' in n or 'dcdc' in n or '12v' in n:
        return mv(12.1)
    if 'pack voltage' in n or 'bus voltage' in n:
        return mv(54.65)
    if 'temp' in n:
        return round(29 + rnd.uniform(-2, 4), 1)
    if 'soh' in n or 'state of health' in n:
        return 96
    if n.strip() == 'soc' or 'state of charge' in n or 'overall battery pack' in n:
        return 78
    if 'cycle number' in n or n.endswith('cycles'):
        return 212
    if 'capacity' in n:
        return 72.5 if 'ah' in u else 3970
    if 'speed' in n:
        return 0
    if 'current' in n:
        return round(rnd.uniform(0.5, 2.0), 1)
    if 'volt' in n:
        return mv(52.3 + rnd.uniform(-0.3, 0.3))
    if 'version' in n:
        return 5.0
    if 'date' in n:
        return 20250114
    if 'status' in n or 'flag' in n or 'enable' in n:
        return 1
    if lo is not None and hi is not None and hi > lo:
        return lo + (hi - lo) * 0.25
    return 1


def build_odx_response(definition, ecu_name, did_hex):
    """Encode a plausible payload for one ODX 0x22 definition (Intel, StartBit from LSB)."""
    length = int(definition.get('AttachedDatalength (Bytes)') or 0)
    params = definition.get('Parameters') or []
    if length <= 0:
        length = max((int(p.get('StartBit') or 0) + int(p.get('Size (Bits)') or 8) + 7) // 8 for p in params) if params else 1
    data = bytearray(length)
    word = 0
    for p in params:
        bits = int(p.get('Size (Bits)') or 0)
        start = int(p.get('StartBit') or 0)
        if bits <= 0:
            continue
        if (p.get('Encoding') or '').upper() == 'ASCII':
            text = f'OLA{ecu_name}{did_hex}DEMO0042'.encode()
            nbytes = bits // 8
            chunk = text[:nbytes].ljust(nbytes, b' ')
            data[start // 8:start // 8 + nbytes] = chunk
            continue
        value = _demo_value(p.get('Parameter'), p.get('Unit'), p, ecu_name, did_hex)
        try:
            res = float(p.get('Resolution') or 1) or 1
        except (TypeError, ValueError):
            res = 1
        try:
            off = float(p.get('Offset') or 0)
        except (TypeError, ValueError):
            off = 0
        raw = int(round((value - off) / res))
        raw = max(0, min(raw, (1 << bits) - 1))
        word |= raw << start
    need = max(length, (word.bit_length() + 7) // 8)          # some ODX lengths are understated
    merged = int.from_bytes(bytes(data).ljust(need, b'\0'), 'little') | word
    return merged.to_bytes(need, 'little')


# ----------------------------------------------------------------------------- server
def _iso_tp_frames(payload: bytes):
    if len(payload) <= 7:
        yield bytes([len(payload)]) + payload + bytes(7 - len(payload))
        return
    yield bytes([0x10 | ((len(payload) >> 8) & 0x0F), len(payload) & 0xFF]) + payload[:6]
    rest, sn = payload[6:], 1
    while rest:
        chunk, rest = rest[:7], rest[7:]
        yield bytes([0x20 | (sn & 0x0F)]) + chunk + bytes(7 - len(chunk))
        sn += 1


class DemoVehicle(pbg.WifiCanRpcServicer):
    def __init__(self):
        self.lock = threading.Lock()
        self.subscribers = []                      # [(queue, dump: bool, ids: set)]
        self.filter_ids = set()
        self.mode = pb.VEHICLE_OP_STATE_CUST
        self.unlocked = {e: False for e in Ecu}
        self.session = {e: 1 for e in Ecu}
        self.rx = {e: None for e in Ecu}
        self.dtcs = {e: list(v) for e, v in DEMO_DTCS.items()}
        self.written = {}                          # (ecu, did_hex) -> bytes
        self.charging = False
        self.soc = 78.0
        self.stop = threading.Event()
        self.dbc = {int(m['id']): m for m in json.loads(DBC_PATH.read_text(encoding='utf-8-sig'))['messages']}
        self.odx = json.loads(ODX_PATH.read_text(encoding='utf-8-sig'))
        self.reads = {}
        for ecu_name, defs in self.odx.items():
            for d in defs:
                rf = bytes.fromhex(d.get('RequestFormat', '') or '00')
                if len(rf) == 3 and rf[0] == 0x22:
                    self.reads.setdefault((ecu_name, rf[1:].hex().upper()), d)
        self.base = {}
        try:
            snap = json.loads(SNAPSHOT.read_text(encoding='utf-8-sig'))['decoded']
            for cid, msg in snap.items():
                raw = msg.get('raw')
                if raw:
                    self.base[int(cid, 16)] = bytes.fromhex(raw).ljust(8, b'\0')[:8]
        except (OSError, ValueError, KeyError):
            pass
        self.base[0x660] = bytes([0x9A, 0x11, 0x10, 0x00, 0x00, 0, 0, 0])
        self.base[0x6D0] = bytes(8)
        self.base.setdefault(0x313, bytes(8))
        self.started = time.time()
        threading.Thread(target=self._broadcast, name='demo-bus', daemon=True).start()

    # ---- fan-out --------------------------------------------------------------
    def _emit(self, can_id, data8, uds=False):
        frame = build_frame(can_id, data8)
        with self.lock:
            subs = list(self.subscribers)
        for q, dump, ids in subs:
            if dump or uds or can_id in ids:
                try:
                    q.put_nowait(frame)
                except queue.Full:
                    pass

    def _respond(self, ecu, payload):
        for f in _iso_tp_frames(payload):
            self._emit(ecu.resp_id, f, uds=True)

    # ---- simulated bus ---------------------------------------------------------
    def _set(self, data, cid, name, value):
        msg = self.dbc.get(cid)
        if not msg:
            return
        for s in msg['signals']:
            if s['name'] == name:
                encode_signal(data, s, value)
                return

    def _frame(self, cid, t):
        d = bytearray(self.base[cid])
        wob = math.sin(t / 7.0)
        amps = (11.8 + 0.4 * wob) if self.charging else (-0.9 - 0.3 * abs(wob))
        if cid == 0x353:
            self._set(d, cid, 'Display_SoC', round(self.soc))
            self._set(d, cid, 'Vehicle_Range', round(self.soc * 1.44))
        elif cid == 0x120:
            self._set(d, cid, 'Overall_SOC', round(self.soc))
            self._set(d, cid, 'Overall_Battery_Current', round(amps, 1))
        elif cid == 0x11C:
            self._set(d, cid, 'Pack_SOC_00', round(self.soc))
        elif cid == 0x640:
            self._set(d, cid, 'Bus_Voltage_00_10ms', round(51.4 + self.soc * 0.045 + 0.05 * wob, 2))
        elif cid == 0x313:
            mcu, mot = 31.4 + 0.6 * wob, 29.8 + 0.4 * math.cos(t / 9.0)
            d[0:2] = (0).to_bytes(2, 'little')
            d[2:4] = int(mcu * 100).to_bytes(2, 'little')
            d[4:6] = int(mot * 100).to_bytes(2, 'little')
        elif cid == 0x143:
            d[0] = 0x73 if self.charging else 0xB1           # L2 SC_CHARGE ACTIVE / PARK; L1 Slow / Idle
        elif cid == 0x62D:
            d[0] = 0x06 if self.charging else 0x00           # Slow charger + plugged
        elif cid == 0x213:
            if not self.charging:
                d = bytearray(8)
        elif cid == 0x6D0:
            idx = int((t // 25) % len(NOTIFICATION_CYCLE))
            d[0] = NOTIFICATION_CYCLE[idx]
        return bytes(d)

    def _broadcast(self):
        fast = {0x353, 0x120, 0x121, 0x11C, 0x640, 0x313, 0x143, 0x62D, 0x213, 0x130, 0x180}
        tick = 0
        last = time.time()
        while not self.stop.is_set():
            now = time.time()
            dt, last = now - last, now
            if self.charging:
                self.soc = min(100.0, self.soc + dt * 0.04)
            else:
                self.soc = max(5.0, self.soc - dt * 0.0008)
            t = now - self.started
            for cid in self.base:
                if cid in fast or tick % 5 == 0:
                    self._emit(cid, self._frame(cid, t))
            tick += 1
            self.stop.wait(0.2)

    # ---- streams ---------------------------------------------------------------
    def _stream(self, context, dump):
        q = queue.Queue(maxsize=4000)
        entry = (q, dump, set(self.filter_ids))
        with self.lock:
            self.subscribers.append(entry)
        try:
            while context.is_active() and not self.stop.is_set():
                try:
                    frame = q.get(timeout=0.2)
                except queue.Empty:
                    continue
                yield pb.CANPacket(can_frame=frame)
        finally:
            with self.lock:
                if entry in self.subscribers:
                    self.subscribers.remove(entry)

    def ReadCanStream(self, request, context):
        yield from self._stream(context, dump=False)

    def CanDumpStream(self, request, context):
        yield from self._stream(context, dump=True)

    def Init(self, request, context):
        self.filter_ids = set(request.can_ids)
        return pb.Response(status=pb.RESP_SUCCESS, status_msg='ok')

    def Deinit(self, request, context):
        return pb.Response(status=pb.RESP_SUCCESS, status_msg='bye')

    def WriteCanStream(self, request_iterator, context):
        for _ in request_iterator:
            pass
        return pb.Response(status=pb.RESP_SUCCESS, status_msg='ok')

    # ---- CAN writes / UDS --------------------------------------------------------
    def WriteCanFrame(self, request, context):
        can_id, data8 = parse_frame(request.can_frame)
        if can_id == 0x6BC:                                   # HMI command -> COMMAND_ACK echo
            self._emit(0x6C0, bytes([data8[0]]) + bytes(7))
            return pb.Response(status=pb.RESP_SUCCESS, status_msg='ok')
        if can_id in (0x62D, 0x143, 0x660):                   # injected display frames: accept
            return pb.Response(status=pb.RESP_SUCCESS, status_msg='ok')
        ecu = next((e for e in Ecu if e.req_id == can_id), None)
        if ecu is None:
            return pb.Response(status=pb.RESP_SUCCESS, status_msg='ignored')
        ft = frame_type(data8)
        if ft == 0x0:
            self._handle(ecu, bytes(data8[1:1 + (data8[0] & 0x0F)]))
        elif ft == 0x1:
            total = ((data8[0] & 0x0F) << 8) | data8[1]
            self.rx[ecu] = {'total': total, 'buf': bytearray(data8[2:8])}
            self._emit(ecu.resp_id, bytes([0x30, 0, 0, 0, 0, 0, 0, 0]), uds=True)
        elif ft == 0x2:
            st = self.rx.get(ecu)
            if st:
                st['buf'].extend(data8[1:8])
                if len(st['buf']) >= st['total']:
                    self.rx[ecu] = None
                    self._handle(ecu, bytes(st['buf'][:st['total']]))
        return pb.Response(status=pb.RESP_SUCCESS, status_msg='ok')

    def _nrc(self, ecu, svc, code):
        self._respond(ecu, bytes([0x7F, svc, code]))

    def _read_payload(self, ecu, did):
        key = did.hex().upper()
        if (ecu.name, key) in self.written:
            return self.written[(ecu.name, key)]
        if ecu == Ecu.VCU and key == '0103':
            return (8421).to_bytes(4, 'little')
        if ecu == Ecu.MCU and key == 'B113':
            return (1874).to_bytes(2, 'little')
        if ecu == Ecu.MCU and key in ('B135', 'B13C', 'B13D'):
            return bytes(random.Random(key).randrange(256) for _ in range({'B135': 16, 'B13C': 20, 'B13D': 4}[key]))
        if ecu == Ecu.VCU and key == '0100':                  # variant byte + feature bitfield
            return bytes([0x02, 0b00011011, 0, 0])            # S1 Pro; cruise+hill+reverse+gethome on
        if ecu == Ecu.VCU and key == 'F190':                  # VIN
            return DEMO_VIN.encode()
        if ecu == Ecu.VCU and key == '0102':                  # hyper-charge flag (default off)
            return b'\0'
        if ecu == Ecu.VCU and '0106' <= key <= '010F':        # temp thresholds (°C ×10, signed LE16)
            base = {'0106': 60, '0107': 55, '0108': 75, '0109': 70, '010A': 90,
                    '010B': 85, '010C': 80, '010D': 100, '010E': 95, '010F': 110}.get(key, 70)
            return int(base * 10).to_bytes(2, 'little', signed=True)
        if key.startswith('F1') and (ecu.name, key) not in self.reads:   # any version/identity DID
            text = {'F180': f'BOOT-{ecu.name}-5.0.0', 'F181': f'{ecu.name}-APP-5.0.0',
                    'F193': f'HW-{ecu.name}-2.1', 'F187': 'SPARE-0A1B2C', 'F18C': f'{ecu.name}SN0042'}.get(key)
            return (text or f'{ecu.name}-{key}').encode()
        if ecu == Ecu.MCU and key == '0504':
            return bytes([0x64, 0x00, 0xF4, 0x01])            # HW 1.00, FW 5.00 (×0.01)
        stock = {'E4C3': 'C301', 'E413': '1343', 'E462': '622E', 'E465': '6534', 'E467': '6737',
                 'E469': '693E', 'E449': '4955', 'E44A': '4A64', 'E44D': '4D69', 'E4BA': 'BA1000'}
        if ecu == Ecu.BMS and key == 'E467':                  # one deviating value, for the factory check
            return bytes.fromhex('6740')
        if ecu == Ecu.BMS and key in stock:                   # factory-matching stock values
            return bytes.fromhex(stock[key])
        if ecu == Ecu.BMS and key.startswith('E4') and (ecu.name, key) not in self.reads:
            return bytes(random.Random(key).randrange(256) for _ in range(2))
        d = self.reads.get((ecu.name, key))
        if d is None:
            return None
        return build_odx_response(d, ecu.name, key)

    def _handle(self, ecu, p):
        if not p:
            return
        svc = p[0]
        time.sleep(0.015)                                     # a little ECU think time
        if svc == 0x10:
            self.session[ecu] = p[1]
            if p[1] == 1:
                self.unlocked[ecu] = False
            self._respond(ecu, bytes([0x50, p[1], 0x00, 0x32, 0x01, 0xF4]))
        elif svc == 0x27 and p[1] == 0x01:
            self._respond(ecu, bytes([0x67, 0x01]) + (bytes(8) if self.unlocked[ecu] else SEED))
        elif svc == 0x27 and p[1] == 0x02:
            if p[2:] == generate_key(SEED, ecu, '01'):
                self.unlocked[ecu] = True
                self._respond(ecu, bytes([0x67, 0x02]))
            else:
                self._nrc(ecu, 0x27, 0x35)
        elif svc == 0x22 and len(p) >= 3:
            data = self._read_payload(ecu, p[1:3])
            if data is None:
                self._nrc(ecu, 0x22, 0x31)
            else:
                self._respond(ecu, bytes([0x62]) + p[1:3] + data)
        elif svc == 0x2E and len(p) >= 4:
            if not self.unlocked[ecu]:
                return self._nrc(ecu, 0x2E, 0x33)
            self.written[(ecu.name, p[1:3].hex().upper())] = bytes(p[3:])
            self._respond(ecu, bytes([0x6E]) + p[1:3])
        elif svc == 0x2F and len(p) >= 4:
            if not self.unlocked[ecu]:
                return self._nrc(ecu, 0x2F, 0x33)
            self._respond(ecu, bytes([0x6F]) + p[1:4] + (p[4:5] if len(p) > 4 else b''))
        elif svc == 0x31 and len(p) >= 4:
            if not self.unlocked[ecu] and p[1] != 0x03:
                return self._nrc(ecu, 0x31, 0x33)
            extra = bytes([0x02, 0x02]) if p[1] == 0x03 else b''   # AutoTune result: attempted / success
            self._respond(ecu, bytes([0x71]) + p[1:4] + b'\x00' + extra)
        elif svc == 0x19 and len(p) >= 2 and p[1] == 0x02:
            body = bytearray([0x59, 0x02, 0xFF])
            for code_hex, status in self.dtcs[ecu]:
                body += bytes.fromhex(code_hex) + bytes([status])
            self._respond(ecu, bytes(body))
        elif svc == 0x14:
            self.dtcs[ecu] = []
            self._respond(ecu, bytes([0x54]))
        elif svc == 0x3E:
            if not (len(p) > 1 and p[1] & 0x80):
                self._respond(ecu, bytes([0x7E, 0x00]))
        elif svc == 0x11:
            self.unlocked[ecu] = False
            self._respond(ecu, bytes([0x51, p[1] if len(p) > 1 else 1]))
        elif svc in (0x23, 0x35):
            self._nrc(ecu, svc, 0x33)
        else:
            self._nrc(ecu, svc, 0x11)

    # ---- RPCs --------------------------------------------------------------------
    def GetVehicleOperationMode(self, request, context):
        return pb.VehicleOperationMode(cur_mode=self.mode, modified_ts=int(self.started),
                                       modified_ts_str=time.ctime(self.started), modified_by='demo')

    def SetVehicleOperationMode(self, request, context):
        if request.cur_mode in (pb.VEHICLE_OP_STATE_CUST, pb.VEHICLE_OP_STATE_SERVICE):
            self.mode = request.cur_mode
            self.unlocked = {e: False for e in Ecu}
            return pb.Response(status=pb.RESP_SUCCESS, status_msg='mode set (demo)')
        return pb.Response(status=pb.RESP_FAILURE if hasattr(pb, 'RESP_FAILURE') else 2,
                           status_msg='mode not allowed in demo')

    def GetSwVersion(self, request, context):
        return pb.Response(status=pb.RESP_SUCCESS, status_msg='MoveOS 5.0.0 (demo)\nVCU 5.0.0 · BMS 3.2.1 · MCU 2.4.0')

    def GetAospVersion(self, request, context):
        return pb.Response(status=pb.RESP_SUCCESS, status_msg='Android 10 · build OLA.5.0.0.DEMO')

    def GetVehicleIdentifiers(self, request, context):
        return pb.VehicleIdentifiers(manifest_json=json.dumps(
            {'vin': DEMO_VIN, 'model': 'S1 Pro (Gen 1)', 'year': 2022, 'source': 'demo'}))

    def SwUpdateCheckStatus(self, request, context):
        return pb.SwUpdateStatus(status=pb.SW_UPDATE_STATE_IDLE, status_msg='No update pending (demo)')

    def RemoteRunTestCmd(self, request, context):
        name = pb.RmtCmdList.Name(request.cmd_id)
        if request.cmd_id == pb.RMT_CMD_VIN:
            return pb.RmtCmdResp(cmd_id=request.cmd_id, resp_status=pb.RMT_CMD_RESP_SUCCESS, resp_str=DEMO_VIN)
        return pb.RmtCmdResp(cmd_id=request.cmd_id, resp_status=pb.RMT_CMD_RESP_SUCCESS,
                             resp_str=f'{name.replace("RMT_CMD_", "")}: OK (demo)')

    def RunSystemTestCmd(self, request, context):
        return pb.SystemTestResp(cmd_id=request.cmd_id, resp_status=pb.RMT_CMD_RESP_SUCCESS,
                                 resp_str='SOM self-test passed (demo)')


class DemoServer:
    """Owns the gRPC server for one demo session."""
    def __init__(self):
        from concurrent import futures
        self.vehicle = DemoVehicle()
        self.server = grpc.server(futures.ThreadPoolExecutor(max_workers=16))
        pbg.add_WifiCanRpcServicer_to_server(self.vehicle, self.server)
        self.port = self.server.add_insecure_port('127.0.0.1:0')
        self.server.start()

    def set_charging(self, on):
        self.vehicle.charging = bool(on)

    def close(self):
        self.vehicle.stop.set()
        self.server.stop(0.5)
