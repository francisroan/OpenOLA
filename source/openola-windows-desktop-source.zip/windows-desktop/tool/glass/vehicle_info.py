"""Firmware / version read-out, vehicle variant + feature config, and temperature thresholds.

All read-only (UDS 0x22, no session change, no unlock). Decodes the identifiers the
factory diagnostic app reads on its Engineering-mode / Config-update screens, plus the
firmware-matching rules the app uses to pick an update bundle.

Sources (reverse_engineering/):
  - version DIDs: BMS/MCU F180 boot, F181 app-SW, F193 HW, MCU 0504; serials F191/F120/F18C
  - VCU config DID 0100 feature bitfield + temp thresholds 0106..010F (VcuConfigParams screen)
  - vehicle variant: VcuConfigParams "Vehicle Variant" + VehicleConstants$Type
  - firmware rules: GrpcConstant bundle names mcu_80/mcu_100 + ReplacementConstants pin types
"""
import re

# ---- version identifiers to read per ECU (UDS 0x22) -------------------------------
# VCU identity is NOT in the VCU ODX read set (the real VCU broadcasts its versions on the
# CAN bus, e.g. 0x679/0x632); only VIN (F190) is a UDS read there.
VERSION_DIDS = {
    'BMS': [('F181', 'Application software'), ('F180', 'Bootloader'), ('F193', 'Hardware version'),
            ('F191', 'BMS serial'), ('F120', 'Pack serial')],
    'MCU': [('F181', 'Application software'), ('F180', 'Boot software'), ('F193', 'Hardware version'),
            ('F18C', 'MCU serial'), ('0504', 'MCU version info')],
    'VCU': [('F190', 'VIN')],
}

# ---- VCU config DID 0100 — feature bitfield (one byte, LSB-first) -----------------
# From VcuConfigParamsViewModel.onCompleteReadMultiFrame (vcuConfigList order).
VCU_FEATURE_BITS = [
    ('Cruise Control', 0), ('Hill Hold', 1), ('Reverse Mode', 2), ('Find My Scooter', 3),
    ('Get Home Mode', 4), ('Take Me Home Lights', 5),
]
# Temperature thresholds the config screen reads/writes (DIDs, °C, signed 0.1 or 1 per ODX).
TEMP_THRESHOLDS = [
    ('0106', 'MCU → NORMAL mode', 'mcu'), ('0107', 'MCU revival of ECO-warn', 'mcu'),
    ('0108', 'MCU → ECO mode', 'mcu'), ('0109', 'MCU revival of ECO', 'mcu'),
    ('010A', 'MCU → PARK mode', 'mcu'),
    ('010B', 'Motor → NORMAL mode', 'motor'), ('010C', 'Motor revival of NORMAL', 'motor'),
    ('010D', 'Motor → ECO mode', 'motor'), ('010E', 'Motor revival of ECO', 'motor'),
    ('010F', 'Motor → PARK mode', 'motor'),
]
VCU_VARIANT_DID = '0100'
VARIANTS = {0x01: 'Ola S1', 0x02: 'Ola S1 Pro', 0x03: 'Ola S1 Pro (Upgrade)'}

# ---- firmware-matching rules (the app's bundle-selection logic) ------------------
# The app ships mcu_80.tar / mcu_100.tar and 8-/16-generation bundles; the MCU firmware
# must match the controller pin type, and the software generation must agree across ECUs.
FIRMWARE_RULES = [
    'The motor-controller firmware must match the controller pin type (80-pin vs 100-pin). '
    'Installing the wrong one is rejected or causes faults.',
    'All modules should be on the same software generation (the app ships "8" and "16" bundles). '
    'A mix can raise VERSION_MISMATCH / CONFIG_MISMATCH / PARTS_MISMATCHED.',
    'A replacement VCU board must carry the correct vehicle variant (S1 / S1 Pro / Pro Upgrade) '
    'or features and limits will not match the scooter.',
]


def _ecu(name):
    from oladiag.seedkey import Ecu
    return Ecu[name]


def read_versions(scooter):
    """Return {ecu: [{did, label, value|error}]} by reading each version DID (0x22)."""
    out = {}
    for ecu_name, dids in VERSION_DIDS.items():
        rows = []
        for did, label in dids:
            row = {'did': did, 'label': label}
            try:
                data = scooter.read(_ecu(ecu_name), bytes.fromhex(did))
                row['value'] = _as_text(data)
                row['hex'] = data.hex(' ').upper()
            except Exception as exc:
                msg = str(exc)
                row['error'] = 'not supported' if 'NRC 0x31' in msg or 'NRC 0x11' in msg else msg[:90]
            rows.append(row)
        out[ecu_name] = rows
    return out


def _as_text(data: bytes):
    """ASCII if printable, else a short hex string."""
    try:
        t = data.decode('ascii').strip('\x00 ').strip()
        if t and all(32 <= ord(c) < 127 for c in t):
            return t
    except Exception:
        pass
    return data.hex(' ').upper()


def mismatch_check(versions):
    """Compare application-software strings across ECUs and flag divergence."""
    findings = []
    apps = {}
    for ecu, rows in versions.items():
        r = next((x for x in rows if x['label'].startswith('Application') and x.get('value')), None)
        if r:
            apps[ecu] = r['value']
    gens = {ecu: _generation(v) for ecu, v in apps.items()}
    present = {g for g in gens.values() if g}
    if len(present) > 1:
        findings.append({'tone': 'warn', 'text': 'Modules report different software generations ('
                         + ', '.join(f'{e}: {g}' for e, g in gens.items() if g)
                         + '). A mix can trigger VERSION_MISMATCH. Update them to the same release.'})
    elif apps:
        findings.append({'tone': 'ok', 'text': 'Module software versions look consistent.'})
    return findings


def _generation(version):
    m = re.search(r'(\d+)\.(\d+)\.(\d+)', str(version))
    return m.group(0) if m else None


def read_vcu_config(scooter):
    """Read VCU variant/feature config (DID 0100) + temperature thresholds (0106..010F)."""
    result = {'variant': None, 'features': [], 'thresholds': [], 'error': None}
    try:
        data = scooter.read(_ecu('VCU'), bytes.fromhex(VCU_VARIANT_DID))
    except Exception as exc:
        result['error'] = str(exc)[:120]
        data = b''
    if data:
        result['variant'] = VARIANTS.get(data[0], f'Unknown (0x{data[0]:02X})')
        flags = data[1] if len(data) > 1 else 0
        result['features'] = [{'name': n, 'on': bool((flags >> b) & 1)} for n, b in VCU_FEATURE_BITS]
    for did, label, kind in TEMP_THRESHOLDS:
        row = {'did': did, 'label': label, 'kind': kind}
        try:
            d = scooter.read(_ecu('VCU'), bytes.fromhex(did))
            raw = int.from_bytes(d[:2], 'little', signed=True) if len(d) >= 2 else (d[0] if d else 0)
            row['value'] = round(raw * 0.1, 1) if abs(raw) > 150 else raw
        except Exception as exc:
            msg = str(exc)
            row['error'] = 'not supported' if 'NRC 0x31' in msg else msg[:60]
        result['thresholds'].append(row)
    return result


def variant_short(versions_or_config):
    """Best-effort model string for the connection header."""
    if isinstance(versions_or_config, dict):
        return versions_or_config.get('variant')
    return None
