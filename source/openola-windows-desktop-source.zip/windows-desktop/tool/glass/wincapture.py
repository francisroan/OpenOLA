"""Window screenshot for the console (Windows): PrintWindow → PNG file + clipboard.

Works even when the window is partly covered, needs no browser permission prompt and no
third-party imaging library (PNG is written with zlib). Other platforms fall back to the
page's own getDisplayMedia capture.
"""
import ctypes
import struct
import sys
import time
import zlib
from pathlib import Path

WINDOWS = sys.platform.startswith('win')

if WINDOWS:
    from ctypes import wintypes as W
    user32, gdi32, kernel32 = ctypes.windll.user32, ctypes.windll.gdi32, ctypes.windll.kernel32
    try:                                   # physical pixels, not DPI-virtualised ones
        user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass
    user32.GetDC.restype = W.HDC
    user32.GetDC.argtypes = [W.HWND]
    user32.ReleaseDC.argtypes = [W.HWND, W.HDC]
    user32.PrintWindow.argtypes = [W.HWND, W.HDC, W.UINT]
    user32.GetClientRect.argtypes = [W.HWND, ctypes.POINTER(W.RECT)]
    user32.GetWindowThreadProcessId.argtypes = [W.HWND, ctypes.POINTER(W.DWORD)]
    user32.GetClassNameW.argtypes = [W.HWND, W.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.argtypes = [W.HWND, W.LPWSTR, ctypes.c_int]
    user32.IsWindowVisible.argtypes = [W.HWND]
    user32.IsIconic.argtypes = [W.HWND]
    user32.OpenClipboard.argtypes = [W.HWND]
    user32.SetClipboardData.argtypes = [W.UINT, W.HANDLE]
    user32.SetClipboardData.restype = W.HANDLE
    gdi32.CreateCompatibleDC.restype = W.HDC
    gdi32.CreateCompatibleDC.argtypes = [W.HDC]
    gdi32.CreateCompatibleBitmap.restype = W.HBITMAP
    gdi32.CreateCompatibleBitmap.argtypes = [W.HDC, ctypes.c_int, ctypes.c_int]
    gdi32.SelectObject.argtypes = [W.HDC, W.HGDIOBJ]
    gdi32.SelectObject.restype = W.HGDIOBJ
    gdi32.DeleteObject.argtypes = [W.HGDIOBJ]
    gdi32.DeleteDC.argtypes = [W.HDC]
    gdi32.GetDIBits.argtypes = [W.HDC, W.HBITMAP, W.UINT, W.UINT, ctypes.c_void_p, ctypes.c_void_p, W.UINT]
    kernel32.GlobalAlloc.restype = W.HGLOBAL
    kernel32.GlobalAlloc.argtypes = [W.UINT, ctypes.c_size_t]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [W.HGLOBAL]
    kernel32.GlobalUnlock.argtypes = [W.HGLOBAL]


def find_window(title='Scooter Console', pid=None):
    """Top-level Chromium window with our title (prefer the one owned by our browser)."""
    found = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, W.HWND, W.LPARAM)
    def cb(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        cls = ctypes.create_unicode_buffer(64)
        user32.GetClassNameW(hwnd, cls, 64)
        if not cls.value.startswith('Chrome_WidgetWin'):
            return True
        text = ctypes.create_unicode_buffer(256)
        user32.GetWindowTextW(hwnd, text, 256)
        if text.value.startswith(title):
            owner = W.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
            found.append((owner.value == pid, hwnd))
        return True
    user32.EnumWindows(cb, 0)
    found.sort(key=lambda x: not x[0])
    return found[0][1] if found else None


def grab(hwnd):
    """(width, height, BGRA top-down bytes) of the window's client area."""
    if user32.IsIconic(hwnd):
        raise RuntimeError('The window is minimised; restore it and try again.')
    r = W.RECT()
    user32.GetClientRect(hwnd, ctypes.byref(r))
    w, h = r.right - r.left, r.bottom - r.top
    if w <= 0 or h <= 0:
        raise RuntimeError('The window has no visible area.')
    hdc = user32.GetDC(hwnd)
    mem = gdi32.CreateCompatibleDC(hdc)
    bmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
    old = gdi32.SelectObject(mem, bmp)
    try:
        if not user32.PrintWindow(hwnd, mem, 1 | 2):          # PW_CLIENTONLY | PW_RENDERFULLCONTENT
            raise RuntimeError('Windows refused to render the window.')
        header = struct.pack('<IiiHHIIiiII', 40, w, -h, 1, 32, 0, 0, 0, 0, 0, 0)
        buf = ctypes.create_string_buffer(w * h * 4)
        if not gdi32.GetDIBits(mem, bmp, 0, h, buf, header, 0):
            raise RuntimeError('Could not read the window pixels.')
        return w, h, buf.raw
    finally:
        gdi32.SelectObject(mem, old)
        gdi32.DeleteObject(bmp)
        gdi32.DeleteDC(mem)
        user32.ReleaseDC(hwnd, hdc)


def to_png(w, h, bgra):
    rows = bytearray()
    stride = w * 4
    for y in range(h):
        row = bgra[y * stride:(y + 1) * stride]
        rgb = bytearray(w * 3)
        rgb[0::3], rgb[1::3], rgb[2::3] = row[2::4], row[1::4], row[0::4]
        rows += b'\x00' + rgb

    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xFFFFFFFF)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(bytes(rows), 6)) + chunk(b'IEND', b''))


def to_clipboard(w, h, bgra):
    """Put the image on the clipboard as CF_DIB (bottom-up 32-bit)."""
    stride = w * 4
    flipped = b''.join(bgra[(h - 1 - y) * stride:(h - y) * stride] for y in range(h))
    header = struct.pack('<IiiHHIIiiII', 40, w, h, 1, 32, 0, len(flipped), 0, 0, 0, 0)
    data = header + flipped
    handle = kernel32.GlobalAlloc(0x0002, len(data))          # GMEM_MOVEABLE
    ptr = kernel32.GlobalLock(handle)
    ctypes.memmove(ptr, data, len(data))
    kernel32.GlobalUnlock(handle)
    for _ in range(10):                                         # clipboard may be briefly busy
        if user32.OpenClipboard(None):
            break
        time.sleep(0.05)
    else:
        return False
    try:
        user32.EmptyClipboard()
        return bool(user32.SetClipboardData(8, handle))          # CF_DIB; clipboard owns handle now
    finally:
        user32.CloseClipboard()


def screenshot(folder, pid=None):
    if not WINDOWS:
        return None
    hwnd = find_window(pid=pid)
    if not hwnd:
        raise RuntimeError('Could not find the console window.')
    w, h, bgra = grab(hwnd)
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / time.strftime('screenshot_%Y%m%d_%H%M%S.png')
    path.write_bytes(to_png(w, h, bgra))
    copied = False
    try:
        copied = to_clipboard(w, h, bgra)
    except Exception:
        pass
    return {'path': str(path), 'width': w, 'height': h, 'copied': copied}
