"""Battery section backend: BMS configuration read, factory-limit comparison, and the
graph signal set. Writes are a single gated path (one DID at a time).

Factory-limit presets come from the diagnostic app's BmsDodValues (the per-model stock
values it writes to restore a pack). We compare the pack's current config to the stock
values and flag deviations — read-only insight; writing stock back is a gated action.
"""
import re

# Signals plotted on the Battery graph (key, label, unit, colour-ish group).
GRAPH_SIGNALS = [
    ('soc', 'State of charge', '%'), ('volts', 'Pack voltage', 'V'),
    ('amps', 'Pack current', 'A'), ('power', 'Power', 'W'),
    ('motor_t', 'Motor temp', '°C'), ('mcu_t', 'Controller temp', '°C'),
]

# Per-model stock config values the app writes to restore a pack (BmsDodValues).
# did -> {model: value_hex}. Only the common, clearly-mapped ones are listed; the app
# writes these with 2E and the DID embedded in the payload.
STOCK_LIMITS = {
    'E4C3': {'name': 'Cell type', 'S1 Pro': 'C301'},
    'E413': {'name': 'Over-temp cutoff', 'S1 Pro': '1343'},
    'E462': {'name': 'Charge over-temp warning', 'S1 Pro': '622E'},
    'E465': {'name': 'Charge over-temp error', 'S1 Pro': '6534'},
    'E467': {'name': 'Drive over-temp warning', 'S1 Pro': '6737'},
    'E469': {'name': 'Drive over-temp error', 'S1 Pro': '693E'},
    'E449': {'name': 'PDU temp warning', 'S1 Pro': '4955'},
    'E44A': {'name': 'PDU temp error', 'S1 Pro': '4A64'},
    'E44D': {'name': 'PDU temp cutoff', 'S1 Pro': '4D69'},
    'E4BA': {'name': 'Parallel cell strings', 'S1 Pro': 'BA1000'},
}


def config_catalog():
    """All BMS configuration identifiers (writable params) from the ODX, read via 0x22."""
    import ecu_report as er
    out = []
    seen = set()
    for d in er.ODX.get('BMS', []):
        rf = (d.get('RequestFormat') or '').replace(' ', '').upper()
        # writable config params are 2E in the ODX; read them back with 22 <DID>
        if not rf.startswith('2E') or len(rf) != 6:
            continue
        did = rf[2:]
        if did in seen or not did.startswith('E'):
            continue
        seen.add(did)
        out.append({'did': did, 'title': (d.get('Description') or d.get('Command') or did).strip(),
                    'params': d.get('Parameters') or []})
    return out


def read_config(scooter, limit=None):
    """Read BMS config DIDs (0x22). Returns rows with decoded values + stock comparison."""
    import ecu_report as er
    from oladiag.seedkey import Ecu
    rows = []
    cat = config_catalog()
    if limit:
        cat = cat[:limit]
    for item in cat:
        did = item['did']
        row = {'did': did, 'title': item['title']}
        try:
            data = scooter.read(Ecu.BMS, bytes.fromhex(did))
            row['hex'] = data.hex().upper()
            # decode using the matching 22-read definition if present, else raw
            rd = next((d for d in er.ODX.get('BMS', []) if (d.get('RequestFormat') or '').replace(' ', '')
                       == '22' + did), None)
            row['values'] = er.decode(rd, data) if rd else [{'name': item['title'], 'value': data.hex().upper(), 'unit': ''}]
            stock = STOCK_LIMITS.get(did)
            if stock and 'S1 Pro' in stock:
                row['stock'] = stock['S1 Pro']
                row['name'] = stock['name']
                row['deviates'] = row['hex'] != stock['S1 Pro'].upper()
        except Exception as exc:
            msg = str(exc)
            row['error'] = 'not supported' if 'NRC 0x31' in msg else msg[:70]
        rows.append(row)
    return rows


# Resting LiNMC open-circuit-voltage → charge% curve (approximate; for a "% left" estimate).
_OCV_CURVE = [(3.00, 0), (3.45, 8), (3.55, 15), (3.65, 28), (3.72, 42), (3.80, 58),
              (3.88, 72), (3.95, 83), (4.05, 92), (4.12, 97), (4.20, 100)]


def _pct_from_mv(mv):
    v = mv / 1000.0
    pts = _OCV_CURVE
    if v <= pts[0][0]:
        return 0.0
    if v >= pts[-1][0]:
        return 100.0
    for (v0, p0), (v1, p1) in zip(pts, pts[1:]):
        if v0 <= v <= v1:
            return round(p0 + (p1 - p0) * (v - v0) / (v1 - v0), 1)
    return 0.0


def read_cells(scooter):
    """Per-cell voltage / IR / estimated capacity / temperature + a charge-% estimate.

    Reads BMS E106 (cell voltages), E109 (internal resistance), E108 (derived capacity Ah),
    E107 (pack temperatures, 6 sensors mapped across the cells). Returns a list of cells plus
    a pack summary (spread, average, weakest cell).
    """
    import ecu_report as er
    from oladiag.seedkey import Ecu

    def read(did):
        try:
            data = scooter.read(Ecu.BMS, bytes.fromhex(did))
            rd = next((d for d in er.ODX.get('BMS', []) if (d.get('RequestFormat') or '').replace(' ', '') == '22' + did), None)
            return er.decode(rd, data) if rd else []
        except Exception:
            return []

    volts = [v['value'] for v in read('E106') if v.get('value') is not None]
    irs = [v['value'] for v in read('E109') if v.get('value') is not None]
    caps = [v['value'] for v in read('E108') if v.get('value') is not None]
    temps = [v['value'] for v in read('E107') if v.get('value') is not None]
    if not volts:
        return {'cells': [], 'error': 'No per-cell data returned by the BMS.'}
    # normalise cell voltage to mV
    mv = [v * 1000 if v < 10 else v for v in volts]
    n = len(mv)
    cells = []
    for i in range(n):
        temp = temps[round(i * (len(temps) - 1) / max(1, n - 1))] if temps else None
        cells.append({
            'cell': i + 1,
            'mv': round(mv[i], 1),
            'pct': _pct_from_mv(mv[i]),
            'ir': round(irs[i], 2) if i < len(irs) else None,
            'ah': round(caps[i], 2) if i < len(caps) else None,
            'temp': round(temp, 1) if temp is not None else None,
        })
    avg = sum(mv) / n
    spread = max(mv) - min(mv)
    weak = min(range(n), key=lambda i: mv[i]) + 1
    ir_med = sorted([c['ir'] for c in cells if c['ir'] is not None])
    ir_med = ir_med[len(ir_med) // 2] if ir_med else None
    return {'cells': cells, 'count': n, 'avg_mv': round(avg, 1), 'spread_mv': round(spread, 1),
            'weak_cell': weak, 'ir_median': ir_med,
            'total_ah': round(sum(c['ah'] for c in cells if c['ah']), 1) if any(c['ah'] for c in cells) else None,
            'time': None}


def factory_check(rows):
    """Summarise deviations from stock for the DIDs we have presets for."""
    checked = [r for r in rows if 'stock' in r]
    dev = [r for r in checked if r.get('deviates')]
    findings = []
    if not checked:
        findings.append({'tone': 'info', 'text': 'Read the settings to compare them with the factory values.'})
    elif not dev:
        findings.append({'tone': 'ok', 'text': f'All {len(checked)} checked limits match the factory values for this model.'})
    else:
        findings.append({'tone': 'warn', 'text': f'{len(dev)} of {len(checked)} checked limits differ from factory: '
                         + ', '.join(f'{r["name"]}' for r in dev) + '. A modified pack or custom tuning can do this.'})
    return findings
