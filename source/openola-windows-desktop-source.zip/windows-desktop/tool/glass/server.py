"""Local-only HTTP bridge between the glass page and the Controller.

Binds 127.0.0.1 on a random port. Every API call must carry the per-launch token and
a localhost Host header (blocks other local pages and DNS-rebinding). Nothing here is
reachable from the network, and no browser profile, cloud service or CDN is involved.
"""
import json
import secrets
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from controller import Controller, Notice, NeedConfirm, ROOT

WEB = Path(__file__).resolve().parent / 'web'
STATIC = {'/': ('index.html', 'text/html; charset=utf-8'),
          '/index.html': ('index.html', 'text/html; charset=utf-8'),
          '/style.css': ('style.css', 'text/css; charset=utf-8'),
          '/app.js': ('app.js', 'text/javascript; charset=utf-8')}

# Native file dialogs run in a short-lived helper process so they never block the
# controller loop (and work no matter which thread the request arrives on).
_PICK = r'''
import json, sys, tkinter as tk
from tkinter import filedialog
a = json.loads(sys.argv[1])
r = tk.Tk(); r.withdraw()
try: r.attributes('-topmost', True)
except Exception: pass
types = [(a.get('label') or 'Files', a.get('pattern') or '*.*'), ('All files', '*.*')]
k = a.get('kind')
if k == 'dir':
    p = filedialog.askdirectory(parent=r, title=a.get('title'), initialdir=a.get('initial'))
elif k == 'open':
    p = filedialog.askopenfilename(parent=r, title=a.get('title'), initialdir=a.get('initial'), filetypes=types)
else:
    p = filedialog.asksaveasfilename(parent=r, title=a.get('title'), initialdir=a.get('initial'),
                                     defaultextension=a.get('ext') or '', filetypes=types)
print(json.dumps(p or ''))
'''
PICK_DIRS = {'captures': ROOT / 'captures', 'learning': ROOT / 'captures/gui/learning',
             'dumps': ROOT / 'captures/dumps', 'recordings': ROOT / 'captures/recordings'}


class App:
    def __init__(self):
        self.ctl = Controller()
        self.token = secrets.token_urlsafe(24)
        self.last_seen = 0.0
        self.bye_at = 0.0
        self.httpd = None
        self.browser_pid = None

    def pick(self, args):
        where = args.get('where')
        if where == 'activity':
            initial = self.ctl._status_log.root
        elif where == 'charge':
            initial = self.ctl._charge_rec.root
        else:
            initial = PICK_DIRS.get(where, ROOT / 'captures')
        spec = {'kind': args.get('kind', 'open'), 'title': str(args.get('title', 'Choose')),
                'initial': str(initial), 'label': args.get('label'), 'pattern': args.get('pattern'),
                'ext': args.get('ext')}
        flags = 0x08000000 if sys.platform.startswith('win') else 0     # CREATE_NO_WINDOW
        out = subprocess.run([sys.executable, '-c', _PICK, json.dumps(spec)], capture_output=True,
                             text=True, timeout=900, creationflags=flags)
        try:
            return json.loads(out.stdout.strip().splitlines()[-1]) if out.stdout.strip() else ''
        except (ValueError, IndexError):
            return ''

    def handler(self):
        app = self

        class Handler(BaseHTTPRequestHandler):
            server_version = 'ScooterConsole/2'

            def log_message(self, *args):            # keep the console quiet
                pass

            def _host_ok(self):
                host = (self.headers.get('Host') or '').split(':')[0]
                return host in ('127.0.0.1', 'localhost')

            def _token_ok(self, query):
                got = self.headers.get('X-Token') or query.get('t', [''])[0]
                return secrets.compare_digest(got, app.token)

            def _send(self, code, body, ctype='application/json; charset=utf-8'):
                data = body if isinstance(body, bytes) else json.dumps(body, default=str).encode('utf-8')
                self.send_response(code)
                self.send_header('Content-Type', ctype)
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('X-Content-Type-Options', 'nosniff')
                if ctype.startswith('text/html'):
                    self.send_header('Content-Security-Policy',
                                     "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
                                     "script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                if not self._host_ok():
                    return self._send(403, {'error': 'forbidden'})
                url = urlparse(self.path)
                query = parse_qs(url.query)
                if url.path in STATIC:
                    name, ctype = STATIC[url.path]
                    return self._send(200, (WEB / name).read_bytes(), ctype)
                if not url.path.startswith('/api/') or not self._token_ok(query):
                    return self._send(404, {'error': 'not found'})
                try:
                    if url.path == '/api/state':
                        app.last_seen = time.monotonic()
                        app.bye_at = 0.0
                        since = int(query.get('since', ['0'])[0] or 0)
                        views = [v for v in query.get('views', [''])[0].split(',') if v]
                        rseq = int(query.get('rseq', ['-1'])[0] or -1)
                        return self._send(200, app.ctl.call(lambda: app.ctl.state(since, views, rseq)))
                    if url.path == '/api/meta':
                        return self._send(200, app.ctl.call(app.ctl.meta))
                    if url.path == '/api/catalog':
                        return self._send(200, app.ctl.call(app.ctl.catalog_rows, timeout=60))
                except Exception as exc:
                    return self._send(500, {'error': str(exc)})
                return self._send(404, {'error': 'not found'})

            def do_POST(self):
                if not self._host_ok():
                    return self._send(403, {'error': 'forbidden'})
                url = urlparse(self.path)
                query = parse_qs(url.query)
                if not self._token_ok(query):
                    return self._send(404, {'error': 'not found'})
                if url.path == '/api/upload_recording':        # screen recording from the page (webm)
                    total = int(self.headers.get('Content-Length') or 0)
                    if not 0 < total <= 4_000_000_000:
                        return self._send(400, {'error': 'bad size'})
                    png = query.get('ext', [''])[0] == 'png'
                    folder = ROOT / ('captures/screenshots' if png else 'captures/recordings')
                    folder.mkdir(parents=True, exist_ok=True)
                    path = folder / time.strftime(('screenshot_%Y%m%d_%H%M%S.png' if png
                                                   else 'recording_%Y%m%d_%H%M%S.webm'))
                    with open(path, 'wb') as f:
                        left = total
                        while left:
                            chunk = self.rfile.read(min(left, 1 << 20))
                            if not chunk:
                                break
                            f.write(chunk)
                            left -= len(chunk)
                    app.ctl.call(lambda: app.ctl.report(f'Screen recording saved: {path}'))
                    return self._send(200, {'path': str(path), 'folder': str(folder)})
                if url.path == '/api/screenshot':
                    try:
                        import wincapture as capture
                        shot = capture.screenshot(ROOT / 'captures/screenshots', app.browser_pid)
                        if shot is None:
                            return self._send(200, {'fallback': True})
                        app.ctl.call(lambda: app.ctl.report(f'Screenshot saved: {shot["path"]}'))
                        return self._send(200, shot)
                    except Exception as exc:
                        return self._send(200, {'error': str(exc), 'fallback': True})
                if url.path == '/api/open_captures':
                    kind = 'recordings' if 'recording' in self.path else 'screenshots'
                    folder = ROOT / 'captures' / kind
                    folder.mkdir(parents=True, exist_ok=True)
                    try:
                        app.ctl._open_path(folder)
                    except Exception:
                        pass
                    return self._send(200, {'ok': True})
                length = min(int(self.headers.get('Content-Length') or 0), 1_000_000)
                try:
                    body = json.loads(self.rfile.read(length) or b'{}') if length else {}
                except ValueError:
                    return self._send(400, {'error': 'bad json'})
                if url.path == '/api/bye':                  # page unloading (close or reload)
                    app.bye_at = time.monotonic()
                    return self._send(200, {'ok': True})
                if url.path == '/api/pick':
                    try:
                        return self._send(200, {'path': app.pick(body)})
                    except Exception as exc:
                        return self._send(200, {'path': '', 'error': str(exc)})
                if url.path.startswith('/api/act/'):
                    name = url.path[len('/api/act/'):]
                    try:
                        result = app.ctl.call(lambda: app.ctl.act(name, body))
                        out = {'ok': True}
                        if isinstance(result, dict):
                            out.update(result)
                        return self._send(200, out)
                    except NeedConfirm as c:
                        return self._send(200, {'ok': False, 'confirm': c.payload})
                    except Notice as n:
                        return self._send(200, {'ok': False, 'notice': n.payload})
                    except Exception as exc:
                        return self._send(200, {'ok': False, 'notice': {'title': name, 'text': str(exc),
                                                                        'tone': 'danger'}})
                return self._send(404, {'error': 'not found'})
        return Handler

    def serve(self, port=0):
        self.httpd = ThreadingHTTPServer(('127.0.0.1', port), self.handler())
        self.httpd.daemon_threads = True
        threading.Thread(target=self.httpd.serve_forever, name='http', daemon=True).start()
        self.ctl.start()
        return f'http://127.0.0.1:{self.httpd.server_address[1]}/?t={self.token}'

    def shutdown(self):
        self.ctl.request_close()
        self.ctl.closed.wait(20)
        if self.httpd:
            self.httpd.shutdown()
