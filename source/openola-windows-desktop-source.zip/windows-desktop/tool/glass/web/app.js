/* Scooter Console — glass UI client. Vanilla JS, no dependencies, offline.
 * The page polls /api/state and posts actions to /api/act/<name>. Every safety prompt
 * comes from the Python controller (NeedConfirm), so this file only renders it. */
'use strict';

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const TOKEN = new URLSearchParams(location.search).get('t') || '';

/* ------------------------------------------------------------------ icons (SF-style line set) */
const P = (d) => `<path d="${d}"/>`;
const C = (cx, cy, r, fill) => `<circle cx="${cx}" cy="${cy}" r="${r}"${fill ? ' fill="currentColor" stroke="none"' : ''}/>`;
const ICONS = {
  bolt: P('M13 2 4 14h7l-1 8 9-12h-7z'),
  house: P('M3 10.5 12 3l9 7.5') + P('M5 9.5V20h5v-6h4v6h5V9.5'),
  gauge: P('M12 14l4-4') + P('M3.5 17a9 9 0 1 1 17 0') + C(12, 14, 1.6),
  plug: P('M9 2v5M15 2v5') + P('M6 7h12v4a6 6 0 0 1-12 0z') + P('M12 17v5'),
  wave: P('M2 12h3l3-7 4 14 3-9 2 2h5'),
  stetho: P('M5 3v6a5 5 0 0 0 10 0V3') + P('M10 14v2a5 5 0 0 0 10 0v-2') + C(20, 11, 2),
  wrench: P('M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z'),
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/>' + P('M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3') + '<rect x="9.5" y="9.5" width="5" height="5" rx="1"/>',
  dial: C(12, 12, 9) + P('M12 7v5l3 2'),
  download: P('M12 3v12m0 0-4.5-4.5M12 15l4.5-4.5') + P('M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2'),
  bt: P('M7 7l10 10-5 5V2l5 5L7 17'),
  sun: C(12, 12, 4) + P('M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4'),
  moon: P('M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z'),
  auto: C(12, 12, 9) + '<path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor" stroke="none"/>',
  list: P('M8 6h13M8 12h13M8 18h13') + C(3.5, 6, 1) + C(3.5, 12, 1) + C(3.5, 18, 1),
  help: C(12, 12, 9) + P('M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .9-1 1.6v.4') + C(12, 17, 0.6, true),
  sidebar: '<rect x="3" y="4" width="18" height="16" rx="3"/>' + P('M9 4v16'),
  'chev-down': P('M6 9l6 6 6-6'),
  updown: P('M8 9l4-4 4 4M8 15l4 4 4-4'),
  info: C(12, 12, 9) + P('M12 11v6') + C(12, 7.5, 0.6, true),
  check: P('M5 12.5l4.5 4.5L19 7.5'),
  shield: P('M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z') + P('M8.5 12l2.5 2.5 4.5-5'),
  play: '<path d="M7 4.5v15l13-7.5z" fill="currentColor" stroke="none"/>',
  pause: '<rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none"/><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2.5" fill="currentColor" stroke="none"/>',
  record: C(12, 12, 6, true),
  folder: P('M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'),
  share: P('M12 3v12M7.5 7.5 12 3l4.5 4.5') + P('M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7'),
  search: C(11, 11, 7) + P('M20 20l-3.5-3.5'),
  flask: P('M9 3h6M10 3v6L4.5 18.5A2 2 0 0 0 6.2 21h11.6a2 2 0 0 0 1.7-2.5L14 9V3') + P('M7 15h10'),
  lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/>' + P('M8 10.5V7.5a4 4 0 0 1 8 0v3'),
  unlock: '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/>' + P('M8 10.5V7.5a4 4 0 0 1 7.7-1.5'),
  box: P('M3 7.5 12 3l9 4.5v9L12 21l-9-4.5z') + P('M3 7.5l9 4.5 9-4.5M12 12v9'),
  refresh: P('M20 11a8 8 0 0 0-14.3-4.9L4 8') + P('M4 3.5V8h4.5') + P('M4 13a8 8 0 0 0 14.3 4.9L20 16') + P('M20 20.5V16h-4.5'),
  eye: P('M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z') + C(12, 12, 3),
  warn: P('M12 3 2 20h20z') + P('M12 10v4.5') + C(12, 17, 0.6, true),
  x: P('M6 6l12 12M18 6 6 18'),
  horn: P('M3 10v4h4l6 4V6L7 10z') + P('M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11'),
  wifi: P('M2 8.5a15 15 0 0 1 20 0M5 12a10 10 0 0 1 14 0M8.5 15.5a5 5 0 0 1 7 0') + C(12, 19, 1, true),
  tag: P('M3 12V4h8l10 10-8 8z') + C(7.5, 7.5, 1.4),
  chip: '<rect x="4" y="4" width="16" height="16" rx="3"/>' + P('M9 9h6v6H9z'),
  sparkle: P('M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z') + P('M19 15l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z'),
  doc: P('M6 3h8l5 5v13H6z') + P('M14 3v5h5') + P('M9 13h7M9 17h5'),
  camera: P('M3 8a2 2 0 0 1 2-2h2.5L9 4h6l1.5 2H19a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z') + C(12, 13, 4),
  video: '<rect x="2.5" y="6" width="13" height="12" rx="2.5"/>' + P('M15.5 10.5 21 7.5v9l-5.5-3'),
  bell: P('M6 16V11a6 6 0 0 1 12 0v5l2 2H4z') + P('M10 20a2 2 0 0 0 4 0'),
  bulb: P('M9 18h6M10 21h4') + P('M12 3a6 6 0 0 0-3.5 10.9c.5.4.5 1.1.5 1.6V16h6v-.5c0-.5 0-1.2.5-1.6A6 6 0 0 0 12 3z'),
  beamHigh: P('M10 6c-3.5 0-6 2.7-6 6s2.5 6 6 6c1.4 0 2-1 2-2V8c0-1-.6-2-2-2z') + P('M15 7h6M15 10h6M15 14h6M15 17h6'),
  beamLow: P('M10 6c-3.5 0-6 2.7-6 6s2.5 6 6 6c1.4 0 2-1 2-2V8c0-1-.6-2-2-2z') + P('M15 9l6 1.5M15 12.5l6 1.5M15 16l6 1.5'),
  arrowL: P('M20 12H5M11 5l-7 7 7 7'),
  arrowR: P('M4 12h15M13 5l7 7-7 7'),
  brake: C(12, 12, 8) + C(12, 12, 4) + P('M3 7a10 10 0 0 0 0 10M21 7a10 10 0 0 1 0 10'),
  speaker: P('M4 9h4l5-4v14l-5-4H4z') + P('M17 9a4 4 0 0 1 0 6'),
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/>' + P('M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21'),
  usb: P('M12 3v15') + P('M9.5 5.5 12 3l2.5 2.5') + P('M12 13l-4-2.5V8M12 15l4-2.5V10') + C(12, 19.5, 1.6) + '<rect x="15" y="8" width="2" height="2"/>' + C(8, 7.5, 1),
  switchI: P('M3 17h4l9-9M16 17h5') + C(7, 17, 1.5) + C(17, 7, 1.5),
  battery: '<rect x="2.5" y="7" width="17" height="10" rx="2.5"/>' + P('M21.5 10.5v3') + P('M6 10v4M9.5 10v4'),
  network: '<rect x="9" y="3" width="6" height="5" rx="1"/><rect x="3" y="16" width="6" height="5" rx="1"/><rect x="15" y="16" width="6" height="5" rx="1"/>' + P('M12 8v4M6 16v-4h12v4'),
  led: C(12, 10, 5) + P('M10 18v3M14 18v3M9 15h6'),
  volUp: P('M4 9h4l5-4v14l-5-4H4z') + P('M17 12h5M19.5 9.5v5'),
  volDown: P('M4 9h4l5-4v14l-5-4H4z') + P('M17 12h5'),
  power: P('M12 3v9') + P('M6.3 6.3a8 8 0 1 0 11.4 0'),
  stand: P('M4 18h16') + P('M12 18l-5-12M12 18l4-8') + C(16.5, 8.5, 1.6),
  seat: P('M5 14c0-4 3-6 7-6s7 2 7 6z') + P('M8 14v5M16 14v5'),
  screen: '<rect x="3" y="4" width="18" height="12" rx="2"/>' + P('M8 20h8M12 16v4'),
  handlebar: P('M3 9c3 0 4 2 9 2s6-2 9-2') + P('M12 11v9') + P('M2 8v3M22 8v3'),
  gps: C(12, 10, 3) + P('M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11z'),
  restart: P('M4 4v5h5') + P('M5.5 15a7.5 7.5 0 1 0 1.3-8.2L4 9'),
  dtc: P('M4 6h16M4 12h10M4 18h7') + C(19, 17, 3) + P('M19 15.5v1.8') ,
};
const icon = (name) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.chip}</svg>`;
function paintIcons(root = document) {
  $$('i[data-icon]', root).forEach((el) => { el.outerHTML = icon(el.dataset.icon); });
}

/* ------------------------------------------------------------------ API */
let offline = 0;
async function http(method, path, body) {
  const res = await fetch(path, {
    method, headers: { 'X-Token': TOKEN, 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function act(name, args = {}) {
  let r;
  try { r = await http('POST', `/api/act/${name}`, args); }
  catch (e) { toast('Console not reachable', 'danger'); return null; }
  while (r && r.confirm) {
    const answer = await confirmSheet(r.confirm);
    if (answer === null) return null;
    r = await http('POST', `/api/act/${name}`, { ...args, confirm: answer });
  }
  if (r && r.notice) noticeSheet(r.notice);
  if (r && r.message) toast(r.message, 'ok');
  poll(true);
  return r;
}

async function pick(spec) {
  const r = await http('POST', '/api/pick', spec).catch(() => ({ path: '' }));
  return r.path || '';
}

/* ------------------------------------------------------------------ theme */
const THEME_KEY = 'scooterConsole.theme';
function applyTheme(mode) {
  const root = document.documentElement;
  if (mode === 'light' || mode === 'dark') root.dataset.theme = mode; else delete root.dataset.theme;
  $$('#themeSeg button').forEach((b) => b.classList.toggle('on', b.dataset.themeSet === (mode || 'system')));
  try { localStorage.setItem(THEME_KEY, mode); } catch (_) { /* private mode */ }
}

/* ------------------------------------------------------------------ Apple-style menus (pop-up buttons) */
let openMenu = null;
function closeMenu() {
  if (!openMenu) return;
  const m = openMenu; openMenu = null;
  m.el.classList.add('closing');
  setTimeout(() => m.el.remove(), 160);
  if (m.anchor) m.anchor.classList.remove('open');
}
/** items: [{label, value, icon, checked, danger, hint, sep}] ; onPick(value) */
function showMenu(anchor, items, onPick, { align = 'left', minWidth } = {}) {
  closeMenu();
  const el = document.createElement('div');
  el.className = 'menu glass';
  el.setAttribute('role', 'menu');
  el.innerHTML = items.map((it, i) => it.sep ? '<div class="menu-sep"></div>'
    : `<button role="menuitemradio" class="menu-item ${it.danger ? 'danger' : ''}" data-i="${i}" aria-checked="${!!it.checked}">
        <span class="menu-check">${it.checked ? icon('check') : ''}</span>
        ${it.icon ? `<span class="menu-icon">${icon(it.icon)}</span>` : ''}
        <span class="menu-label">${esc(it.label)}${it.hint ? `<small>${esc(it.hint)}</small>` : ''}</span>
      </button>`).join('');
  document.body.appendChild(el);
  const r = anchor.getBoundingClientRect();
  el.style.minWidth = (minWidth || Math.max(r.width, 180)) + 'px';
  const mw = el.offsetWidth, mh = el.offsetHeight;
  let left = align === 'right' ? r.right - mw : r.left;
  left = Math.max(8, Math.min(left, innerWidth - mw - 8));
  let top = r.bottom + 6;
  if (top + mh > innerHeight - 8) top = Math.max(8, r.top - mh - 6);
  el.style.left = left + 'px'; el.style.top = top + 'px';
  el.style.transformOrigin = `${align === 'right' ? 'right' : 'left'} ${top < r.top ? 'bottom' : 'top'}`;
  anchor.classList.add('open');
  openMenu = { el, anchor };
  const buttons = $$('.menu-item', el);
  const focusIdx = Math.max(0, buttons.findIndex((b) => b.getAttribute('aria-checked') === 'true'));
  setTimeout(() => buttons[focusIdx] && buttons[focusIdx].focus(), 10);
  el.addEventListener('click', (e) => {
    const b = e.target.closest('.menu-item'); if (!b) return;
    const it = items[+b.dataset.i];
    closeMenu(); onPick(it.value, it);
  });
  el.addEventListener('keydown', (e) => {
    const i = buttons.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); buttons[(i + 1) % buttons.length].focus(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); buttons[(i - 1 + buttons.length) % buttons.length].focus(); }
    if (e.key === 'Escape') { e.preventDefault(); closeMenu(); anchor.focus(); }
    if (e.key === 'Tab') closeMenu();
  });
}
document.addEventListener('pointerdown', (e) => {
  if (openMenu && !openMenu.el.contains(e.target) && !openMenu.anchor.contains(e.target)) closeMenu();
}, true);
window.addEventListener('resize', closeMenu);
document.addEventListener('scroll', (e) => { if (openMenu && !openMenu.el.contains(e.target)) closeMenu(); }, true);

/** Replace a native <select> with an Apple pop-up button; the select stays the source of truth. */
function enhanceSelect(sel) {
  if (sel._pop) return refreshSelect(sel);
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'popup ' + (sel.className || '');
  btn.innerHTML = '<span class="popup-label"></span>' + icon('updown');
  sel.classList.add('native-hidden');
  sel.after(btn);
  sel._pop = btn;
  btn.addEventListener('click', () => {
    if (openMenu && openMenu.anchor === btn) return closeMenu();
    const items = [...sel.options].map((o) => ({ label: o.textContent, value: o.value, checked: o.selected }));
    showMenu(btn, items, (v) => {
      if (sel.value !== v) { sel.value = v; sel.dispatchEvent(new Event('change', { bubbles: true })); }
      refreshSelect(sel);
    });
  });
  btn.addEventListener('keydown', (e) => { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); btn.click(); } });
  refreshSelect(sel);
}
function refreshSelect(sel) {
  const o = sel.options[sel.selectedIndex];
  if (sel._pop) $('.popup-label', sel._pop).textContent = o ? o.textContent : '';
}
/** Text input + suggestions menu (replaces <datalist>). */
function enhanceCombo(input, values) {
  const wrap = document.createElement('div');
  wrap.className = 'combo ' + (input.classList.contains('grow') ? 'grow' : '');
  input.before(wrap); wrap.appendChild(input);
  const btn = document.createElement('button');
  btn.type = 'button'; btn.className = 'combo-btn'; btn.title = 'Suggestions'; btn.innerHTML = icon('updown');
  wrap.appendChild(btn);
  input.removeAttribute('list');
  btn.addEventListener('click', () => {
    if (openMenu && openMenu.anchor === wrap) return closeMenu();
    showMenu(wrap, values.map((v) => ({ label: v, value: v, checked: v === input.value })), (v) => { input.value = v; input.focus(); });
  });
}

/* ------------------------------------------------------------------ navigation */
let view = 'home';
const tabs = { live: 'signals', tests: 'components', comp: 'ids', health: 'Fault signals', bat: 'overview' };
function go(name, tabSpec) {
  if (!$('#v-' + name)) return;
  view = name;
  $$('.view').forEach((v) => v.classList.toggle('on', v.id === 'v-' + name));
  $$('.nav-item').forEach((b) => b.classList.toggle('on', b.dataset.view === name));
  $('#toolbarTitle').textContent = $('#v-' + name).dataset.title;
  $('#scroller').scrollTop = 0;
  $('#sidebar').classList.remove('open');
  closeMenu();
  if (tabSpec) { const [g, t] = tabSpec.split(':'); setTab(g, t); }
  try { sessionStorage.setItem('scooterConsole.view', name); } catch (_) { /* ignore */ }
  poll(true);
}
function setTab(group, tab) {
  tabs[group] = tab;
  $$(`[data-tabs="${group}"] button`).forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  $$(`[data-pane^="${group}:"]`).forEach((p) => { p.hidden = p.dataset.pane !== `${group}:${tab}`; });
  if (group === 'comp' && tab === 'catalog') loadCatalog();
  if (group === 'health') renderHealth();
}
function viewsParam() {
  const v = [view];
  if (view === 'home') v.push('status');
  if (!$('#drawer').hidden) v.push('activity');
  return v.join(',');
}

/* ------------------------------------------------------------------ island (busy + toasts) */
const island = { toastUntil: 0, busy: '' };
function toast(text, tone = 'ok') {
  const el = $('#island');
  island.toastUntil = Date.now() + 2800;
  el.className = `island show toast ${tone}`;
  $('#islandIcon').innerHTML = icon(tone === 'danger' ? 'warn' : tone === 'info' ? 'info' : 'check');
  $('#islandText').textContent = text;
}
function renderIsland() {
  const el = $('#island');
  if (rec.active) {
    el.className = 'island show recording';
    $('#islandIcon').innerHTML = '';
    const s = Math.floor((Date.now() - rec.started) / 1000);
    $('#islandText').innerHTML = `<span class="rec-dot"></span>Recording ${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}<button class="island-stop" id="recStop">Stop</button>`;
    return;
  }
  if (Date.now() < island.toastUntil) return;
  if (island.busy) {
    el.className = 'island show busy';
    $('#islandText').textContent = island.busy;
  } else {
    el.className = 'island';
  }
}
setInterval(renderIsland, 400);

/* ------------------------------------------------------------------ sheets */
let sheetResolve = null;
const TONE = { danger: ['red', 'warn'], warn: ['orange', 'warn'], info: ['blue', 'info'], ok: ['green', 'check'] };
function openSheet(html, { wide = false } = {}) {
  const layer = $('#layer'), sheet = $('#sheet');
  closeMenu();
  layer.classList.remove('closing');
  sheet.className = 'sheet glass' + (wide ? ' wide' : '');
  sheet.innerHTML = html;
  layer.hidden = false;
  const focus = $('input', sheet) || $('.btn.primary, .btn.danger.solid', sheet);
  setTimeout(() => focus && focus.focus(), 60);
  return sheet;
}
function closeSheet(value = null) {
  const layer = $('#layer');
  if (layer.hidden) return;
  layer.classList.add('closing');
  setTimeout(() => { layer.hidden = true; layer.classList.remove('closing'); }, 200);
  const r = sheetResolve; sheetResolve = null;
  if (r) r(value);
}
function sheetHead(tone, title, ic) {
  const [color, defIcon] = TONE[tone] || TONE.info;
  return `<div class="sheet-icon tile-icon ${color}">${icon(ic || defIcon)}</div><h2>${esc(title)}</h2>`;
}
function confirmSheet(c) {
  return new Promise((resolve) => {
    sheetResolve = resolve;
    const danger = c.tone === 'danger';
    const sheet = openSheet(`${sheetHead(c.tone, c.title)}<p class="body">${esc(c.text)}</p>
      ${c.word ? `<div class="word"><label>Type <b>${esc(c.word)}</b> to confirm</label><input id="wordIn" autocomplete="off" spellcheck="false"></div>` : ''}
      <div class="actions"><button class="btn" data-x="cancel">Cancel</button>
      <button class="btn ${danger ? 'danger solid' : 'primary'}" data-x="ok" ${c.word ? 'disabled' : ''}>${esc(c.button || 'Continue')}</button></div>`);
    const ok = $('[data-x=ok]', sheet), input = $('#wordIn', sheet);
    if (input) input.addEventListener('input', () => { ok.disabled = input.value.trim().toUpperCase() !== c.word; });
    const submit = () => {
      if (input && input.value.trim().toUpperCase() !== c.word) { sheet.classList.remove('shake'); void sheet.offsetWidth; sheet.classList.add('shake'); return; }
      closeSheet(c.word ? c.word : true);
    };
    ok.onclick = submit;
    $('[data-x=cancel]', sheet).onclick = () => closeSheet(null);
    sheet.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); submit(); } };
  });
}
function noticeSheet(n, action) {
  const long = (n.text || '').length > 260 || (n.text || '').includes('{');
  const sheet = openSheet(`${sheetHead(n.tone || 'info', n.title || 'Notice')}<p class="body ${long ? 'mono' : ''}">${esc(n.text)}</p>
    <div class="actions">${action ? `<button class="btn" data-x="close">Not now</button><button class="btn primary" data-x="go">${esc(action.label)}</button>`
      : `<button class="btn primary" data-x="close">OK</button>`}</div>`, { wide: long });
  $('[data-x=close]', sheet).onclick = () => closeSheet();
  if (action) $('[data-x=go]', sheet).onclick = () => { closeSheet(); act(action.name, action.args || {}); };
}
function settingsSheet() {
  const c = S.conn || {};
  if (c.demo) return noticeSheet({ title: 'Demo scooter', text: 'You’re connected to the built-in simulated scooter. Nothing is sent to a real vehicle. Press Disconnect to end the demo, then set up your scooter’s Wi‑Fi connection here.', tone: 'info' });
  const sheet = openSheet(`${sheetHead('info', 'Scooter Wi‑Fi connection', 'wifi')}
    <p class="body">Join the scooter’s Wi‑Fi on this PC first. Changes apply the next time you connect.</p>
    <div class="form">
      <label>Host<input id="cfHost" value="${esc(c.host)}" spellcheck="false" class="mono"></label>
      <label>Port<input id="cfPort" value="${esc(c.port)}" inputmode="numeric" class="mono"></label>
      <div class="toggle-row"><span>Certificate authentication (mTLS)<small>Only if your setup uses client certificates</small></span><span class="switch"><input type="checkbox" id="cfTls" ${c.secure ? 'checked' : ''}><span></span></span></div>
    </div>
    <div class="actions"><button class="btn" data-x="cancel">Cancel</button><button class="btn primary" data-x="ok">Save</button></div>`);
  $('[data-x=cancel]', sheet).onclick = () => closeSheet();
  const save = async () => {
    const r = await act('set_connection', { host: $('#cfHost').value, port: $('#cfPort').value, secure: $('#cfTls').checked });
    if (r && r.ok) closeSheet();
  };
  $('[data-x=ok]', sheet).onclick = save;
  sheet.onkeydown = (e) => { if (e.key === 'Enter') save(); };
}

/* ------------------------------------------------------------------ server events */
function handleEvent(e) {
  if (e.kind === 'toast') return toast(e.title + (e.text ? ' · ' + e.text : ''), e.tone || 'ok');
  if (e.kind === 'error') return noticeSheet({ title: e.title + ' failed', text: e.text, tone: 'danger' });
  if (e.kind === 'ask') return noticeSheet({ title: e.title, text: e.text, tone: 'info' }, e.action);
  noticeSheet({ title: e.title, text: e.text, tone: e.tone || 'info' });
}

/* ------------------------------------------------------------------ state + polling */
let S = {}, META = null, seq = null, pollTimer = null, polling = false, reportSeen = -1, REPORT = null;
function getPath(obj, path) { return path.split('.').reduce((o, k) => (o == null ? o : o[k]), obj); }

async function poll(soon) {
  if (soon) { clearTimeout(pollTimer); pollTimer = setTimeout(() => poll(), 60); return; }
  if (polling) return;
  polling = true;
  try {
    const since = seq === null ? 1e15 : seq;
    const st = await http('GET', `/api/state?since=${since}&views=${viewsParam()}&rseq=${reportSeen}`);
    offline = 0;
    if (seq !== null) (st.events || []).forEach(handleEvent);
    seq = st.seq;
    if (st.report) { REPORT = st.report; reportSeen = st.report.seq; buildReport(); }
    S = st;
    render();
  } catch (_) {
    offline += 1;
    if (offline > 3) { island.busy = 'Console stopped — you can close this window'; }
  } finally {
    polling = false;
    clearTimeout(pollTimer);
    pollTimer = setTimeout(() => poll(), 650);
  }
}

function setText(el, value) {
  const v = value == null || value === '' ? '—' : String(value);
  if (el.textContent !== v) el.textContent = v;
}
function setHTML(el, html) {
  if (el._html !== html) { el._html = html; el.innerHTML = html; }
}

/* ------------------------------------------------------------------ render */
function render() {
  const c = S.conn || {};
  island.busy = S.closing ? 'Disconnecting…' : (S.busy_label || '');

  $$('[data-b]').forEach((el) => {
    let v = getPath(S, el.dataset.b);
    if (v === undefined) return;
    // Big numerals read better with an Apple-style "--" placeholder than a long em dash.
    if ((v === '—' || v === '' || v == null) && el.closest('.stat-val, .ring-value, .metric, .big-read, .tile-val')) v = '--';
    if (v === null) v = '--';
    setText(el, v);
  });

  // connection pill + buttons
  const pill = $('#connPill');
  const connecting = S.busy_label === 'Connect';
  pill.classList.toggle('ok', !!c.connected);
  pill.classList.toggle('wait', connecting);
  pill.classList.toggle('demo', !!c.demo);
  setText($('#connTitle'), connecting ? 'Connecting…' : c.connected ? `${c.model || (c.demo ? 'Demo' : 'Connected')} · ${c.mode}` : 'Not connected');
  setText($('#connSub'), c.demo ? 'Simulated scooter · nothing is sent' : `${c.host}:${c.port} · ${c.secure ? 'mTLS' : 'Wi‑Fi'}`);
  const cb = $('#connectBtn');
  cb.textContent = c.connected ? (c.demo ? 'End demo' : 'Disconnect') : connecting ? 'Connecting…' : 'Connect';
  cb.className = 'btn ' + (c.connected ? '' : 'primary');
  cb.disabled = connecting;
  $('#demoBtn').hidden = !!c.connected || connecting;
  $('#demoPill').hidden = !c.demo;
  $('#heroDemo').hidden = !!c.connected;

  const bench = $('#bench');
  if (document.activeElement !== bench) bench.checked = !!c.bench;
  $('#benchWrap').classList.toggle('on', !!c.bench);
  const ua = $('#unlockAccess');
  if (ua && document.activeElement !== ua) ua.checked = !!c.unlock_access;
  const vl = $('#vitalsLog');
  if (vl && S.monitor && document.activeElement !== vl) vl.checked = !!S.monitor.vitals_log;

  $('#monPaused').hidden = !(S.monitor && S.monitor.paused) || !['status', 'charging', 'live', 'diagnostics', 'home'].includes(view);

  // faults badge
  const nf = (S.faults || []).length;
  const badge = $('#navFaults');
  badge.hidden = !(S.monitor && S.monitor.on && nf);
  badge.textContent = nf;
  const nr = $('#navRec'); if (nr) { nr.hidden = !S.rec_active; nr.textContent = '●'; }

  renderHome();
  renderStatus();
  renderCharging();
  renderTests();
  renderReportProgress();
  if (view === 'firmware') renderFirmware();
  if (view === 'battery') renderBattery();
  if (view === 'recorder') renderRecorder();
  if (view === 'live') { renderLive(); renderLearn(); }
  if (view === 'diagnostics') renderHealth();
  if (view === 'components') renderSetting();
  if (view === 'bluetooth') renderBle();
  if (!$('#drawer').hidden && S.activity) {
    const pre = $('#activityLog');
    const txt = S.activity.join('\n');
    if (pre._t !== txt) { pre._t = txt; pre.textContent = txt; pre.scrollTop = pre.scrollHeight; }
  }
}

function renderHome() {
  const c = S.conn || {}, mon = S.monitor || {}, sv = S.sv || {};
  const soc = parseFloat(sv.soc);
  const ring = $('#socRing');
  const CIRC = 326.73;
  const off = Number.isFinite(soc) ? CIRC * (1 - Math.max(0, Math.min(100, soc)) / 100) : CIRC;
  if (ring._o !== off) { ring._o = off; ring.style.strokeDashoffset = off; }
  setText($('#heroMode span'), c.connected ? `${c.mode} mode${c.demo ? ' · demo' : ''}` : 'Not connected');
  const ha = $('#heroAction');
  const next = !c.connected ? ['Connect', 'connect'] : !mon.on ? ['Start monitor', 'monitor_start'] : ['Open Status', 'go:status'];
  if (ha.dataset.next !== next[1]) { ha.dataset.next = next[1]; ha.textContent = next[0]; }
  const tf = $('#tileFaults'), nf = (S.faults || []).length;
  const tIcon = $('.tile-icon', tf);
  if (!mon.on) { setText($('#tileFaultsVal'), 'Monitor off'); tIcon.className = 'tile-icon green'; }
  else { setText($('#tileFaultsVal'), nf ? `${nf} active` : 'All clear'); tIcon.className = 'tile-icon ' + (nf ? 'red' : 'green'); }
}

function renderStatus() {
  const mon = S.monitor || {};
  const dot = $('#monDot');
  dot.classList.toggle('on', !!mon.on && !mon.paused);
  setText($('#monLabel'), mon.on ? (mon.paused ? 'Paused' : 'Monitoring') : 'Monitor off');
  if (view !== 'status' && view !== 'home') return;
  const faults = S.faults || [];
  const fc = $('#faultCount');
  fc.className = 'count ' + (faults.length ? 'red' : 'green');
  fc.hidden = !mon.on;
  setText(fc, String(faults.length));
  setHTML($('#faultList'), !mon.on ? '<li class="empty">Start the monitor to read live faults.</li>'
    : faults.length ? faults.map((f) => `<li><span class="bullet red"></span>${esc(f)}</li>`).join('')
      : `<li class="ok-row">${icon('check')} No active faults</li>`);
  if (view !== 'status') return;
  const notes = S.notifications || [];
  setHTML($('#notifList'), notes.length ? notes.map((n) => `<li><span class="bullet ${n.alert ? 'red' : ''}"></span><span class="t">${esc(n.time)}</span><span class="code">[${esc(n.code)}]</span><span>${esc(n.name)}</span></li>`).join('')
    : '<li class="empty">No notifications yet.</li>');
  const fs = S.features;
  setHTML($('#featureGrid'), !fs ? '<span class="empty">Waiting for the first 0x660 frame…</span>'
    : fs.features.map(([n, on]) => `<span class="feat ${on ? 'on' : ''}">${esc(n)}</span>`).join('')
      + '<span class="feat-sep"></span>'
      + fs.tech_packs.map(([n, v]) => `<span class="feat ${v ? 'on' : ''}">${esc(n)} = ${esc(v)}</span>`).join(''));
  const lines = S.log_lines || [];
  const pre = $('#statusLog');
  const key = lines.length + '|' + (lines[lines.length - 1] || '');
  if (pre._k !== key) {
    pre._k = key;
    const atBottom = pre.scrollHeight - pre.scrollTop - pre.clientHeight < 30;
    pre.innerHTML = lines.map((l) => {
      const m = /\[(\w+)\]/.exec(l); const tag = m ? m[1] : '';
      const cls = { FAULT: 'c-fault', CMD: 'c-cmd', CHARGE: 'c-charge', CONN: 'c-conn', LIVE: 'c-live' }[tag] || '';
      return cls ? `<span class="${cls}">${esc(l)}</span>` : esc(l);
    }).join('\n') || '<span style="opacity:.5">Log is empty — connect to start a session.</span>';
    if (atBottom) pre.scrollTop = pre.scrollHeight;
  }
}

function renderCharging() {
  const c = S.conn || {};
  const recOn = !!(S.monitor && S.monitor.recording);
  $('#recordCard').classList.toggle('recording', recOn);
  setText($('#recTitle'), recOn ? 'Recording charge session…' : 'Record a charge session');
  setText($('#recSub'), recOn ? 'Tap to stop and save. Keep Wi‑Fi connected.' : 'Logs charge-related CAN frames and vitals to JSONL while you charge.');
  $('#demoCharger').hidden = !c.demo;
  const sw = $('#demoChargerSw');
  if (document.activeElement !== sw) sw.checked = !!c.demo_charging;
}

/* ---- live data */
let category = 'All';
function renderLive() {
  const L = S.live; if (!L || !META) return;
  setText($('#liveStatus'), `${L.state} · ${L.fresh} fresh of ${L.total} signals`);
  META.live_metrics.forEach(([k]) => { const el = $(`#lm-${k}`); const v = L.metrics[k]; if (el) setText(el, v === '—' ? '--' : v); });
  const q = $('#liveSearch').value.trim().toLowerCase();
  const kw = META.categories[category];
  const rows = L.rows.filter((r) => {
    const hay = `${r[0]} ${r[1]} ${r[2]}`.toLowerCase();
    return (!kw || kw.some((k) => hay.includes(k))) && (!q || hay.includes(q));
  });
  $('#liveEmpty').hidden = rows.length > 0;
  if (!rows.length && L.total) $('#liveEmpty').textContent = 'No signals match this filter.';
  else $('#liveEmpty').innerHTML = 'Press <b>Start live</b> to stream decoded signals, or open a saved capture.';
  setHTML($('#liveBody'), rows.map((r) => `<tr class="${r[6] ? 'stale' : ''}"><td class="id">${esc(r[0])}</td><td>${esc(r[1])}</td><td>${esc(r[2])}</td>`
    + `<td class="r val">${esc(r[3])}</td><td>${esc(r[4])}</td><td class="c"><span class="age">${esc(r[5])}</span></td></tr>`).join(''));
}

/* ---- learn */
let learnSel = -1;
function renderLearn() {
  const L = S.learn; if (!L || !META) return;
  setText($('#learnInstr'), L.instructions);
  setText($('#learnStatus'), L.status);
  setHTML($('#learnPhases'), META.learn_phases.map((name, i) =>
    `<div class="phase ${i < L.phases ? 'done' : i === L.phases && L.active ? 'now' : ''}"><i>${i < L.phases ? '✓' : i + 1}</i>${esc(name)}</div>`).join(''));
  $('#learnRec').disabled = !L.active || L.phases >= 5 || S.busy;
  if (learnSel >= L.candidates.length) learnSel = -1;
  setHTML($('#learnBody'), L.candidates.length ? L.candidates.map((c, i) => `<tr data-i="${i}" class="${i === learnSel ? 'sel' : ''}">`
    + c.map((v, j) => `<td class="${j === 1 ? 'id' : ''}">${esc(v)}</td>`).join('') + '</tr>').join('')
    : `<tr><td colspan="6" class="empty">${L.has_report ? 'No repeatable candidates.' : 'Candidates appear after the fifth capture.'}</td></tr>`);
  $('#learnSave').disabled = learnSel < 0;
}

/* ---- diagnostics */
const HEALTH_TABS = ['Fault signals', 'Stored DTCs', 'Battery', 'Drive inputs', 'Communication', 'Events'];
function renderHealth() {
  const H = S.health; if (!H) return;
  setText($('#healthSummary'), H.summary);
  const tab = tabs.health;
  $('#dtcBar').hidden = tab !== 'Stored DTCs';
  const q = $('#healthSearch').value.trim().toLowerCase();
  const only = $('#healthOnly').checked && tab === 'Fault signals';
  const rows = (H.groups[tab] || []).filter((r) => (!q || `${r[0]} ${r[1]}`.toLowerCase().includes(q)) && (!only || r[3] === 'Asserted'));
  $('#healthEmpty').hidden = rows.length > 0;
  $('#healthEmpty').textContent = tab === 'Stored DTCs' ? 'Read a module above to list its stored fault codes.' : 'Nothing here yet.';
  setHTML($('#healthBody'), rows.map((r) => `<tr class="${esc(r[5])}"><td class="id">${esc(r[0])}</td><td>${esc(r[1])}</td><td class="val">${esc(r[2])}</td><td>${esc(r[3])}</td><td>${esc(r[4])}</td></tr>`).join(''));
}

/* ---- ECU tests: actuator tiles */
const GROUP_STYLE = {
  'Lights & signals': ['orange', 'sun'], 'Switches & sensors': ['teal', 'switchI'], 'Locks & security': ['blue', 'lock'],
  'System & module': ['indigo', 'cpu'], 'Power & HV (danger)': ['red', 'bolt'],
};
function actuatorIcon(name) {
  const n = name.toLowerCase();
  const rules = [
    ['high beam', 'beamHigh'], ['low beam', 'beamLow'], ['drl', 'sun'], ['left indicator', 'arrowL'], ['right indicator', 'arrowR'],
    ['brake light', 'brake'], ['rear light', 'bulb'], ['boot light', 'bulb'], ['horn', 'horn'], ['alarm', 'bell'],
    ['steering lock', 'lock'], ['seat lock', 'box'], ['speaker', 'speaker'], ['usb', 'usb'], ['contactor', 'switchI'],
    ['pilot', 'plug'], ['cpw', 'plug'], ['aux battery', 'battery'], ['ble', 'bt'], ['can trx', 'network'],
    ['status led', 'led'], ['volume up', 'volUp'], ['volume down', 'volDown'], ['power key', 'power'], ['power boot', 'power'],
    ['side stand', 'stand'], ['pad wear', 'brake'], ['brake', 'brake'], ['seat occupant', 'seat'], ['head unit', 'screen'],
    ['hbc', 'handlebar'], ['ssb', 'power'], ['lin', 'network'], ['dc-dc', 'bolt'], ['3v3', 'bolt'], ['3.8v', 'bolt'],
    ['mcu digital', 'cpu'], ['fault reset', 'restart'], ['driver', 'cpu'],
  ];
  const hit = rules.find(([k]) => n.includes(k));
  return hit ? hit[1] : (GROUP_STYLE[META.actuators.find((a) => a.name === name)?.group] || ['', 'chip'])[1];
}
let actGroup = 'Lights & signals';
function buildActuatorChips() {
  const groups = ['All', ...META.actuator_groups];
  $('#actChips').innerHTML = groups.map((g) => `<button data-actgroup="${esc(g)}" class="${g === actGroup ? 'on' : ''}">${esc(g.replace(' (danger)', ''))}</button>`).join('');
}
function buildActuators() {
  const q = $('#actSearch').value.trim().toLowerCase();
  const list = META.actuators.filter((a) => (actGroup === 'All' || a.group === actGroup) && `${a.name} ${a.did}`.toLowerCase().includes(q));
  const byGroup = {};
  list.forEach((a) => { (byGroup[a.group] = byGroup[a.group] || []).push(a); });
  $('#actGrid').innerHTML = META.actuator_groups.filter((g) => byGroup[g]).map((g) => {
    const [color] = GROUP_STYLE[g] || ['indigo'];
    return `<div class="act-group"><h3 class="act-group-title">${esc(g.replace(' (danger)', ''))}${g.includes('danger') ? ' <em class="tag red">Typed confirm</em>' : ''}</h3><div class="act-grid">`
      + byGroup[g].map((a) => `<button class="act-tile glass ${a.danger ? 'danger' : ''}" data-actuator="${esc(a.name)}">`
        + `<span class="tile-icon ${a.danger ? 'red' : color}">${icon(actuatorIcon(a.name))}</span>`
        + `<span class="act-name">${esc(a.name)}</span><span class="act-did">${a.did}${a.danger ? ' · red' : ''}</span></button>`).join('')
      + '</div></div>';
  }).join('') || '<div class="empty pad">No tests match.</div>';
  $('#actCount').textContent = `${list.length} of ${META.actuators.length} tests · VCU`;
}
function actuatorSheet(name) {
  const a = META.actuators.find((x) => x.name === name); if (!a) return;
  const dur = a.name === 'Horn' ? '0.75 s' : '2 s';
  const [color] = GROUP_STYLE[a.group] || ['indigo'];
  const c = S.conn || {};
  const ready = c.connected && c.bench && c.mode === 'SERVICE';
  const sheet = openSheet(`<div class="sheet-icon tile-icon ${a.danger ? 'red' : color}">${icon(actuatorIcon(a.name))}</div>
    <h2>${esc(a.name)}</h2>
    <p class="body">${esc(a.group.replace(' (danger)', ''))} · VCU identifier ${a.did}\n\nSwitches the output ON for ${dur}, then OFF and hands control back to the VCU. `
    + `${a.danger ? 'This one can switch power or move hardware, so you’ll type a word to confirm.' : 'Watch or listen to the scooter to see it respond.'}</p>
    <div class="checklist">
      <span class="${c.connected ? 'ok' : ''}">${icon(c.connected ? 'check' : 'x')}Connected</span>
      <span class="${c.mode === 'SERVICE' ? 'ok' : ''}">${icon(c.mode === 'SERVICE' ? 'check' : 'x')}Service mode</span>
      <span class="${c.bench ? 'ok' : ''}">${icon(c.bench ? 'check' : 'x')}Bench mode</span>
    </div>
    <div class="actions"><button class="btn" data-x="cancel">Close</button>
    <button class="btn ${a.danger ? 'danger solid' : 'primary'}" data-x="run">${a.danger ? 'Pulse output…' : 'Run test'}</button></div>`);
  $('[data-x=cancel]', sheet).onclick = () => closeSheet();
  $('[data-x=run]', sheet).onclick = () => { closeSheet(); act('actuator_test', { name: a.name }); };
  if (!ready) $('[data-x=run]', sheet).title = 'The console will tell you what’s missing';
}
function renderTests() {
  const c = S.conn || {};
  setText($('#modeNow'), c.connected ? c.mode : 'Not connected');
  setText($('#fwNow'), c.connected ? `Firmware ${c.firmware}` : 'Connect to read the mode and firmware');
  if (view !== 'tests' || !S.workshop) return;
  const rows = S.workshop;
  const html = rows.length ? rows.map((r) => `<li><span class="t">${esc(r.time)}</span><b>${esc(r.label)}</b><span class="grow-text">${esc(r.result)}</span></li>`).join('')
    : '<li class="empty">Nothing run yet.</li>';
  setHTML($('#workshopLog'), html);
  setHTML($('#huLog'), html.replace('Nothing run yet.', 'No tests run yet.'));
  const at = S.auto_test;
  const atl = $('#autoTestList');
  if (atl) {
    atl.hidden = !at;
    if (at) atl.innerHTML = at.steps.map((x) => `<li><span class="bullet ${x.ok ? '' : 'red'}"></span><b>${esc(x.step)}</b><span class="grow-text">${esc(x.detail)}</span></li>`).join('');
  }
}
const HU_ICONS = { lcd: ['screen', 'blue'], spkr: ['speaker', 'pink'], mic: ['mic', 'purple'], gps: ['gps', 'green'],
  bt: ['bt', 'blue'], ble: ['bt', 'indigo'], esim: ['network', 'teal'], wifi: ['wifi', 'orange'] };
function buildWorkshop() {
  $('#huGrid').innerHTML = META.hu_tests.map(([k, label, note]) => { const [ic, col] = HU_ICONS[k] || ['chip', 'blue'];
    return `<div class="hu-tile glass"><span class="tile-icon ${col}">${icon(ic)}</span><div class="hu-text"><b>${esc(label)}</b><small>${esc(note)}</small></div>`
      + `<div class="hu-actions"><button class="btn small primary" data-act="hu_test" data-args='{"key":"${k}","action":"start"}'>Start</button>`
      + `<button class="btn small" data-act="hu_test" data-args='{"key":"${k}","action":"stop"}'>Stop</button></div></div>`; }).join('')
    + `<div class="hu-tile glass"><span class="tile-icon indigo">${icon('tag')}</span><div class="hu-text"><b>Vehicle number (VIN)</b><small>Reads the VIN stored in the head unit.</small></div>`
    + `<div class="hu-actions"><button class="btn small primary" data-act="hu_test" data-args='{"key":"vin"}'>Read</button></div></div>`;
  $('#routineList').innerHTML = META.routines.map(([k, ecu, rid, label, desc]) => `<div class="routine glass">
      <span class="tile-icon ${k === 'tune' ? 'green' : k === 'bal' ? 'orange' : 'indigo'}">${icon(k === 'tune' ? 'dial' : k === 'bal' ? 'battery' : 'stetho')}</span>
      <div class="grow"><b>${esc(label)}</b><small>${esc(ecu)} · routine ${esc(rid)} · ${esc(desc)}</small></div>
      <button class="btn small ${k === 'tune' ? '' : 'danger'}" data-act="routine" data-args='{"key":"${k}"}'>${k === 'tune' ? 'Read' : 'Run…'}</button></div>`).join('');
  $('#resetGrid').innerHTML = META.ecus.map((e) => `<div class="reset-tile"><span class="tile-icon ${e === 'BMS' ? 'green' : e === 'VCU' ? 'blue' : 'purple'}">${icon(e === 'BMS' ? 'battery' : e === 'VCU' ? 'cpu' : 'dial')}</span>`
    + `<b>${e}</b><small>${e === 'BMS' ? 'Battery' : e === 'VCU' ? 'Vehicle controller' : 'Motor controller'}</small>`
    + `<div class="row tight"><button class="btn small danger" data-act="ecu_reset" data-args='{"ecu":"${e}","kind":"soft"}'>Soft restart…</button>`
    + `<button class="btn small plain" data-act="ecu_reset" data-args='{"ecu":"${e}","kind":"hard"}'>Hard…</button></div></div>`).join('');
}

/* ---- battery: graph + settings */
const graphOn = {};
const GRAPH_COLORS = ['#34c759','#0a84ff','#ff9f0a','#bf5af2','#ff375f','#40c8e0'];
function renderBattery() {
  const sigs = (S.graph_signals || []);
  if (sigs.length && !$('#graphChips').childElementCount) {
    sigs.forEach(([k], i) => { if (graphOn[k] === undefined) graphOn[k] = i < 4; });
    $('#graphChips').innerHTML = sigs.map(([k, lbl], i) => `<button data-graph="${k}" class="${graphOn[k] ? 'on' : ''}" style="--gc:${GRAPH_COLORS[i % 6]}"><i class="gdot"></i>${esc(lbl)}</button>`).join('');
  }
  drawGraph();
  renderBmsSettings();
  renderCells();
}
function renderCells() {
  const C = S.cells; const grid = $('#cellsGrid'); if (!grid) return;
  if (!C || !C.cells || !C.cells.length) { return; }
  const avg = C.avg_mv || 0;
  setText($('#cellsSummary'), `${C.count} cells · spread ${C.spread_mv} mV · weakest #${C.weak_cell}${C.total_ah ? ' · ~' + C.total_ah + ' Ah' : ''}`);
  $('#cellsLegend').hidden = false;
  const irMed = C.ir_median || 0;
  // Build once per data change (setHTML skips identical markup) so the fill animates
  // a single time and nothing restarts on every poll.
  const dcirAll = (S.conn || {}).cell_dcir || [];
  const html = C.cells.map((c) => {
    const dev = c.mv - avg;
    const dcir = dcirAll[c.cell - 1];
    const irBad = irMed && c.ir && c.ir > irMed * 1.4;
    const cls = (dev < -30 || irBad) ? 'bad' : (dev < -15 || (c.temp && c.temp > 45)) ? 'warn' : 'ok';
    const fill = Math.max(5, Math.min(100, c.pct));
    const stat = (v, u) => v != null ? `${v}<i>${u}</i>` : '—';
    return `<div class="cell-battery ${cls} ${c.cell === C.weak_cell ? 'weak' : ''}" style="--fill:${fill}%" title="Cell ${c.cell}: ${c.mv} mV, ${c.pct}%${c.ir != null ? ', IR ' + c.ir + ' mΩ' : ''}${dcir != null ? ', live DCIR ' + dcir + ' mΩ' : ''}${c.ah != null ? ', ' + c.ah + ' Ah' : ''}${c.temp != null ? ', ' + c.temp + '°C' : ''}">
      <div class="cb-head">#${c.cell}</div>
      <div class="cb-body"><div class="cb-liquid"><span class="cb-surface"></span></div><div class="cb-glare"></div><span class="cb-pct">${Math.round(c.pct)}<small>%</small></span></div>
      <div class="cb-volt">${(c.mv/1000).toFixed(3)}<small>V</small></div>
      <div class="cb-stats">${stat(c.ir, 'mΩ')}<i class="dot"></i>${stat(c.ah, 'Ah')}<i class="dot"></i>${stat(c.temp, '°')}</div>
    </div>`;
  }).join('');
  setHTML(grid, html);
}
function drawChart(cv, series, order, labels, units) {
  if (!cv) return;
  const dpr = window.devicePixelRatio || 1;
  const w = cv.clientWidth, h = cv.clientHeight;
  if (cv.width !== w * dpr) { cv.width = w * dpr; cv.height = h * dpr; }
  const ctx = cv.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
  const pad = { l: 40, r: 12, t: 10, b: 20 };
  const active = order.filter((k) => (series[k] || []).length);
  let tMax = 0, tMin = Infinity;
  active.forEach((k) => (series[k] || []).forEach((p) => { tMax = Math.max(tMax, p[0]); tMin = Math.min(tMin, p[0]); }));
  const style = getComputedStyle(document.body); const grid = style.getPropertyValue('--sep') || '#ccc'; const txt = style.getPropertyValue('--text-2') || '#888';
  if (!active.length || tMax <= tMin) { ctx.fillStyle = 'rgba(128,128,128,.6)'; ctx.font = '13px system-ui'; ctx.fillText('No data to plot yet.', pad.l, h / 2); return { tMin: 0, tMax: 0, active: [] }; }
  ctx.lineWidth = 1; ctx.strokeStyle = grid;
  for (let i = 0; i <= 4; i++) { const y = pad.t + (h - pad.t - pad.b) * i / 4; ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke(); }
  const X = (t) => pad.l + (w - pad.l - pad.r) * (t - tMin) / Math.max(1, tMax - tMin);
  active.forEach((k, ai) => {
    const data = series[k]; let lo = Infinity, hi = -Infinity; data.forEach((p) => { lo = Math.min(lo, p[1]); hi = Math.max(hi, p[1]); });
    const rng = hi - lo || 1; const Y = (v) => pad.t + (h - pad.t - pad.b) * (1 - (v - lo) / rng);
    ctx.strokeStyle = GRAPH_COLORS[ai % 6]; ctx.lineWidth = 2; ctx.beginPath();
    data.forEach((p, j) => { const x = X(p[0]), y = Y(p[1]); j ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); ctx.stroke();
  });
  ctx.fillStyle = txt; ctx.font = '11px system-ui'; ctx.fillText(`${Math.round(tMin)}s`, pad.l, h - 6); ctx.fillText(`${Math.round(tMax)}s`, w - pad.r - 24, h - 6);
  return { tMin, tMax, active };
}
function drawGraph() {
  const cv = $('#graphCanvas'); if (!cv || !S.graph) return;
  const sigs = S.graph_signals || [];
  const dpr = window.devicePixelRatio || 1;
  const w = cv.clientWidth, h = cv.clientHeight;
  if (cv.width !== w * dpr) { cv.width = w * dpr; cv.height = h * dpr; }
  const ctx = cv.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
  const pad = { l: 38, r: 12, t: 10, b: 20 };
  const active = sigs.filter(([k]) => graphOn[k] && (S.graph[k] || []).length);
  let tMax = 0, tMin = Infinity;
  active.forEach(([k]) => (S.graph[k] || []).forEach((p) => { tMax = Math.max(tMax, p[0]); tMin = Math.min(tMin, p[0]); }));
  if (!active.length || tMax === 0) { ctx.fillStyle = 'rgba(128,128,128,.6)'; ctx.font = '13px system-ui'; ctx.fillText('Start the monitor to record — no data yet.', pad.l, h / 2); $('#graphWindow').textContent = ''; return; }
  const style = getComputedStyle(document.body); const grid = style.getPropertyValue('--sep') || '#ccc'; const txt = style.getPropertyValue('--text-2') || '#888';
  const order = sigs.filter(([k]) => graphOn[k]).map(([k]) => k);
  const r = drawChart(cv, S.graph, order, {}, {});
  $('#graphWindow').textContent = r.active.length ? `${Math.round(r.tMax - r.tMin)}s window` : '';
  $('#graphLegend').innerHTML = r.active.map((k, ai) => { const m = sigs.find(([kk]) => kk === k); const d = S.graph[k]; const last = d[d.length - 1]; return `<span><i style="background:${GRAPH_COLORS[ai % 6]}"></i>${esc(m ? m[1] : k)}: <b>${last ? last[1] : '--'}</b> ${esc(m ? m[2] : '')}</span>`; }).join('');
}

/* ---- recorder */
let recPick = {};
function renderRecorder() {
  const rec = S.recorder || {}; const active = rec.active;
  const btn = $('#sessionRecBtn'); if (btn) btn.closest('.record-session').classList.toggle('recording', !!active);
  setText($('#recSessionTitle'), active ? `Recording… ${rec.elapsed || 0}s` : 'Record a session');
  setText($('#recSessionSub'), active ? `${rec.samples || 0} samples · ${rec.signals || 0} signals → ${(rec.path || '').split(/[\/]/).pop()}`
    : 'Captures all broadcast signals each second to a timestamped file. Needs a connection; the monitor starts automatically.');
  const sum = S.recording_summary;
  $('#recOpenEmpty').hidden = !!sum;
  $('#recSummary').hidden = !sum;
  if (sum) {
    $('#recSummaryHl').innerHTML = [['File', sum.name], ['Duration', sum.duration + ' s'], ['Samples', sum.samples], ['Signals', sum.signals.length]]
      .map(([k, v]) => `<div class="hl glass"><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join('');
    const q = $('#recSigSearch').value.trim().toLowerCase();
    const rows = sum.signals.filter((s) => !q || s.name.toLowerCase().includes(q));
    $('#recSigBody').innerHTML = rows.slice(0, 300).map((s) => `<tr><td><input type="checkbox" class="recpick" data-sig="${esc(s.name)}" ${recPick[s.name] ? 'checked' : ''}></td>`
      + `<td>${esc(s.name)}</td><td class="r val">${esc(s.min)}</td><td class="r val">${esc(s.max)}</td><td class="r val">${esc(s.last)}</td><td class="r">${esc(s.count)}</td></tr>`).join('');
    drawRecording();
  }
}
function drawRecording() {
  const ser = S.rec_series || {};
  const order = Object.keys(recPick).filter((k) => recPick[k]);
  const r = drawChart($('#recCanvas'), ser, order, {}, {});
  $('#recLegend').innerHTML = r.active.map((k, ai) => { const d = ser[k]; const last = d[d.length - 1]; return `<span><i style="background:${GRAPH_COLORS[ai % 6]}"></i>${esc(k)}: <b>${last ? last[1] : '--'}</b></span>`; }).join('');
}
function renderBmsSettings() {
  const cfg = S.bms_config, fnd = S.bms_findings;
  $('#bmsFindings').hidden = !fnd;
  if (fnd) $('#bmsFindingsList').innerHTML = fnd.map((f) => `<li class="finding ${esc(f.tone)}"><span class="tile-icon ${{danger:'red',warn:'orange',ok:'green',info:'blue'}[f.tone]}">${icon({danger:'warn',warn:'warn',ok:'check',info:'info'}[f.tone])}</span><span>${esc(f.text)}</span></li>`).join('');
  $('#bmsEmpty').hidden = !!cfg;
  if (!cfg) { $('#bmsBody').innerHTML = ''; return; }
  const q = $('#bmsSearch').value.trim().toLowerCase();
  const devOnly = $('#bmsDevOnly').checked;
  const rows = cfg.filter((r) => (!q || `${r.title} ${r.did}`.toLowerCase().includes(q)) && (!devOnly || r.deviates));
  $('#bmsBody').innerHTML = rows.map((r) => {
    const cur = r.error ? `<span class="muted">${esc(r.error)}</span>` : `<code>${esc(r.hex || '')}</code>`;
    const stock = r.stock ? (r.deviates ? `<span class="tag red">was ${esc(r.stock)}</span>` : `<span class="tag green">stock</span>`) : '';
    const wbtn = r.stock && r.deviates ? `<button class="btn small danger" data-bmswrite="${esc(r.did)}" data-stock="${esc(r.stock)}">Restore…</button>` : '';
    return `<tr class="${r.deviates ? 'asserted' : ''}"><td>${esc(r.name || r.title)}</td><td class="sub-t">${esc(r.did)}</td><td class="r val">${cur}</td><td>${stock}</td><td>${wbtn}</td></tr>`;
  }).join('') || '<tr><td colspan="5" class="empty">No settings match.</td></tr>';
}

/* ---- firmware & config */
function renderFirmware() {
  const F = S.firmware, cfg = S.vcu_config;
  $('#fwEmpty').hidden = !!(F || cfg);
  if (F) {
    const fnd = F.findings || [];
    $('#fwFindings').hidden = !fnd.length;
    $('#fwFindingsList').innerHTML = fnd.map((f) => `<li class="finding ${esc(f.tone)}"><span class="tile-icon ${{danger:'red',warn:'orange',ok:'green',info:'blue'}[f.tone]}">${icon({danger:'warn',warn:'warn',ok:'check',info:'info'}[f.tone])}</span><span>${esc(f.text)}</span></li>`).join('');
    const hw = (S.conn || {}).hardware || {};
    const hwCard = Object.keys(hw).length
      ? `<div class="card glass"><div class="card-head"><h3>Hardware variants</h3></div>`
        + `<table class="table plain-table"><tbody>`
        + Object.entries(hw).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="r val"><b>${esc(v)}</b></td></tr>`).join('')
        + `</tbody></table><div class="sub-t" style="padding:8px 12px">Per-controller generation — firmware must match these.</div></div>`
      : '';
    const som = S.som_config || {};
    const somCmds = som.CommandList || [];
    const somCard = somCmds.length
      ? `<div class="card glass"><div class="card-head"><h3>Manufacturing config (reference)</h3></div>`
        + `<table class="table plain-table"><tbody>`
        + somCmds.map((c) => `<tr><td>${esc(c.name)}${/jtag/i.test(c.name) ? ' 🔒' : ''}</td><td class="r val">0x${(c.did >>> 0).toString(16).toUpperCase().padStart(4, '0')}</td><td class="sub-t">${esc((c.data || []).join(' '))} · ${esc(c.ecu_type || '')}</td></tr>`).join('')
        + `</tbody></table><div class="sub-t" style="padding:8px 12px">Factory ECU-writes from the production app. JTAG toggles debug ports — reference only; OpenOLA does not send them.</div></div>`
      : '';
    $('#fwVersions').innerHTML = hwCard + Object.entries(F.versions).map(([ecu, rows]) => `<div class="card glass"><div class="card-head"><h3>${esc(ecu)}</h3></div>`
      + `<table class="table plain-table"><tbody>` + rows.map((r) => `<tr><td>${esc(r.label)}</td><td class="r val">${r.error ? `<span class="muted">${esc(r.error)}</span>` : `<b>${esc(r.value)}</b>`}</td><td class="sub-t">${esc(r.did)}</td></tr>`).join('') + '</tbody></table></div>').join('') + somCard;
    $('#fwRules').hidden = false;
    $('#fwRulesList').innerHTML = (F.rules || []).map((r) => `<li>${esc(r)}</li>`).join('');
  }
  if (cfg) {
    $('#variantCard').hidden = false;
    setText($('#variantTag'), cfg.variant || '—');
    $('#variantFeatures').innerHTML = (cfg.features || []).map((f) => `<span class="feat ${f.on ? 'on' : ''}">${esc(f.name)}</span>`).join('') || '<span class="empty">No feature flags read.</span>';
    const th = (cfg.thresholds || []).filter((t) => !t.error);
    $('#threshCard').hidden = !th.length;
    $('#threshBody').innerHTML = th.map((t) => `<tr><td>${esc(t.label)}</td><td class="r val">${esc(t.value)}</td><td class="sub-t">${esc(t.did)}</td></tr>`).join('');
  }
}

/* ---- health report */
let reportKind = 'quick';
function reportEcus() { return $$('#reportEcus button.on').map((b) => b.dataset.ecuPick); }
function updateReportHint() {
  if (!META) return;
  const n = reportKind === 'quick' ? META.report_counts.quick : META.report_counts.full;
  $('#reportHint').textContent = `${reportKind === 'quick' ? 'Health, cells, identity and live values' : 'Everything, including ~150 BMS configuration limits'}`
    + ` · up to ${n} identifiers. Plain reads: no unlock, no changes. Needs Bench mode (charger unplugged).`;
}
function renderReportProgress() {
  const p = S.report_progress;
  const running = !!p;
  $('#reportRing').hidden = !running;
  $('#reportCancel').hidden = !running;
  $('#reportRun').hidden = running;
  $('#reportStatus').hidden = !running;
  if (running) {
    const pct = p.total ? Math.round(100 * p.done / p.total) : 0;
    $('#reportRingFill').style.strokeDashoffset = 119.4 * (1 - pct / 100);
    setText($('#reportPct'), pct + '%');
    setText($('#reportStatus'), `${p.done} of ${p.total} · ${p.label}`);
  }
}
function fmtVal(v) {
  if (v.value === null || v.value === undefined) return `<span class="muted">${esc(v.note || '—')}</span>`;
  return `<b>${esc(v.value)}</b>${v.unit ? ` <span class="unit">${esc(v.unit)}</span>` : ''}`;
}
function buildReport() {
  const R = REPORT && REPORT.data; if (!R) return;
  $('#reportEmpty').hidden = true; $('#reportBody').hidden = false;
  const ok = R.items.filter((r) => !r.error).length;
  $('#reportMeta').textContent = `${R.time} · ${R.quick ? 'Quick check' : 'Full read-out'} · ${ok} of ${R.items.length} read in ${R.duration_s} s${R.vehicle && R.vehicle.demo ? ' · demo scooter' : ''}${R.cancelled ? ' · cancelled' : ''}`;
  const s = R.summary;
  $('#reportHighlights').innerHTML = s.highlights.map((h) => `<div class="hl glass"><span>${esc(h.label)}</span><b>${esc(h.value)}</b></div>`).join('');
  $('#reportFindings').innerHTML = s.findings.map((f) => `<li class="finding ${esc(f.tone)}"><span class="tile-icon ${{ danger: 'red', warn: 'orange', ok: 'green', info: 'blue' }[f.tone]}">${icon({ danger: 'warn', warn: 'warn', ok: 'check', info: 'info' }[f.tone])}</span><span>${esc(f.text)}</span></li>`).join('')
    || '<li class="empty">No findings.</li>';
  const cells = s.cells;
  $('#cellCard').hidden = !cells;
  if (cells) {
    $('#cellMeta').textContent = `avg ${cells.avg_mv} mV · spread ${cells.spread_mv} mV`;
    const maxDev = Math.max(20, ...cells.cells.map((c) => Math.abs(c.dev)));
    $('#cellChart').innerHTML = cells.cells.map((c) => {
      const cls = Math.abs(c.dev) > 30 ? 'bad' : Math.abs(c.dev) > 15 ? 'warn' : 'ok';
      const h = 8 + 82 * (Math.abs(c.dev) / maxDev);
      return `<div class="cell ${cls}" title="Cell ${c.cell}: ${c.mv} mV (${c.dev > 0 ? '+' : ''}${c.dev} mV)${c.ir !== undefined ? ` · IR ${c.ir}` : ''}${c.ah !== undefined ? ` · ${c.ah} Ah` : ''}">`
        + `<div class="cell-bar-wrap"><div class="cell-bar ${c.dev < 0 ? 'neg' : 'pos'}" style="height:${h / 2}%"></div></div>`
        + `<b>${Math.round(c.mv)}</b><small>#${c.cell}</small></div>`;
    }).join('');
  }
  renderReportGroups();
}
function renderReportGroups() {
  const R = REPORT && REPORT.data; if (!R) return;
  const q = $('#reportSearch').value.trim().toLowerCase();
  const groups = META ? META.report_groups : [];
  $('#reportGroups').innerHTML = groups.map((g) => {
    const items = R.items.filter((r) => r.group === g && (!q || `${r.title} ${r.did} ${r.ecu} ${(r.values || []).map((v) => v.name + ' ' + v.value).join(' ')}`.toLowerCase().includes(q)));
    if (!items.length) return '';
    const open = q || ['Battery health', 'Identity & versions', 'Motor & controller'].includes(g);
    return `<details class="card glass rgroup" ${open ? 'open' : ''}><summary><span><b>${esc(g)}</b><small>${items.length} item${items.length > 1 ? 's' : ''}</small></span>${icon('chev-down')}</summary>`
      + items.map((r) => `<div class="ritem"><div class="ritem-head"><b>${esc(r.title)}</b><span class="sub-t">${esc(r.ecu)} · ${esc(r.did)}</span></div>`
        + (r.error ? `<div class="muted small">${esc(r.error)}</div>`
          : `<div class="rvals">${(r.values || []).map((v) => `<div class="rval"><span>${esc(v.name)}</span>${fmtVal(v)}</div>`).join('')}</div>`)
        + '</div>').join('') + '</details>';
  }).join('');
}

/* ---- components */
let ecu = 'MCU';
function settingNote(name) {
  const d = META.settings[name];
  return `MCU · ${d.request} · Extracted definition, not bench-validated. `
    + (name.includes('Limp') ? 'Limp-home percentage only; this is not the road-speed limit.'
      : 'Regen current limits are percentages, not kW.');
}
function renderSetting() {
  if (!META) return;
  const name = $('#settingSel').value;
  const d = META.settings[name]; if (!d) return;
  const cur = S.setting && S.setting.name === name ? S.setting : null;
  setText($('#settingNote'), settingNote(name));
  setHTML($('#settingBody'), d.params.map((p) => `<tr><td>${esc(p.name)}</td><td class="r val">${esc(cur ? cur.values[p.name] ?? '—' : '—')}</td>`
    + `<td>${esc(p.unit)}</td><td>${esc(p.min)} – ${esc(p.max)}</td></tr>`).join(''));
  setText($('#settingRaw'), cur ? `Current MCU bytes: ${cur.raw}. Performance editing stays disabled.`
    : 'Not read yet. Source ranges aren’t verified vehicle operating limits.');
}
let catalog = null, catSel = null;
async function loadCatalog() {
  if (catalog) return;
  try { catalog = await http('GET', '/api/catalog'); } catch (_) { catalog = null; return; }
  renderCatalog();
}
function renderCatalog() {
  if (!catalog) return;
  const q = $('#catSearch').value.trim().toLowerCase();
  const rows = catalog.filter((r) => !q || `${r[1]} ${r[2]} ${r[3]}`.toLowerCase().includes(q));
  const shown = rows.slice(0, 400);
  $('#catList').innerHTML = shown.map((r) => `<li data-i="${r[0]}" class="${r[0] === catSel ? 'sel' : ''}"><span class="sub-t">${esc(r[1])}</span>`
    + `<span class="name">${esc(r[3])}</span><span class="sub-t">${esc(r[2])}</span></li>`).join('') || '<li class="empty">No matches.</li>';
  $('#catCount').textContent = `${rows.length} of ${catalog.length} entries` + (rows.length > shown.length ? ` · showing first ${shown.length}` : '');
}

/* ---- bluetooth */
function renderBle() {
  const B = S.ble; if (!B) return;
  setHTML($('#bleList'), B.rows.length ? B.rows.map(([n, mac, rssi]) => `<li data-mac="${esc(mac)}" class="${mac === B.mac ? 'sel' : ''}">`
    + `<span class="risk ${rssi > -70 ? 'safe' : rssi > -85 ? 'caution' : 'danger'}"></span><span class="name">${esc(n || '(unnamed)')}</span>`
    + `<span class="sub-t">${esc(mac)} · ${esc(rssi)} dBm</span></li>`).join('')
    : '<li class="empty">Scan to find nearby devices. Close the Ola app and turn off your phone’s Bluetooth so this PC can hold the link.</li>');
  const mac = $('#bleMac');
  if (document.activeElement !== mac && mac.value !== B.mac) mac.value = B.mac;
}

/* ------------------------------------------------------------------ capture: screenshot + screen recording */
const rec = { active: false, started: 0, recorder: null, chunks: [], stream: null };
function shutterFlash() {
  const f = document.createElement('div'); f.className = 'shutter'; document.body.appendChild(f);
  setTimeout(() => f.remove(), 700);
}
async function takeScreenshot() {
  closeMenu();
  // Let menus / the island clear before the window is captured.
  const prev = island.toastUntil; island.toastUntil = 0; $('#island').className = 'island';
  await new Promise((r) => setTimeout(r, 220));
  let r;
  try { r = await http('POST', '/api/screenshot', {}); } catch (_) { r = { fallback: true }; }
  island.toastUntil = prev;
  if (r && r.path) {
    shutterFlash();
    toast(r.copied ? 'Screenshot saved and copied' : 'Screenshot saved', 'ok');
    return;
  }
  // Fallback (non-Windows, or Windows refused): capture this tab through the browser.
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false, preferCurrentTab: true, selfBrowserSurface: 'include' });
    const video = document.createElement('video'); video.srcObject = stream; video.muted = true; await video.play();
    await new Promise((res) => setTimeout(res, 150));
    const canvas = document.createElement('canvas'); canvas.width = video.videoWidth; canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    stream.getTracks().forEach((t) => t.stop());
    const blob = await new Promise((res) => canvas.toBlob(res, 'image/png'));
    shutterFlash();
    try { await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]); } catch (_) { /* clipboard optional */ }
    await fetch(`/api/upload_recording?ext=png`, { method: 'POST', headers: { 'X-Token': TOKEN }, body: blob });
    toast('Screenshot saved', 'ok');
  } catch (e) {
    toast(r && r.error ? r.error : 'Screenshot cancelled', 'info');
  }
}
async function startRecording() {
  closeMenu();
  if (rec.active) return;
  let stream;
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: 30 }, audio: false, preferCurrentTab: true, selfBrowserSurface: 'include', surfaceSwitching: 'exclude',
    });
  } catch (_) { toast('Recording cancelled', 'info'); return; }
  const type = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'].find((t) => window.MediaRecorder && MediaRecorder.isTypeSupported(t));
  const recorder = new MediaRecorder(stream, type ? { mimeType: type, videoBitsPerSecond: 6_000_000 } : undefined);
  Object.assign(rec, { active: true, started: Date.now(), recorder, chunks: [], stream });
  recorder.ondataavailable = (e) => { if (e.data && e.data.size) rec.chunks.push(e.data); };
  recorder.onstop = async () => {
    stream.getTracks().forEach((t) => t.stop());
    rec.active = false;
    const blob = new Blob(rec.chunks, { type: 'video/webm' });
    toast('Saving recording…', 'info');
    try {
      const res = await fetch('/api/upload_recording', { method: 'POST', headers: { 'X-Token': TOKEN }, body: blob });
      const j = await res.json();
      toast(j.path ? 'Recording saved' : 'Could not save the recording', j.path ? 'ok' : 'danger');
    } catch (_) { toast('Could not save the recording', 'danger'); }
  };
  stream.getVideoTracks()[0].addEventListener('ended', () => { if (recorder.state !== 'inactive') recorder.stop(); });
  recorder.start(1000);
  renderIsland();
}
function stopRecording() { if (rec.active && rec.recorder && rec.recorder.state !== 'inactive') rec.recorder.stop(); }
function captureMenu() {
  const btn = $('#captureBtn');
  if (openMenu && openMenu.anchor === btn) return closeMenu();
  showMenu(btn, [
    { label: 'Take screenshot', hint: 'Ctrl+Shift+4 · saved and copied', value: 'shot', icon: 'camera' },
    rec.active ? { label: 'Stop recording', hint: 'Ctrl+Shift+5', value: 'stop', icon: 'stop', danger: true }
      : { label: 'Record screen', hint: 'Ctrl+Shift+5 · saves a .webm video', value: 'rec', icon: 'video' },
    { sep: true },
    { label: 'Open screenshots folder', value: 'open-shots', icon: 'folder' },
    { label: 'Open recordings folder', value: 'open-recs', icon: 'folder' },
  ], (v) => {
    if (v === 'shot') takeScreenshot();
    if (v === 'rec') startRecording();
    if (v === 'stop') stopRecording();
    if (v === 'open-shots') http('POST', '/api/open_captures', {});
    if (v === 'open-recs') http('POST', '/api/open_captures?recording=1', {});
  }, { align: 'right', minWidth: 260 });
}

/* ------------------------------------------------------------------ build from meta */
function buildFromMeta() {
  // charging cells
  $('#chargeCells').innerHTML = META.charge_cells.map(([k, cap, unit]) =>
    `<div class="metric"><span>${esc(cap)}</span><b><span data-b="sv.${k}">—</span>${unit ? `<small>${esc(unit)}</small>` : ''}</b></div>`).join('');
  // live metrics
  $('#liveMetrics').innerHTML = META.live_metrics.map(([k, label]) => `<div class="metric"><span>${esc(label)}</span><b id="lm-${k}">--</b></div>`).join('');
  $('#catChips').innerHTML = Object.keys(META.categories).map((c) => `<button data-cat="${esc(c)}" class="${c === category ? 'on' : ''}">${esc(c)}</button>`).join('');
  // learn label: Apple combo instead of a datalist
  enhanceCombo($('#learnLabel'), META.learn_labels);
  // health tabs + DTC buttons
  $('#healthTabs').innerHTML = HEALTH_TABS.map((t) => `<button data-tab="${esc(t)}" class="${t === tabs.health ? 'on' : ''}">${esc(t)}</button>`).join('');
  $('#dtcBar').insertAdjacentHTML('beforeend', META.ecus.map((e) => `<button class="btn small" data-act="read_dtc" data-args='{"ecu":"${e}"}'>Read ${e}</button>`).join('')
    + `<button class="btn small danger" id="clearDtcBtn">${icon('x')}Clear codes…</button>`);
  // actuators
  buildActuatorChips();
  buildActuators();
  buildWorkshop();
  // HMI
  $('#hmiIntro').textContent = `${META.hmi_count} ` + $('#hmiIntro').textContent;
  $('#hmiGroups').innerHTML = META.hmi.map((g) => `<div class="card glass hmi-group"><h3>${esc(g.title)}</h3><div class="hmi-grid">`
    + g.rows.map(([o, label, tier]) => `<button class="hmi-btn ${tier === 'danger' ? 'danger' : ''}" data-hmi="${o}"><span class="risk ${tier}"></span>${esc(label)}<span class="o">${o}</span></button>`).join('')
    + '</div></div>').join('');
  // components
  $('#ecuSeg').innerHTML = META.ecus.map((e) => `<button data-ecu="${e}" class="${e === ecu ? 'on' : ''}">${e}</button>`).join('');
  $('#settingSel').innerHTML = Object.keys(META.settings).map((n) => `<option>${esc(n)}</option>`).join('');
  // calibration feature toggles
  $('#featToggles').innerHTML = META.feature_toggles.map(([n, en, dis]) => `<span>${esc(n)}</span><div class="row tight">`
    + `<button class="btn small" data-act="feature_toggle" data-args='{"ordinal":${en}}'>Enable</button>`
    + `<button class="btn small plain" data-act="feature_toggle" data-args='{"ordinal":${dis}}'>Disable</button></div>`).join('')
    + `<span>Regen type</span><div class="row tight">` + META.regen_types.map(([l, o]) =>
      `<button class="btn small" data-act="feature_toggle" data-args='{"ordinal":${o}}'>${esc(l)}</button>`).join('') + '</div>';
  // software
  const rpcIcons = { GetSwVersion: ['chip', 'blue'], GetAospVersion: ['sparkle', 'green'], GetVehicleIdentifiers: ['tag', 'indigo'], SwUpdateCheckStatus: ['download', 'orange'] };
  $('#rpcGrid').innerHTML = META.update_rpcs.map(([label, m]) => { const [ic, col] = rpcIcons[m] || ['info', 'blue'];
    return `<button class="quick glass" data-act="rpc" data-args='{"method":"${m}"}'><span class="tile-icon ${col}">${icon(ic)}</span><span><b>${esc(label)}</b></span></button>`; }).join('');
  // bluetooth
  $('#bleOff').hidden = META.ble_available; $('#bleOn').hidden = !META.ble_available;
  // every native <select> → Apple pop-up button
  $$('select').forEach(enhanceSelect);
  renderSetting();
  updateReportHint();
}

/* ------------------------------------------------------------------ tour */
const TOUR_KEY = 'scooterConsole.tour.v1';
const TOUR = [
  { icon: 'bolt', color: 'blue', title: 'Your scooter, your data', text: 'This console reads health, battery and fault data directly from your Ola S1. It’s the same information a service centre sees, on your own computer.' },
  { icon: 'sparkle', color: 'purple', title: 'No scooter nearby?', text: 'Press “Try demo” at the top to explore everything with a simulated scooter. Nothing is sent to a real vehicle.' },
  { icon: 'wifi', color: 'teal', title: 'Connect over Wi‑Fi', text: 'Join the scooter’s Wi‑Fi on this PC, then press Connect at the top right. The address and port live under the connection pill.' },
  { icon: 'doc', color: 'green', title: 'Get a health report', text: 'Health Report reads every value the factory diagnostic app knows (cell voltages, temperatures, charge cycles, serial numbers) and flags weak cells. You can share it with a mechanic.' },
  { icon: 'shield', color: 'orange', title: 'Safe by design', text: 'Anything that sends a command, such as tests, calibration or writes, stays locked until you turn on Bench mode, and it always asks first. Red actions need you to type a word.' },
  { icon: 'camera', color: 'indigo', title: 'You’re all set', text: 'Use the camera button (or Ctrl+Shift+4 / Ctrl+Shift+5) for screenshots and screen recordings. Switch light/dark at the bottom of the sidebar, and reopen this tour with the ? button.' },
];
let tourAt = 0;
function showTour(i = 0, back = false) {
  tourAt = i;
  const t = TOUR[i], last = i === TOUR.length - 1;
  $('#tour').hidden = false;
  $('#tourCard').innerHTML = `<div class="tour-step ${back ? 'back' : ''}"><div class="tour-art tile-icon ${t.color}">${icon(t.icon)}</div>
    <h2>${esc(t.title)}</h2><p>${esc(t.text)}</p></div>
    <div class="tour-dots">${TOUR.map((_, j) => `<i class="${j === i ? 'on' : ''}"></i>`).join('')}</div>
    <label class="tour-dontshow"><span class="switch small"><input type="checkbox" id="tourDontShow" checked><span></span></span>Don’t show this again</label>
    <div class="tour-actions"><button class="btn plain" data-t="skip">${last ? '' : 'Skip'}</button>
    <div class="row tight">${i ? '<button class="btn" data-t="back">Back</button>' : ''}<button class="btn primary" data-t="next">${last ? 'Get started' : 'Continue'}</button></div></div></div>`;
  $('[data-t=skip]').style.visibility = last ? 'hidden' : 'visible';
  $('[data-t=next]').focus();
}
function endTour() {
  $('#tour').hidden = true;
  const dontShow = !$('#tourDontShow') || $('#tourDontShow').checked;   // default: remember
  try { if (dontShow) localStorage.setItem(TOUR_KEY, '1'); else localStorage.removeItem(TOUR_KEY); } catch (_) { /* ignore */ }
}

/* ------------------------------------------------------------------ wiring */
function wire() {
  document.addEventListener('click', async (e) => {
    if (e.target.closest('#recStop')) return stopRecording();
    const t = e.target.closest('button, li[data-i], li[data-mac], tr[data-i]');
    if (!t || t.closest('.menu')) return;
    if (t.matches('[data-view]')) return go(t.dataset.view);
    if (t.matches('[data-go]')) return go(t.dataset.go, t.dataset.tabGo);
    if (t.matches('[data-act]')) return act(t.dataset.act, t.dataset.args ? JSON.parse(t.dataset.args) : {});
    if (t.matches('[data-theme-set]')) return applyTheme(t.dataset.themeSet);
    if (t.matches('[data-tabs] button')) return setTab(t.closest('[data-tabs]').dataset.tabs, t.dataset.tab);
    if (t.matches('[data-cat]')) { category = t.dataset.cat; $$('#catChips button').forEach((b) => b.classList.toggle('on', b === t)); return renderLive(); }
    if (t.matches('[data-actgroup]')) { actGroup = t.dataset.actgroup; buildActuatorChips(); return buildActuators(); }
    if (t.matches('[data-actuator]')) return actuatorSheet(t.dataset.actuator);
    if (t.matches('[data-hmi]')) return act('hmi_send', { ordinal: +t.dataset.hmi, ready: $('#hmiReady').checked });
    if (t.matches('[data-ble]')) return act('ble_cmd', { cmd: t.dataset.ble, mac: $('#bleMac').value });
    if (t.matches('[data-ecu]')) { ecu = t.dataset.ecu; $$('#ecuSeg button').forEach((b) => b.classList.toggle('on', b === t)); return; }
    if (t.matches('[data-kind]')) { reportKind = t.dataset.kind; $$('#reportKind button').forEach((b) => b.classList.toggle('on', b === t)); return updateReportHint(); }
    if (t.matches('[data-ecu-pick]')) { t.classList.toggle('on'); if (!reportEcus().length) t.classList.add('on'); return; }
    if (t.matches('[data-t]')) {
      const k = t.dataset.t;
      if (k === 'next') return tourAt === TOUR.length - 1 ? endTour() : showTour(tourAt + 1);
      if (k === 'back') return showTour(tourAt - 1, true);
      return endTour();
    }
    if (t.matches('#catList li[data-i]')) {
      catSel = +t.dataset.i; $$('#catList li').forEach((li) => li.classList.toggle('sel', li === t));
      const r = await act('catalog_detail', { i: catSel });
      if (r && r.ok) { $('#catDetail').textContent = r.text; $('#catRead').disabled = !r.readable; }
      return;
    }
    if (t.matches('#learnBody tr[data-i]')) { learnSel = +t.dataset.i; return renderLearn(); }
    if (t.matches('#bleList li[data-mac]')) { $('#bleMac').value = t.dataset.mac; return act('ble_set_mac', { mac: t.dataset.mac }); }
  });

  $('#connectBtn').onclick = () => act((S.conn || {}).connected ? 'disconnect' : 'connect');
  $('#demoBtn').onclick = () => act('demo_start');
  $('#heroDemo').onclick = () => act('demo_start');
  $('#captureBtn').onclick = captureMenu;
  $('#connPill').onclick = settingsSheet;
  $('#heroAction').onclick = () => { const n = $('#heroAction').dataset.next; n && n.startsWith('go:') ? go(n.slice(3)) : act(n); };
  $('#bench').onchange = async (e) => { const on = e.target.checked; e.target.checked = !on; await act('set_bench', { on }); };
  $('#unlockAccess').onchange = (e) => act('set_unlock_access', { on: e.target.checked });
  $('#vitalsLog').onchange = (e) => act('vitals_log', { on: e.target.checked });
  $('#demoChargerSw').onchange = (e) => act('demo_charger', { on: e.target.checked });
  $('#toggleSidebar').onclick = () => $('#sidebar').classList.toggle('open');
  $('#openActivity').onclick = () => { $('#drawer').hidden = !$('#drawer').hidden; poll(true); };
  $('#closeDrawer').onclick = () => { $('#drawer').hidden = true; };
  $('#openTour').onclick = () => showTour(0);
  $('#scrim').onclick = () => closeSheet(null);
  $('#scroller').addEventListener('scroll', (e) => $('.toolbar').classList.toggle('scrolled', e.target.scrollTop > 40), { passive: true });

  // status
  $('#revealBtn').onclick = () => act('feature_reveal', { name: $('#revealSel').value });
  $('#logExport').onclick = async () => { const path = await pick({ kind: 'save', title: 'Export activity log', where: 'activity', label: 'Text', pattern: '*.txt', ext: '.txt' }); if (path) act('log_export', { path }); };
  const pickFolder = async (which) => { const path = await pick({ kind: 'dir', title: which === 'charge' ? 'Charge session folder' : 'Activity log folder', where: which }); if (path) act(which === 'charge' ? 'set_charge_folder' : 'set_activity_folder', { path }); };
  $('#pickActivity').onclick = () => pickFolder('activity');
  $('#pickCharge').onclick = () => pickFolder('charge');
  $('#pickCharge2').onclick = () => pickFolder('charge');

  // live
  $('#liveSearch').addEventListener('input', renderLive);
  $('#replayBtn').onclick = async () => { const path = await pick({ kind: 'open', title: 'Open capture', where: 'captures', label: 'Capture JSON', pattern: '*.json' }); if (path) act('replay', { path }); };
  $('#exportCsv').onclick = async () => { const path = await pick({ kind: 'save', title: 'Export CSV', where: 'captures', label: 'CSV', pattern: '*.csv', ext: '.csv' }); if (path) act('export_csv', { path }); };
  $('#learnNew').onclick = () => act('learn_new', { label: $('#learnLabel').value });
  $('#learnOpen').onclick = async () => { const path = await pick({ kind: 'open', title: 'Open learning session', where: 'learning', label: 'Learning sessions', pattern: '*.json' }); if (path) act('learn_open', { path }); };
  $('#learnSave').onclick = () => act('learn_save', { index: learnSel });

  // diagnostics
  $('#healthSearch').addEventListener('input', renderHealth);
  $('#healthOnly').addEventListener('change', renderHealth);
  $('#healthExport').onclick = async () => { const path = await pick({ kind: 'save', title: 'Export diagnostic report', where: 'captures', label: 'Diagnostic report', pattern: '*.json', ext: '.json' }); if (path) act('health_export', { path }); };
  document.addEventListener('click', (e) => {
    const b = e.target.closest('#clearDtcBtn'); if (!b) return;
    showMenu(b, META.ecus.map((x) => ({ label: `Clear ${x} codes…`, value: x, icon: 'x', danger: true })), (x) => act('clear_dtc', { ecu: x }), { align: 'right' });
  });

  // tests
  $('#actSearch').addEventListener('input', buildActuators);

  // battery
  document.addEventListener('click', (e) => {
    const g = e.target.closest('[data-graph]'); if (g) { graphOn[g.dataset.graph] = !graphOn[g.dataset.graph]; g.classList.toggle('on'); return drawGraph(); }
    const w = e.target.closest('[data-bmswrite]'); if (w) return act('bms_write', { did: w.dataset.bmswrite, payload: w.dataset.stock });
    const rp = e.target.closest('.recpick'); if (rp) { recPick[rp.dataset.sig] = rp.checked; const sel = Object.keys(recPick).filter((k) => recPick[k]).slice(0, 6); return act('session_plot', { names: sel }); }
  });
  $('#recSigSearch').addEventListener('input', renderRecorder);
  $('#graphExportBtn').onclick = async () => { const path = await pick({ kind: 'save', title: 'Export graph CSV', where: 'captures', label: 'CSV', pattern: '*.csv', ext: '.csv' }); if (path) act('graph_export', { path }); };
  $('#recExportBtn').onclick = async () => { const path = await pick({ kind: 'save', title: 'Export recording to CSV', where: 'recordings', label: 'CSV', pattern: '*.csv', ext: '.csv' }); if (path) act('session_export', { path }); };
  $('#recExportOpenBtn').onclick = async () => { const path = await pick({ kind: 'save', title: 'Export recording to CSV', where: 'recordings', label: 'CSV', pattern: '*.csv', ext: '.csv' }); if (path) act('session_export', { path }); };
  $('#recOpenBtn').onclick = async () => { const path = await pick({ kind: 'open', title: 'Open a recording', where: 'recordings', label: 'Recordings', pattern: '*.jsonl' }); if (path) { recPick = {}; act('session_open', { path }); } };
  $('#bmsSearch').addEventListener('input', renderBmsSettings);
  $('#bmsDevOnly').addEventListener('change', renderBmsSettings);

  // report
  $('#reportRun').onclick = () => act('report_start', { quick: reportKind === 'quick', ecus: reportEcus() });
  $('#reportSearch').addEventListener('input', renderReportGroups);

  // components
  $('#readDid').onclick = () => act('read_did', { ecu, did: $('#didInput').value.trim() });
  $('#readFaults').onclick = () => act('read_faults', { ecu });
  $('#openSession').onclick = () => act('open_session', { ecu });
  $('#settingSel').onchange = renderSetting;
  $('#readSetting').onclick = () => act('read_setting', { name: $('#settingSel').value });
  $('#catSearch').addEventListener('input', renderCatalog);
  $('#catRead').onclick = () => catSel !== null && act('catalog_read', { i: catSel });

  // calibration
  $('#odoWrite').onclick = () => act('write_odometer', { km: $('#odoNew').value });
  $('#boostWrite').onclick = () => act('write_boost', { did: $('#boostDid').value, payload: $('#boostPayload').value });
  const mem = () => ({ ecu: $('#memEcu').value, addr: $('#memAddr').value, size: $('#memSize').value });
  $('#memRead').onclick = () => act('mem_read', mem());
  $('#memDump').onclick = () => act('mem_dump', mem());

  // bluetooth
  $('#blePair').onclick = () => act('ble_pair', { mac: $('#bleMac').value });

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === '4' || e.code === 'Digit4')) { e.preventDefault(); return takeScreenshot(); }
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === '5' || e.code === 'Digit5')) { e.preventDefault(); return rec.active ? stopRecording() : startRecording(); }
    if (e.key === 'Escape') {
      if (openMenu) return closeMenu();
      if (!$('#layer').hidden) return closeSheet(null);
      if (!$('#tour').hidden) return endTour();
      if (!$('#drawer').hidden) { $('#drawer').hidden = true; return; }
      $('#sidebar').classList.remove('open');
    }
    if (!$('#tour').hidden && e.key === 'ArrowRight') { tourAt < TOUR.length - 1 ? showTour(tourAt + 1) : endTour(); }
    if (!$('#tour').hidden && e.key === 'ArrowLeft' && tourAt > 0) showTour(tourAt - 1, true);
  });

  // Tell the bridge the window is going away (a reload re-polls within the grace period).
  window.addEventListener('pagehide', () => { try { navigator.sendBeacon(`/api/bye?t=${encodeURIComponent(TOKEN)}`, '{}'); } catch (_) { /* ignore */ } });
}

/* ------------------------------------------------------------------ boot */
(async function boot() {
  paintIcons();
  let theme = 'system';
  try { theme = localStorage.getItem(THEME_KEY) || 'system'; } catch (_) { /* ignore */ }
  applyTheme(theme);
  const h = new Date().getHours();
  $('#greeting').textContent = h < 5 ? 'Good evening' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  wire();
  try { META = await http('GET', '/api/meta'); buildFromMeta(); paintIcons(); }
  catch (_) { toast('Could not reach the console', 'danger'); }
  let start = 'home';
  try { start = sessionStorage.getItem('scooterConsole.view') || 'home'; } catch (_) { /* ignore */ }
  go(start);
  let seen = false;
  try { seen = localStorage.getItem(TOUR_KEY) === '1'; } catch (_) { /* ignore */ }
  if (!seen) setTimeout(() => showTour(0), 450);
})();
