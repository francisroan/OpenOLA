"""Full-session recorder: streams every decoded scooter signal to a timestamped file.

While recording, each monitor tick appends one JSON line with the current value of every
signal the bus is broadcasting (plus decoded battery/charge numbers). The result is a
compact, memory-safe JSONL you can re-open in the GUI or export to a wide CSV for Excel —
ideal for a drive/drain test: battery %, pack current, per-sensor cell min/max over time.

File format (one JSON object per line):
    {"recorder": 1, "started": <unix>, "meta": {...}}      # first line
    {"t": 12.3, "v": {"Overall_SOC": 78, "MCU_Voltage": 54.6, ...}}   # each sample
"""
import csv
import json
import time
from pathlib import Path


class SessionRecorder:
    def __init__(self):
        self.path = None
        self._fh = None
        self.started = 0.0
        self.samples = 0
        self.signals = set()
        self._t0 = None

    @property
    def active(self):
        return self._fh is not None

    def start(self, path, meta=None):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = path.open('w', encoding='utf-8')
        self.path = path
        self.started = time.time()
        self._t0 = None
        self.samples = 0
        self.signals = set()
        self._fh.write(json.dumps({'recorder': 1, 'started': self.started, 'meta': meta or {}}) + '\n')
        self._fh.flush()
        return path

    def sample(self, values: dict):
        """values: {signal_name: number}. Skips Nones; records elapsed seconds."""
        if not self._fh:
            return
        clean = {k: v for k, v in values.items() if isinstance(v, (int, float)) and v is not None}
        if not clean:
            return
        now = time.time()
        if self._t0 is None:
            self._t0 = now
        self.signals.update(clean)
        self.samples += 1
        self._fh.write(json.dumps({'t': round(now - self._t0, 2), 'v': clean}) + '\n')
        if self.samples % 20 == 0:
            self._fh.flush()

    def stop(self):
        if not self._fh:
            return None
        try:
            self._fh.flush()
            self._fh.close()
        finally:
            self._fh = None
        return self.path

    def stats(self):
        return {'active': self.active, 'path': str(self.path) if self.path else None,
                'samples': self.samples, 'signals': len(self.signals),
                'elapsed': round(time.time() - self.started, 1) if self.started else 0}


# ----------------------------------------------------------------------------- read back
def summarize(path):
    """Scan a recording: duration, sample count, and per-signal min/max/last/count."""
    path = Path(path)
    meta = {}
    n = 0
    tmax = 0.0
    agg = {}
    with path.open(encoding='utf-8') as f:
        for line in f:
            try:
                o = json.loads(line)
            except ValueError:
                continue
            if 'recorder' in o:
                meta = o.get('meta', {})
                continue
            n += 1
            tmax = max(tmax, o.get('t', 0))
            for k, v in o.get('v', {}).items():
                a = agg.get(k)
                if a is None:
                    agg[k] = {'count': 1, 'min': v, 'max': v, 'last': v}
                else:
                    a['count'] += 1
                    a['min'] = min(a['min'], v)
                    a['max'] = max(a['max'], v)
                    a['last'] = v
    signals = [{'name': k, **a} for k, a in sorted(agg.items())]
    return {'path': str(path), 'name': path.name, 'meta': meta, 'samples': n,
            'duration': round(tmax, 1), 'signals': signals}


def load_series(path, names, max_points=1500):
    """Return {name: [[t, v], ...]} for the requested signals (decimated to max_points)."""
    path = Path(path)
    want = set(names)
    series = {k: [] for k in want}
    with path.open(encoding='utf-8') as f:
        for line in f:
            try:
                o = json.loads(line)
            except ValueError:
                continue
            if 'recorder' in o:
                continue
            t = o.get('t', 0)
            for k in want:
                if k in o['v']:
                    series[k].append([t, o['v'][k]])
    for k, pts in series.items():
        if len(pts) > max_points:
            step = len(pts) / max_points
            series[k] = [pts[int(i * step)] for i in range(max_points)]
    return series


def export_csv(jsonl_path, csv_path):
    """Pivot a recording to a wide CSV: time column + one column per signal."""
    jsonl_path, csv_path = Path(jsonl_path), Path(csv_path)
    cols = []
    seen = set()
    rows = []
    with jsonl_path.open(encoding='utf-8') as f:
        for line in f:
            try:
                o = json.loads(line)
            except ValueError:
                continue
            if 'recorder' in o:
                continue
            for k in o['v']:
                if k not in seen:
                    seen.add(k)
                    cols.append(k)
            rows.append((o.get('t', 0), o['v']))
    with csv_path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['time_s'] + cols)
        for t, v in rows:
            w.writerow([t] + [v.get(c, '') for c in cols])
    return csv_path, len(rows), len(cols)


def write_series_csv(series: dict, csv_path):
    """Write an in-memory {name: [[t,v]]} graph to a wide CSV (union of timestamps)."""
    csv_path = Path(csv_path)
    names = [k for k, v in series.items() if v]
    times = sorted({round(p[0], 1) for k in names for p in series[k]})
    lookup = {k: {round(p[0], 1): p[1] for p in series[k]} for k in names}
    with csv_path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['time_s'] + names)
        for t in times:
            w.writerow([t] + [lookup[k].get(t, '') for k in names])
    return csv_path, len(times), len(names)
