"""Headless controller for the glass GUI.

A faithful port of ``scooter_gui.App`` without Tk. Everything that touches state runs
on ONE loop thread (the equivalent of Tk's mainloop): HTTP handlers post calls into
``inbox`` and wait for the reply, worker threads post their results back the same way.
Vehicle I/O, seed/key, keepalive, actuator cleanup and audit are the unchanged
``scooter_backend`` code paths.

Safety prompts live HERE, not in the browser: an action that needs confirmation raises
``NeedConfirm`` until the request carries the exact word / acknowledgement, so the UI
can never skip a prompt. (This is also the single place future gating hooks into.)
"""
import csv
import json
import os
import queue
import re
import sys
import threading
import time
from collections import deque
from pathlib import Path

TOOL = Path(__file__).resolve().parents[1]
for _p in (TOOL, TOOL / 'ble'):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from scooter_backend import (ROOT, SETTINGS, ACTUATORS, ACTUATOR_GROUPS,  # noqa: E402
                             ACTUATOR_GROUP_ORDER, ACTUATOR_DANGER, Ecu, Scooter,
                             decode_setting, audit)
from command_trace import CommandTrace  # noqa: E402
from status_monitor import (SessionLog, ChargeSessionRecorder, active_faults,  # noqa: E402
                            decode_battery, decode_charge, decode_charge_extra,
                            decode_feature_status, decode_vehicle_notification,
                            decode_hardware, decode_dcir, decode_vehicle_state,
                            enrich_power, _sig)
import hmi_commands as hc  # noqa: E402
from signal_learning import LearningSession, PHASES, analysis_report  # noqa: E402
from oladiag.wifican import wifican_pb2 as pb  # noqa: E402
import ecu_report  # noqa: E402
import vehicle_info  # noqa: E402
import battery as battery_mod  # noqa: E402
from session_recorder import SessionRecorder, summarize as rec_summarize, load_series, export_csv, write_series_csv  # noqa: E402

try:
    import gui_backend as ble          # Bluetooth (proximity) path; optional
except Exception:                      # keep the GUI usable if the BLE stack is absent
    ble = None


class Notice(Exception):
    """A user-facing message instead of an action (e.g. 'Connect first')."""
    def __init__(self, text, title='', tone='info'):
        super().__init__(text)
        self.payload = {'title': title, 'text': text, 'tone': tone}


class NeedConfirm(Exception):
    """The action needs an explicit OK (word=None) or a typed word before it runs."""
    def __init__(self, title, text, word=None, tone='warn', button='Continue'):
        super().__init__(title)
        self.payload = {'title': title, 'text': text, 'word': word, 'tone': tone, 'button': button}


LIVE_METRICS = [('Overall_SOC', 'Battery SOC', '%'), ('MCU_Voltage', 'Bus voltage', 'V'),
                ('BMS0_Cell_Min_Voltage', 'Min cell', 'V'), ('BMS0_Cell_Max_Voltage', 'Max cell', 'V'),
                ('Motor_Temprature', 'Motor temp', '°C'), ('MCU_Temperatute', 'MCU temp', '°C')]

CATEGORIES = {
    'All': None,
    'Battery': ('soc', 'cell', 'pack', 'bms', 'contactor', 'charge', 'battery'),
    'Motor': ('mcu', 'motor', 'rpm', 'speed', 'torque', 'throttle', 'drive'),
    'Power': ('voltage', 'current', 'dcdc', 'dc_dc', 'bus', 'power'),
    'Temperature': ('temp',),
    'Faults': ('fault', 'error', 'warn', 'protect', 'abnormal', 'fail', 'inhibit', 'derate', 'timeout',
               'disconnect', 'overcurrent', 'undervolt', 'overvolt'),
    'Vehicle': ('odom', 'mode', 'indicator', 'brake', 'light', 'horn', 'lamp', 'stand', 'lock'),
}

FEATURE_TOGGLES = [('Boost mode', 48, 49), ('Hill hold', 66, 67), ('Vacation mode', 68, 69),
                   ('Proximity lock', 54, 55), ('Motor cutoff delay', 64, 65), ('Park assist', 103, 104)]
REGEN_TYPES = [('Default', 41), ('City', 42), ('Highway', 43)]
UPDATE_RPCS = [('Software version', 'GetSwVersion'), ('Android version', 'GetAospVersion'),
               ('Vehicle identifiers', 'GetVehicleIdentifiers'), ('Update status', 'SwUpdateCheckStatus'),
               # Read-only cert status check. GenerateCerts/RegisterInstallCerts are
               # deliberately excluded — they can break the scooter's trust.
               ('Validate identity', 'ValidateCerts')]
LEARN_LABELS = ['Right indicator', 'Left indicator', 'Horn', 'Left brake lever', 'Right brake lever',
                'Side stand down', 'Low beam', 'High beam', 'Brake light']
# Head-unit self-tests over gRPC RemoteRunTestCmd (no ECU unlock) — from the diagnostic app.
HU_TESTS = [  # key, label, cmd, sub-field, start, stop, note
    ('lcd', 'Display', 'RMT_CMD_LCD_TEST', 'sub_cmd_lcd', 'RMT_SUB_CMD_LCD_TEST_START', 'RMT_SUB_CMD_LCD_TEST_STOP',
     'Cycles test patterns on the dash display.'),
    ('spkr', 'Speaker', 'RMT_CMD_SPKR_TEST', 'sub_cmd_spkr', 'RMT_SUB_CMD_SPKR_TEST_START', 'RMT_SUB_CMD_SPRK_TEST_STOP',
     'Plays a test tone through the scooter speaker.'),
    ('mic', 'Microphone', 'RMT_CMD_MIC_TEST', 'sub_cmd_mic', 'RMT_SUB_CMD_MIC_TEST_START', 'RMT_SUB_CMD_MIC_TEST_STOP',
     'Checks the head-unit microphone.'),
    ('gps', 'GPS', 'RMT_CMD_GPS_TEST', 'sub_cmd_gps', 'RMT_SUB_CMD_GPS_TEST_START', 'RMT_SUB_CMD_GPS_TEST_STOP',
     'Checks the GPS receiver. Works best outdoors.'),
    ('bt', 'Bluetooth', 'RMT_CMD_BT_TEST', 'sub_cmd_bt', 'RMT_SUB_CMD_BT_TEST_START', 'RMT_SUB_CMD_BT_TEST_STOP',
     'Checks the classic Bluetooth radio (music / calls).'),
    ('ble', 'Bluetooth LE', 'RMT_CMD_BLE_TEST', 'sub_cmd_ble', 'RMT_SUB_CMD_BLE_TEST_START', 'RMT_SUB_CMD_BLE_TEST_STOP',
     'Checks the low-energy radio used by the phone key.'),
    ('esim', 'eSIM', 'RMT_CMD_ESIM_TEST', 'sub_cmd_esim', 'RMT_SUB_CMD_ESIM_TEST_START', 'RMT_SUB_CMD_ESIM_TEST_STOP',
     'Checks the cellular eSIM module.'),
    ('wifi', 'Wi‑Fi', 'RMT_CMD_WIFI_TEST', 'sub_cmd_wifi', 'RMT_SUB_CMD_WIFI_TEST_START', 'RMT_SUB_CMD_WIFI_TEST_STOP',
     'Checks the Wi‑Fi radio. This console talks over that Wi‑Fi, so the link may drop.'),
]
# Workshop routines from the ODX (31 01 …) — unverified on this firmware, so each is gated.
ROUTINES = [  # key, ecu, request hex, label, description
    ('bf01', 'VCU', '3101BF01', 'MCU peripherals check', 'End-of-line check of the motor-controller interfaces.'),
    ('bf02', 'VCU', '3101BF02', 'Smart module self-check', 'Self check of the smart module (SOM / head unit).'),
    ('bf03', 'VCU', '3101BF03', 'SOM UART transmit check', 'Checks VCU → smart-module serial transmission.'),
    ('bf04', 'VCU', '3101BF04', 'SOM UART receive check', 'Checks smart-module → VCU serial reception.'),
    ('bf05', 'VCU', '3101BF05', 'Handlebar LIN check', 'Checks LIN communication with the handlebar controls.'),
    ('bf06', 'VCU', '3101BF06', 'Head-unit CAN check', 'Checks CAN communication with the head unit.'),
    ('tune', 'MCU', '310306F1', 'AutoTune result', 'Reads the AutoTune result: status, attempts and successes (read-only).'),
    ('bal', 'BMS', '310105F8', 'Cell balancing', 'Starts the BMS cell-balancing routine.'),
]
CHARGE_CELLS = [('soc', 'SOC', '%'), ('volts', 'Pack', 'V'), ('amps', 'Current', 'A'), ('power', 'Power', 'W'),
                ('ctype', 'Type', ''), ('vl1', 'Mode L1', ''), ('vl2', 'Mode L2', ''), ('cmode', 'CC / CV', ''),
                ('ilim', 'BMS I limit', 'A'), ('vlim', 'BMS V limit', 'V'), ('avail_i', 'Charger avail.', 'A'),
                ('crate', 'C-rate', ''), ('billing', 'Billing', ''), ('evse', 'EVSE id', '')]


def _jsonable(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    return str(value)


class Controller:
    def __init__(self):
        self.scooter = Scooter()
        self.scooter.trace = CommandTrace(ROOT / 'captures/gui/protocol')
        self.inbox = queue.Queue()
        self.busy = False
        self.busy_label = ''
        self.connected = False
        self.live = False
        self.replay = False
        self.closing = False
        self._close_disconnect = False
        self.closed = threading.Event()
        self.next_poll = 0
        self.rows = {}
        self.current = None
        self.setting_values = {}

        self._prefs_path = ROOT / 'captures/gui/glass_prefs.json'
        prefs = self._load_json(self._prefs_path)
        self.host = prefs.get('host', '')
        self.port = str(prefs.get('port', '50005'))
        self.secure = bool(prefs.get('secure', False))
        self.unlock_access = False
        self.bench = False
        self.status_text = 'Disconnected • No commands sent'
        self.mode = 'unknown'
        self.firmware = 'unknown'
        self.activity = deque(maxlen=400)

        # UI events (toasts / result sheets) — polled by the page with a cursor.
        self.events = deque(maxlen=200)
        self.seq = 0

        # Status / charging
        self.status_on = False
        self.auto_log_vitals = False
        self._logged_faults = set()
        self._last_vitals_log = 0.0
        self._log_prefs = ROOT / 'captures/gui/log_folders.json'
        self._default_activity = ROOT / 'captures/gui/activity'
        self._default_charge = ROOT / 'captures/charging'
        # Cross-session battery-health trend (SoH / cell spread over time).
        self._batt_hist_path = ROOT / 'captures/gui/battery_history.json'
        self.batt_history = self._load_json(self._batt_hist_path) or []
        self._batt_hist_last = 0.0
        activity_dir, charge_dir = self._load_log_folders()
        self._status_log = SessionLog(activity_dir)
        self._charge_rec = ChargeSessionRecorder(charge_dir, self.scooter.dbc)
        self._charge_snoop = False
        self.sv = {k: '—' for k in ('soc', 'range', 'volts', 'amps', 'power', 'chg', 'motor_t', 'mcu_t',
                                    'ctype', 'vl1', 'vl2', 'cmode', 'ilim', 'vlim', 'avail_i', 'crate',
                                    'billing', 'evse')}
        self.faults = []
        self.notifications = deque(maxlen=200)
        self._notif_seen = None
        self.features = None
        self._feat_raw = None
        self._feat_bytes = None

        # Calibration
        self.cal = {'motor_angle': '—', 'cal_status': 'Not run this session', 'odo_value': '—',
                    'odo_status': 'Not read this session', 'boost_dids': '—', 'mem_result': '—'}

        # Software page
        self.update_text = ''

        # Bluetooth
        self.ble_rows = []
        self.ble_mac = ble.DEFAULT_MAC if ble else ''
        self.ble_status = 'Close the Ola app and the phone’s Bluetooth so this PC can hold the link.'
        self._ble_q = []

        # Health dashboard (diagnostics)
        self.health = {}
        self.health_events = deque(maxlen=1000)
        self._health_prev = {}
        self.health_stored = {}
        self._health_next = 0

        # Passive signal learning
        self.learn = None
        self.learn_report = None
        self.learn_candidates = []
        self.learn_instructions = 'Connect first, choose a function label, then start a new session.'
        self.learn_status = 'No session yet'

        self._catalog = None

        # Demo mode (simulated scooter on localhost)
        self.demo = None
        self._demo_saved = None

        # ECU read-out report
        self.report_progress = None            # {'done','total','label'} while running
        self.report_cancel = threading.Event()
        self.last_report = None
        self.report_seq = 0
        self.report_files = None

        # Workshop results (routines / head-unit tests)
        self.workshop_log = deque(maxlen=60)

        # Firmware / versions + VCU variant & feature config
        self.fw_report = None                  # {versions, findings} once read
        self.vcu_config = None
        self.model = None
        self.hw_variants = {}       # per-ECU hardware-variant codes (0x610/0x678)
        self.cell_dcir = []         # per-cell DC internal resistance mΩ (0x1AB-0x1AE)
        self.vehicle_state = {}     # friendly CAN vehicle state (drive mode, safety…)
        self.fw_flash = None        # OTA firmware-flash progress {'state','progress'}
        self.adb_output = ''        # last ExecuteADBCommand root-shell output
        try:                        # manufacturing config (reference tips only)
            self.som_config = json.loads(
                (ROOT / 'tool/oladiag/config/som_ecu_config.json').read_text(encoding='utf-8-sig'))
        except (OSError, ValueError):
            self.som_config = {}
        self.auto_test = None
        self.battery_health = None
        self.bms_config = None                 # [{did,title,values,stock,deviates}]
        self.bms_findings = None
        self.cells = None
        # Battery graph: rolling time-series per signal (seconds since connect, value).
        self.graph = {k: deque(maxlen=600) for k, _, _ in battery_mod.GRAPH_SIGNALS}
        self._graph_t0 = None
        self.recorder = SessionRecorder()
        self.loaded_recording = None           # summary of an opened recording
        self.loaded_series = None              # {name: [[t,v]]} for plotting a recording                      # detected variant, shown on the header

    # ------------------------------------------------------------------ plumbing
    @staticmethod
    def _load_json(path):
        try:
            if path.exists():
                return json.loads(path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            pass
        return {}

    def start(self):
        threading.Thread(target=self._loop, name='controller', daemon=True).start()

    def _loop(self):
        while not self.closed.is_set():
            deadline = time.monotonic() + 0.5
            while True:
                timeout = deadline - time.monotonic()
                if timeout <= 0:
                    break
                try:
                    item = self.inbox.get(timeout=timeout)
                except queue.Empty:
                    break
                kind = item[0]
                if kind == 'call':
                    _, fn, box, done_evt = item
                    try:
                        box['value'] = fn()
                    except BaseException as exc:      # handed back to the HTTP thread
                        box['error'] = exc
                    done_evt.set()
                elif kind == 'result':
                    self._on_result(*item[1:])
                if self.closed.is_set():
                    return
            try:
                self.tick()
            except Exception as exc:                  # never let the loop die
                self.report(f'Internal error: {exc}')

    def call(self, fn, timeout=15):
        """Run fn on the loop thread and return its value (raises its exception)."""
        box, evt = {}, threading.Event()
        self.inbox.put(('call', fn, box, evt))
        if not evt.wait(timeout):
            raise TimeoutError('The console is busy — try again in a moment.')
        if 'error' in box:
            raise box['error']
        return box.get('value')

    def emit(self, kind, title, text='', tone='info', action=None):
        self.seq += 1
        self.events.append({'id': self.seq, 'kind': kind, 'title': title, 'text': str(text),
                            'tone': tone, 'action': action})

    def report(self, text):
        self.status_text = text
        self.activity.append(time.strftime('%H:%M:%S ') + text)

    def run(self, label, fn, done=None, quiet=False, resume=False):
        if self.busy:
            if not quiet:
                self.report('Wait for the current operation to finish.')
                raise Notice('Wait for the current operation to finish.', 'Busy')
            return
        self.busy = True
        self.busy_label = '' if quiet else label
        self.scooter.bench_confirmed = self.bench
        if not quiet:
            self.report(label + '…')
            self._status_log.log('CMD', f'START  {label}')

        def work():
            tracked = not quiet or label.startswith('Analyze')
            trace_path = None
            try:
                if tracked:
                    trace_path = self.scooter.trace.begin(label)
                    audit('operation-start', label)
                result = fn()
                if tracked:
                    summary = {'items': len(result)} if isinstance(result, list) else result
                    if isinstance(result, dict) and 'changed_unverified' in result:
                        summary = {'candidates': len(result['candidates']),
                                   'changed_unverified': len(result['changed_unverified']),
                                   'quality': result['quality'], 'issues': result['issues']}
                    self.scooter.trace.end(result=str(summary))
                    audit('operation-result', {'operation': label, 'result': str(summary),
                                               'protocol_trace': trace_path})
                self.inbox.put(('result', label, result, None, done, quiet, resume))
            except Exception as exc:
                error = str(exc) or type(exc).__name__
                if tracked and self.scooter.trace.active:
                    try:
                        self.scooter.trace.end(error=error)
                    except Exception as trace_error:
                        error += '; trace error: ' + str(trace_error)
                try:
                    audit('operation-error', {'operation': label, 'error': error, 'protocol_trace': trace_path})
                except OSError:
                    pass
                self.inbox.put(('result', label, None, error, done, quiet, resume))
        threading.Thread(target=work, daemon=True).start()

    def _on_result(self, label, result, error, done, quiet, resume=False):
        self.busy = False
        self.busy_label = ''
        if resume:      # after this result is handled, give the bus back to the monitor
            self.inbox.put(('call', self._resume_monitor, {}, threading.Event()))
        if self._close_disconnect and label == 'Disconnect':
            self._finish_close()
            return
        if error:
            self.live = False
            self.report(f'{label} failed: {error}')
            if not quiet:
                self._status_log.log('CMD', f'FAIL  {label} → {error}')
                text = error
                if label == 'Connect' and self.demo:
                    self._stop_demo()
                if label == 'Connect':
                    text = (f'Couldn’t reach the scooter at {self.host}:{self.port}.\n\nCheck that this PC is joined '
                            'to the scooter’s Wi‑Fi and the scooter is awake, then try again. The address and port '
                            f'are under the connection pill at the top.\n\nDetails: {error}')
                    self.mode = 'unknown'
                self.emit('error', label, text, 'danger')
            if label.startswith('Passive capture') and self.learn:
                self.learn_status = 'Capture stopped. Start a new session if it failed (see the error).'
                self._learn_stage()
            if label == 'Analyze observed signals':
                self.learn_status = f'Analysis failed: {error}'
            if label.startswith('ECU report'):
                self.report_progress = None
            if self._ble_q:
                self._ble_drain()
            return
        if done:
            try:
                done(result)
            except Notice as n:
                self.emit('notice', n.payload['title'] or label, n.payload['text'], n.payload['tone'])
            except Exception as exc:
                self.report(f'{label}: display error: {exc}')
        if not quiet:
            summary = result if isinstance(result, str) else 'completed'
            self.report(f'{label}: {summary}')
            self._status_log.log('CMD', f'OK    {label} → {summary}')

    def tick(self):
        if self.closing and not self.busy:
            self.closing = False
            self._close_disconnect = True
            self.run('Disconnect', self.scooter.disconnect, quiet=True)
            return
        if self.live and not self.busy and time.monotonic() >= self.next_poll:
            self.next_poll = time.monotonic() + 1.5
            self.run('Live stream', self.scooter.samples, self.accept_rows, quiet=True)
        try:
            self._tick_status()
        except Exception:
            pass
        if time.monotonic() >= self._health_next:
            self._health_next = time.monotonic() + 1.0
            try:
                self._tick_health()
            except Exception:
                pass

    def request_close(self):
        """Window closed: stop streams, wait for the running op + actuator OFF, disconnect."""
        def go():
            self.live = False
            self.status_on = False
            if self._charge_snoop:
                try:
                    self._charge_rec.stop()
                    self._detach_charge_observer()
                except Exception:
                    pass
                self._charge_snoop = False
            self.closing = True
            self.report('Closing after the current command and actuator OFF attempt finish…')
        try:
            self.call(go, timeout=5)
        except Exception:
            self.closing = True

    def _finish_close(self):
        try:
            self.scooter.trace.close()
        except Exception:
            pass
        if self.recorder.active:
            self.recorder.stop()
        self._stop_demo()
        self.closed.set()

    # ------------------------------------------------------------------ guards
    def _need_conn(self, title):
        if not self.connected:
            raise Notice('Connect to the scooter over Wi‑Fi first.', title)

    def _need_bench(self, title):
        if not self.bench:
            raise Notice('Turn on “Bench mode” first — scooter parked and charger unplugged.', title, 'warn')

    def _need_idle(self):
        if self.busy:
            raise Notice('Wait for the current operation to finish.', 'Busy')

    @staticmethod
    def _confirm(p, title, text, word=None, tone='warn', button='Continue'):
        got = p.get('confirm')
        if word:
            if isinstance(got, str) and got.strip() == word:
                return
        elif got is True:
            return
        raise NeedConfirm(title, text, word, tone, button)

    # ------------------------------------------------------------------ dispatch
    def act(self, name, p):
        fn = getattr(self, 'a_' + name, None)
        if fn is None:
            raise Notice(f'Unknown action “{name}”.', 'Error', 'danger')
        return fn(p or {})

    # ------------------------------------------------------------------ connection
    def a_set_connection(self, p):
        self._need_idle()
        if self.demo:
            raise Notice('End the demo (Disconnect) before changing the connection.', 'Connection')
        host = str(p.get('host', '')).strip()
        port = str(p.get('port', '')).strip()
        if not host or any(c.isspace() for c in host):
            raise Notice('Enter a valid host name or IP address.', 'Connection')
        if not port.isdigit() or not 1 <= int(port) <= 65535:
            raise Notice('Port must be a number from 1 to 65535.', 'Connection')
        self.host, self.port, self.secure = host, port, bool(p.get('secure'))
        try:
            self._prefs_path.parent.mkdir(parents=True, exist_ok=True)
            self._prefs_path.write_text(json.dumps({'host': self.host, 'port': self.port,
                                                    'secure': self.secure}, indent=2), encoding='utf-8')
        except OSError:
            pass
        return {'message': 'Connection settings saved — they apply on the next connect.'}

    def a_connect(self, p):
        self._need_idle()
        self._connect()

    def _connect(self, after=None):
        host, port, secure = self.host, self.port, self.secure
        if not host.strip():
            raise Notice('Enter the scooter Wi-Fi host in Connection settings before connecting.', 'Host required')
        self.live = False
        self.current = None
        self.connected = False
        self.mode, self.firmware = 'connecting', 'unknown'
        self._status_log.begin_session(f'{host}:{port}')

        def after_connect(data):
            self.info(data)
            self._status_log.log('CONN', f"connected mode={data.get('mode')} fw={data.get('firmware')}")
            if after:
                after()
            else:
                self.emit('toast', 'Connected', f"{data.get('mode')} mode", 'ok')
        self.run('Connect', lambda: self.scooter.connect(host, port, secure), after_connect)

    def info(self, data):
        self.connected = True
        self.mode = data['mode']
        self.firmware = data['firmware']

    def a_disconnect(self, p):
        if self.busy:
            self.report('Wait for the operation and test cleanup before disconnecting.')
            raise Notice('Wait for the operation and test cleanup before disconnecting.', 'Busy')
        if self._charge_snoop:
            self._toggle_charge_snoop()
        self.status_on = False
        self.live = False

        def done(_):
            self.connected = False
            self.current = None
            self.mode, self.firmware = 'unknown', 'unknown'
            self._status_log.end_session('disconnect')
            self.model = self.fw_report = self.vcu_config = self.auto_test = None
            self.battery_health = self.bms_config = self.bms_findings = self.cells = None
            self.a_graph_clear({})
            if self.recorder.active:
                self.recorder.stop()
            if self.demo:
                self._stop_demo()
                self._status_log.log('SYS', 'demo mode ended')
        self.run('Disconnect', self.scooter.disconnect, done)

    def a_set_bench(self, p):
        if p.get('on'):
            self._confirm(p, 'Turn on Bench mode?',
                          'Bench mode unlocks active tests and writes. Before you continue:\n\n'
                          '•  Scooter parked on the centre stand, rear wheel clear\n'
                          '•  Charger physically unplugged (a past read interrupted charging)\n'
                          '•  Nobody on or near the scooter\n\n'
                          'Every command still asks before it sends.', button='Turn on')
        self.bench = bool(p.get('on'))
        # Applies immediately (not only on the next run) so switching it off blocks at once.
        self.scooter.bench_confirmed = self.bench
        self._status_log.log('SYS', 'bench mode ' + ('ON' if self.bench else 'OFF'))

    def a_set_unlock_access(self, p):
        self.unlock_access = bool(p.get('on'))

    # ------------------------------------------------------------------ log folders
    def _load_log_folders(self):
        activity, charge = self._default_activity, self._default_charge
        data = self._load_json(self._log_prefs)
        try:
            if data.get('activity'):
                activity = Path(data['activity'])
            if data.get('charge'):
                charge = Path(data['charge'])
        except TypeError:
            pass
        return activity, charge

    def _save_log_folders(self):
        self._log_prefs.parent.mkdir(parents=True, exist_ok=True)
        self._log_prefs.write_text(json.dumps({'activity': str(self._status_log.root),
                                               'charge': str(self._charge_rec.root)}, indent=2),
                                   encoding='utf-8')

    def a_set_activity_folder(self, p):
        path = p.get('path')
        if not path:
            return
        self._status_log.set_root(Path(path))
        self._save_log_folders()
        self._status_log.log('SYS', f'activity folder → {path}')
        self.report(f'Activity logs → {path}')

    def a_set_charge_folder(self, p):
        path = p.get('path')
        if not path:
            return
        if self._charge_snoop:
            raise Notice('Stop charge recording first.', 'Charge folder', 'warn')
        try:
            self._charge_rec.set_root(Path(path))
        except RuntimeError as exc:
            raise Notice(str(exc), 'Charge folder', 'danger')
        self._save_log_folders()
        self._status_log.log('SYS', f'charge folder → {path}')
        self.report(f'Charge logs → {path}')

    def a_reset_folders(self, p):
        if self._charge_snoop:
            raise Notice('Stop charge recording first.', 'Log folders', 'warn')
        self._status_log.set_root(self._default_activity)
        self._charge_rec.set_root(self._default_charge)
        self._save_log_folders()
        self.report('Log folders reset to defaults')
        return {'message': 'Log folders reset to defaults'}

    # ------------------------------------------------------------------ status monitor
    def a_monitor_start(self, p):
        self._need_conn('Status')
        self._start_monitor()

    def _start_monitor(self):
        def done(_):
            self.status_on = True
            self.live = True          # reuse the dump poll path
            self.replay = False
            self._logged_faults.clear()
            self._status_log.log('SYS', f'monitor start (mode={self.mode})')
        self.run('Start status monitor', self.scooter.start_live, done)

    def a_monitor_stop(self, p):
        if self._charge_snoop:
            self._toggle_charge_snoop()
        self.status_on = False
        self._status_log.log('SYS', 'monitor stop')

    def a_notif_clear(self, p):
        self._notif_seen = None
        self.notifications.clear()

    def a_vitals_log(self, p):
        self.auto_log_vitals = bool(p.get('on'))
        self._status_log.log('LIVE', 'vitals heartbeat ON' if self.auto_log_vitals else 'vitals heartbeat OFF')

    def a_log_open(self, p):
        folder = Path(self._status_log.root)
        folder.mkdir(parents=True, exist_ok=True)
        self._open_path(folder)

    def a_charge_folder_open(self, p):
        folder = Path(self._charge_rec.root)
        folder.mkdir(parents=True, exist_ok=True)
        self._open_path(folder)

    @staticmethod
    def _open_path(folder):
        try:
            if sys.platform.startswith('win'):
                os.startfile(str(folder))
            else:
                import subprocess
                subprocess.Popen(['open' if sys.platform == 'darwin' else 'xdg-open', str(folder)])
        except OSError as exc:
            raise Notice(f'{folder}\n({exc})', 'Logs')

    def a_log_clear(self, p):
        self._confirm(p, 'Clear log', 'Clear the current activity log session?', button='Clear')
        self._status_log.clear()

    def a_log_export(self, p):
        path = p.get('path')
        if not path:
            return
        Path(path).write_text(self._status_log.export_text(), encoding='utf-8')
        self.report(f'Activity log exported: {path}')
        return {'message': f'Exported to {path}'}

    def _update_vehicle_notifications(self, snap):
        result = decode_vehicle_notification(snap)
        code = None if not result else result[0]
        if code == self._notif_seen:          # 0x6D0 holds the last code until it changes
            return
        self._notif_seen = code
        if not result:
            return
        _, name, is_alert = result
        self.notifications.appendleft({'time': time.strftime('%H:%M:%S'), 'code': code,
                                       'name': name, 'alert': bool(is_alert)})
        self._status_log.log('NOTE', f'0x6D0 {name} ({code})')

    def _update_feature_status(self, snap):
        fs = decode_feature_status(snap)
        if not fs or fs['raw'] == self._feat_raw:
            return
        self._feat_raw = fs['raw']
        self._feat_bytes = fs.get('raw_bytes')
        self.features = {'features': [[n, bool(on)] for n, on in fs['features'].items()],
                         'tech_packs': [[n, _jsonable(v)] for n, v in fs['tech_packs'].items()]}

    def a_feature_reveal(self, p):
        self._need_idle()
        self._need_conn('Reveal feature UI')
        self._need_bench('Reveal feature UI')
        name = p.get('name')
        if name not in ('Energy insights', 'Hyper charger', 'Fast charger'):
            raise Notice('Choose a feature.', 'Reveal feature UI')
        base = self._feat_bytes
        if not base:
            raise Notice('No 0x660 frame seen yet — wait for the Features card to populate, then retry.',
                         'Reveal feature UI', 'warn')
        hyper = ('\n\nNote: Hyper charge shows the UI only — actual hyper charging stays cloud/payment-gated '
                 'and will NOT be authorised by this.' if name == 'Hyper charger' else '')
        self._confirm(p, 'Reveal feature UI (0x660 test)',
                      f'Inject 0x660 so the head unit sees “{name}” available, to test whether its built-in UI '
                      'appears (it is normally suppressed only while dues are unpaid).\n\nThis is a NON-PERSISTENT '
                      'test: it re-injects for ~20 s, fights the real BCM broadcast, and reverts on stop/reboot. '
                      f'It does not change the cloud/BCM value.{hyper}', word='SHOW', tone='danger', button='Inject')
        self.run(f'Reveal {name} UI (0x660)',
                 lambda: self.scooter.enable_feature_0660(name, base, value=1, seconds=20, hz=5),
                 lambda r: self.report(r))

    def a_feature_reveal_stop(self, p):
        if not self.connected:
            return
        self.run('Stop 0x660 injection', self.scooter.stop_feature_0660, lambda r: self.report(r))

    # ------------------------------------------------------------------ charge recorder
    def a_charge_record(self, p):
        self._need_conn('Charge recording')
        self._toggle_charge_snoop()

    def _toggle_charge_snoop(self):
        if self._charge_snoop:
            path = self._charge_rec.stop()
            self._detach_charge_observer()
            self._charge_snoop = False
            self._status_log.log('CHARGE', f'session stop → {path} frames={self._charge_rec.frames} '
                                           f'vitals={self._charge_rec.vitals}')
            self.report(f'Charge session saved: {path}')
            self.emit('toast', 'Charge session saved', str(path), 'ok')
            return
        if not self.status_on and not self.live:
            self._start_monitor()
        path = self._charge_rec.start()
        self._attach_charge_observer()
        self._charge_snoop = True
        self._status_log.log('CHARGE', f'session start → {path}')
        self.emit('sheet', 'Recording charge session',
                  f'Recording charge-related IDs + vitals (SOC/V/A/contactor) to:\n{path}\n\n'
                  'Plug in Bolt Blaze (or Hyper) now and keep Wi‑Fi connected.\n'
                  'This is vehicle CAN — SC demand/status usually appear; SC auth 0x080 and full Hyper '
                  'may need a charge-port tap.')

    def _attach_charge_observer(self):
        t = self.scooter.t
        if not t:
            return
        prev = t.observer
        rec = self._charge_rec

        def combined(stamp, cid, data):
            if prev:
                try:
                    prev(stamp, cid, data)
                except Exception:
                    pass
            try:
                rec.on_frame(stamp, cid, data)
            except Exception:
                pass
        with t.sample_lock:
            t.observer = combined
            t._charge_prev_observer = prev

    def _detach_charge_observer(self):
        t = self.scooter.t
        if not t:
            return
        with t.sample_lock:
            t.observer = getattr(t, '_charge_prev_observer', None)
            if hasattr(t, '_charge_prev_observer'):
                del t._charge_prev_observer

    # ------------------------------------------------------------------ charging commands
    def a_fast_display(self, p):
        self._need_idle()
        self._need_conn('Show as Fast')
        if not getattr(self.scooter, 'streaming', False):
            raise Notice('Start the monitor first so the charger-liveness signal (0x213) is available.',
                         'Show as Fast')
        self._need_bench('Show as Fast')
        self._confirm(p, 'Show as Fast charging',
                      'Inject the display frames 0x62D / 0x143 so the dash shows FAST charging over the real '
                      'charge.\n\nDisplay only — the charge control frames are not touched. It auto-stops and '
                      'shows “charging stopped” the moment the charger CAN goes quiet.', button='Inject')
        self.run('Show as Fast charging', lambda: self.scooter.force_fast_charge_display(hz=20),
                 lambda r: self.report(r))

    def a_fast_display_stop(self, p):
        if not self.connected:
            return
        self.run('Stop Fast display', self.scooter.stop_fast_charge_display, lambda r: self.report(r))

    def a_charge_cmd(self, p):
        self._need_idle()
        ordinal = int(p.get('ordinal', -1))
        label = hc._LABEL_BY_ORDINAL.get(ordinal)
        if not label or ordinal not in (13, 48, 49):
            raise Notice(f'Unknown command {ordinal}', 'Charge command', 'danger')
        self._need_conn('Charge command')
        self._need_bench('Charge command')
        self._confirm(p, 'Confirm charge command', f'{label}\n\nRED, UNVERIFIED — sends once, no undo.',
                      word='SEND', tone='danger', button='Send')
        self.run('HMI ' + label, lambda: hc.send_once(self.scooter, label),
                 lambda r: self.emit('sheet', 'Charge command', r))

    def a_charge_recover(self, p):
        self._need_idle()
        self._need_conn('Recovery')
        self._need_bench('Recovery')
        self._confirm(p, 'Confirm recovery', 'Sends Boost Disable (49) then Stop Charge (13) — two RED, '
                      'UNVERIFIED writes.', word='SEND', tone='danger', button='Send both')

        def seq():
            out = []
            for o in (49, 13):
                lbl = hc._LABEL_BY_ORDINAL[o]
                try:
                    out.append(hc.send_once(self.scooter, lbl))
                except Exception as exc:
                    out.append(f'{lbl}: {exc}')
            return '\n\n'.join(out)
        self.run('Charge recovery', seq, lambda r: self.emit('sheet', 'Recovery result', r))

    # ------------------------------------------------------------------ status tick
    def _tick_status(self):
        if not self.status_on or not self.scooter.t:
            return
        with self.scooter.t.sample_lock:
            snap = dict(self.scooter.t.latest)
        if not snap:
            return
        dbc = self.scooter.dbc
        faults = active_faults(dbc, snap)
        for f in faults:
            if f not in self._logged_faults:
                self._status_log.log('FAULT', f'SET   {f}')
        for f in self._logged_faults:
            if f not in faults:
                self._status_log.log('FAULT', f'CLEAR {f}')
        self._logged_faults = set(faults)
        self.faults = sorted(faults)

        self.hw_variants = decode_hardware(snap)
        self.cell_dcir = decode_dcir(snap)
        self.vehicle_state = decode_vehicle_state(dbc, snap)
        self._record_batt_history(dbc, snap)
        batt = decode_battery(dbc, snap)
        chg = enrich_power(decode_charge(dbc, snap), batt)
        self._record_graph(batt, chg)
        if self.recorder.active:
            self._record_session(batt, chg)
        extra = decode_charge_extra(snap)
        if not chg.get('charger_type') and extra.get('charger_type') not in (None, 'None'):
            chg['charger_type'] = extra['charger_type']
        if chg.get('charger_type') == 'None':          # 0x62D "no charger" — not a charger type
            chg['charger_type'] = None
        if chg.get('plugged') is None:
            chg['plugged'] = extra.get('plugged')
        sv = self.sv

        def fmt(v, spec):
            return '—' if v is None else format(v, spec)
        if batt:
            sv['soc'] = fmt(batt['soc'], '.0f')
            sv['range'] = fmt(batt['range_km'], '.0f')
            sv['volts'] = fmt(batt['volts'], '.1f')
            sv['amps'] = fmt(batt['amps'], '.1f')
            sv['motor_t'] = fmt(batt.get('motor_t'), '.0f')
            sv['mcu_t'] = fmt(batt.get('mcu_t'), '.0f')
            label = 'Not plugged in'
            if batt['charger_connected']:
                label = 'Charging' if batt['charging'] else 'Connected'
            if chg.get('charger_type'):
                label = chg['charger_type'] + ('' if not batt['charging'] else ' · ON')
            if extra.get('billing'):
                label += ' · BILLED'
            if extra.get('connector_latched'):
                label += ' · latched'
            sv['chg'] = label
        sv['power'] = fmt(chg.get('power_w'), '.0f')
        sv['ctype'] = chg.get('charger_type') or '—'
        sv['vl1'] = chg.get('veh_l1') or '—'
        sv['vl2'] = chg.get('veh_l2') or '—'
        sv['ilim'] = fmt(chg.get('charge_i_lim'), '.1f')
        sv['vlim'] = fmt(chg.get('charge_v_lim'), '.2f')
        sv['avail_i'] = fmt(chg.get('chg_avail_i'), '.1f')
        sv['cmode'] = chg.get('chg_mode') or '—'
        sv['crate'] = chg.get('chg_rate') or '—'
        sv['billing'] = 'YES (paid session)' if extra.get('billing') else 'no'
        sv['evse'] = extra.get('evse_id') or '—'

        self._update_vehicle_notifications(snap)
        self._update_feature_status(snap)

        if self._charge_snoop:
            fields = {
                'soc': None if not batt else batt.get('soc'),
                'range_km': None if not batt else batt.get('range_km'),
                'pack_v': None if not batt else batt.get('volts'),
                'pack_a': None if not batt else batt.get('amps'),
                'power_w': chg.get('power_w'),
                'charging': False if not batt else batt.get('charging'),
                'charger_connected': False if not batt else batt.get('charger_connected'),
                'charger_type': chg.get('charger_type'), 'plugged': chg.get('plugged'),
                'contactor': chg.get('contactor'), 'charge_v_lim': chg.get('charge_v_lim'),
                'charge_i_lim': chg.get('charge_i_lim'), 'chg_avail_v': chg.get('chg_avail_v'),
                'chg_avail_i': chg.get('chg_avail_i'), 'chg_mode': chg.get('chg_mode'),
                'chg_rate': chg.get('chg_rate'), 'veh_l1': chg.get('veh_l1'), 'veh_l2': chg.get('veh_l2'),
                'auth_err': chg.get('auth_err'), 'sc_fault': chg.get('sc_fault'),
                'billing': extra.get('billing'), 'connector_latched': extra.get('connector_latched'),
                'evse_id': extra.get('evse_id'),
                'motor_t': None if not batt else batt.get('motor_t'),
                'mcu_t': None if not batt else batt.get('mcu_t'),
                'active_faults': len(faults),
            }
            try:
                self._charge_rec.on_vitals(fields)
            except Exception:
                pass

        now = time.time()
        if self.auto_log_vitals and batt and now - self._last_vitals_log > 30:
            self._last_vitals_log = now
            self._status_log.log(
                'LIVE', f"soc={batt.get('soc')} range={batt.get('range_km')} V={batt.get('volts')} "
                        f"A={batt.get('amps')} chg={batt.get('charging')} type={chg.get('charger_type')} "
                        f"ilim={chg.get('charge_i_lim')} mode={chg.get('veh_l2')} faults={len(faults)}")

    # ------------------------------------------------------------------ calibration
    def a_read_motor_angle(self, p):
        self._need_idle()
        self._need_read('Motor angle')

        def done(r):
            self.cal['motor_angle'] = f"{r['degrees']:.1f}"
            self.cal['cal_status'] = f"B113 read OK · raw=0x{r['raw']:04X} · {r['hex']}"
            self.report(f"Motor angle {r['degrees']:.1f}°")
        self.run('Read motor angle B113', self.scooter.read_motor_angle, done, resume=True)

    def a_mcu_cal(self, p):
        self._need_idle()
        action = p.get('action')
        if action not in ('start', 'stop'):
            raise Notice('Unknown AutoTune action.', 'MCU cal', 'danger')
        self._need_conn('MCU cal')
        self._need_bench('MCU cal')
        word = 'START' if action == 'start' else 'STOP'
        self._confirm(p, 'Confirm MCU AutoTune',
                      f'This will {word} motor AutoTune (RMT_CMD_MCU_CAL).\n\nCentre stand only — the motor may '
                      'spin / learn angle. Wrong use can cause overcurrent or runaway torque.',
                      word=word, tone='danger', button=word.title())

        def done(msg):
            self.cal['cal_status'] = msg
            if action == 'stop':
                self.emit('ask', 'AutoTune stopped', f'{msg}\n\nRead the B113 angle now?',
                          action={'name': 'read_motor_angle', 'label': 'Read B113'})
        self.run(f'mcu-cal {action}', lambda: self.scooter.mcu_cal(action), done)

    def a_read_odometer(self, p):
        self._need_idle()
        self._need_read('Odometer')

        def done(r):
            self.cal['odo_value'] = str(r['km'])
            self.cal['odo_status'] = f"Read OK · {r['km']} km · raw {r['hex']}"
            self.report(f"Odometer {r['km']} km")
        self.run('Read odometer 0103', self.scooter.read_odometer, done, resume=True)

    def a_write_odometer(self, p):
        self._need_idle()
        self._need_conn('Odometer')
        self._need_bench('Odometer')
        raw = str(p.get('km', '')).strip()
        if not raw.isdigit():
            raise Notice('Enter the new odometer value in whole km.', 'Odometer', 'warn')
        km = int(raw)
        self._confirm(p, 'Confirm odometer write',
                      f'This will WRITE the VCU odometer to {km} km (2E 0103).\n\nThis is a real change to the '
                      'vehicle. Legitimate only for restoring the correct reading to a replacement VCU board on '
                      'your own scooter. Falsifying an odometer is illegal in most jurisdictions.',
                      word='WRITE', tone='danger', button='Write')

        def done(r):
            self.cal['odo_value'] = str(r['readback_km'])
            self.cal['odo_status'] = r['message']
            self.report(r['message'])
        self.run(f'Write odometer {km} km', lambda: self.scooter.write_odometer(km), done)

    def a_read_boost(self, p):
        self._need_idle()
        self._need_read('Boost DIDs')

        def done(rows):
            lines = []
            for r in rows:
                if 'error' in r:
                    lines.append(f"{r['name']} ({r['did']}): ERROR {r['error']}")
                else:
                    lines.append(f"{r['name']} ({r['did']}, {r['len']}B): {r['hex']}")
            self.cal['boost_dids'] = '\n'.join(lines)
            self.report('Boost DIDs read')
        self.run('Read Boost DIDs', self.scooter.read_boost_dids, done, resume=True)

    def a_write_boost(self, p):
        self._need_idle()
        self._need_conn('Boost DID')
        self._need_bench('Boost DID')
        did = str(p.get('did', '')).strip().upper()
        if did not in ('B135', 'B13C', 'B13D'):
            raise Notice('Choose B135, B13C or B13D.', 'Boost DID')
        payload = str(p.get('payload', '')).strip().replace(' ', '')
        if not payload:
            raise Notice('Enter the full DID payload as hex first (read it from an entitled bike). '
                         'No default is provided.', 'Boost DID', 'warn')
        self._confirm(p, 'Confirm Boost DID write',
                      f'REAL change to the MCU performance map.\n\nWrite DID {did} = {payload}\n\nBench only, '
                      'centre stand, wheel clear. Wrong values can cause bad torque/commutation. No retry.',
                      word='WRITE', tone='danger', button='Write')

        def done(r):
            self.cal['boost_dids'] = (f"{r['did']}: before={r['before']} wrote={r['wrote']} "
                                      f"readback={r['readback']} match={r['match']}\n{r['message']}")
            self.report(r['message'])
        self.run(f'Write Boost DID {did}', lambda: self.scooter.write_boost_did(did, payload, unlock=True), done)

    def _mem_params(self, p):
        try:
            ecu = str(p.get('ecu', 'MCU')).strip().upper()
            if ecu not in ('MCU', 'VCU', 'BMS'):
                raise ValueError
            addr = int(str(p.get('addr', '')).strip().lower().replace('0x', ''), 16)
            size = int(str(p.get('size', '')).strip())
            return ecu, addr, size
        except ValueError:
            raise Notice('Bad address (hex) or size (whole number).', 'Memory read', 'warn')

    def a_mem_read(self, p):
        self._need_idle()
        self._need_conn('Memory read')
        self._need_bench('Memory read')
        ecu, addr, size = self._mem_params(p)
        self._confirm(p, 'Memory read', f'Read {size} bytes @ 0x{addr:08X} from {ecu} (UDS 0x23, needs unlock)?'
                                        '\n\nRead-only; may return a UDS refusal.', button='Read')

        def done(r):
            self.cal['mem_result'] = f"{ecu} @0x{addr:08X} ({r['len']}B): {r['hex']}"
            self.report(f"Memory read OK ({r['len']}B)")
        self.run('UDS read memory', lambda: self.scooter.uds_read_memory(ecu, addr, size), done)

    def a_mem_dump(self, p):
        self._need_idle()
        self._need_conn('Memory dump')
        self._need_bench('Memory dump')
        ecu, addr, size = self._mem_params(p)
        self._confirm(p, 'Confirm dump', f'Bulk-upload {size} bytes @ 0x{addr:08X} from {ecu} via UDS 0x35/0x36.'
                                         '\n\nRead-only but long.', word='DUMP', tone='danger', button='Dump')
        out_dir = ROOT / 'captures' / 'dumps'
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f'{ecu}_{addr:08X}_{size}.bin'

        def work():
            data = self.scooter.uds_upload(ecu, addr, size)
            out.write_bytes(data)
            return {'path': str(out), 'len': len(data)}

        def done(r):
            self.cal['mem_result'] = f"Dumped {r['len']} B → {r['path']}"
            self.report(f"Memory dump saved: {r['path']}")
        self.run('UDS memory dump', work, done)

    def a_feature_toggle(self, p):
        self._need_idle()
        self._need_conn('Feature toggle')
        self._need_bench('Feature toggle')
        if self.replay:
            raise Notice('Connect to a live scooter first.', 'Offline')
        ordinal = int(p.get('ordinal', -1))
        allowed = {o for _, a, b in FEATURE_TOGGLES for o in (a, b)} | {o for _, o in REGEN_TYPES}
        label = hc._LABEL_BY_ORDINAL.get(ordinal)
        if not label or ordinal not in allowed:
            raise Notice(f'Unknown command ordinal {ordinal}', 'Feature toggle', 'danger')
        self._confirm(p, 'Feature toggle', f'Send “{label}” once?\n\nUnverified on MoveOS 5 — check the scooter / '
                                           'notifications after.', button='Send')
        self.run('HMI ' + label, lambda: hc.send_once(self.scooter, label),
                 lambda r: self.emit('sheet', 'Feature toggle result', r))

    # ------------------------------------------------------------------ ECU tests / modes
    def a_refresh_mode(self, p):
        self._need_idle()
        self.run('Read mode', self.scooter.info, self.info)

    def a_set_mode(self, p):
        self._need_idle()
        mode = p.get('mode')
        if mode not in ('SERVICE', 'CUST'):
            raise Notice('Unsupported mode.', 'Mode', 'danger')
        self._confirm(p, 'Change scooter mode', f'Set the scooter to {mode}?\n\nPark the scooter. Service mode '
                      'changes diagnostic access and vehicle behaviour.', button='Change mode')
        self.current = None
        self.run('Set ' + mode, lambda: self.scooter.mode(mode), self.info)

    def a_bf07(self, p):
        self._need_idle()
        self._confirm(p, 'BF07 lock/unlock sequence', 'Run VCU routine BF07 over Wi‑Fi?\n\nUndirected sequence '
                      '(not separate Lock/Unlock). Final state unverified. Prefer Wi‑Fi Lock / Unlock / Trunk, '
                      'or Bluetooth for consumer lock.', button='Run')
        self.run('BF07 sequence', self.scooter.lock_unlock_sequence)

    def a_wifi_lock(self, p):
        self._need_idle()
        self._confirm(p, 'Wi‑Fi Lock', 'Send experimental Wi‑Fi Lock (Steering Lock 0400 ON + BF07)?\n\n'
                                       'Check the scooter physically afterward.', button='Lock')
        self.run('Wi‑Fi Lock', self.scooter.wifi_lock)

    def a_wifi_unlock(self, p):
        self._need_idle()
        self._confirm(p, 'Wi‑Fi Unlock', 'Send experimental Wi‑Fi Unlock (Steering Lock 0400 OFF + BF07)?\n\n'
                                         'Check the scooter physically afterward.', button='Unlock')
        self.run('Wi‑Fi Unlock', self.scooter.wifi_unlock)

    def a_wifi_trunk(self, p):
        self._need_idle()
        self._confirm(p, 'Trunk (Wi‑Fi)', 'Pulse Seat Lock 0402 over Wi‑Fi (trunk)?\n\nSame path as the Seat Lock '
                                          'actuator.', button='Open trunk')
        self.run('Trunk Wi‑Fi', self.scooter.wifi_trunk_pulse)

    def a_actuator_test(self, p):
        self._need_idle()
        name = p.get('name')
        if name not in ACTUATORS:
            raise Notice('Choose a component test.', 'Actuator test')
        did = ACTUATORS[name]
        if name in ACTUATOR_DANGER:
            self._confirm(p, 'Confirm risky actuator',
                          f'{name}  (VCU DID {did:04X})\n\nThis drives a contactor, lock, charger or power rail — it '
                          'can move hardware or switch power even with the scooter parked. Only proceed if you know '
                          'exactly what this output does.', word='TEST', tone='danger', button='Pulse')
        else:
            self._confirm(p, 'Actuator test',
                          f'Test {name} on the VCU now?  (DID {did:04X})\n\nNeeds Service mode and a parked scooter. '
                          'The VCU is unlocked automatically and held open by a keepalive; the test sends ON, holds '
                          '~2 s, then OFF.\n\nAn acknowledgement confirms a command response, not that the part '
                          'physically moved.', button='Run test')
        self.run(name + ' test', lambda: self.scooter.pulse(name))

    def a_hmi_send(self, p):
        self._need_idle()
        ordinal = int(p.get('ordinal', -1))
        label = hc._LABEL_BY_ORDINAL.get(ordinal)
        if not label:
            raise Notice(f'Unknown command {ordinal}', 'HMI command', 'danger')
        if not p.get('ready') or not self.bench:
            raise Notice('Confirm the bench setup on this page and turn on Bench mode first.', 'Bench setup', 'warn')
        if self.replay:
            raise Notice('Exit replay and connect to a live scooter first.', 'Offline capture')
        tier = hc.risk(ordinal)
        if tier == 'danger':
            self._confirm(p, 'Confirm red command', f'{label}\n\nThis is a RED command (drive / moving part / '
                          'reboot / charge / entitlement) and is UNVERIFIED on this firmware. It sends once with no '
                          'automatic undo. Keep the throttle untouched.', word='SEND', tone='danger', button='Send')
        elif tier == 'caution':
            self._confirm(p, 'Confirm', f'Send “{label}” once?\n\nUnverified command — check the scooter afterwards.',
                          button='Send')
        else:
            self._confirm(p, 'Send', f'Send “{label}” once?', button='Send')
        self.run('HMI ' + label, lambda: hc.send_once(self.scooter, label),
                 lambda r: self.emit('sheet', 'HMI result', r))

    # ------------------------------------------------------------------ live data
    def a_live_start(self, p):
        self._need_idle()

        def done(_):
            self.live, self.replay = True, False
            self.rows.clear()
        self.run('Start live data', self.scooter.start_live, done)

    def a_live_pause(self, p):
        self.live = False
        self.report('Display paused. Received values age; CAN reader remains available for diagnostics.')

    def accept_rows(self, rows):
        for row in rows:
            self.rows[(row[0], row[2])] = row

    def a_replay(self, p):
        self._need_idle()
        path = p.get('path')
        if not path:
            return
        try:
            with open(path, encoding='utf-8-sig') as f:
                data = json.load(f)
            rows = []
            for cid, msg in data['decoded'].items():
                for name, signal in msg['signals'].items():
                    rows.append((cid.replace('0x', ''), msg['message'], name, signal['value'],
                                 signal.get('units', ''), 0))
        except Exception as exc:
            raise Notice(str(exc), 'Capture', 'danger')
        self.live, self.replay = False, True
        self.rows.clear()
        self.accept_rows(rows)
        return {'message': f'Loaded {len(rows)} signals from capture'}

    def a_export_csv(self, p):
        path = p.get('path')
        if not path:
            return
        try:
            with open(path, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f)
                writer.writerow(['CAN ID', 'Message', 'Signal', 'Value', 'Unit', 'Received Unix time', 'Source'])
                writer.writerows([*row, 'offline capture' if self.replay else 'live session']
                                 for row in self.rows.values())
        except OSError as exc:
            raise Notice(str(exc), 'Export', 'danger')
        self.report('Exported ' + path)
        return {'message': 'Exported ' + path}

    def _live_state(self):
        now = time.time()
        fresh = 0
        metrics = {k: '—' for k, _, _ in LIVE_METRICS}
        rows = []
        for (cid, msg, signal, value, unit, stamp) in self.rows.values():
            stale = self.replay or now - stamp > 3
            fresh += int(not stale)
            if signal in metrics:
                metrics[signal] = f'{value} {unit}'.strip() if not stale else ('OFFLINE' if self.replay else 'STALE')
            age = 'OFFLINE' if self.replay else f'{now - stamp:.1f}s'
            rows.append([cid, msg, signal, _jsonable(value), unit, age, stale])
        state = 'OFFLINE CAPTURE' if self.replay else 'LIVE' if self.live else 'PAUSED'
        return {'state': state, 'rows': rows, 'metrics': metrics, 'fresh': fresh, 'total': len(self.rows)}

    # ------------------------------------------------------------------ passive learning
    def a_learn_new(self, p):
        self._need_idle()
        label = str(p.get('label', '')).strip()
        try:
            self.learn = LearningSession(label, ROOT / 'captures/gui/learning',
                                         {'endpoint': self.host + ':' + self.port,
                                          'mode_and_firmware': f'Mode: {self.mode} | Firmware: {self.firmware}'})
        except ValueError as exc:
            raise Notice(str(exc), 'New session', 'warn')
        self.learn_candidates, self.learn_report = [], None
        self.learn_status = 'Session ready'
        self._learn_stage()

    def _learn_stage(self):
        if not self.learn:
            return
        index = len(self.learn.data['phases'])
        if index < 5:
            state = 'ON / active' if index in (1, 3) else 'OFF / released'
            self.learn_instructions = f'{index + 1}/5 • {self.learn.data["label"]}: set {state}, then record.'
        else:
            self.learn_instructions = 'Sequence complete. Review the repeated associations below.'
            self._learn_analyze()

    def a_learn_capture(self, p):
        self._need_idle()
        session = self.learn
        if session is None:
            raise Notice('Start a new session first.', 'Capture')
        self._need_conn('Capture')
        if len(session.data['phases']) >= 5:
            return
        self.live = False
        self.learn_status = 'Hold the selected state: settling for 3 seconds, then recording for 8 seconds.'

        def done(result):
            self.learn_status = result
            self._learn_stage()
        self.run('Passive capture: ' + PHASES[len(session.data['phases'])],
                 lambda: self.scooter.capture_stage(session), done)

    def _learn_analyze(self):
        self.learn_candidates, self.learn_report = [], None
        self.learn_status = 'Comparing all raw bits and named signals across five stages…'
        session = self.learn

        def analyze():
            report = analysis_report(session.data, self.scooter.dbc)
            session.path.with_suffix('.analysis.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
            return report

        def done(report):
            self.learn_report = report
            self.learn_candidates = report['candidates']
            self.learn_status = (f'{len(self.learn_candidates)} candidates. Raw evidence: {session.path.name}'
                                 if self.learn_candidates else
                                 f'0 repeatable candidates; {len(report["changed_unverified"])} changing signals/bits. '
                                 'Use “Phase evidence” for OFF/ON distributions.')
        if self.busy:          # e.g. stage just finished inside another result; retry shortly
            self.inbox.put(('call', self._learn_analyze, {}, threading.Event()))
            return
        self.run('Analyze observed signals', analyze, done, quiet=True)

    def a_learn_evidence(self, p):
        if not self.learn_report or not self.learn:
            raise Notice('Finish or open a session first.', 'Phase evidence')
        r = self.learn_report
        parts = [r['timestamp_limit'], '', *r['issues'], '']
        parts += [str(q) for q in r['quality']]
        for item in r['changed_unverified']:
            parts.append(f'\nUNVERIFIED {item["can_id"]} {item["name"]}')
            for phase, counts in zip(self.learn.data['phases'], item['phase_counts']):
                parts.append(f'  {phase["name"]}: ' + ', '.join(f'{v} × {c}' for v, c in counts))
        self.emit('sheet', 'Phase evidence — changing signals are UNVERIFIED', '\n'.join(parts))

    def a_learn_save(self, p):
        if not self.learn:
            return
        try:
            candidate = self.learn_candidates[int(p.get('index', -1))]
        except (ValueError, IndexError):
            raise Notice('Select a candidate first.', 'Save association')
        self._confirm(p, 'Save observed association',
                      f'Label {candidate["can_id"]} / {candidate["name"]} as {self.learn.data["label"]}?\n\n'
                      'This labels observed data only. It does not establish a transmit command.', button='Save')
        try:
            self.learn_status = self.learn.save_mapping(candidate)
            self.scooter.reload_mappings()
        except (ValueError, OSError) as exc:
            raise Notice(str(exc), 'Save mapping', 'danger')

    def a_learn_open(self, p):
        self._need_idle()
        filename = p.get('path')
        if not filename:
            return
        try:
            path = Path(filename)
            if path.stat().st_size > 100_000_000:
                raise ValueError('Session file is too large')
            data = json.loads(path.read_text(encoding='utf-8'))
            if data.get('schema') != 1 or not data.get('passive') or not 1 <= len(data['phases']) <= 5:
                raise ValueError('Choose a passive learning session with 1–5 stages')
            self.learn = LearningSession(data['label'], ROOT / 'captures/gui/learning', data.get('context'))
            self.learn.data = data      # save a local copy; the original import stays untouched
            self.learn.save()
            self.learn_instructions = 'Imported evidence: review only. Start a new session for a fresh sequence.'
            self._learn_analyze()
        except (ValueError, KeyError, TypeError, OSError) as exc:
            raise Notice(str(exc), 'Session', 'danger')

    def _learn_state(self):
        phases = len(self.learn.data['phases']) if self.learn else 0
        cands = []
        for c in self.learn_candidates:
            on = ', '.join(str(pair[0]) for pair in c['on'][0])
            cands.append([_jsonable(c['score']), c['can_id'], c['kind'], c['name'], _jsonable(c['off']), on])
        return {'active': bool(self.learn), 'label': self.learn.data['label'] if self.learn else '',
                'phases': phases, 'instructions': self.learn_instructions, 'status': self.learn_status,
                'candidates': cands, 'has_report': bool(self.learn_report)}

    # ------------------------------------------------------------------ components / catalog
    def a_read_did(self, p):
        self._need_idle()
        try:
            did = bytes.fromhex(str(p.get('did', '')))
            if len(did) != 2:
                raise ValueError('DID must contain exactly four hex digits')
            ecu = Ecu[str(p.get('ecu', 'MCU'))]
        except (ValueError, KeyError) as exc:
            raise Notice(str(exc) or 'Bad ECU / DID', 'Identifier', 'warn')
        self._need_read('Identifier')
        self.run(f'Read {ecu.name} {did.hex().upper()} (no session change)', lambda: self.scooter.read(ecu, did),
                 lambda r: self.emit('sheet', 'Component response', f'{ecu.name} / {did.hex().upper()}\n'
                                                                    f'Data bytes: {r.hex(" ")}'), resume=True)

    def a_read_faults(self, p):
        self._need_idle()
        ecu = Ecu[str(p.get('ecu', 'MCU'))]
        self._need_read('Stored faults')

        def fmt():
            faults = self.scooter.read_faults(ecu)
            if not faults:
                return 'No stored fault codes.'
            return '\n'.join(f"{f['code']}  {f['description']}\n        {', '.join(f['status_flags'])}"
                             for f in faults)
        self.run(f'{ecu.name} faults', fmt, lambda r: self.emit('sheet', f'Stored faults · {ecu.name}', r), resume=True)

    def a_open_session(self, p):
        self._need_idle()
        ecu, unlock = Ecu[str(p.get('ecu', 'MCU'))], self.unlock_access
        self._confirm(p, 'State-changing diagnostic session',
                      f'Enter extended diagnostic session on {ecu.name}?\nSecurity access: '
                      f'{"requested" if unlock else "not requested"}.\n\nThis sends 10 03 before any security request. '
                      'Previous identifier reads interrupted charging. Charger must be disconnected and scooter parked. '
                      'The session may affect contactors or vehicle operation.\n\nOrdinary Read identifier / Read '
                      'faults buttons never send this request.', button='Open session')
        self.run(f'Explicit {ecu.name} session', lambda: self.scooter.open_diagnostic_session(ecu, unlock))

    def a_read_setting(self, p):
        self._need_idle()
        name = p.get('name')
        if name not in SETTINGS:
            raise Notice('Choose a setting.', 'Setting')
        definition = SETTINGS[name]
        did = bytes.fromhex(definition['RequestFormat'])[1:]
        self._need_read('Setting')

        def done(raw):
            try:
                values = decode_setting(definition, raw)
            except ValueError as exc:
                self.current = None
                raise Notice(str(exc), 'Definition mismatch', 'danger')
            self.current = (name, raw)
            self.setting_values = {'name': name, 'raw': raw.hex(' '),
                                   'values': {k.strip(): _jsonable(v) for k, v in values.items()}}
        self.run('Read ' + name + ' (no session change)', lambda: self.scooter.read(Ecu.MCU, did), done, resume=True)

    def catalog(self):
        if self._catalog is None:
            from diagnostic_pages import catalog
            self._catalog = catalog()
        return self._catalog

    def a_catalog_detail(self, p):
        entries = self.catalog()
        try:
            ecu, source, name, definition, did = entries[int(p.get('i', -1))]
        except (ValueError, IndexError):
            raise Notice('Select an entry.', 'Catalog')
        text = json.dumps(definition, indent=2, ensure_ascii=False)
        if source == 'CAN' or source.endswith(' CAN'):
            signal = definition.get('DBC Name')
            want = str(definition.get('CAN ID (Hex)', '')).upper().lstrip('0')
            rows = [r for r in self.rows.values() if r[2] == signal and r[0].upper().lstrip('0') == want]
            text += '\n\nReceived snapshot: ' + (str(rows[-1]) if rows else 'Not received')
        elif did is None:
            text += '\n\nNo explicit DID in this live-parameter entry. Search the ODX reads; no address is guessed.'
        return {'text': text, 'readable': did is not None}

    def a_catalog_read(self, p):
        self._need_idle()
        entries = self.catalog()
        try:
            ecu, source, name, definition, did = entries[int(p.get('i', -1))]
        except (ValueError, IndexError):
            raise Notice('Select an entry.', 'Catalog')
        if did is None:
            return
        self._need_read('Catalog')
        self.run(f'Read {ecu} {did.hex()} {name}', lambda: self.scooter.read(Ecu[ecu], did),
                 lambda raw: self.emit('sheet', name, f'Received {time.strftime("%Y-%m-%d %H:%M:%S")}\n'
                                                      f'Raw payload: {raw.hex(" ")}\n\nDefinition (encoding not '
                                                      'automatically inferred):\n' + json.dumps(definition, indent=2)), resume=True)

    # ------------------------------------------------------------------ diagnostics (health)
    def _tick_health(self):
        from health_dashboard import snapshot
        now = time.time()
        self.health = snapshot(self.scooter.dbc, list(self.rows.values()), now,
                               self.connected, self.live, self.replay)
        faults = self.health['Fault signals']
        current = {(x['id'], x['signal']): (x['state'], x.get('flag'), x['value']) for x in faults}
        if not self.replay:
            for key, value in current.items():
                old = self._health_prev.get(key)
                if old is not None and old != value:
                    self.health_events.append({'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'id': key[0],
                                               'signal': key[1], 'before': old, 'after': value})
        self._health_prev = {} if self.replay else current

    def _health_state(self):
        groups = {}
        for name, items in self.health.items():
            rows = []
            for x in items:
                state = x.get('flag', x['state'])
                if state == 'Unknown':
                    state = x['state']
                value = '—' if x['value'] is None else f'{x["value"]} {x["unit"]}'.strip()
                tag = 'asserted' if state == 'Asserted' else 'unknown' if x['state'] != 'Fresh' else ''
                rows.append([x['id'], x['signal'], value, state,
                             '—' if x['age'] is None else f'{x["age"]:.1f}s', tag])
            groups[name] = rows
        groups['Events'] = [[e['id'], e['signal'], str(e['after'][2]),
                             f'{e["before"][0]} → {e["after"][0]} / {e["after"][1]}', e['time'], '']
                            for e in reversed(self.health_events)]
        stored = []
        for name, r in self.health_stored.items():
            if r['error']:
                stored.append([name, r['error'], '—', 'Read failed', r['time'], 'unknown'])
            elif not r['faults']:
                stored.append([name, 'No DTCs returned for requested mask', '—', 'Snapshot', r['time'], ''])
            else:
                for f in r['faults']:
                    stored.append([name, f['description'], f['code'], ', '.join(f['status_flags']), r['time'], ''])
        groups['Stored DTCs'] = stored
        faults = self.health.get('Fault signals', [])
        asserted = sum(x.get('flag') == 'Asserted' for x in faults)
        unknown = sum(x['state'] != 'Fresh' for x in faults)
        summary = (f'{asserted} asserted fault flags · {unknown}/{len(faults)} unavailable as current data · '
                   'stored DTCs read separately')
        return {'groups': _jsonable(groups), 'summary': summary, 'asserted': asserted}

    def a_read_dtc(self, p):
        self._need_idle()
        ecu = Ecu[str(p.get('ecu', 'MCU'))]
        self._need_read('Stored DTCs')

        def read():
            try:
                return {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'faults': self.scooter.read_faults(ecu),
                        'error': None}
            except Exception as exc:
                return {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'faults': None, 'error': str(exc)}

        def done(result):
            self.health_stored[ecu.name] = result
        self.run(f'{ecu.name} DTC snapshot', read, done, resume=True)

    def a_health_export(self, p):
        path = p.get('path')
        if not path:
            return
        self._tick_health()
        report = {'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                  'mode': f'Mode: {self.mode} | Firmware: {self.firmware}', 'offline': self.replay,
                  'observations': self.health, 'stored_dtcs': self.health_stored,
                  'events': list(self.health_events), 'event_limit': 1000}
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(_jsonable(report), f, indent=2)
        except OSError as exc:
            raise Notice('Export failed: ' + str(exc), 'Export', 'danger')
        self.report('Saved diagnostic report: ' + path)
        return {'message': 'Saved diagnostic report'}

    # ------------------------------------------------------------------ software
    def a_rpc(self, p):
        self._need_idle()
        method = p.get('method')
        if method not in {m for _, m in UPDATE_RPCS}:
            raise Notice('Unknown request.', 'Software', 'danger')

        def done(value):
            self.update_text = time.strftime('%Y-%m-%d %H:%M:%S') + '  ·  ' + method + '\n' + str(value)
        self.run(method, lambda: self.scooter.rpc(method), done)

    def a_fw_flash(self, p):
        # EXPERIMENTAL gRPC OTA. Brick-capable; the checksum format is unverified.
        self._need_idle()
        self._need_conn('Firmware OTA')
        self._need_bench('Firmware OTA')
        path = (p.get('path') or '').strip()
        target = (p.get('target') or 'ALL').strip().upper()
        if not path:
            raise Notice('Enter the firmware file path first.', 'Firmware OTA')
        fp = Path(path)
        if not fp.is_file():
            raise Notice(f'File not found: {path}', 'Firmware OTA', 'danger')
        self._confirm(
            p, 'Flash firmware?',
            f'EXPERIMENTAL and BRICK-CAPABLE. Flashes {fp.name} to {target} over '
            'gRPC. The checksum format is unverified; a wrong file or an '
            'interrupted write can permanently brick the ECU. Keep the scooter '
            'parked and on charge.',
            word='CONFIRM', tone='danger', button='Flash')
        data = fp.read_bytes()
        self.fw_flash = {'state': 'Starting', 'progress': 0.0}

        def work():
            def prog(sent, total):
                self.fw_flash = {'state': 'Uploading',
                                 'progress': (sent / total) if total else 0.0}
            return self.scooter.sw_flash(data, fp.name, target, progress=prog)

        def done(state):
            self.fw_flash = {'state': state, 'progress': 1.0}
            self.report(f'OTA triggered · {state}. The scooter reboots during install.')
        self.run('Firmware OTA', work, done)

    def a_adb(self, p):
        # Root shell on the head unit via ExecuteADBCommand. Powerful/unguarded.
        self._need_idle()
        self._need_conn('ADB')
        cmd = (p.get('cmd') or '').strip()
        if not cmd:
            raise Notice('Enter a shell command.', 'ADB')
        self._confirm(
            p, 'Run as root?',
            f'Runs `{cmd}` as uid 0 on the head unit. Root access can change '
            'system state.', word='CONFIRM', tone='danger', button='Run')

        def done(out):
            self.adb_output = out or '(no output)'
            self.report('ADB command ran')
        self.run('ADB', lambda: self.scooter.execute_adb(cmd), done)

    def a_adb_foreground(self, p):
        # Bring the scooter diagnostic app to the front (for self-tests).
        self._need_idle()
        self._need_conn('ADB')

        def done(out):
            self.adb_output = out or '(diagnostic app foregrounded)'
            self.report('Diagnostic app foregrounded')
        self.run('ADB foreground', lambda: self.scooter.execute_adb(
            'monkey -p com.olaelectric.udstestapp '
            '-c android.intent.category.LAUNCHER 1'), done)

    # ------------------------------------------------------------------ bluetooth
    def a_ble_scan(self, p):
        if ble is None:
            raise Notice('Bluetooth is unavailable in this Python.', 'Bluetooth')
        self._need_idle()
        self.ble_status = 'Scanning…'
        self.run('BLE scan', lambda: ble.scan_list(6.0), self._ble_scan_done)

    def _ble_scan_done(self, rows):
        self.ble_rows = [[name or '', mac, rssi] for name, mac, rssi in (rows or [])]
        olas1 = next((r for r in self.ble_rows if r[0].lower() == 'olas1'), None)
        if olas1:
            self.ble_mac = olas1[1]
            self.ble_status = f'Found OLAS1 at {self.ble_mac}'
        elif self.ble_rows:
            self.ble_mac = self.ble_rows[0][1]
            self.ble_status = f'Found {len(self.ble_rows)} device(s) — pick one, or type the address'
        else:
            self.ble_status = 'No BLE devices found (scooter awake? phones’ Bluetooth off?)'

    def a_ble_set_mac(self, p):
        self.ble_mac = str(p.get('mac', '')).strip()
        row = next((r for r in self.ble_rows if r[1] == self.ble_mac), None)
        if row:
            self.ble_status = f'Selected {row[0] or "(unnamed)"} · {row[1]} · {row[2]} dBm'

    def a_ble_pair(self, p):
        if ble is None:
            raise Notice('Bluetooth is unavailable in this Python.', 'Bluetooth')
        self._need_idle()
        mac = str(p.get('mac') or self.ble_mac).strip()
        self.ble_mac = mac

        def done(r):
            self.ble_status = f'Pair: {r}'
        self.run('BLE pair', lambda: ble.pair(mac), done)

    def a_ble_cmd(self, p):
        if ble is None:
            raise Notice('Bluetooth is unavailable in this Python.', 'Bluetooth')
        cmd = p.get('cmd')
        labels = {'UNLOCK': 'Unlock', 'LOCK': 'Lock', 'TRUNK_OPEN': 'Open trunk', 'FLASH': 'Flash lights',
                  'FLASH_HORN': 'Flash + horn'}
        if cmd not in labels:
            raise Notice('Unknown command.', 'Bluetooth', 'danger')
        label = labels[cmd]
        if cmd in ('UNLOCK', 'LOCK', 'TRUNK_OPEN'):
            self._confirm(p, label, f'Send {label} to the scooter over Bluetooth?', button=label)
        mac = str(p.get('mac') or self.ble_mac).strip()
        self.ble_mac = mac
        self._ble_q.append((label, cmd, mac))
        waiting = len(self._ble_q) - 1
        if self.busy:
            self.ble_status = f'{label} queued' + (f' ({waiting} ahead)' if waiting else '')
            return
        self._ble_drain()

    def _ble_drain(self):
        if not self._ble_q or self.busy:
            return
        label, cmd, mac = self._ble_q.pop(0)
        extra = f' · {len(self._ble_q)} waiting' if self._ble_q else ''
        self.ble_status = f'{label}…{extra}'

        def done(result):
            self.ble_status = result
            self.inbox.put(('call', self._ble_drain, {}, threading.Event()))
        self.run(f'BLE {label}', lambda: ble.command(cmd, mac), done)

    # ------------------------------------------------------------------ read guard + monitor resume
    def _need_read(self, title):
        self._need_conn(title)
        if not self.bench:
            raise Notice('Reading from the scooter’s modules needs Bench mode. Park the scooter and unplug the '
                         'charger first (an earlier read briefly interrupted a charge), then switch Bench mode on '
                         'at the top.', title, 'warn')

    def _monitor_wanted(self):
        return self.connected and (self.status_on or self.live) and not self.replay

    def _resume_monitor(self):
        """Diagnostic requests move the CAN stream to the filtered diagnostic channel, which
        silently froze the Status / Live monitor. Give the bus back to it afterwards."""
        if self._monitor_wanted() and self.scooter.stream_mode != 'dump' and not self.busy and not self.closing:
            self.run('Resume monitor', self.scooter.start_live, quiet=True)

    def a_monitor_resume(self, p):
        self._need_idle()
        self._need_conn('Monitor')
        self.live = True
        self.run('Resume monitor', self.scooter.start_live)

    # ------------------------------------------------------------------ demo mode
    def a_demo_start(self, p):
        self._need_idle()
        if self.connected:
            raise Notice('Disconnect from the scooter first, then start the demo.', 'Demo')
        from demo_vehicle import DemoServer
        try:
            self.demo = DemoServer()
        except Exception as exc:
            self.demo = None
            raise Notice(f'The demo scooter could not start: {exc}', 'Demo', 'danger')
        self._demo_saved = (self.host, self.port, self.secure)
        self.host, self.port, self.secure = '127.0.0.1', str(self.demo.port), False
        self._status_log.log('SYS', 'demo mode started (simulated scooter, nothing is sent to a vehicle)')
        def after():
            self.emit('toast', 'Demo scooter connected', 'Simulated data', 'ok')
            # Passive listening only; start it so Home / Status fill in straight away.
            self.inbox.put(('call', self._start_monitor, {}, threading.Event()))
        self._connect(after=after)

    def a_demo_charger(self, p):
        if not self.demo:
            raise Notice('The virtual charger is only available in Demo mode.', 'Demo')
        self.demo.set_charging(bool(p.get('on')))
        return {'message': 'Virtual charger plugged in' if p.get('on') else 'Virtual charger unplugged'}

    def _stop_demo(self):
        if self.demo:
            try:
                self.demo.close()
            except Exception:
                pass
            self.demo = None
            if self._demo_saved:
                self.host, self.port, self.secure = self._demo_saved
                self._demo_saved = None

    # ------------------------------------------------------------------ ECU report (ODX read-out)
    def a_report_start(self, p):
        self._need_idle()
        self._need_read('ECU report')
        ecus = [e for e in ('BMS', 'VCU', 'MCU') if e in (p.get('ecus') or ['BMS', 'VCU', 'MCU'])]
        if not ecus:
            raise Notice('Choose at least one module.', 'ECU report')
        quick = bool(p.get('quick', True))
        self.report_cancel.clear()
        self.report_progress = {'done': 0, 'total': len(ecu_report.catalog(ecus, quick)), 'label': 'Starting…'}

        def progress(done, total, label):
            self.report_progress = {'done': done, 'total': total, 'label': label}

        def work():
            report = ecu_report.run(self.scooter, ecus, quick, progress, self.report_cancel)
            report['vehicle'] = {'mode': self.mode, 'firmware': self.firmware, 'demo': bool(self.demo)}
            files = ecu_report.save(report, ROOT / 'captures/reports')
            return report, files

        def done(result):
            report, files = result
            self.last_report = report
            self.report_files = [str(f) for f in files]
            self.report_seq += 1
            self.report_progress = None
            n_ok = sum(1 for r in report['items'] if not r.get('error'))
            self._status_log.log('CMD', f'ECU report {",".join(ecus)} quick={quick}: {n_ok}/{len(report["items"])} read')
            self.emit('toast', 'Report ready', f'{n_ok} of {len(report["items"])} values read', 'ok')
        self.run('ECU report' + (' (quick)' if quick else ' (full)'), work, done, resume=True)

    def _on_report_error(self):
        self.report_progress = None

    def a_report_cancel(self, p):
        self.report_cancel.set()

    def a_report_open(self, p):
        if not self.report_files:
            raise Notice('Run a report first.', 'ECU report')
        self._open_path(Path(self.report_files[1] if p.get('kind') == 'html' else Path(self.report_files[0]).parent))

    # ------------------------------------------------------------------ firmware / versions + config
    def a_read_firmware(self, p):
        self._need_idle()
        self._need_read('Firmware')

        def work():
            versions = vehicle_info.read_versions(self.scooter)
            return {'versions': versions, 'findings': vehicle_info.mismatch_check(versions),
                    'rules': vehicle_info.FIRMWARE_RULES, 'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'config': vehicle_info.read_vcu_config(self.scooter)}

        def done(r):
            cfg = r.pop('config')
            self.fw_report = _jsonable(r)
            self.vcu_config = _jsonable(cfg)
            if cfg.get('variant'):
                self.model = cfg['variant']
            self._status_log.log('CMD', 'firmware versions + config read')
        self.run('Read firmware & config', work, done, resume=True)

    def a_read_vcu_config(self, p):
        self._need_idle()
        self._need_read('Vehicle config')

        def done(r):
            self.vcu_config = _jsonable(r)
            if r.get('variant'):
                self.model = r['variant']
        self.run('Read vehicle config', lambda: vehicle_info.read_vcu_config(self.scooter), done, resume=True)

    # ------------------------------------------------------------------ head-unit self-tests
    def a_hu_test(self, p):
        self._need_idle()
        self._need_conn('Self-test')
        key, action = p.get('key'), p.get('action', 'start')
        test = next((t for t in HU_TESTS if t[0] == key), None)
        if key == 'vin':
            req = pb.RmtCmdReq(cmd_id=pb.RMT_CMD_VIN, sub_cmd_vin=pb.RMT_SUB_CMD_VIN_GET)
            label = 'Read VIN'
        elif test and action in ('start', 'stop'):
            _, label, cmd, field, start, stop, note = test
            if action == 'start':
                extra = '\n\nThe Wi‑Fi link to this console may drop during the test.' if key == 'wifi' else ''
                self._confirm(p, f'{label} self-test', f'{note}\n\nStarts the head unit’s built-in {label.lower()} '
                              f'test (gRPC RemoteRunTestCmd). Stop it from the same tile.{extra}',
                              tone='warn' if key == 'wifi' else 'info', button='Start test')
            req = pb.RmtCmdReq(cmd_id=getattr(pb, cmd))
            setattr(req, field, getattr(pb, start if action == 'start' else stop))
            label = f'{label} test {action}'
        else:
            raise Notice('Unknown self-test.', 'Self-test', 'danger')

        def work():
            if action == 'start':
                # Best-effort: foreground the diagnostic app so the test shows.
                try:
                    self.scooter.execute_adb(
                        'monkey -p com.olaelectric.udstestapp '
                        '-c android.intent.category.LAUNCHER 1')
                except Exception:
                    pass
            r = self.scooter.rpc('RemoteRunTestCmd', req)
            status = pb.RmtCmdRespStatus.Name(r.resp_status).replace('RMT_CMD_RESP_', '').title()
            text = (r.resp_str or '').strip() or (r.resp_bytes.hex(' ') if r.resp_bytes else '')
            return f'{status}' + (f' · {text}' if text else '')

        def done(msg):
            self.workshop_log.appendleft({'time': time.strftime('%H:%M:%S'), 'label': label, 'result': msg})
        self.run(label, work, done)

    # ------------------------------------------------------------------ hyper charge entitlement
    def a_hyper_charge(self, p):
        self._need_idle()
        action = p.get('action')
        if action not in ('read', 'enable', 'disable'):
            raise Notice('Unknown action.', 'Hyper charging', 'danger')
        self._need_read('Hyper charging')
        from oladiag.seedkey import Ecu
        did = bytes.fromhex('0102')
        if action == 'read':
            def work_r():
                data = self.scooter.read(Ecu.VCU, did)
                return 'enabled' if (data and data[0]) else 'disabled'
            return self.run('Read Hyper charge status', work_r,
                            lambda r: self.emit('sheet', 'Hyper charging', f'Currently {r} (VCU DID 0102).'),
                            resume=True)
        self._need_bench('Hyper charging')
        on = action == 'enable'
        self._confirm(p, f'{"Enable" if on else "Disable"} Hyper charging',
                      f'This writes the Hyper-charging entitlement flag on the VCU (2E 0102 '
                      f'{"01" if on else "00"}).\n\nHyper charging is a paid feature. Turning the flag on does not '
                      'pay for or authorise it with Ola, and the cloud can set it back. This is for your own '
                      'scooter and your own records only. UNVERIFIED on this firmware.',
                      word='WRITE', tone='danger', button=('Enable' if on else 'Disable'))

        def work():
            u = self.scooter.ensure_unlocked(Ecu.VCU)
            u._request(Ecu.VCU, b'\x2e\x01\x02' + (b'\x01' if on else b'\x00'))
            back = self.scooter.read(Ecu.VCU, did)
            return f'Hyper charging flag is now {"enabled" if (back and back[0]) else "disabled"} (readback).'

        def done(msg):
            self.workshop_log.appendleft({'time': time.strftime('%H:%M:%S'), 'label': 'Hyper charge ' + action,
                                          'result': msg})
            self.emit('toast', 'Hyper charging', msg, 'ok')
        self.run('Hyper charge ' + action, work, done, resume=True)

    # ------------------------------------------------------------------ SOM system test
    def a_som_test(self, p):
        self._need_idle()
        self._need_conn('SOM test')
        req = pb.SystemTestCmd(cmd_id=pb.SYS_CMD_SOM)

        def work():
            r = self.scooter.rpc('RunSystemTestCmd', req)
            status = pb.RmtCmdRespStatus.Name(r.resp_status).replace('RMT_CMD_RESP_', '').title()
            return status + ((' · ' + r.resp_str.strip()) if r.resp_str else '')

        def done(msg):
            self.workshop_log.appendleft({'time': time.strftime('%H:%M:%S'), 'label': 'SOM system test',
                                          'result': msg})
        self.run('SOM system test', work, done)

    # ------------------------------------------------------------------ battery health shortcut
    def a_battery_health(self, p):
        self._need_idle()
        self._need_read('Battery health')
        from oladiag.seedkey import Ecu
        import ecu_report as er

        def work():
            out = {}
            for did in ('E103', 'E101', 'E100'):
                try:
                    data = self.scooter.read(Ecu.BMS, bytes.fromhex(did))
                    defn = next(d for d in er.ODX.get('BMS', []) if (d.get('RequestFormat') or '').replace(' ', '')
                                == '22' + did)
                    out[did] = er.decode(defn, data)
                except Exception:
                    out[did] = []
            soh = next((v for v in out.get('E103', []) if 'soh' in v['name'].lower()), None)
            cyc = next((v for v in out.get('E101', []) if 'cycle' in v['name'].lower()), None)
            temp = next((v for v in out.get('E100', []) if 'effective temp' in v['name'].lower()), None)
            return {'soh': soh and soh['value'], 'cycles': cyc and cyc['value'],
                    'pack_temp': temp and temp['value']}

        def done(r):
            self.battery_health = {**r, 'time': time.strftime('%H:%M:%S')}
        self.run('Read battery health', work, done, resume=True)

    def a_force_balance(self, p):
        # Delegates to the cell-balancing routine, with a battery-flavoured prompt.
        return self.a_routine({**p, 'key': 'bal'})

    # ------------------------------------------------------------------ battery graph
    def _record_graph(self, batt, chg):
        if not batt:
            return
        now = time.time()
        if self._graph_t0 is None:
            self._graph_t0 = now
        t = round(now - self._graph_t0, 1)
        vals = {'soc': batt.get('soc'), 'volts': batt.get('volts'), 'amps': batt.get('amps'),
                'power': chg.get('power_w'), 'motor_t': batt.get('motor_t'), 'mcu_t': batt.get('mcu_t')}
        for k, v in vals.items():
            if v is not None:
                self.graph[k].append([t, round(float(v), 2)])

    def a_graph_clear(self, p):
        for d in self.graph.values():
            d.clear()
        self._graph_t0 = None

    def a_graph_export(self, p):
        path = p.get('path')
        if not path:
            return
        series = {lbl: list(self.graph[k]) for k, lbl, _ in battery_mod.GRAPH_SIGNALS if self.graph[k]}
        if not series:
            raise Notice('No graph data yet — start the monitor first.', 'Export', 'warn')
        _, rows, cols = write_series_csv(series, path)
        self.report(f'Graph exported: {path}')
        return {'message': f'Exported {cols} signals × {rows} rows'}

    # ------------------------------------------------------------------ full session recorder
    def _record_session(self, batt, chg):
        values = {}
        for (cid, signal), row in self.rows.items():
            v = row[3]
            if isinstance(v, bool):
                continue
            if isinstance(v, (int, float)):
                values.setdefault(signal, v)
            else:
                try:
                    values.setdefault(signal, float(v))
                except (TypeError, ValueError):
                    pass
        if batt:
            for k in ('soc', 'range_km', 'volts', 'amps', 'motor_t', 'mcu_t', 'speed'):
                if batt.get(k) is not None:
                    values['batt_' + k] = batt[k]
        if chg.get('power_w') is not None:
            values['power_w'] = chg['power_w']
        self.recorder.sample(values)

    def a_session_record(self, p):
        self._need_idle()
        if self.recorder.active:
            path = self.recorder.stop()
            st = self.recorder.stats()
            self._status_log.log('CMD', f'recording stopped → {path} ({st["samples"]} samples)')
            self.emit('toast', 'Recording saved', f'{st["samples"]} samples · {st["signals"]} signals', 'ok')
            return {'message': f'Saved {path}'}
        self._need_conn('Recorder')
        if not (self.status_on or self.live):
            self._start_monitor()
        path = p.get('path') or str(ROOT / 'captures/recordings' / time.strftime('session_%Y%m%d_%H%M%S.jsonl'))
        meta = {'host': self.host, 'port': self.port, 'demo': bool(self.demo), 'model': self.model,
                'firmware': self.firmware, 'started_str': time.strftime('%Y-%m-%d %H:%M:%S')}
        self.recorder.start(path, meta)
        self._status_log.log('CMD', f'recording started → {path}')
        self.emit('toast', 'Recording…', 'Capturing every signal to a file', 'ok')
        return {'message': 'Recording started'}

    def a_session_export(self, p):
        path = p.get('path')
        src = self.recorder.path or (self.loaded_recording and self.loaded_recording['path'])
        if not path or not src:
            raise Notice('Record or open a session first.', 'Export')
        if self.recorder.active:
            raise Notice('Stop the recording before exporting.', 'Export', 'warn')

        def work():
            _, rows, cols = export_csv(src, path)
            return {'rows': rows, 'cols': cols, 'path': path}
        self.run('Export recording to CSV', work,
                 lambda r: self.emit('toast', 'Exported to CSV', f'{r["cols"]} signals × {r["rows"]} rows', 'ok'))

    def a_session_open(self, p):
        self._need_idle()
        path = p.get('path')
        if not path:
            return
        self.run('Open recording', lambda: rec_summarize(path),
                 lambda r: setattr(self, 'loaded_recording', _jsonable(r)))

    def a_session_plot(self, p):
        names = p.get('names') or []
        src = self.loaded_recording and self.loaded_recording['path']
        if not src or not names:
            return
        self.run('Load recording series', lambda: load_series(src, names[:6]),
                 lambda r: setattr(self, 'loaded_series', _jsonable(r)), quiet=True)

    # ------------------------------------------------------------------ per-cell view
    def a_read_cells(self, p):
        self._need_idle()
        self._need_read('Cells')

        def done(r):
            if r.get('time') is not None or 'cells' in r:
                r['time'] = time.strftime('%H:%M:%S')
            self.cells = _jsonable(r)
        self.run('Read cells', lambda: battery_mod.read_cells(self.scooter), done, resume=True)

    # ------------------------------------------------------------------ BMS configuration + factory check
    def a_bms_config(self, p):
        self._need_idle()
        self._need_read('Battery settings')

        def done(rows):
            self.bms_config = _jsonable(rows)
            self.bms_findings = battery_mod.factory_check(rows)
            self._status_log.log('CMD', f'BMS config read ({len(rows)} settings)')
        self.run('Read battery settings', lambda: battery_mod.read_config(self.scooter), done, resume=True)

    def a_bms_write(self, p):
        self._need_idle()
        self._need_conn('Battery write')
        self._need_bench('Battery write')
        did = str(p.get('did', '')).strip().upper()
        payload = str(p.get('payload', '')).strip().replace(' ', '')
        if not re.fullmatch(r'E[0-9A-F]{3}', did):
            raise Notice('Choose a BMS setting (DID like E4C3).', 'Battery write')
        try:
            pay = bytes.fromhex(payload)
        except ValueError:
            pay = b''
        if not pay:
            raise Notice('Enter the new value as hex. Read the setting first so you know the current bytes.',
                         'Battery write', 'warn')
        self._confirm(p, 'Write a battery setting',
                      f'This writes a BMS calibration/limit value (2E {did} {payload}).\n\n'
                      'Battery settings affect safety, range and thermal protection. A wrong value can damage a '
                      'module or the pack. Change one value at a time, and record the original first. '
                      'UNVERIFIED, bench only.', word='WRITE', tone='danger', button='Write')
        from oladiag.seedkey import Ecu
        did_b = bytes.fromhex(did)

        def work():
            before = self.scooter.read(Ecu.BMS, did_b)
            u = self.scooter.ensure_unlocked(Ecu.BMS)
            u._request(Ecu.BMS, b'\x2e' + did_b + pay)
            after = self.scooter.read(Ecu.BMS, did_b)
            return {'did': did, 'before': before.hex().upper(), 'wrote': pay.hex().upper(),
                    'readback': after.hex().upper(), 'match': after == pay}

        def done(r):
            msg = (f'{did}: wrote {r["wrote"]}, readback {r["readback"]}'
                   + (' — matches.' if r['match'] else ' — differs (BMS may clamp). No retry.'))
            self.workshop_log.appendleft({'time': time.strftime('%H:%M:%S'), 'label': f'BMS write {did}', 'result': msg})
            self.emit('toast', 'Battery setting written', msg, 'ok' if r['match'] else 'warn')
        self.run(f'Write BMS {did}', work, done, resume=True)

    # ------------------------------------------------------------------ one-tap auto test (alpha)
    def a_auto_test(self, p):
        self._need_idle()
        self._need_conn('Auto test')
        self._need_bench('Auto test')
        self._confirm(p, 'Run auto test (alpha)',
                      'Runs a quick sequence like the factory end-of-line check:\n\n'
                      '•  Read stored fault codes from BMS, VCU and MCU\n'
                      '•  Check the charge path and drive inputs are reporting\n\n'
                      'Read-only — it does not actuate anything. Alpha: results are a summary, not a pass/fail '
                      'verdict.', button='Run')
        from oladiag.seedkey import Ecu

        def work():
            steps = []
            for name in ('BMS', 'VCU', 'MCU'):
                try:
                    faults = self.scooter.read_faults(Ecu[name])
                    steps.append({'step': f'{name} fault codes', 'ok': not faults,
                                  'detail': 'none stored' if not faults else f'{len(faults)} stored'})
                except Exception as exc:
                    steps.append({'step': f'{name} fault codes', 'ok': False, 'detail': str(exc)[:60]})
            with self.scooter.t.sample_lock:
                snap = dict(self.scooter.t.latest) if self.scooter.t else {}
            steps.append({'step': 'Charge path reporting', 'ok': 0x213 in snap or 0x120 in snap,
                          'detail': 'frames seen' if (0x213 in snap or 0x120 in snap) else 'start the monitor first'})
            steps.append({'step': 'Drive inputs reporting', 'ok': 0x143 in snap,
                          'detail': 'frames seen' if 0x143 in snap else 'start the monitor first'})
            return steps

        def done(steps):
            self.auto_test = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'steps': steps}
            ok = sum(1 for s in steps if s['ok'])
            self.emit('toast', 'Auto test done', f'{ok}/{len(steps)} checks clear', 'ok' if ok == len(steps) else 'warn')
        self.run('Auto test', work, done, resume=True)

    # ------------------------------------------------------------------ workshop routines
    def a_routine(self, p):
        self._need_idle()
        key = p.get('key')
        r = next((x for x in ROUTINES if x[0] == key), None)
        if not r:
            raise Notice('Unknown routine.', 'Routine', 'danger')
        _, ecu_name, req_hex, label, desc = r
        read_only = key == 'tune'
        self._need_conn(label)
        self._need_bench(label)
        if read_only:
            self._confirm(p, label, f'{desc}\n\nNeeds Service mode; the {ecu_name} is unlocked automatically.',
                          button='Read')
        else:
            word = 'RUN'
            self._confirm(p, label, f'{desc}\n\n{ecu_name} routine {req_hex[2:]} from the factory ODX. It is '
                          'UNVERIFIED on this firmware, needs Service mode and unlocks the module. Scooter on the '
                          'stand, charger unplugged.', word=word, tone='danger', button='Run routine')
        ecu = Ecu[ecu_name]
        request = bytes.fromhex(req_hex)

        def work():
            u = self.scooter.ensure_unlocked(ecu)
            resp = u._request(ecu, request)
            body = resp[4:]
            if key == 'tune' and len(body) >= 3:
                return f'status 0x{body[0]:02X} · attempted {body[1]} · successful {body[2]}'
            return f'status 0x{body[0]:02X}' if body else f'acknowledged ({resp.hex(" ")})'

        def done(msg):
            self.workshop_log.appendleft({'time': time.strftime('%H:%M:%S'), 'label': label, 'result': msg})
        self.run(label, work, done)

    def a_clear_dtc(self, p):
        self._need_idle()
        ecu_name = str(p.get('ecu', ''))
        if ecu_name not in ('BMS', 'VCU', 'MCU'):
            raise Notice('Choose a module.', 'Clear codes')
        self._need_read('Clear codes')
        self._confirm(p, f'Clear stored codes · {ecu_name}',
                      f'Erases every stored diagnostic trouble code on the {ecu_name} (UDS 14 FF FF FF).\n\n'
                      'Do this only after the fault is repaired, and export a report first if you need a record. '
                      'Codes that are still active will come back.', word='CLEAR', tone='danger', button='Clear codes')
        ecu = Ecu[ecu_name]

        def work():
            from scooter_backend import UdsNegativeResponse
            u = self.scooter.uds(ecu, require_service=False)
            try:
                u._request(ecu, b'\x14\xff\xff\xff')
            except UdsNegativeResponse as exc:
                if exc.code not in (0x7F, 0x22, 0x33):
                    raise
                u = self.scooter.ensure_unlocked(ecu)         # needs Service mode
                u._request(ecu, b'\x14\xff\xff\xff')
            faults = self.scooter.read_faults(ecu)
            return {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'faults': faults, 'error': None}

        def done(result):
            self.health_stored[ecu_name] = result
            left = len(result['faults'] or [])
            self.emit('toast', f'{ecu_name} codes cleared', f'{left} still present' if left else 'None left', 'ok')
        self.run(f'Clear {ecu_name} codes', work, done, resume=True)

    def a_ecu_reset(self, p):
        self._need_idle()
        ecu_name, kind = str(p.get('ecu', '')), p.get('kind', 'soft')
        if ecu_name not in ('BMS', 'VCU', 'MCU') or kind not in ('soft', 'hard'):
            raise Notice('Choose a module.', 'Restart module')
        self._need_conn('Restart module')
        self._need_bench('Restart module')
        self._confirm(p, f'{"Soft" if kind == "soft" else "Hard"} restart · {ecu_name}',
                      f'Restarts the {ecu_name} (UDS 11 {"03" if kind == "soft" else "01"}), like a power cycle of '
                      'that module only. The scooter may beep, drop its display or turn off briefly.\n\n'
                      'UNVERIFIED on this firmware. Scooter parked on the stand, charger unplugged, nobody riding. '
                      'Can help clear a stuck state (for example a latched “charging” screen) without the app’s '
                      'full force-reboot.', word='RESTART', tone='danger', button='Restart')
        ecu = Ecu[ecu_name]
        sub = b'\x03' if kind == 'soft' else b'\x01'

        def work():
            u = self.scooter.ensure_unlocked(ecu)
            resp = u._request(ecu, b'\x11' + sub)
            self.scooter.unlocked.discard(ecu)
            self.scooter.stop_keepalive()
            return f'{ecu_name} {kind} restart acknowledged ({resp.hex(" ")})'

        def done(msg):
            self.workshop_log.appendleft({'time': time.strftime('%H:%M:%S'), 'label': f'{ecu_name} {kind} restart',
                                          'result': msg})
        self.run(f'{ecu_name} {kind} restart', work, done)

    # ------------------------------------------------------------------ snapshots for the page
    def meta(self):
        groups = []
        for title, rows in hc.grouped():
            groups.append({'title': title, 'rows': [[o, lbl.split('  [')[0], tier] for o, lbl, tier in rows]})
        return {
            'actuators': [{'name': n, 'did': f'{d:04X}', 'danger': n in ACTUATOR_DANGER,
                           'group': next((g for g, names in ACTUATOR_GROUPS.items() if n in names), '')}
                          for n, d in sorted(ACTUATORS.items())],
            'actuator_groups': list(ACTUATOR_GROUP_ORDER),
            'settings': {name: {'request': d['RequestFormat'],
                                'params': [{'name': par['Parameter'].strip(), 'unit': par['Unit'],
                                            'min': _jsonable(par['Physical Minimum']),
                                            'max': _jsonable(par['Physical Maximum'])}
                                           for par in d['Parameters']]}
                         for name, d in SETTINGS.items()},
            'hmi': groups,
            'hmi_count': len(hc.ORDINALS),
            'categories': {k: list(v) if v else None for k, v in CATEGORIES.items()},
            'live_metrics': LIVE_METRICS,
            'feature_toggles': FEATURE_TOGGLES,
            'regen_types': REGEN_TYPES,
            'update_rpcs': UPDATE_RPCS,
            'learn_labels': LEARN_LABELS,
            'learn_phases': list(PHASES),
            'charge_cells': CHARGE_CELLS,
            'ble_available': bool(ble and ble.available()),
            'hu_tests': [[k, label, note] for k, label, *_rest, note in HU_TESTS],
            'routines': [[k, ecu, req[2:], label, desc] for k, ecu, req, label, desc in ROUTINES],
            'report_counts': {'quick': len(ecu_report.catalog(quick=True)), 'full': len(ecu_report.catalog())},
            'report_groups': ecu_report.GROUP_ORDER,
            'ecus': [e.name for e in Ecu],
        }

    def catalog_rows(self):
        return [[i, ecu, source, name, did is not None] for i, (ecu, source, name, _, did) in enumerate(self.catalog())]

    def _record_batt_history(self, dbc, snap):
        """Append a SoH / cell-spread point at most once a minute and persist it,
        for the cross-session battery-health trend."""
        now = time.time()
        if now - self._batt_hist_last < 60:
            return
        soh = _sig(dbc, snap, 0x352, 'SOH_Disp') or _sig(dbc, snap, 0x150, 'Pack_SoH')
        cmin = _sig(dbc, snap, 0x170, 'BMS0_Cell_Min_Voltage')
        cmax = _sig(dbc, snap, 0x170, 'BMS0_Cell_Max_Voltage')
        spread = (cmax - cmin) * 1000 if (cmin is not None and cmax is not None) else None
        if soh is None and spread is None:
            return
        self._batt_hist_last = now
        self.batt_history.append({'t': now, 'soh': soh, 'spread': spread})
        if len(self.batt_history) > 2000:
            self.batt_history = self.batt_history[-2000:]
        try:
            self._batt_hist_path.parent.mkdir(parents=True, exist_ok=True)
            self._batt_hist_path.write_text(json.dumps(self.batt_history))
        except Exception:
            pass

    def _batt_history_series(self):
        """History as a drawChart series dict: {label: [[t_rel_s, value], …]}."""
        if not self.batt_history:
            return {}
        t0 = self.batt_history[0]['t']
        soh, spread = [], []
        for p in self.batt_history:
            ts = p['t'] - t0
            if p.get('soh') is not None:
                soh.append([ts, p['soh']])
            if p.get('spread') is not None:
                spread.append([ts, p['spread']])
        out = {}
        if soh:
            out['SoH (%)'] = soh
        if spread:
            out['Spread (mV)'] = spread
        return out

    def state(self, since=0, views=(), rseq=-1):
        views = set(views)
        s = {
            'seq': self.seq,
            'events': [e for e in self.events if e['id'] > since],
            'conn': {'connected': self.connected, 'host': self.host, 'port': self.port, 'secure': self.secure,
                     'mode': self.mode, 'firmware': self.firmware, 'bench': self.bench,
                     'unlock_access': self.unlock_access, 'demo': bool(self.demo),
                     'demo_charging': bool(self.demo and self.demo.vehicle.charging),
                     'model': self.model,
                     'hardware': {k: f'0x{v:02X}' for k, v in self.hw_variants.items()},
                     'cell_dcir': [None if v is None else round(v, 2) for v in self.cell_dcir],
                     'vehicle_state': self.vehicle_state},
            'busy': self.busy, 'busy_label': self.busy_label,
            'rec_active': bool(self.recorder.active),
            'rec_stats': self.recorder.stats() if self.recorder.active else None,
            'status_text': self.status_text,
            'monitor': {'on': self.status_on, 'live': self.live, 'replay': self.replay,
                        'recording': self._charge_snoop, 'vitals_log': self.auto_log_vitals,
                        'paused': bool(self._monitor_wanted() and self.scooter.stream_mode != 'dump'
                                       and not self.busy)},
            'report_progress': self.report_progress,
            'report_seq': self.report_seq,
            'sv': dict(self.sv),
            'som_config': self.som_config,
            'fw_flash': self.fw_flash,
            'adb_output': self.adb_output,
            'faults': list(self.faults),
            'closing': self.closing or self._close_disconnect,
        }
        if 'status' in views:
            s['notifications'] = list(self.notifications)
            s['features'] = self.features
            s['log_lines'] = self._status_log.lines()[-200:]
            s['folders'] = {'activity': str(self._status_log.root), 'charge': str(self._charge_rec.root)}
        if 'charging' in views:
            s['folders'] = {'activity': str(self._status_log.root), 'charge': str(self._charge_rec.root)}
        if 'calibration' in views:
            s['cal'] = dict(self.cal)
        if 'live' in views:
            s['live'] = self._live_state()
            s['learn'] = self._learn_state()
        if 'diagnostics' in views:
            s['health'] = self._health_state()
        if 'components' in views:
            s['setting'] = self.setting_values
        if 'software' in views:
            s['update_text'] = self.update_text
        if 'bluetooth' in views:
            s['ble'] = {'rows': self.ble_rows, 'mac': self.ble_mac, 'status': self.ble_status,
                        'queued': len(self._ble_q)}
        if 'report' in views and self.last_report and rseq != self.report_seq:
            s['report'] = {'seq': self.report_seq, 'data': _jsonable(self.last_report), 'files': self.report_files}
        if 'tests' in views or 'calibration' in views:
            s['workshop'] = list(self.workshop_log)
        if 'firmware' in views:
            s['firmware'] = self.fw_report
            s['vcu_config'] = self.vcu_config
        if 'tests' in views:
            s['auto_test'] = self.auto_test
        if 'status' in views:
            s['battery_health'] = self.battery_health
        if 'battery' in views:
            s['battery_health'] = self.battery_health
            s['cells'] = self.cells
            s['graph'] = {k: list(v) for k, v in self.graph.items()}
            s['battery_history'] = self._batt_history_series()
            s['graph_signals'] = [[k, lbl, u] for k, lbl, u in battery_mod.GRAPH_SIGNALS]
            s['bms_config'] = self.bms_config
            s['bms_findings'] = self.bms_findings
        if 'recorder' in views:
            s['recorder'] = self.recorder.stats()
            s['recording_summary'] = self.loaded_recording
            s['rec_series'] = self.loaded_series
        if 'activity' in views:
            s['activity'] = list(self.activity)[-200:]
        return s
