"""ECU read-out report — decodes every ODX 0x22 identifier of the diagnostic app.

The factory diagnostic app ships an ODX table (notes/apk_x/res/raw/odx.json) describing
~310 readable identifiers across BMS / VCU / MCU, each with bit position, size, scaling,
offset and unit. The console used to show these as raw bytes only; this module reads
them (plain 0x22, no session change, no unlock — the same path as "Read identifier")
and turns them into labelled values plus a battery-cell analysis.
"""
import html
import json
import re
import statistics
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ODX = json.loads((ROOT / 'notes/apk_x/res/raw/odx.json').read_text(encoding='utf-8-sig'))

GROUP_ORDER = ['Battery health', 'Battery cells', 'Identity & versions', 'Motor & controller',
               'Vehicle inputs & sensors', 'BMS configuration', 'Sensor calibration', 'Output states', 'Other']


def _num(v, default=None):
    try:
        f = float(v)
        return f
    except (TypeError, ValueError):
        return default


def _group(ecu, did, desc):
    d = desc.lower()
    if 'control status' in d or (ecu == 'VCU' and '03F1' <= did <= '0424') or did.startswith('E7'):
        return 'Output states'
    if did.startswith('F1') or did in ('E4C3', 'DFF0') or any(k in d for k in ('serial', 'version', 'part number',
                                                                                'identification', 'flashed', 'scope')):
        return 'Identity & versions'
    if ecu == 'BMS':
        if did in ('E106', 'E108', 'E109', 'E10A'):
            return 'Battery cells'
        if 'E100' <= did <= 'E10F':
            return 'Battery health'
        if did.startswith('E3'):
            return 'Sensor calibration'
        return 'BMS configuration'
    if ecu == 'MCU':
        return 'Motor & controller'
    if ecu == 'VCU':
        return 'Vehicle inputs & sensors'
    return 'Other'


def catalog(ecus=('BMS', 'VCU', 'MCU'), quick=False):
    """Readable identifiers: [{ecu, did, title, group, definition}] (one per DID)."""
    out = []
    for ecu in ecus:
        seen = set()
        for d in ODX.get(ecu, []):
            rf = (d.get('RequestFormat') or '').replace(' ', '').upper()
            if not rf.startswith('22') or len(rf) != 6:
                continue
            did = rf[2:]
            if did in seen:
                continue
            seen.add(did)
            title = (d.get('Description') or d.get('Command') or did).strip()
            group = _group(ecu, did, title)
            if quick and group in ('BMS configuration', 'Sensor calibration', 'Output states'):
                continue
            out.append({'ecu': ecu, 'did': did, 'title': title, 'group': group, 'definition': d})
    return out


def decode(definition, data: bytes):
    """[{name, value, unit}] for one response payload (data after 62 DID)."""
    word = int.from_bytes(data, 'little')
    rows = []
    for p in definition.get('Parameters') or []:
        name = (p.get('Parameter') or '').strip()
        bits = int(_num(p.get('Size (Bits)'), 0) or 0)
        start = int(_num(p.get('StartBit'), 0) or 0)
        if not name or name in ('0', '-') or bits <= 0:
            continue
        unit = p.get('Unit')
        unit = '' if unit in (None, '0', '-', 'None') else str(unit).strip()
        if (p.get('Encoding') or '').upper() == 'ASCII':
            chunk = data[start // 8:(start + bits) // 8]
            text = chunk.decode('ascii', 'replace').strip('\x00 ').strip()
            text = ''.join(c if c.isprintable() else '·' for c in text)
            rows.append({'name': name, 'value': text or '(empty)', 'unit': ''})
            continue
        if start + bits > len(data) * 8:
            rows.append({'name': name, 'value': None, 'unit': unit, 'note': 'not in response'})
            continue
        raw = (word >> start) & ((1 << bits) - 1)
        res = _num(p.get('Resolution'), 1) or 1
        off = _num(p.get('Offset'), 0) or 0
        if (p.get('DataType') or '') == 'TextTable' or (bits == 1 and res == 1 and off == 0):
            value = raw
        else:
            value = raw * res + off
            value = round(value, 6)
            if float(value).is_integer():
                value = int(value)
        rows.append({'name': name, 'value': value, 'unit': unit})
    return rows


def run(scooter, ecus, quick, progress=None, cancel=None):
    """Read and decode identifiers. Never raises for a single DID (records the error)."""
    from oladiag.seedkey import Ecu
    items = catalog(ecus, quick)
    results = []
    started = time.time()
    for i, item in enumerate(items):
        if cancel is not None and cancel.is_set():
            break
        if progress:
            progress(i, len(items), f'{item["ecu"]} · {item["title"]}')
        entry = {k: item[k] for k in ('ecu', 'did', 'title', 'group')}
        try:
            data = scooter.read(Ecu[item['ecu']], bytes.fromhex(item['did']))
            entry['hex'] = data.hex(' ').upper()
            entry['values'] = decode(item['definition'], data)
        except Exception as exc:
            msg = str(exc)
            entry['error'] = ('not supported by this ECU' if 'NRC 0x31' in msg or 'NRC 0x11' in msg
                              else msg[:160])
        results.append(entry)
    if progress:
        progress(len(items), len(items), 'done')
    report = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'duration_s': round(time.time() - started, 1),
              'ecus': list(ecus), 'quick': quick, 'cancelled': bool(cancel is not None and cancel.is_set()),
              'items': results}
    report['summary'] = summarize(results)
    return report


# ----------------------------------------------------------------------------- analysis
def _values(results, ecu, did):
    item = next((r for r in results if r['ecu'] == ecu and r['did'] == did and r.get('values')), None)
    return item['values'] if item else []


def _find(results, ecu, did, pattern):
    for v in _values(results, ecu, did):
        if re.search(pattern, v['name'], re.I) and v.get('value') is not None:
            return v
    return None


def summarize(results):
    s = {'highlights': [], 'findings': [], 'cells': None}

    def add(label, v, fmt=None):
        if v is not None and v.get('value') is not None:
            val = v['value']
            text = fmt(val) if fmt else f'{val}{(" " + v["unit"]) if v.get("unit") else ""}'
            s['highlights'].append({'label': label, 'value': text})

    add('State of charge', _find(results, 'BMS', 'E103', r'^soc'), lambda x: f'{x:g} %')
    add('State of health', _find(results, 'BMS', 'E103', r'soh'), lambda x: f'{x:g}')   # ODX unit is unreliable
    add('Charge cycles', _find(results, 'BMS', 'E101', r'cycle'), lambda x: f'{x:g}')
    add('Pack temperature', _find(results, 'BMS', 'E100', r'effective temp'), lambda x: f'{x:g} °C')
    add('Energy this cycle', _find(results, 'BMS', 'E102', r'kwhr'), lambda x: f'{x:g} kWh')
    add('Contactors', _find(results, 'BMS', 'E10E', r'contactor'))
    for ecu, did, label in (('BMS', 'F191', 'BMS serial'), ('BMS', 'F120', 'Pack serial'),
                            ('MCU', 'F18C', 'MCU serial'), ('BMS', 'F181', 'BMS software'),
                            ('MCU', 'F181', 'MCU software'), ('VCU', 'F181', 'VCU software')):
        v = _values(results, ecu, did)
        if v and v[0].get('value') not in (None, '(empty)'):
            s['highlights'].append({'label': label, 'value': str(v[0]['value'])})

    volts = [v for v in _values(results, 'BMS', 'E106') if v.get('value') is not None]
    ir = [v for v in _values(results, 'BMS', 'E109') if v.get('value') is not None]
    cap = [v for v in _values(results, 'BMS', 'E108') if v.get('value') is not None]
    if volts:
        vals = [float(v['value']) for v in volts]
        scale = 1000 if max(vals) < 10 else 1                    # → mV
        mv = [x * scale for x in vals]
        avg = statistics.mean(mv)
        cells = []
        for i, x in enumerate(mv):
            c = {'cell': i + 1, 'mv': round(x, 1), 'dev': round(x - avg, 1)}
            if i < len(ir):
                c['ir'] = ir[i]['value']
            if i < len(cap):
                c['ah'] = cap[i]['value']
            cells.append(c)
        spread = max(mv) - min(mv)
        s['cells'] = {'cells': cells, 'avg_mv': round(avg, 1), 'spread_mv': round(spread, 1),
                      'min_cell': mv.index(min(mv)) + 1, 'max_cell': mv.index(max(mv)) + 1}
        s['highlights'].insert(0, {'label': 'Cell spread', 'value': f'{spread:.0f} mV'})
        if spread > 50:
            s['findings'].append({'tone': 'danger', 'text': f'Cell voltage spread is {spread:.0f} mV, which is high. '
                                  f'Cell {mv.index(min(mv)) + 1} is the lowest. Let the BMS balance on a full slow charge '
                                  'and re-check; a persistent gap points to a weak cell.'})
        elif spread > 25:
            s['findings'].append({'tone': 'warn', 'text': f'Cell voltage spread is {spread:.0f} mV (moderate). '
                                  f'Cell {mv.index(min(mv)) + 1} is the lowest. A full slow charge lets the BMS balance.'})
        else:
            s['findings'].append({'tone': 'ok', 'text': f'Cells are well balanced: {spread:.0f} mV spread across {len(mv)} cells.'})
        if ir and len(ir) >= 3:
            irs = [float(v['value']) for v in ir]
            med = statistics.median(irs)
            for i, x in enumerate(irs):
                if med > 0 and x > med * 1.5:
                    s['findings'].append({'tone': 'warn', 'text': f'Cell {i + 1} internal resistance is {x:g} '
                                          f'(median {med:g}), well above the rest. That is an ageing or weak cell indicator.'})
    errors = [r for r in results if r.get('error')]
    if errors:
        unsupported = sum(1 for r in errors if r['error'] == 'not supported by this ECU')
        other = len(errors) - unsupported
        s['findings'].append({'tone': 'info', 'text': f'{len(results) - len(errors)} of {len(results)} identifiers read. '
                              f'{unsupported} are not supported by this firmware'
                              + (f'; {other} failed (see the list).' if other else '.')})
    return s


# ----------------------------------------------------------------------------- export
def to_html(report):
    e = html.escape
    rows = []
    for g in GROUP_ORDER:
        items = [r for r in report['items'] if r['group'] == g]
        if not items:
            continue
        rows.append(f'<h2>{e(g)}</h2><table><tr><th>ECU</th><th>DID</th><th>Item</th><th>Values</th></tr>')
        for r in items:
            if r.get('error'):
                vals = f'<span class="err">{e(r["error"])}</span>'
            else:
                vals = '<br>'.join(f'{e(v["name"])}: <b>{e(str(v["value"]))}</b> {e(v.get("unit") or "")}'
                                   for v in r.get('values', []))
            rows.append(f'<tr><td>{e(r["ecu"])}</td><td><code>{e(r["did"])}</code></td><td>{e(r["title"])}</td><td>{vals}</td></tr>')
        rows.append('</table>')
    s = report['summary']
    hl = ''.join(f'<div class="hl"><span>{e(h["label"])}</span><b>{e(h["value"])}</b></div>' for h in s['highlights'])
    fd = ''.join(f'<li class="{e(f["tone"])}">{e(f["text"])}</li>' for f in s['findings'])
    return f'''<!doctype html><html><head><meta charset="utf-8"><title>Scooter ECU report {e(report["time"])}</title>
<style>body{{font:14px -apple-system,"Segoe UI",sans-serif;color:#1d1d1f;max-width:1000px;margin:30px auto;padding:0 20px}}
h1{{font-size:28px;margin:0}}h2{{margin-top:28px;font-size:18px}}table{{border-collapse:collapse;width:100%}}
td,th{{border-bottom:1px solid #e5e5ea;padding:6px 8px;text-align:left;vertical-align:top}}th{{color:#86868b;font-size:12px}}
.hls{{display:flex;flex-wrap:wrap;gap:10px;margin:18px 0}}.hl{{background:#f2f2f7;border-radius:12px;padding:10px 14px}}
.hl span{{display:block;color:#86868b;font-size:12px}}.hl b{{font-size:17px}}li.danger{{color:#d70015}}li.warn{{color:#b25000}}
li.ok{{color:#248a3d}}.err{{color:#86868b}}code{{font-family:ui-monospace,Consolas,monospace}}</style></head><body>
<h1>Scooter ECU report</h1><p>{e(report["time"])} · {", ".join(report["ecus"])} · {"quick health check" if report["quick"] else "full read-out"}
 · {len(report["items"])} identifiers in {report["duration_s"]} s</p><div class="hls">{hl}</div><ul>{fd}</ul>{"".join(rows)}
<p style="color:#86868b;margin-top:30px">Generated by Scooter Console from the diagnostic app's ODX definitions. Values are decoded
from plain identifier reads (UDS 0x22). Configuration limits are ECU settings, not verified safe operating limits.</p></body></html>'''


def save(report, folder):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d_%H%M%S')
    jp = folder / f'ecu_report_{stamp}.json'
    hp = folder / f'ecu_report_{stamp}.html'
    jp.write_text(json.dumps(report, indent=2, default=str), encoding='utf-8')
    hp.write_text(to_html(report), encoding='utf-8')
    return jp, hp
