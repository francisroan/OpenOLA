"""Exact local protocol evidence. No secrets are sent outside this workspace."""
import json
from pathlib import Path
import queue
import threading
import time
import uuid


class CommandTrace:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.queue = queue.Queue(maxsize=100000)
        self.lock = threading.RLock()
        self.active = None
        self.error = None
        self.dropped = 0
        self.worker = threading.Thread(target=self._write, daemon=True)
        self.worker.start()

    def begin(self, label):
        self.directory.mkdir(parents=True, exist_ok=True)
        with self.lock:
            self.active = self.directory / (time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:8] + '.jsonl')
            self.dropped = 0
        self.event('operation_start', label=label)
        return str(self.active)

    def event(self, event, **data):
        with self.lock:
            path = self.active
            if path is None:
                return
            record = {'time_unix': time.time(), 'monotonic': time.monotonic(), 'event': event, **data}
            try:
                self.queue.put_nowait((path, record))
            except queue.Full:
                self.dropped += 1

    def end(self, result=None, error=None):
        with self.lock:
            path = self.active
            self.event('operation_end', result=result, error=error, dropped_events=self.dropped)
            self.active = None
        barrier = threading.Event()
        self.queue.put((barrier, None), timeout=3)
        if not barrier.wait(3):
            raise RuntimeError('Protocol trace did not flush within three seconds')
        if self.error or self.dropped:
            raise RuntimeError(f'Protocol trace incomplete: {self.error or str(self.dropped) + " events dropped"}')
        return str(path) if path else None

    def _write(self):
        handle = None
        current = None
        while True:
            target, record = self.queue.get()
            try:
                if isinstance(target, threading.Event):
                    if handle:
                        handle.flush()
                    target.set()
                elif target is None:
                    return
                else:
                    if current != target:
                        if handle:
                            handle.close()
                        handle = target.open('a', encoding='utf-8')
                        current = target
                    handle.write(json.dumps(record) + '\n')
            except Exception as exc:
                self.error = str(exc)
            finally:
                self.queue.task_done()
                if target is None and handle:
                    handle.close()

    def close(self):
        self.queue.put((None, None), timeout=3)
        self.worker.join(3)


def message_evidence(message):
    """Wire-serializable protobuf payload and readable representation, both local."""
    return {'protobuf_type': message.DESCRIPTOR.full_name, 'protobuf_hex': message.SerializeToString().hex(),
            'text': str(message)}
