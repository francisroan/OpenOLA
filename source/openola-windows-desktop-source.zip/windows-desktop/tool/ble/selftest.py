"""Offline self-test for the Ola BLE client. No hardware, no network.

Runs the full crypto chain and asserts the one hard ground-truth vector we have
(diagnostic F7D6A2E3 -> 48153568), so a regression in the seed/key port is caught.
    py -3 selftest.py
"""
import olakey, crypto
from protocol import Framer, DIRECT_COMMAND, SEED_REQUEST, SEED_KEY, CMD

def main():
    # 1) Known-good vector proves the shared grid-ASCII algorithm.
    assert olakey.generate_key(b"F7D6A2E3", "VCU", "01") == b"48153568", "VCU vector regressed"
    print("[ok] diagnostic vector F7D6A2E3 -> 48153568")

    # 2) BLE key is deterministic.
    seed = b"F7D6A2E3"
    sk = olakey.generate_key(seed, "BLE", "01")
    assert len(sk) == 8 and all(c in b"0123456789ABCDEF" for c in sk)
    print(f"[ok] BLE seedKey {sk.decode()}")

    # 3) HKDF deterministic, AES-CTR round-trips.
    key = crypto.session_key(seed, sk)
    assert len(key) == 16
    ct, r2 = crypto.encrypt(key, bytes([CMD["UNLOCK"]]))
    assert crypto.decrypt(key, ct, r2) == bytes([CMD["UNLOCK"]])
    print(f"[ok] HKDF key {key.hex()}  AES-CTR round-trip")

    # 4) Framing reproduces REAL captured frames byte-for-byte (Nothing Phone 2).
    from protocol import crc16_ccitt_false
    assert crc16_ccitt_false(bytes.fromhex("0a016aa8fda9010230")) == 0x7c2b, "CRC regressed"
    assert crc16_ccitt_false(bytes.fromhex("13026aa8fdaa0102314143413538443834" "01")) == 0x4dee
    import time as _t
    orig = _t.time
    try:
        f = Framer(start_id=1); _t.time = lambda: 0x6aa8fda9
        assert f.build_plain(SEED_REQUEST).hex() == "0a016aa8fda90102307c2b"
        _t.time = lambda: 0x6aa8fdaa
        assert f.build_plain(SEED_KEY, b"ACA58D84").hex() == "13026aa8fdaa0102314143413538443834014dee"
    finally:
        _t.time = orig
    print("[ok] framing reproduces real captured seed-request + key frames (CRC incl.)")

    # 5) Session key decrypts the captured commands (algorithm end-to-end).
    K = crypto.session_key(b"95839592", b"ACA58D84")
    assert olakey.generate_key(b"95839592", "BLE", "01") == b"ACA58D84"
    print(f"[ok] capture seed 95839592 -> key ACA58D84; session {K.hex()}")
    print("\nALL OFFLINE CHECKS PASSED (protocol verified against a real capture)")

if __name__ == "__main__":
    main()
