/*
 * Frida hook to capture the Ola app's real BLE frames (the Rosetta stone for
 * calibrating tool/ble). Logs every GATT write the app sends and every
 * notification it receives, with characteristic UUID + hex payload.
 *
 * This captures the exact SEED_AUTHENTICATION_REQUEST bytes, the seed reply,
 * the SEED_AUTHENTICATION_KEY bytes, and the AES command frames -- everything
 * needed to lock down protocol.py.
 *
 * Run (rooted phone or emulator):
 *     frida -U -f com.olaelectric.companion -l frida_ola_ble.js --no-pause
 * Non-rooted: repackage with a gadget first (objection patchapk -s Ola.apk),
 * install the patched app, then: frida -U -n gadget -l frida_ola_ble.js
 *
 * Reproduce: open the app and press Unlock. Copy the OUT/IN lines to Claude.
 */
function hex(bytes) {
  if (!bytes) return "null";
  var b = Java.array('byte', bytes), s = "";
  for (var i = 0; i < b.length; i++) {
    var v = (b[i] & 0xff).toString(16); s += (v.length === 1 ? "0" : "") + v;
  }
  return s;
}

Java.perform(function () {
  var Ch = Java.use("android.bluetooth.BluetoothGattCharacteristic");
  var Gatt = Java.use("android.bluetooth.BluetoothGatt");

  // outgoing: setValue then writeCharacteristic
  Ch.setValue.overload('[B').implementation = function (v) {
    try { console.log("OUT setValue " + this.getUuid() + "  " + hex(v)); } catch (e) {}
    return this.setValue(v);
  };
  Gatt.writeCharacteristic.overload('android.bluetooth.BluetoothGattCharacteristic')
    .implementation = function (c) {
      try { console.log("OUT write   " + c.getUuid() + "  " + hex(c.getValue())); } catch (e) {}
      return this.writeCharacteristic(c);
    };

  // incoming notifications: app reads characteristic value in its callback
  var CB = Java.use("android.bluetooth.BluetoothGattCallback");
  CB.onCharacteristicChanged.overload(
    'android.bluetooth.BluetoothGatt', 'android.bluetooth.BluetoothGattCharacteristic')
    .implementation = function (g, c) {
      try { console.log("IN  notify  " + c.getUuid() + "  " + hex(c.getValue())); } catch (e) {}
      return this.onCharacteristicChanged(g, c);
    };

  console.log("[*] Ola BLE hooks installed. Open the app and press Unlock.");
});
