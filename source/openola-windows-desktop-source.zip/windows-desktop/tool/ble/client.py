"""
Ola S1 BLE client (proximity/control path) -- for the owner's OWN scooter.

Protocol fully verified against a real capture (Nothing Phone 2, 2026-09-15):
  connect -> notify(6e400002) -> SEED_REQUEST(48) -> seed reply(type 0x70)
  -> key = getKey(seed) -> SEED_KEY(49) -> ack(type 0x71, 01=authorized)
  -> TEST_AES(50) -> DIRECT_COMMAND(1) with LOCK=1 / UNLOCK=2 / TRUNK_OPEN=3 ...

The OLAS1 module pairs Just Works (no PIN), so a fresh central can reach this.
Use only against a scooter you own.

Deps:  pip install bleak cryptography
Usage:
    py -3 client.py scan
    py -3 client.py auth --addr <MAC>
    py -3 client.py cmd UNLOCK --addr <MAC>
    py -3 client.py cmd FLASH  --addr <MAC>
"""
from __future__ import annotations
import argparse, asyncio, sys

import olakey, crypto
from protocol import (Framer, SEED_REQUEST, SEED_KEY, TEST_AES, DIRECT_COMMAND, CMD)

SERVICE = "6e400001-b5a3-f393-e0a9-8a85b62fc3df"
RX = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"   # notify (scooter -> phone)
TX = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"   # write  (phone -> scooter)
NAME = "OLAS1"

SEED_REPLY, KEY_ACK, AES_ACK = 0x70, 0x71, 0x72
TEST_AES_DATA = b"D_ALIVE"   # payload seen after the type byte in the real TEST_AES


async def scan(timeout=8.0):
    from bleak import BleakScanner
    found = await BleakScanner.discover(timeout=timeout, return_adv=True)
    rows = sorted(found.values(), key=lambda r: -(r[1].rssi or -999))
    for d, adv in rows:
        nm = adv.local_name or d.name or ""
        star = "  <== OLAS1" if NAME.lower() in nm.lower() else ""
        print(f"{d.address:20} rssi={adv.rssi!s:>5}  {nm!r}{star}")
    for d, adv in rows:
        if NAME.lower() in (adv.local_name or d.name or "").lower():
            return d.address
    return None


def parse_frame(b: bytes):
    """Return (type, data) from a notify frame Len|Id|Time4|IV2|Type|Data|EOF|CRC."""
    if len(b) < 11:
        return None, b""
    return b[8], b[9:-3]


class OlaBle:
    def __init__(self, address, verbose=True):
        self.address, self.verbose = address, verbose
        self.framer = Framer()
        self.key = None            # AES session key
        self._q: asyncio.Queue = asyncio.Queue()
        self._client = None

    def log(self, *a):
        if self.verbose: print(*a, file=sys.stderr, flush=True)

    async def __aenter__(self):
        from bleak import BleakClient, BleakScanner
        # After OS pairing bleak's cache is empty; rediscover before connecting.
        target = await BleakScanner.find_device_by_address(self.address, timeout=12.0)
        self._client = BleakClient(target or self.address, timeout=20.0)
        await self._client.connect()
        self.log("connected:", self._client.is_connected)
        await self._client.start_notify(RX, lambda _c, d: self._q.put_nowait(bytes(d)))
        return self

    async def __aexit__(self, *exc):
        try: await self._client.stop_notify(RX)
        except Exception: pass
        await self._client.disconnect()

    async def _write(self, frame: bytes):
        for pkt in Framer.chunk(frame):
            await self._client.write_gatt_char(TX, pkt, response=True)

    async def _await_type(self, want_type: int, timeout=5.0):
        """Drain notifications until one with the wanted app-layer type shows up."""
        loop = asyncio.get_event_loop()
        end = loop.time() + timeout
        while loop.time() < end:
            try:
                b = await asyncio.wait_for(self._q.get(), timeout=end - loop.time())
            except asyncio.TimeoutError:
                break
            t, data = parse_frame(b)
            if t == want_type:
                return data
        return None

    async def authenticate(self):
        self.log("-> SEED_REQUEST")
        await self._write(self.framer.build_plain(SEED_REQUEST))
        seed = await self._await_type(SEED_REPLY)
        if not seed or len(seed) < 8:
            raise RuntimeError(f"no seed reply (got {seed!r})")
        seed = seed[:8]
        key = olakey.generate_key(seed, "BLE", "01")
        self.key = crypto.session_key(seed, key)
        self.log(f"<- seed {seed.decode()}  key {key.decode()}  session {self.key.hex()}")

        self.log("-> SEED_KEY")
        await self._write(self.framer.build_plain(SEED_KEY, key))
        ack = await self._await_type(KEY_ACK)
        ok = bool(ack) and ack[0] == 0x01
        self.log(f"<- key ack {ack!r} -> {'AUTHORIZED' if ok else 'NOT authorized'}")
        if not ok:
            raise RuntimeError("seed/key not authorized")

        self.log("-> TEST_AES")
        await self._write(self.framer.build_encrypted(self.key, TEST_AES, TEST_AES_DATA))
        await self._await_type(AES_ACK, timeout=2.0)
        return True

    async def send_command(self, name: str):
        if self.key is None:
            raise RuntimeError("authenticate() first")
        val = CMD[name.upper()]
        self.log(f"-> DIRECT_COMMAND {name.upper()} [1,{val}]")
        await self._write(self.framer.build_encrypted(self.key, DIRECT_COMMAND, bytes([val])))
        await asyncio.sleep(0.35)


async def run(args):
    if args.action == "scan":
        await scan(); return
    addr = args.addr or await scan()
    if not addr:
        print("OLAS1 not found (phone BT off? scooter awake?)", file=sys.stderr); sys.exit(1)
    async with OlaBle(addr) as dev:
        await dev.authenticate()
        if args.action == "cmd":
            await dev.send_command(args.command)
        print("OK", file=sys.stderr)


def main():
    p = argparse.ArgumentParser(description="Ola S1 BLE client (own scooter)")
    sub = p.add_subparsers(dest="action", required=True)
    sub.add_parser("scan")
    sub.add_parser("auth").add_argument("--addr")
    c = sub.add_parser("cmd"); c.add_argument("command", choices=sorted(CMD)); c.add_argument("--addr")
    args = p.parse_args()
    try:
        asyncio.run(run(args))
    except ModuleNotFoundError as e:
        print(f"missing dep: {e}. Run: pip install bleak cryptography", file=sys.stderr); sys.exit(2)


if __name__ == "__main__":
    main()
