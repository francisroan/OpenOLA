"""
Ola consumer-app BLE payload crypto.

Ported from:
  consumer_app/Ic.b.txt  (KeyGenerator impl: fixed IV/salt, saveKey, HKDF key)
  consumer_app/Ic.a.txt  (Encrypt impl: AES/CTR/NoPadding, IV = salt||2 rnd bytes)

Key facts (all hard-coded in the app, no per-vehicle secret):
  * FIXED_IV   = 16 bytes, also used as the HKDF *salt*
  * RANDOM_SALT = FIXED_IV[:14]  (misnamed; it is constant)
  * session key = HKDF-SHA256(salt=FIXED_IV, ikm = seed || seedKey, info="", L=16)
  * per-message IV = RANDOM_SALT (14) || 2 SecureRandom bytes  -> 16 bytes
  * cipher = AES-128-CTR, key = session key, iv = per-message IV

HKDF uses only stdlib (hmac/hashlib) so the offline self-test needs no deps.
AES-CTR uses `cryptography` (pip install cryptography) for live use.
"""

from __future__ import annotations
import hmac
import hashlib
import os

FIXED_IV = bytes.fromhex("2fb19e766ba25d804ef4d7c15317683e")  # Ic.b field a[16]
RANDOM_SALT = FIXED_IV[:14]                                    # Ic.b getRandomSalt()


def hkdf_sha256(ikm: bytes, salt: bytes = FIXED_IV, info: bytes = b"", length: int = 16) -> bytes:
    """RFC5869 HKDF-SHA256, matching Ic.b.generateKey (extract + single-block expand)."""
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()
    t = b""
    okm = b""
    counter = 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([counter]), hashlib.sha256).digest()
        okm += t
        counter += 1
    return okm[:length]


def session_key(seed: bytes, seed_key: bytes) -> bytes:
    """saveKey(seed, seedKey) stores c = seed||seedKey; generateKey() = HKDF over it."""
    return hkdf_sha256(seed + seed_key)


def make_iv(rand2: bytes | None = None) -> bytes:
    """Per-message IV = RANDOM_SALT(14) || 2 bytes.  Ic.a.getEncryptedIV()."""
    if rand2 is None:
        rand2 = os.urandom(2)
    if len(rand2) != 2:
        raise ValueError("rand2 must be 2 bytes")
    return RANDOM_SALT + rand2


def _aes_ctr(key: bytes, iv: bytes, data: bytes) -> bytes:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    c = Cipher(algorithms.AES(key), modes.CTR(iv))
    e = c.encryptor()
    return e.update(data) + e.finalize()


def encrypt(key: bytes, data: bytes, rand2: bytes | None = None):
    """Return (ciphertext, rand2). AES-CTR is symmetric so decrypt reuses this."""
    iv = make_iv(rand2)
    return _aes_ctr(key, iv, data), iv[14:]


def decrypt(key: bytes, data: bytes, rand2: bytes) -> bytes:
    return _aes_ctr(key, make_iv(rand2), data)


def encrypt_type(key: bytes, type_val: int, rand2: bytes | None = None):
    """encryptType(long, iv): encrypt the single low byte of `type_val`."""
    return encrypt(key, bytes([type_val & 0xFF]), rand2)


if __name__ == "__main__":
    # Offline: HKDF is deterministic and dependency-free; prove it is stable.
    seed = b"F7D6A2E3"
    from olakey import generate_key
    sk = generate_key(seed, "BLE", "01")
    k = session_key(seed, sk)
    print("seed      :", seed.decode())
    print("seedKey   :", sk.decode())
    print("HKDF key  :", k.hex(), f"({len(k)} bytes)")
    print("fixed IV  :", FIXED_IV.hex())
    try:
        ct, r2 = encrypt(k, bytes([1]))  # a LOCK data byte
        print("enc LOCK  :", ct.hex(), "rand2", r2.hex(), "-> dec",
              decrypt(k, ct, r2).hex())
    except ModuleNotFoundError:
        print("enc LOCK  : (install `cryptography` for AES-CTR)")
