"""
Ola consumer-app BLE packet framing + command catalogue.

Frame field order (from PktGenerator.getAllSequence, consumer_app):
    Length(1) | Id(1) | Time(4) | IV(2) | Type(1) | Data(var) | EOF(1) | CRC(2)
then chunked into <=20-byte GATT writes (PktGenerator.determinePayload(20)).

For the EncryptedPacketBuilder path, build() prepends the 1-byte Type to the
payload and AES-CTR-encrypts (Type||Data) together; the 2 random IV bytes ride
in the IV field so the peer can reconstruct FIXED_SALT(14)||IV(2) and decrypt.

STATUS: field ORDER and widths are recovered from static bytecode. The exact
Length semantics, Id/Time seeding, EOF byte and CRC algorithm are NOT provable
from static analysis alone. `frame()` encodes the best reconstruction and every
uncertain constant is a named parameter. Calibrate once against a real capture
(see capture.py / the disclosure doc) before trusting live writes.
"""

from __future__ import annotations
import struct
import time as _time

from crypto import encrypt as _encrypt

# CommandType.command  (outer packet Type field) -- consumer_app/CommandType.txt
SEED_REQUEST = 48
SEED_KEY = 49
TEST_AES = 50
DIRECT_COMMAND = 1
VIN_COMMAND = 4
ENABLE_PROXIMITY = 7
PHONE_ALIVE = 8


def crc16_ccitt_false(data: bytes) -> int:
    """CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF, no reflection).
    Verified against real captured frames (seed request 7c2b, key 4dee)."""
    crc = 0xFFFF
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if (crc & 0x8000) else (crc << 1) & 0xFFFF
    return crc

# CommandDataTypes.data  (inner value carried by a DIRECT_COMMAND)
#   consumer_app/CommandDataTypes.txt. LOCK/UNLOCK/TRUNK verified by decrypting
#   a real capture; FLASH/FLASH_HORN are the app's "Ping my scooter" values.
CMD = {
    "UNLOCK": 2,
    "LOCK": 1,
    "TRUNK_OPEN": 3,
    "FLASH": 6,          # PING_MY_SCOOTER_FLASH_COMMAND  (lights)
    "FLASH_HORN": 7,     # PING_MY_SCOOTER_FLASH_AND_HORN_COMMAND (lights + horn)
    # CommandDataTypes.SILENT_UNLOCK data long = 13 (ordinal is 10 — do not confuse)
    "SILENT_UNLOCK": 13,
}

# Frame constants -- CONFIRMED against the Nothing Phone 2 capture (2026-09-15).
PLAIN_IV = b"\x01\x02"   # PlainPacketBuilder.getIV()
EOF_BYTE = 0x01          # EOFBytePosition value when data is present


class Framer:
    """Stateful framer. Real frame (confirmed):
        Len | Id | Time(4 BE) | IV(2) | Type(1) | Data | [EOF=01 if data] | CRC(2 BE)
    Len = total_frame_len - 1.  CRC = CRC-16/CCITT-FALSE over Len..EOF.
    """

    def __init__(self, start_id: int = 1):
        self._id = start_id - 1

    def _next_id(self) -> int:
        self._id = (self._id + 1) & 0xFF
        return self._id

    def _assemble(self, type_val: int, iv: bytes, body: bytes, has_eof: bool) -> bytes:
        pid = self._next_id()
        t = struct.pack(">I", int(_time.time()) & 0xFFFFFFFF)
        inner = bytes([pid]) + t + iv + bytes([type_val & 0xFF]) + body
        if has_eof:
            inner += bytes([EOF_BYTE])
        length = len(inner) + 2          # + 2 CRC bytes = total_len - 1
        head = bytes([length & 0xFF]) + inner
        crc = crc16_ccitt_false(head)
        return head + struct.pack(">H", crc)

    def build_plain(self, type_val: int, payload: bytes = b"") -> bytes:
        """Unencrypted packet. IV=0102; EOF appended only when there is data."""
        return self._assemble(type_val, PLAIN_IV, payload, has_eof=bool(payload))

    def build_encrypted(self, key: bytes, type_val: int, payload: bytes) -> bytes:
        """Encrypted DIRECT_COMMAND: AES-CTR(Type||payload); 2 IV bytes in header.
        (Command wire-format still to be confirmed against a captured unlock.)"""
        ct, rand2 = _encrypt(key, bytes([type_val & 0xFF]) + payload)
        return self._assemble(ct[0], rand2, ct[1:], has_eof=True)

    @staticmethod
    def chunk(frame: bytes, mtu: int = 20):
        return [frame[i:i + mtu] for i in range(0, len(frame), mtu)]
