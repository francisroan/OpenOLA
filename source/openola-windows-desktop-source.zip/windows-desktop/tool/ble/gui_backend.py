"""
Synchronous BLE adapter for the desktop GUI (Windows).

Warm authenticated session (apk/BLE_CHECKPOINT.md): reuse while the key is live,
TEST_AES ping after 3.5s idle, hard reconnect after 40s. Do not drop a live
link at 12s — that made every other click pay full connect+auth.
"""
from __future__ import annotations
import asyncio
import threading
import time

DEFAULT_MAC = "8A:85:B6:2F:C3:DF"
COMMANDS = ["UNLOCK", "LOCK", "TRUNK_OPEN", "FLASH", "FLASH_HORN"]
# Change #1 (same as APK): ping after idle; reconnect if the module likely dropped.
_PING_AFTER = 3.5
_HARD_RECONNECT = 40.0

try:
    from winrt.windows.devices.bluetooth import BluetoothLEDevice
    from winrt.windows.devices.enumeration import (
        DevicePairingKinds, DevicePairingResultStatus)
    _WINRT = True
except Exception as _e:            # pragma: no cover
    _WINRT = False
    _IMPORT_ERR = str(_e)


def available() -> bool:
    return _WINRT


def _mac_int(mac: str) -> int:
    return int(mac.replace(":", ""), 16)


async def _is_paired(mac: str):
    dev = await BluetoothLEDevice.from_bluetooth_address_async(_mac_int(mac))
    if dev is None:
        return None
    return dev.device_information.pairing.is_paired


async def _pair(mac: str) -> str:
    dev = await BluetoothLEDevice.from_bluetooth_address_async(_mac_int(mac))
    if dev is None:
        return "device not found (scooter awake? phones' BT off?)"
    p = dev.device_information.pairing
    if p.is_paired:
        return "already paired"
    if not p.can_pair:
        return "device reports it cannot pair"
    custom = p.custom
    def on_req(_s, args):
        args.accept()
    token = custom.add_pairing_requested(on_req)
    try:
        res = await custom.pair_async(DevicePairingKinds.CONFIRM_ONLY)
    finally:
        custom.remove_pairing_requested(token)
    ok = res.status in (DevicePairingResultStatus.PAIRED,
                        DevicePairingResultStatus.ALREADY_PAIRED)
    return "paired" if ok else f"pair failed: {res.status}"


def pair(mac: str = DEFAULT_MAC) -> str:
    if not _WINRT:
        return f"BLE unavailable: {_IMPORT_ERR}"
    return asyncio.run(_pair(mac))


def status(mac: str = DEFAULT_MAC) -> str:
    if not _WINRT:
        return "BLE unavailable"
    paired = asyncio.run(_is_paired(mac))
    if paired is None:
        return "not found"
    return "paired" if paired else "not paired"


# ---- persistent session (one authenticated link reused across clicks) ----
_lock = threading.Lock()
_loop: asyncio.AbstractEventLoop | None = None
_thread: threading.Thread | None = None
_session = None          # winrt_client.Ola
_session_mac: str | None = None
_session_at = 0.0


def _ensure_loop():
    global _loop, _thread
    if _loop is not None and _loop.is_running():
        return _loop
    loop = asyncio.new_event_loop()
    def run():
        asyncio.set_event_loop(loop)
        loop.run_forever()
    t = threading.Thread(target=run, name="ola-ble-loop", daemon=True)
    t.start()
    _loop = loop
    _thread = t
    return loop


async def _close_session():
    global _session, _session_mac, _session_at
    s = _session
    _session = None
    _session_mac = None
    _session_at = 0.0
    if s is not None:
        try:
            await s.__aexit__(None, None, None)
        except Exception:
            pass


async def _get_session(mac: str):
    """Authenticated Ola session; ping or reconnect instead of a 12s hard drop."""
    global _session, _session_mac, _session_at
    import winrt_client
    now = time.monotonic()
    live = (_session is not None and _session_mac == mac and _session.key is not None)
    if live:
        idle = now - _session_at
        if _session_at == 0 or idle > _HARD_RECONNECT:
            live = False
        elif idle > _PING_AFTER:
            try:
                await _session.keep_alive()
                _session_at = time.monotonic()
            except Exception:
                live = False
    if live:
        _session_at = time.monotonic()
        return _session

    await _close_session()

    # ensure bonded
    dev = await BluetoothLEDevice.from_bluetooth_address_async(_mac_int(mac))
    if dev is None:
        raise RuntimeError("scooter not found (awake? in range? phones' BT off?)")
    if not dev.device_information.pairing.is_paired:
        r = await _pair(mac)
        if not r.startswith(("paired", "already")):
            raise RuntimeError(r)

    o = winrt_client.Ola(mac)
    await o.__aenter__()
    try:
        await o.authenticate()
    except Exception:
        try:
            await o.__aexit__(None, None, None)
        except Exception:
            pass
        raise
    _session = o
    _session_mac = mac
    _session_at = time.monotonic()
    return o


async def _command(mac: str, name: str) -> str:
    o = await _get_session(mac)
    if name.upper() != "AUTH":
        try:
            await o.command(name)
        except Exception:
            # session may be stale — one reconnect
            await _close_session()
            o = await _get_session(mac)
            await o.command(name)
    return f"{name} sent — authorized"


def command(name: str, mac: str = DEFAULT_MAC) -> str:
    if not _WINRT:
        return f"BLE unavailable: {_IMPORT_ERR}"
    with _lock:
        loop = _ensure_loop()
        fut = asyncio.run_coroutine_threadsafe(_command_retry(mac, name), loop)
        try:
            return fut.result(timeout=20)
        except Exception as e:
            # force drop session on hard failure
            asyncio.run_coroutine_threadsafe(_close_session(), loop).result(timeout=5)
            raise e


async def _command_retry(mac: str, name: str, attempts: int = 2) -> str:
    last = None
    for i in range(attempts):
        try:
            return await _command(mac, name)
        except Exception as e:
            last = e
            await _close_session()
            if i + 1 < attempts:
                await asyncio.sleep(0.35)
    raise last


async def _scan(timeout: float) -> str:
    for name, addr, _ in await _scan_list(timeout):
        if name.lower() == "olas1":
            return addr
    return ""


def scan(timeout: float = 8.0) -> str:
    if not _WINRT:
        return ""
    try:
        return asyncio.run(_scan(timeout))
    except Exception:
        return ""


async def _scan_list(timeout: float):
    from bleak import BleakScanner
    found = await BleakScanner.discover(timeout=timeout, return_adv=True)
    rows = [((adv.local_name or d.name or "").strip(), d.address, adv.rssi or -999)
            for d, adv in found.values()]
    rows.sort(key=lambda r: -r[2])
    return rows


def scan_list(timeout: float = 6.0):
    if not _WINRT:
        return []
    try:
        return asyncio.run(_scan_list(timeout))
    except Exception:
        return []
