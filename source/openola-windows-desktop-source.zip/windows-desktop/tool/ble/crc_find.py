import sys; sys.path.insert(0, ".")
import olakey

# Real vectors from the Nothing Phone 2 capture (handle 0x001d writes)
# seed request: no data, no EOF
SEEDREQ = bytes.fromhex("0a016aa8fda9010230"); SEEDREQ_CRC = 0x7c2b
# key: type 31, data "ACA58D84", EOF 01
KEY     = bytes.fromhex("13026aa8fdaa0102314143413538443834 01".replace(" ","")); KEY_CRC = 0x4dee

# --- verify seed/key algorithm: seed was sent by scooter; key we captured ---
# From the seed-request reply the app computed key "ACA58D84". Find the seed:
print("== check algorithm ==")
# the seed appears in the scooter notifications; test a couple candidates
for cand in (b"95839592", b"58839592", b"39353833"):
    try:
        print(f"  generate_key({cand!r}) = {olakey.generate_key(cand,'BLE','01').decode()}")
    except Exception as e:
        print("  ", cand, e)
print("  (target key = ACA58D84)")

# --- CRC search ---
def crc16(data, poly, init, refin, refout, xorout):
    def rb(b):
        b &= 0xff; r = 0
        for _ in range(8): r = (r << 1) | (b & 1); b >>= 1
        return r
    crc = init
    for byte in data:
        b = rb(byte) if refin else byte
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ poly) & 0xffff if (crc & 0x8000) else (crc << 1) & 0xffff
    if refout:
        o = 0
        for _ in range(16): o = (o << 1) | (crc & 1); crc >>= 1
        crc = o
    return crc ^ xorout

CATALOG = {
    "CCITT-FALSE": (0x1021,0xFFFF,False,False,0x0000),
    "XMODEM":      (0x1021,0x0000,False,False,0x0000),
    "KERMIT":      (0x1021,0x0000,True,True,0x0000),
    "CCITT-AUG":   (0x1021,0x1D0F,False,False,0x0000),
    "GENIBUS":     (0x1021,0xFFFF,False,False,0xFFFF),
    "ARC":         (0x8005,0x0000,True,True,0x0000),
    "MODBUS":      (0x8005,0xFFFF,True,True,0x0000),
    "USB":         (0x8005,0xFFFF,True,True,0xFFFF),
    "MAXIM":       (0x8005,0x0000,True,True,0xFFFF),
    "DNP":         (0x3D65,0x0000,True,True,0xFFFF),
    "X25":         (0x1021,0xFFFF,True,True,0xFFFF),
}
def ranges(frame):
    # try: whole frame, frame without leading length byte
    return {"full": frame, "no_len": frame[1:]}

print("\n== CRC search (must match BOTH vectors) ==")
for name,(poly,init,ri,ro,xo) in CATALOG.items():
    for rname, sr in ranges(SEEDREQ).items():
        kr = ranges(KEY)[rname]
        for order in ("be","le"):
            c1 = crc16(sr,poly,init,ri,ro,xo); c2 = crc16(kr,poly,init,ri,ro,xo)
            def pack(c): return c if order=="be" else ((c&0xff)<<8)|(c>>8)
            if pack(c1)==SEEDREQ_CRC and pack(c2)==KEY_CRC:
                print(f"  MATCH: {name} range={rname} order={order}")
