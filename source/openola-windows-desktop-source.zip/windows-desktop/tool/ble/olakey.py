"""
Ola consumer-app BLE seed/key security access.

This is the SAME grid-ASCII seed/key transform used on the diagnostic (UDS/CAN)
side and already verified there (tool/oladiag/seedkey.py). The only difference
for the phone BLE path is the 4-element constant vector, which the consumer app
selects for VehicleEcuType.BLE.

Source: consumer_app/Fc.b.txt  (method b([B seed, String level, VehicleEcuType))
        consumer_app/Fc.b$a.txt (ecu ordinal -> branch map: BMS1 VCU2 MCU3 BLE4)

Decisive point for the "one app for all" question:
    b(seed, level, ecuType) takes ONLY the vehicle-supplied seed plus two
    compile-time constants (level string, ecu type). There is NO VIN, account
    token, or per-vehicle secret anywhere in it. => the algorithm is identical
    for every scooter of this firmware family.

The seed arrives from the module as 8 bytes that are the ASCII codes of 8 hex
digits (e.g. b"F7D6A2E3"); those ASCII codes are the input the transform packs.
The returned key is likewise 8 ASCII hex-digit bytes, written verbatim to the
SEED_AUTHENTICATION_KEY packet.
"""

from __future__ import annotations

# getKey() constant vectors, per ECU / security level.
# BLE values decoded from Fc.b.txt (BLE branch, ordinal 4):
#   level "01"  -> [78, 99, 67, 22]
#   level other -> [13, 31, 90, 96]
# The BMS/VCU/MCU rows are carried for cross-checking against tool/oladiag.
_KEY_CONST = {
    "BLE": {"01": [78, 99, 67, 22], "other": [13, 31, 90, 96]},
    "BMS": {"01": [54, 43, 79, 19], "other": [77, 13, 53, 47]},
    "VCU": {"01": [99, 61, 69, 19], "other": [30, 43, 5, 62]},
    "MCU": {"01": [39, 67, 2, 23], "other": [39, 67, 2, 23]},
}


def _hex2dec(pair):
    """[c0, c1] ASCII codes of hex digits -> byte value (c0 low nibble)."""
    c0, c1 = pair
    v = 0
    if 48 <= c0 < 58:
        v += (c0 - 48)
    elif 65 <= c0 < 71:
        v += (c0 - 55)
    if 48 <= c1 < 58:
        v += (c1 - 48) * 16
    elif 65 <= c1 < 71:
        v += (c1 - 55) * 16
    return v


def _dec2hex(val):
    """byte value -> [low_nibble_char, high_nibble_char] as ASCII codes."""
    lo = val % 16
    lo = lo + 55 if lo >= 10 else lo + 48
    hi = (val // 16) % 16
    hi = hi + 55 if hi >= 10 else hi + 48
    return [lo, hi]


def _random_number_tester(seed_ints, consts):
    m = [[0, 0] for _ in range(4)]
    m[0][0], m[0][1] = seed_ints[0], seed_ints[1]
    m[1][0], m[1][1] = seed_ints[2], seed_ints[3]
    m[2][0], m[2][1] = seed_ints[4], seed_ints[5]
    m[3][0], m[3][1] = seed_ints[6], seed_ints[7]
    # rotate first column up
    tmp = m[0][0]
    m[0][0], m[1][0], m[2][0], m[3][0] = m[1][0], m[2][0], m[3][0], tmp
    x = [_hex2dec(m[i]) for i in range(4)]
    y = [((x[i] - consts[i] + 127) % 127) for i in range(4)]
    # app: (v*91 + 202) % 127  ==  (v*91 + 75) % 127
    z = [(((y[i] * 91) + 202) % 127) for i in range(4)]
    return z


def _key_p(p):
    a = ((((p[0] * 7) + 255) % 255) ^ 23)
    b = ((((p[1] * 5) + 255) % 255) ^ 67)
    c = ((((p[2] * 1) + 255) % 255) ^ 8)
    d = ((((8 * p[3]) + 255) % 255) ^ 45)
    v9, v14, v1, v2 = a ^ b, b ^ c, c ^ d, d ^ a
    return [_dec2hex(v9), _dec2hex(v14), _dec2hex(v1), _dec2hex(v2)]


def generate_key(seed: bytes, ecu: str = "BLE", level: str = "01") -> bytes:
    """
    Compute the 8-byte security-access key from an 8-byte seed.

    seed  : the 8 bytes received in the SEED response (ASCII codes of hex digits)
    ecu   : "BLE" for the phone path; "BMS"/"VCU"/"MCU" reuse the diagnostic rows
    level : security level string, "01" is SecurityLevel.LEVEL1
    """
    if len(seed) != 8:
        raise ValueError(f"BLE seed must be 8 bytes, got {len(seed)}")
    consts = _KEY_CONST[ecu]["01" if level == "01" else "other"]
    grid = _key_p(_random_number_tester(list(seed), consts))
    out = [0] * 8
    for r in range(4):
        out[r * 2 + 0] = grid[r][0]
        out[r * 2 + 1] = grid[r][1]
    return bytes(out)


if __name__ == "__main__":
    # Deterministic self-consistency vectors (no vehicle needed).
    for level in ("01", "03"):
        for s in (b"F7D6A2E3", b"11223344", b"ABCDEF01"):
            print(f"BLE level {level} seed {s.decode()} -> "
                  f"{generate_key(s, 'BLE', level).decode(errors='replace')} "
                  f"({generate_key(s, 'BLE', level).hex()})")
