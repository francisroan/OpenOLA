"""
Ola S1 BLE client over WinRT GATT (owner's own scooter).

Keeps the link snappy: cached service lookup first, short notify arming,
don't block long on TEST_AES, short post-command hold.
"""
import asyncio, sys, os
DEBUG = os.environ.get("OLA_BLE_DEBUG") == "1"
import olakey, crypto
from protocol import Framer, SEED_REQUEST, SEED_KEY, TEST_AES, DIRECT_COMMAND, CMD

from winrt.windows.devices.bluetooth import BluetoothLEDevice, BluetoothCacheMode
from winrt.windows.devices.bluetooth.genericattributeprofile import (
    GattClientCharacteristicConfigurationDescriptorValue as CCCD,
    GattCommunicationStatus, GattWriteOption)
from winrt.windows.storage.streams import DataReader, DataWriter

MAC = "00:00:00:00:00:00"
SERVICE = "6e400001-b5a3-f393-e0a9-8a85b62fc3df"
RX = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
TX = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
SEED_REPLY, KEY_ACK, AES_ACK = 0x70, 0x71, 0x72
TEST_AES_DATA = b"D_ALIVE"


def _u(x): return str(x).lower()

def buf_to_bytes(ibuffer):
    r = DataReader.from_buffer(ibuffer)
    out = bytearray(ibuffer.length)
    r.read_bytes(out)
    return bytes(out)

def bytes_to_buf(data):
    w = DataWriter(); w.write_bytes(bytes(data)); return w.detach_buffer()


class Ola:
    def __init__(self, mac=MAC):
        self.mac = mac; self.framer = Framer(); self.key = None
        self._q = asyncio.Queue(); self._loop = None
        self.dev = self.rx = self.tx = None
        self._token = None

    async def _get_services(self):
        """Prefer cached services (fast); fall back to uncached with short retries."""
        last = None
        for uncached in (False, True, True):
            try:
                if uncached:
                    last = await self.dev.get_gatt_services_with_cache_mode_async(
                        BluetoothCacheMode.UNCACHED)
                else:
                    try:
                        last = await self.dev.get_gatt_services_with_cache_mode_async(
                            BluetoothCacheMode.CACHED)
                    except AttributeError:
                        last = await self.dev.get_gatt_services_async()
            except AttributeError:
                last = await self.dev.get_gatt_services_async()
            if last is not None and last.services is not None and len(last.services) > 0:
                return last
            await asyncio.sleep(0.15)
        return last

    async def __aenter__(self):
        self._loop = asyncio.get_event_loop()
        addr = int(self.mac.replace(":", ""), 16)
        self.dev = await BluetoothLEDevice.from_bluetooth_address_async(addr)
        if self.dev is None:
            raise RuntimeError("device not found (paired? in range?)")
        sres = await self._get_services()
        svc = None
        if sres is not None and sres.services is not None:
            for s in sres.services:
                if _u(s.uuid) == SERVICE:
                    svc = s; break
        if svc is None:
            raise RuntimeError("Ola BLE service not found (scooter busy? try again)")
        cres = await svc.get_characteristics_async()
        for c in cres.characteristics:
            if _u(c.uuid) == RX: self.rx = c
            elif _u(c.uuid) == TX: self.tx = c
        if self.rx is None or self.tx is None:
            raise RuntimeError("Ola BLE characteristics not found")

        def on_val(sender, args):
            b = buf_to_bytes(args.characteristic_value)
            if DEBUG: print("   << notify", b.hex(), file=sys.stderr, flush=True)
            self._loop.call_soon_threadsafe(self._q.put_nowait, b)
        self._token = self.rx.add_value_changed(on_val)
        st = await self.rx.write_client_characteristic_configuration_descriptor_async(CCCD.NOTIFY)
        if DEBUG: print("CCCD notify status:", st, file=sys.stderr)
        return self

    async def __aexit__(self, *e):
        try:
            if self._token is not None:
                self.rx.remove_value_changed(self._token)
        except Exception: pass
        try:
            await self.rx.write_client_characteristic_configuration_descriptor_async(CCCD.NONE)
        except Exception: pass
        try:
            if self.dev is not None:
                self.dev.close()
        except Exception: pass
        self.dev = self.rx = self.tx = None

    async def _write(self, frame):
        for pkt in Framer.chunk(frame):
            r = await self.tx.write_value_with_result_async(bytes_to_buf(pkt))
            if r.status != GattCommunicationStatus.SUCCESS:
                print("write status", r.status, file=sys.stderr)

    async def _await_type(self, want, timeout=5.0):
        end = self._loop.time() + timeout
        while self._loop.time() < end:
            try:
                b = await asyncio.wait_for(self._q.get(), timeout=end - self._loop.time())
            except asyncio.TimeoutError:
                return None
            if len(b) > 8 and b[8] == want:
                return b[9:-3]
        return None

    async def authenticate(self):
        await asyncio.sleep(0.12)         # brief arm after CCCD
        if DEBUG: print("-> SEED_REQUEST", file=sys.stderr)
        seed = None
        for _ in range(2):
            await self._write(self.framer.build_plain(SEED_REQUEST))
            seed = await self._await_type(SEED_REPLY, timeout=2.5)
            if seed and len(seed) >= 8:
                break
        if not seed or len(seed) < 8:
            raise RuntimeError(f"no seed reply ({seed!r})")
        seed = seed[:8]
        key = olakey.generate_key(seed, "BLE", "01")
        self.key = crypto.session_key(seed, key)
        if DEBUG: print(f"<- seed {seed.decode()}  key {key.decode()}\n-> SEED_KEY", file=sys.stderr)
        await self._write(self.framer.build_plain(SEED_KEY, key))
        ack = await self._await_type(KEY_ACK, timeout=2.5)
        if not (ack and ack[0] == 1):
            raise RuntimeError(f"not authorized (ack {ack!r})")
        if DEBUG: print("<- AUTHORIZED", file=sys.stderr)
        await self._write(self.framer.build_encrypted(self.key, TEST_AES, TEST_AES_DATA))
        # Don't stall here — scooter often chatters; proceed once we see AES ack or after a short wait.
        await self._await_type(AES_ACK, timeout=0.45)
        return True

    async def command(self, name):
        val = CMD[name.upper()]
        if DEBUG: print(f"-> {name.upper()} [1,{val}]", file=sys.stderr)
        else: print(f"-> {name.upper()} [1,{val}]", file=sys.stderr)
        await self._write(self.framer.build_encrypted(self.key, DIRECT_COMMAND, bytes([val])))
        # Hold just long enough for the module to start actuating (apk/BLE_CHECKPOINT.md).
        await asyncio.sleep(0.30)

    async def keep_alive(self):
        """Idle TEST_AES ping — see apk/BLE_CHECKPOINT.md change #1."""
        if self.key is None:
            raise RuntimeError("authenticate first")
        await self._write(self.framer.build_encrypted(self.key, TEST_AES, TEST_AES_DATA))
        if await self._await_type(AES_ACK, timeout=0.45) is None:
            raise RuntimeError("AES ping timeout")


async def main():
    action = sys.argv[1] if len(sys.argv) > 1 else "auth"
    async with Ola() as o:
        await o.authenticate()
        if action == "cmd":
            await o.command(sys.argv[2])
        print("OK", file=sys.stderr)

if __name__ == "__main__":
    asyncio.run(main())
