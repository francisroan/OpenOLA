# tool/ble — Ola S1 BLE control client (owner's own scooter)

Reimplements the consumer app's BLE control path (lock / unlock / trunk / lights)
from reverse-engineered protocol constants. Full write-up and the "one app for
all" / disclosure analysis: `reverse_engineering/BLE_CLIENT_AND_ONE_APP_FOR_ALL.md`.

## Files
- `olakey.py`  — seed→key (universal grid-ASCII algorithm; BLE constant vector). **Verified** vs `F7D6A2E3→48153568`.
- `crypto.py`  — HKDF-SHA256 session key + AES-128-CTR + fixed-salt IV. **Verified** (deterministic, round-trips).
- `protocol.py`— frame layout `Len|Id|Time|IV|Type|Data|EOF|CRC` + command catalogue. Order/widths from bytecode; wire constants need one capture.
- `client.py`  — bleak GATT client: `scan` / `auth` / `cmd`. **Untested on hardware.**
- `capture.py` — btsnoop_hci.log → ATT payload dump, to calibrate `protocol.py` and read SMP pairing fields.
- `selftest.py`— offline checks, no hardware/network.

## Setup
```
py -3 -m pip install bleak cryptography
py -3 selftest.py            # offline, should print ALL OFFLINE CHECKS PASSED
```

## Use (owner's scooter only)
```
py -3 client.py scan                                   # find the OLAS1 module
py -3 client.py auth --addr <BLE_MAC>                   # seed/key handshake
py -3 client.py cmd FLASH  --addr <BLE_MAC>            # start harmless
py -3 client.py cmd UNLOCK --addr <BLE_MAC>
```

## Status / honesty
- The **crypto and auth math are proven**; the **byte-exact wire framing and the
  bonding requirement are not yet confirmed on hardware.**
- Requires a **bonded** link. This tool does not bypass pairing and must only be
  used against a scooter you own. See the disclosure doc before any live test.
- Calibrate the frame once from a real capture: run the stock app with HCI snoop
  on, then `py -3 capture.py btsnoop_hci.log` and line the frames up against
  `olakey`/`crypto`.
