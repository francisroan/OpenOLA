"""Bond the laptop to OLAS1 using Windows custom pairing (ConfirmOnly = Just Works).
bleak's default pair() doesn't drive the NoInputNoOutput ceremony; this does.
   py -3 pair_win.py [MAC]        pair
   py -3 pair_win.py [MAC] unpair unpair/forget
"""
import asyncio, sys
from winrt.windows.devices.bluetooth import BluetoothLEDevice
from winrt.windows.devices.enumeration import (
    DevicePairingKinds, DevicePairingProtectionLevel, DevicePairingResultStatus)

def mac_to_int(mac): return int(mac.replace(":", ""), 16)

async def main():
    mac = sys.argv[1] if len(sys.argv) > 1 else "8A:85:B6:2F:C3:DF"
    unpair = len(sys.argv) > 2 and sys.argv[2] == "unpair"
    dev = await BluetoothLEDevice.from_bluetooth_address_async(mac_to_int(mac))
    if dev is None:
        print("device not found (in range? BT on?)"); return
    pairing = dev.device_information.pairing
    print(f"can_pair={pairing.can_pair} is_paired={pairing.is_paired}")

    if unpair:
        res = await pairing.unpair_async()
        print("unpair:", res.status); return
    if pairing.is_paired:
        print("already paired"); return

    custom = pairing.custom
    def on_req(sender, args):
        print("  pairing_requested kind:", args.pairing_kind)
        args.accept()                       # ConfirmOnly -> Just Works accept
    token = custom.add_pairing_requested(on_req)
    try:
        res = await custom.pair_async(DevicePairingKinds.CONFIRM_ONLY)
        print("pair result:", res.status)
        print("PAIRED" if res.status in (
            DevicePairingResultStatus.PAIRED,
            DevicePairingResultStatus.ALREADY_PAIRED) else "NOT paired")
    finally:
        custom.remove_pairing_requested(token)

asyncio.run(main())
