"""
Minimal btsnoop_hci.log parser -> extract ATT Write / Notification payloads.

Purpose: calibrate protocol.py against a real capture of the stock Ola app doing
seed-auth + unlock, and pull the SMP pairing fields for the disclosure. Wireshark
is richer for SMP; this is a quick offline dump of the ATT value payloads so you
can line them up with olakey/crypto.

Usage:  py -3 capture.py btsnoop_hci.log
"""
from __future__ import annotations
import struct
import sys

# btsnoop: 8-byte magic "btsnoop\0" + version(4) + datalink(4), then records:
#   orig_len(4) incl_len(4) flags(4) drops(4) ts(8) | packet[incl_len]
def records(path):
    with open(path, "rb") as f:
        hdr = f.read(16)
        if not hdr.startswith(b"btsnoop\x00"):
            raise SystemExit("not a btsnoop file")
        while True:
            rh = f.read(24)
            if len(rh) < 24:
                break
            olen, ilen, flags, drops, ts = struct.unpack(">IIIIq", rh)
            pkt = f.read(ilen)
            yield flags, pkt


def att_values(path):
    """Yield (direction, opcode, handle, value) for ATT write/notify/read-rsp."""
    for flags, pkt in records(path):
        # HCI ACL: type(1)=0x02, handle(2), total(2), L2CAP len(2), cid(2), ATT...
        if not pkt or pkt[0] != 0x02 or len(pkt) < 9:
            continue
        cid = struct.unpack_from("<H", pkt, 7)[0]
        if cid != 0x0004:  # ATT
            continue
        att = pkt[9:]
        if not att:
            continue
        op = att[0]
        direction = "phone->scooter" if (flags & 1) == 0 else "scooter->phone"
        # 0x12 Write Req, 0x52 Write Cmd, 0x1B Notify, 0x1D Indicate, 0x0B Read Rsp
        if op in (0x12, 0x52) and len(att) >= 3:
            handle = struct.unpack_from("<H", att, 1)[0]
            yield direction, op, handle, att[3:]
        elif op in (0x1B, 0x1D) and len(att) >= 3:
            handle = struct.unpack_from("<H", att, 1)[0]
            yield direction, op, handle, att[3:]
        elif op == 0x0B:
            yield direction, op, None, att[1:]


OPNAME = {0x12: "WriteReq", 0x52: "WriteCmd", 0x1B: "Notify", 0x1D: "Indicate", 0x0B: "ReadRsp"}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    for direction, op, handle, val in att_values(sys.argv[1]):
        h = f"0x{handle:04x}" if handle is not None else "  -  "
        print(f"{direction:15} {OPNAME.get(op, hex(op)):9} hdl={h} len={len(val):3} {val.hex()}")
