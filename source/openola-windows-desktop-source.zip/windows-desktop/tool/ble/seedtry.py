"""Focused live seed-request calibration. Corrected framing:
   Length | Id | Time(4, unix secs, %08X) | IV=0102 | Type=30 | CRC=0102
Tries a few Length values (the one field whose exact semantics are murky).
Listens on 6e400002 for the seed reply. Owner's scooter only."""
import asyncio, struct, time, sys
from bleak import BleakClient
import olakey

ADDR = "8A:85:B6:2F:C3:DF"
RX = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
TX = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

def frame(length, tsec, pid=1, typ=0x30):
    t4 = struct.pack(">I", tsec & 0xFFFFFFFF)
    return bytes([length & 0xFF, pid & 0xFF]) + t4 + b"\x01\x02" + bytes([typ]) + b"\x01\x02"

got = []
def cb(c, d):
    b = bytes(d); got.append(b)
    print("  << NOTIFY", getattr(c,'uuid',c), f"[{len(b)}]", b.hex(), flush=True)

async def main():
    async with BleakClient(ADDR, timeout=20.0) as cl:
        print("connected", cl.is_connected, flush=True)
        await cl.start_notify(RX, cb)
        tsec = int(time.time())
        # candidates: Length = total(11), total+1(12), payload-ish, 0, 9, 10
        for L in (0x0b, 0x0c, 0x0a, 0x09, 0x02, 0x00):
            if not cl.is_connected:
                print("  (reconnecting)", flush=True)
                return
            fr = frame(L, tsec)
            n = len(got)
            print(f">> Len=0x{L:02x}: {fr.hex()}", flush=True)
            try:
                await cl.write_gatt_char(TX, fr, response=True)
            except Exception as e:
                print("   write/err:", e, flush=True); return
            await asyncio.sleep(2.0)
            if len(got) > n:
                print(f"   *** REPLY to Len=0x{L:02x} ***", flush=True)
                break
        await asyncio.sleep(1.0)
    print("\nreplies:", len(got))
    for b in got:
        for off in range(max(1, len(b)-7)):
            s = b[off:off+8]
            if len(s)==8 and all(c in b"0123456789ABCDEFabcdef" for c in s):
                print(f"  seed@{off}={s!r} -> key {olakey.generate_key(bytes(s),'BLE','01').decode(errors='replace')}")

asyncio.run(main())
