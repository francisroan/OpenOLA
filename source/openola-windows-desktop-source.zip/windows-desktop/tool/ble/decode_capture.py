"""Decode a captured Ola BLE session end-to-end (auth + commands).
Usage: py -3 decode_capture.py <btsnoop_hci.log>
Uses the seed/key seen in the capture to derive the session key and decrypt
every DIRECT_COMMAND, proving the whole stack against real data."""
import sys
import crypto, olakey
from capture import att_values
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

CMD = {0:"PROXIMITY",1:"LOCK",2:"UNLOCK",3:"TRUNK_OPEN",4:"TRUNK_CLOSE",
       5:"PROX_LOCK",6:"PROX_UNLOCK",7:"PROX_ENABLED",8:"PROX_DISABLED",
       9:"SEND_PROFILE_ID",10:"SILENT_UNLOCK"}
RTYPE = {0x70:"SEED_REPLY",0x71:"KEY_ACK",0x72:"AES_ACK"}

def main(path):
    seed = key = None
    frames = [(d, o, h, bytes(v)) for d, o, h, v in att_values(path)
              if h in (0x001d, 0x001a)]
    # find seed (reply type 0x70) and key (our write type 0x31)
    for d, o, h, v in frames:
        if d.startswith("scooter") and len(v) > 9 and v[8] == 0x70:
            seed = v[9:17]
        if d.startswith("phone") and len(v) > 9 and v[6:8] == b"\x01\x02" and v[8] == 0x31:
            key = v[9:17]
    print("seed   :", seed, "->", seed.decode() if seed else None)
    print("key    :", key, "->", key.decode() if key else None)
    if seed:
        print("key(alg):", olakey.generate_key(seed, "BLE", "01").decode(),
              "(matches capture)" if key and olakey.generate_key(seed,"BLE","01")==key else "")
    if not (seed and key):
        print("could not locate seed/key"); return
    K = crypto.session_key(seed, key)
    print("session:", K.hex(), "\n--- frames ---")
    seen = set()
    for d, o, h, v in frames:
        if h == 0x001a: continue
        if v[6:8] == b"\x01\x02":
            print(f"{d}  PLAIN type={v[8]}")
            continue
        iv = crypto.RANDOM_SALT + v[6:8]
        ct = v[8:-3]
        pt = Cipher(algorithms.AES(K), modes.CTR(iv)).decryptor().update(ct)
        if pt in seen: continue
        seen.add(pt)
        tag = ""
        if len(pt) == 2 and pt[0] == 1:
            tag = "  <== DIRECT_COMMAND " + CMD.get(pt[1], f"?{pt[1]}")
        print(f"{d}  ENC pt={list(pt)} ascii={pt!r}{tag}")

if __name__ == "__main__":
    main(sys.argv[1])
