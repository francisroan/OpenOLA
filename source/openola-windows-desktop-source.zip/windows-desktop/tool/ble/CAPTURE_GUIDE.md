# Capturing the Ola app's real BLE frames (non-rooted phone)

Goal: get the exact bytes the Ola app writes for the seed request + key, and the
seed reply, to calibrate `tool/ble`. We repackage the app with a Frida gadget.

Everything runs on the laptop except installing/running the app on the phone
(phone connected by USB, USB debugging ON in Developer options).

## 0. One-time tooling (laptop)
```
py -3 -m pip install objection frida-tools
```
- Install a JDK (Temurin 17+) and make sure `java` is on PATH.
- Android platform-tools (`adb`) on PATH.
- APKEditor (to merge the split bundle): download `APKEditor.jar` from
  https://github.com/REAndroid/APKEditor/releases

## 1. Merge the split bundle into one universal APK
The file `notes/Ola-Electric_5.4.0_apkcube.apk` is a ZIP of base + config splits;
objection needs a single APK.
```
java -jar APKEditor.jar merge -i "D:\Ola_claude\notes\Ola-Electric_5.4.0_apkcube.apk" -o ola_merged.apk
```

## 2. Patch with the Frida gadget
```
objection patchapk -s ola_merged.apk
```
Produces `ola_merged.objection.apk` (gadget injected, re-signed with a debug key).

## 3. Install the patched app
```
adb uninstall com.olaelectric.companion      # remove the store version first
adb install ola_merged.objection.apk
```

## 4. Attach Frida and log
- Launch the app on the phone; it will pause on a splash waiting for Frida.
- On the laptop:
```
frida -U -n Gadget -l "D:\Ola_claude\tool\ble\frida_ola_ble.js"
```
  (if `-n Gadget` fails, try `objection -g com.olaelectric.companion explore`
  then `import D:\Ola_claude\tool\ble\frida_ola_ble.js`.)
- Log in (OTP), make sure the scooter is awake and in range, then press **Unlock**
  (and Lock, and Trunk).

## 5. Send me the output
Copy every line that starts with `OUT` or `IN`, e.g.
```
OUT write   6e400003-...  0b01....30....
IN  notify  6e400002-...  ....            <- the seed
OUT write   6e400003-...  ....49....      <- the key
```
Those ~5-10 lines let me finish `protocol.py` exactly.

## Realistic caveats
- **Tamper detection:** production apps sometimes refuse to run when re-signed.
  If the app crashes on launch or login fails, this route is blocked -- fall back
  to an **nRF52840 BLE sniffer** (captures over-the-air, no app changes) or a
  rooted spare phone.
- **Login/bond:** reinstalling clears the app's stored session; you'll re-login by
  OTP. The scooter bond lives in Android's Bluetooth settings, not the app, so it
  persists.
- The scooter only accepts one BLE central at a time; keep the laptop's BLE idle
  while capturing from the phone.
