"""
Live BLE bring-up probe for OLAS1 (owner's scooter). READ-MOSTLY:
  scan            -> list devices, highlight OLAS1
  gatt  --addr X  -> connect, bond (Just Works, silent), dump full GATT table
  seed  --addr X  -> the above + subscribe notifies + send ONE SEED_REQUEST,
                     print every raw notification (so we can calibrate framing).
                     Does NOT send lock/unlock or any actuator command.

bleak 3.x + cryptography. Run with phone Bluetooth OFF so the module is free.
"""
from __future__ import annotations
import argparse, asyncio, sys
import olakey, crypto
from protocol import Framer, SEED_REQUEST, SEED_KEY

NAME = "OLAS1"


async def scan(timeout=10.0):
    from bleak import BleakScanner
    found = await BleakScanner.discover(timeout=timeout, return_adv=True)
    rows = list(found.values())
    rows.sort(key=lambda r: -(r[1].rssi or -999))
    print(f"{'ADDRESS':20} {'RSSI':>5}  NAME / uuids")
    for dev, adv in rows:
        nm = adv.local_name or dev.name or ""
        star = " <== OLAS1" if NAME.lower() in (nm or "").lower() else ""
        print(f"{dev.address:20} {adv.rssi!s:>5}  {nm!r} {list(adv.service_uuids)}{star}")
    return rows


async def _find_addr(timeout=10.0):
    for dev, adv in (await scan(timeout)):
        if NAME.lower() in ((adv.local_name or dev.name or "")).lower():
            return dev.address
    return None


def _dump_gatt(client):
    notify_c = write_c = None
    print("\n--- GATT TABLE ---")
    for s in client.services:
        print(f"service {s.uuid}")
        for c in s.characteristics:
            props = ",".join(c.properties)
            print(f"   char {c.uuid}  handle={c.handle}  [{props}]")
            if ("notify" in c.properties or "indicate" in c.properties) and notify_c is None:
                notify_c = c
            if ("write" in c.properties or "write-without-response" in c.properties) and write_c is None:
                write_c = c
            for d in c.descriptors:
                print(f"      desc {d.uuid} handle={d.handle}")
    print(f"--- picked RX(notify)={notify_c and notify_c.uuid}  "
          f"TX(write)={write_c and write_c.uuid} ---\n")
    return notify_c, write_c


async def gatt(addr):
    from bleak import BleakClient
    async with BleakClient(addr, timeout=20.0) as client:
        print("connected:", client.is_connected)
        _dump_gatt(client)


async def seed(addr, rx_uuid=None, tx_uuid=None):
    from bleak import BleakClient
    got = []
    async with BleakClient(addr, timeout=20.0) as client:
        print("connected:", client.is_connected)
        rx, tx = _dump_gatt(client)
        if rx_uuid: rx = rx_uuid
        else: rx = rx.uuid if rx else None
        if tx_uuid: tx = tx_uuid
        else: tx = tx.uuid if tx else None
        if not rx or not tx:
            print("!! could not resolve RX/TX; pass --rx/--tx", file=sys.stderr); return

        # NOTE: no pair() -- notify subscribes fine unbonded and the seed/key +
        # AES is the app-layer auth. Sweep the notify char over the UART TX.
        def on_notify(c, data):
            b = bytes(data)
            got.append((getattr(c, "uuid", str(c)), b))
            print(f"<< NOTIFY {getattr(c,'uuid',c)} [{len(b):3}]  {b.hex()}")

        subscribed = []
        for s in client.services:
            for ch in s.characteristics:
                if "notify" in ch.properties or "indicate" in ch.properties:
                    try:
                        await client.start_notify(ch, on_notify); subscribed.append(ch.uuid)
                    except Exception as e:
                        print(f"   notify {ch.uuid} skip: {e}")
        print("subscribed:", subscribed)

        framer = Framer()
        candidates = [
            ("framed_type48", framer.build_plain(SEED_REQUEST, b"")),
            ("raw_30",        bytes([SEED_REQUEST])),
            ("raw_30_00",     bytes([SEED_REQUEST, 0x00])),
            ("len2_30",       bytes([0x02, SEED_REQUEST, 0x00])),
            ("pad20_30",      bytes([SEED_REQUEST] + [0] * 19)),
        ]
        # every custom write char, both write modes
        write_chars = ["6e400003-b5a3-f393-e0a9-e50e24dcca9e",
                       "45616c3f-b5a3-f393-e0a9-e50e24dcca9e",
                       "46616c3f-b5a3-f393-e0a9-e50e24dcca9e"]
        for wc in write_chars:
            for name, frame in candidates:
                before = len(got)
                for resp in (True, False):
                    try:
                        for pkt in Framer.chunk(frame):
                            await client.write_gatt_char(wc, pkt, response=resp)
                        print(f">> [{wc[:8]}] {name} resp={resp}: {frame.hex()}")
                        break
                    except Exception as e:
                        if resp is False:
                            print(f">> [{wc[:8]}] {name}: write failed: {e}")
                await asyncio.sleep(1.5)
                if len(got) > before:
                    print(f"   *** {len(got)-before} REPLY to {name} on {wc} ***")
        for u in subscribed:
            try: await client.stop_notify(u)
            except Exception: pass

    # interpret
    print("\n--- ANALYSIS ---")
    if not got:
        print("no notifications. The seed frame header is probably wrong, or the "
              "module wants a different opcode / needs the app-layer session. "
              "Try: dump-only (gatt) confirmed the write char is right?")
        return
    for uuid, b in got:
        print(f"reply on {uuid}: {b.hex()}  ascii={b!r}")
        # try to locate an 8-byte ASCII-hex seed anywhere in the frame
        for off in range(0, max(1, len(b) - 7)):
            s8 = b[off:off + 8]
            if len(s8) == 8 and all(c in b"0123456789ABCDEFabcdef" for c in s8):
                try:
                    k = olakey.generate_key(bytes(s8), "BLE", "01")
                    print(f"  seed@{off}={s8!r} -> BLE key {k.decode(errors='replace')}")
                except Exception:
                    pass


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("scan")
    for name in ("gatt", "seed"):
        sp = sub.add_parser(name)
        sp.add_argument("--addr")
        sp.add_argument("--rx"); sp.add_argument("--tx")
    a = p.parse_args()
    if a.cmd == "scan":
        asyncio.run(scan())
    else:
        addr = a.addr or asyncio.run(_find_addr())
        if not addr:
            print("OLAS1 not found in scan; is phone BT off and scooter awake?", file=sys.stderr)
            sys.exit(1)
        asyncio.run((gatt if a.cmd == "gatt" else seed)(
            addr, *( (a.rx, a.tx) if a.cmd == "seed" else () )))


if __name__ == "__main__":
    main()
