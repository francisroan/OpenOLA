#!/usr/bin/env python3
"""Serial monitor for the Ola charger emulator (charger_emulator.ino), in Python.

Interactive terminal + timestamped logging at 115200 baud. Type emulator commands
(SLOW / FAST / BOOST / ARM / STOP / I 960 / V 600 / MODE 4 / FC on / LINK 3000 /
STATUS ...) and watch the 1 Hz heartbeat and all '#' messages. Everything is logged
to captures/charging/serial_<timestamp>.log.

Safety niceties that match the .ino:
  * --heartbeat N   sends a bare newline every N s. The emulator treats an empty line
                    as "no command" but the byte still refreshes its LINK <ms> watchdog,
                    so a hands-off run stays alive while this monitor is running and
                    auto-disconnects the moment you close it (or it crashes).
  * on exit (Ctrl-C / EOF) it sends STOP and waits ~1.3 s for disarmGraceful() to run,
    so the scooter is released cleanly instead of stranded (unless --no-stop-on-exit).

Usage:
  python serial_monitor.py                 # auto-detect the board's port
  python serial_monitor.py --list          # list serial ports and exit
  python serial_monitor.py --port COM7     # explicit port
  python serial_monitor.py --heartbeat 1   # keepalive newline every 1 s (for LINK)
"""
import argparse
import datetime
import sys
import threading
import time
from pathlib import Path

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    sys.exit("pyserial is not installed. Install it with:\n"
             "    python -m pip install pyserial")

# USB-serial adapter fingerprints commonly seen on Arduino/ESP32 boards.
HINTS = ('arduino', 'ch340', 'ch341', 'cp210', 'cp2102', 'cp2104', 'ftdi', 'ft232',
         'usb serial', 'usb-serial', 'wchusbserial', 'usbmodem', 'slab', 'esp32',
         'silicon labs', 'wch')


def _ports():
    return list(list_ports.comports())


def list_ports_cmd():
    ports = _ports()
    if not ports:
        print("No serial ports found. Plug in the board and try again.")
        return
    print("Serial ports:")
    for p in ports:
        print(f"  {p.device:12} {p.description}  [{p.hwid}]")


def find_port():
    ports = _ports()
    for p in ports:
        blob = f"{p.description} {p.hwid} {p.manufacturer or ''}".lower()
        if any(h in blob for h in HINTS):
            return p.device
    return ports[0].device if ports else None


def main():
    ap = argparse.ArgumentParser(description="Serial monitor for the Ola charger emulator.")
    ap.add_argument('--port', help='serial port, e.g. COM7 (default: auto-detect)')
    ap.add_argument('--baud', type=int, default=115200)
    ap.add_argument('--heartbeat', type=float, default=0.0,
                    help='send a keepalive newline every N seconds (for LINK <ms>)')
    ap.add_argument('--log', help='log file path (default: captures/charging/serial_<ts>.log)')
    ap.add_argument('--list', action='store_true', help='list serial ports and exit')
    ap.add_argument('--no-stop-on-exit', action='store_true',
                    help='do NOT send STOP on exit (leave the emulator running)')
    args = ap.parse_args()

    if args.list:
        list_ports_cmd()
        return

    port = args.port or find_port()
    if not port:
        print("No serial port found. Plug in the board, or pass --port COMx.")
        list_ports_cmd()
        return

    logdir = Path(__file__).resolve().parents[2] / 'captures' / 'charging'
    logdir.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    logpath = Path(args.log) if args.log else logdir / f'serial_{ts}.log'

    try:
        ser = serial.Serial(port, args.baud, timeout=0.1)
    except Exception as exc:
        sys.exit(f"Could not open {port} @ {args.baud}: {exc}")

    logf = open(logpath, 'a', encoding='utf-8', buffering=1)
    print(f"# connected {port} @ {args.baud} — logging to {logpath}")
    print("# commands: SLOW FAST BOOST ARM STOP  |  I 960  V 600  MODE 4  FC on  LINK 3000  STATUS")
    print("# type a command and press Enter. Ctrl-C to quit (sends STOP for a clean disconnect).")
    stop = threading.Event()

    def stamp():
        return datetime.datetime.now().strftime('%H:%M:%S.%f')[:-3]

    def reader():
        buf = b''
        while not stop.is_set():
            try:
                data = ser.read(256)
            except Exception:
                break
            if not data:
                continue
            buf += data
            while b'\n' in buf:
                line, buf = buf.split(b'\n', 1)
                text = line.decode('utf-8', 'replace').rstrip('\r')
                s = stamp()
                print(f"{s}  {text}")
                logf.write(f"{s}\t{text}\n")

    def beater():
        while not stop.is_set():
            try:
                ser.write(b'\n')
            except Exception:
                break
            stop.wait(args.heartbeat)

    threading.Thread(target=reader, daemon=True).start()
    if args.heartbeat > 0:
        threading.Thread(target=beater, daemon=True).start()
        print(f"# heartbeat: newline every {args.heartbeat}s (keeps the LINK watchdog satisfied)")

    try:
        for line in sys.stdin:
            cmd = line.rstrip('\n')
            try:
                ser.write((cmd + '\n').encode('utf-8'))
            except Exception as exc:
                print(f"# write failed: {exc}")
                break
            logf.write(f"{stamp()}\t>>> {cmd}\n")
    except KeyboardInterrupt:
        pass
    finally:
        if not args.no_stop_on_exit:
            try:
                print("# sending STOP for a clean disconnect…")
                ser.write(b'STOP\n')
                time.sleep(1.3)  # let disarmGraceful() send the end-of-session frames
            except Exception:
                pass
        stop.set()
        time.sleep(0.2)
        try:
            ser.close()
        except Exception:
            pass
        logf.close()
        print(f"# closed. log: {logpath}")


if __name__ == '__main__':
    main()
