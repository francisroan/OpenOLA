/*
 * Ola S1 CHARGER EMULATOR (ESP32 or Arduino Uno/Nano + MCP2515)
 * ============================================================================
 * Plays the CHARGER side on ch_can (500 kbit/s) to the scooter, to enumerate
 * how the vehicle classifies chargers (Slow/Fast/Boost) and how the BMS current
 * limit (0x121) responds to the advertised available current (0x213 Iavail).
 *
 * This TRANSMITS on the bus (MCP2515 in NORMAL mode). Read the safety block.
 * ----------------------------------------------------------------------------
 *  SAFETY  (bench / research on your own vehicle only)
 *  - Connect ONLY to CAN_H / CAN_L / GND at the charge socket. NEVER touch HV.
 *  - Do this with NO real charger connected and NO HV charging in progress.
 *    (You are impersonating the charger; a second real charger = bus contention.)
 *  - Scooter awake or asleep is fine; the 0x00B flood will wake the BMS.
 *  - The BMS may think a charger is present and command precharge/contactor.
 *    With no HV source nothing is delivered; the BMS will simply time out /
 *    fault when it sees no current. That is expected on a bench — just reset.
 *  - Boots DISARMED. It will NOT transmit until you type: ARM
 *    Type SAFE (or DISARM) at any time to stop transmitting immediately.
 * ----------------------------------------------------------------------------
 *  SERIAL @ 115200, newline-terminated commands:
 *
 *   PRESETS (type one word — it configures AND starts emulating that charger):
 *    SLOW             SC path, 49.1 A, mode 1, FC off      (expect type = Slow)
 *    FAST             + FC frames, mode 4, 96 A            (probe type = Fast)
 *    BOOST            + FC frames, mode 6, 96 A            (probe type = Boost)
 *    STOP | SAFE | DISARM   stop transmit, return to listen-only
 *
 *   FINE CONTROL (tweak the current preset live):
 *    ARM              enable transmit with current settings
 *    I <0.1A>         set 0x213 available current, e.g.  I 491 -> 49.1 A / I 960 -> 96.0 A
 *    V <0.1V>         set 0x213 available voltage, e.g.  V 600 -> 60.0 V
 *    MODE <0-7>       set 0x213 Charger_Mode field
 *    AUTH slow        0x083 = "EA75E877" (stock slow charger)
 *    AUTH blaze       0x083 = "57AE778E" (Bolt Blaze DC)
 *    AUTH <16 hex>    0x083 = raw 8 bytes, e.g. AUTH 3537414537373845
 *    FC on | off      inject FC frames (0x508/0x531) to probe Fast/Boost
 *    RX on | off      throttled sample of RX frames (default OFF, so the bus flood
 *                     can't drown your typed commands)
 *    LINK <ms>        serial/host link watchdog: if no serial byte arrives for <ms>
 *                     while ARMED, auto-send the graceful disconnect and stop TX.
 *                     LINK 0 = off (default). Use for a hands-off logged test: set e.g.
 *                     LINK 3000 and have your logger emit a byte every ~1 s; if the
 *                     logger/monitor dies, the scooter is cleanly disconnected.
 *    STATUS           print current settings
 *
 *   SILENT BY DEFAULT: boots DISARMED and transmits NOTHING until you send ARM or a
 *   preset over serial. On boards with native USB (ESP32-S2/S3, Leonardo), closing the
 *   Serial Monitor is detected instantly and auto-triggers the graceful disconnect. On
 *   UART-bridge boards (Uno/Nano, ESP32 classic) there is no host-presence line, so use
 *   LINK <ms> for the same safety.
 *
 *   A 1 Hz heartbeat always prints: armed?, awake?, your tx213 current, and the
 *   BMS-granted 0x121 current — feedback without the flood. Commands work with the
 *   Serial Monitor line-ending = Newline, OR "No line ending" (auto-completed
 *   150 ms after Send).
 *
 *   NOTE: FAST/BOOST are best-guess hypotheses (real chargers all used the SC
 *   path at mode 1, even DC). A flip of 0x62D to Fast/Boost is the finding;
 *   the exact FC byte layout is not yet known.
 *
 *  Read the vehicle's verdict (charger type = 0x62D) on VEHICLE CAN via the GUI;
 *  0x62D is NOT on ch_can. On ch_can watch the BMS reply here: 0x121 (granted
 *  current limit), 0x120, 0x040, 0x080 (auth request).
 *
 * Library: "mcp_can" by coryjfowler.  Wiring: reverse_engineering/CHARGE_CAN_CAPTURE.md
 */

#include <SPI.h>
#include <mcp_can.h>

#if defined(ARDUINO_ARCH_ESP32)
static const int PIN_CS = 5;
#else
static const int PIN_CS = 10;
#endif
MCP_CAN CAN(PIN_CS);

static const long BAUD_ENUM = CAN_500KBPS;
static const byte CRYSTAL   = MCP_8MHZ;   // change to MCP_16MHZ if your board is 16 MHz

// ---- emulated charger state (defaults = Bolt Blaze DC observed values) -------
bool     armed        = false;   // TX enabled?
bool     printRx      = false;   // OFF by default — a flooded bus drowns the console & your typed cmds
bool     fcInject     = false;
bool     vehicleAwake = false;   // heard a BMS frame yet?
byte     last121[8]   = {0};     // last BMS granted-limit frame (for the heartbeat)
bool     have121      = false;
unsigned long lastRxPrint = 0, lastBeat = 0, lastCharMs = 0;
uint16_t availI_01A   = 491;     // 0x213 Charging_Current_Available_range (0.1 A)
uint16_t availV_01V   = 600;     // 0x213 Charging_Voltage_Available_range (0.1 V)
uint8_t  chargerMode  = 1;       // 0x213 Charger_Mode (bits 1..3)
byte     wakeId[8]    = {0x01,0x0B,0xC0,0x32,0x83,0x23,0x11,0x00}; // 0x00B identity
byte     authResp[8]  = {0x35,0x37,0x41,0x45,0x37,0x37,0x38,0x45}; // 0x083 "57AE778E"

// cadence timers
unsigned long lastWake = 0, last213 = 0, last083 = 0, lastFc = 0;

// serial/host link watchdog (0 = off). lastCharMs (above) is the last serial-byte time.
unsigned long linkTimeoutMs = 0;

// forward declarations (used by applyPreset before their definitions)
void setMode(bool on);
void printStatus();

// ---------------------------------------------------------------------------
void buildStatus213(byte *out) {
  // Intel/LE bit-pack: Status_Signal@0(1) Mode@1(3) Vavail@4(16,0.1V) Iavail@20(16,0.1A)
  uint64_t v = 0;
  v |= (uint64_t)1;                                   // Charger_Status_Signal = 1 (active)
  v |= (uint64_t)(chargerMode & 0x7)      << 1;
  v |= (uint64_t)(availV_01V  & 0xFFFF)   << 4;
  v |= (uint64_t)(availI_01A  & 0xFFFF)   << 20;
  for (int i = 0; i < 8; i++) out[i] = (v >> (8 * i)) & 0xFF;
}

void txStatus213() {
  byte b[8];
  buildStatus213(b);
  CAN.sendMsgBuf(0x213, 0, 8, b);
}
void txWake()  { CAN.sendMsgBuf(0x00B, 0, 8, wakeId);   }
void txAuth()  { CAN.sendMsgBuf(0x083, 0, 8, authResp); }

void txFc() {
  // EXPERIMENTAL — layouts unknown. Minimal "fast charger present + ready" probe.
  // chargerMode carried as a class marker (4=Fast, 6=Boost) so the two presets differ.
  byte p1[8] = {0x00,0x04,chargerMode,0x00,0x00,0x00,0x00,0x00}; // 0x508 Fast_Charger_Parameter_1
  byte ka[8] = {0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00};       // 0x531 Fast_Charger_Alive
  CAN.sendMsgBuf(0x508, 0, 8, p1);
  CAN.sendMsgBuf(0x531, 0, 8, ka);
}

// Preset bundles. Each sets the full param set and starts emulating (auto-ARM).
void applyPreset(const char *name) {
  byte blaze[8] = {0x35,0x37,0x41,0x45,0x37,0x37,0x38,0x45};
  memcpy(authResp, blaze, 8);
  availV_01V = 600;
  if      (!strncasecmp(name,"SLOW",4))  { fcInject=false; chargerMode=1; availI_01A=491; }
  else if (!strncasecmp(name,"FAST",4))  { fcInject=true;  chargerMode=4; availI_01A=960; }
  else if (!strncasecmp(name,"BOOST",5)) { fcInject=true;  chargerMode=6; availI_01A=960; }
  Serial.print(F("# PRESET ")); Serial.println(name);
  printStatus();
  setMode(true);   // start emulating this class
}

// ---------------------------------------------------------------------------
void setMode(bool on) {
  CAN.setMode(on ? MCP_NORMAL : MCP_LISTENONLY);
  armed = on;
  vehicleAwake = false;
  Serial.println(on ? F("# ARMED — emulating charger (TX on)")
                    : F("# SAFE — listen-only (TX off)"));
}

// Graceful end-of-session BEFORE going silent (charge spec §7). Cutting CAN abruptly
// while the vehicle still thinks a charger is present makes it treat the charger as
// "lost mid-session" and latch a stuck state (dash shows "unplug charger" with nothing
// connected). A clean stop = move 0x213 out of the active state (byte0 != 0x83) with
// available current -> 0, and, if FC frames were being injected, clear the connector-
// latched bit (0x508 byte1 bit2) and stop the keepalive — all while STILL transmitting,
// then drop to listen-only.
void disarmGraceful() {
  if (armed) {
    byte stop213[8] = {0,0,0,0,0,0,0,0};   // status_signal=0, V/I-available=0 -> "not active"
    byte stop508[8] = {0,0,0,0,0,0,0,0};   // connector-latched (byte1 bit2) cleared
    Serial.println(F("# stopping session gracefully (1 s) so the vehicle releases the charger"));
    for (int i = 0; i < 10; i++) {         // ~1 s at 100 ms cadence
      CAN.sendMsgBuf(0x213, 0, 8, stop213);
      if (fcInject) CAN.sendMsgBuf(0x508, 0, 8, stop508);
      delay(100);
    }
  }
  fcInject = false;
  setMode(false);
}

// True while the controlling host is present. Native-USB boards report the Serial
// Monitor being open/closed via (bool)Serial; UART-bridge boards have no such line,
// so they return true and rely on the LINK <ms> heartbeat watchdog instead.
static inline bool hostLikelyConnected() {
#if defined(USBCON) || defined(ARDUINO_USB_CDC_ON_BOOT)
  return (bool)Serial;
#else
  return true;
#endif
}

void printStatus() {
  Serial.print(F("# STATUS armed=")); Serial.print(armed);
  Serial.print(F(" I=")); Serial.print(availI_01A/10.0,1);
  Serial.print(F("A V=")); Serial.print(availV_01V/10.0,1);
  Serial.print(F("V mode=")); Serial.print(chargerMode);
  Serial.print(F(" fc=")); Serial.print(fcInject);
  Serial.print(F(" auth="));
  for (int i=0;i<8;i++){ if(authResp[i]<16)Serial.print('0'); Serial.print(authResp[i],HEX);}
  Serial.println();
}

int hexNib(char c){ if(c>='0'&&c<='9')return c-'0'; c|=0x20; if(c>='a'&&c<='f')return c-'a'+10; return -1;}

void handleLine(char *s) {
  // uppercase the command verb only; leave hex as-is (hexNib is case-insensitive)
  if      (!strncasecmp(s,"SLOW",4))    applyPreset("SLOW");
  else if (!strncasecmp(s,"FAST",4))    applyPreset("FAST");
  else if (!strncasecmp(s,"BOOST",5))   applyPreset("BOOST");
  else if (!strncasecmp(s,"ARM",3))     setMode(true);
  else if (!strncasecmp(s,"SAFE",4) || !strncasecmp(s,"DISARM",6) || !strncasecmp(s,"STOP",4)) disarmGraceful();
  else if (!strncasecmp(s,"STATUS",6)) printStatus();
  else if (!strncasecmp(s,"RX ",3))    { printRx = !strncasecmp(s+3,"on",2); }
  else if (!strncasecmp(s,"FC ",3))    { fcInject = !strncasecmp(s+3,"on",2);
                                         Serial.print(F("# fc=")); Serial.println(fcInject); }
  else if (!strncasecmp(s,"LINK ",5))  { linkTimeoutMs = strtoul(s+5,NULL,10);
                                         Serial.print(F("# link-watchdog ms=")); Serial.println(linkTimeoutMs); }
  else if (!strncasecmp(s,"I ",2))     { availI_01A = atoi(s+2); printStatus(); }
  else if (!strncasecmp(s,"V ",2))     { availV_01V = atoi(s+2); printStatus(); }
  else if (!strncasecmp(s,"MODE ",5))  { chargerMode = atoi(s+5) & 0x7; printStatus(); }
  else if (!strncasecmp(s,"AUTH ",5)) {
    char *a = s+5;
    if      (!strncasecmp(a,"slow",4)) { byte t[8]={0x45,0x41,0x37,0x35,0x45,0x38,0x37,0x37}; memcpy(authResp,t,8); }
    else if (!strncasecmp(a,"blaze",5)){ byte t[8]={0x35,0x37,0x41,0x45,0x37,0x37,0x38,0x45}; memcpy(authResp,t,8); }
    else { // 16 hex chars -> 8 bytes
      for (int i=0;i<8;i++){ int h=hexNib(a[i*2]),l=hexNib(a[i*2+1]); if(h<0||l<0){Serial.println(F("# bad hex"));return;} authResp[i]=(h<<4)|l; }
    }
    printStatus();
  }
  else if (s[0]) Serial.println(F("# ? unknown cmd (try STATUS)"));
}

char lineBuf[48]; uint8_t lineLen = 0;
void pumpSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    lastCharMs = millis();
    if (c=='\n' || c=='\r') { lineBuf[lineLen]=0; if(lineLen) handleLine(lineBuf); lineLen=0; }
    else if (lineLen < sizeof(lineBuf)-1) lineBuf[lineLen++]=c;
  }
  // Fallback for "No line ending": Serial Monitor sends the whole command as one burst,
  // so complete the line 150 ms after the last char if no terminator arrived.
  if (lineLen && millis()-lastCharMs > 150) { lineBuf[lineLen]=0; handleLine(lineBuf); lineLen=0; }
}

void pumpRx() {
  if (CAN.checkReceive() != CAN_MSGAVAIL) return;
  unsigned long id=0; byte len=0, buf[8];
  if (CAN.readMsgBuf(&id,&len,buf) != CAN_OK) return;
  if (len<=8 && (id==0x080||id==0x120||id==0x121||id==0x040)) vehicleAwake = true; // BMS is talking
  if (id==0x121 && len>=8) { memcpy(last121,buf,8); have121=true; }                // granted limit
  if (armed && id==0x080) txAuth();   // reply to auth request immediately (only when emulating)
  // Print only when asked, only "interesting" IDs, and rate-limited so the bus flood
  // can never drown your typed commands or the heartbeat.
  if (printRx && len<=8 && (id==0x080||id==0x120||id==0x121) && millis()-lastRxPrint>200) {
    lastRxPrint = millis();
    Serial.print(F("RX ")); Serial.print(id,HEX);
    for (byte i=0;i<len;i++){ Serial.print(' '); if(buf[i]<16)Serial.print('0'); Serial.print(buf[i],HEX); }
    Serial.println();
  }
}

void heartbeat() {
  if (millis()-lastBeat < 1000) return;
  lastBeat = millis();
  Serial.print(F("# emu armed=")); Serial.print(armed);
  Serial.print(F(" awake=")); Serial.print(vehicleAwake);
  Serial.print(F(" tx213_I=")); Serial.print(availI_01A/10.0,1);
  Serial.print(F("A"));
  if (have121) {
    uint16_t granted = last121[0] | (last121[1]<<8);
    Serial.print(F(" | BMS_granted_0x121=")); Serial.print(granted*0.01,2); Serial.print(F("A"));
  }
  Serial.println();
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println(F("# charger_emulator ready — DISARMED. Type ARM to transmit, SAFE to stop."));
  SPI.begin();
  if (CAN.begin(MCP_ANY, BAUD_ENUM, CRYSTAL) != CAN_OK)
    Serial.println(F("# FATAL CAN init failed (check crystal 8/16 MHz, wiring)"));
  CAN.setMode(MCP_LISTENONLY);   // start passive
  printStatus();
}

void loop() {
  pumpSerial();
  pumpRx();
  heartbeat();
  if (!armed) return;

  // Serial/host link watchdog: if the controlling host disappears while we're
  // emulating, cleanly disconnect from the scooter (graceful stop) instead of
  // stranding a phantom charge. Native USB: monitor closed. UART: LINK <ms> heartbeat.
  if (!hostLikelyConnected() ||
      (linkTimeoutMs && (millis() - lastCharMs) > linkTimeoutMs)) {
    Serial.println(F("# serial/host link lost — disconnecting from scooter"));
    disarmGraceful();
    return;
  }

  unsigned long now = millis();
  // Wake: flood 0x00B fast until the BMS answers, then back off to 100 ms.
  unsigned long wakePeriod = vehicleAwake ? 100 : 3;
  if (now - lastWake >= wakePeriod) { lastWake = now; txWake(); }
  // Charger status + auth response at 10 Hz once awake.
  if (vehicleAwake && now - last213 >= 100) { last213 = now; txStatus213(); }
  if (vehicleAwake && now - last083 >= 100) { last083 = now; txAuth();    }
  if (fcInject     && now - lastFc  >= 100) { lastFc  = now; txFc();      }
}
