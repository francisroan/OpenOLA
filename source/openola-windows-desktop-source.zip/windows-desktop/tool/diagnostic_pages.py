"""Source-backed diagnostic browsers; browsing never sends vehicle requests."""
import json
import time
import tkinter as tk
from tkinter import ttk
from scooter_backend import ROOT, ODX, Ecu


def catalog():
    entries = []
    live = json.loads((ROOT / 'notes/apk_x/res/raw/live_parameters.json').read_text(encoding='utf-8-sig'))
    for ecu, definitions in live.items():
        for definition in definitions:
            entries.append((ecu, definition.get('Source', 'Unknown'), definition.get('Parameter Name', ''), definition, None))
    for ecu, definitions in ODX.items():
        for definition in definitions:
            request = bytes.fromhex(definition.get('RequestFormat', ''))
            if request and request[0] == 0x22:
                entries.append((ecu, 'UDS ' + request[1:].hex().upper(), definition.get('Description') or definition['Command'], definition, request[1:] if len(request) == 3 else None))
    return entries


class DetailsBrowser(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.title('Live signal and ECU detail catalog')
        self.geometry('950x640')
        self.entries = catalog()
        self.query = tk.StringVar()
        ttk.Label(self, text='Search every app live parameter and ODX read. UDS values are requested snapshots, not broadcast telemetry.').pack(anchor='w', padx=12, pady=8)
        ttk.Entry(self, textvariable=self.query).pack(fill='x', padx=12)
        table_frame = ttk.Frame(self)
        table_frame.pack(fill='both', expand=True, padx=12, pady=8)
        self.table = ttk.Treeview(table_frame, columns=('ecu', 'source', 'name'), show='headings', height=12)
        for column, width in [('ecu', 65), ('source', 120), ('name', 640)]:
            self.table.heading(column, text=column.title())
            self.table.column(column, width=width)
        self.table.pack(side='left', fill='both', expand=True)
        scroll = ttk.Scrollbar(table_frame, command=self.table.yview)
        scroll.pack(side='right', fill='y')
        self.table.configure(yscrollcommand=scroll.set)
        self.detail = tk.Text(self, height=9, wrap='word', state='disabled')
        self.detail.pack(fill='both', expand=True, padx=12)
        self.read_button = ttk.Button(self, text='Read selected identifier', state='disabled', command=self.read)
        self.read_button.pack(pady=8)
        self.table.bind('<<TreeviewSelect>>', self.select)
        self.query.trace_add('write', lambda *_: self.refresh())
        self.refresh()

    def refresh(self):
        self.table.delete(*self.table.get_children())
        self.read_button.configure(state='disabled')
        for i, (ecu, source, name, definition, did) in enumerate(self.entries):
            if self.query.get().lower() in f'{ecu} {source} {name} {json.dumps(definition)}'.lower():
                self.table.insert('', 'end', iid=str(i), values=(ecu, source, name))

    def display(self, text):
        if not self.winfo_exists():
            return
        self.detail.configure(state='normal')
        self.detail.delete('1.0', 'end')
        self.detail.insert('end', text)
        self.detail.configure(state='disabled')

    def select(self, *_):
        selected = self.table.selection()
        if not selected:
            return
        ecu, source, name, definition, did = self.entries[int(selected[0])]
        text = json.dumps(definition, indent=2, ensure_ascii=False)
        if source == 'CAN':
            signal = definition.get('DBC Name')
            rows = [r for r in self.app.rows.values() if r[2] == signal and r[0].upper().lstrip('0') == str(definition.get('CAN ID (Hex)', '')).upper().lstrip('0')]
            text += '\n\nReceived snapshot: ' + (str(rows[-1]) if rows else 'Not received')
        elif did is None:
            text += '\n\nNo explicit DID in this live-parameter entry. Search the ODX reads; no address is guessed.'
        self.display(text)
        self.read_button.configure(state='normal' if did is not None else 'disabled')

    def read(self):
        selected = self.table.selection()
        if not selected:
            return
        ecu, source, name, definition, did = self.entries[int(selected[0])]
        if did is None:
            return
        self.app.live = False
        self.app.run(f'Read {ecu} {did.hex()} {name}', lambda: self.app.scooter.read(Ecu[ecu], did),
                     lambda raw: self.display(f'{name}\nReceived {time.strftime("%Y-%m-%d %H:%M:%S")}\nRaw payload: {raw.hex(" ")}\n\nDefinition (encoding not automatically inferred):\n' + json.dumps(definition, indent=2)))


def build_pages(app):
    from health_dashboard import HealthDashboard
    app.health_dashboard = HealthDashboard(app.pages['Diagnostics'], app)
    p = app.pages['Update']
    ttk.Label(p, text='Software and update status', style='H2.TLabel').pack(anchor='w')
    ttk.Label(p, text='Read installed versions, identifiers and update status. Firmware upload / flashing is not enabled.', wraplength=850).pack(anchor='w', pady=10)
    update_text = tk.Text(p, height=15, state='disabled', wrap='word')
    def result(value):
        update_text.configure(state='normal'); update_text.delete('1.0', 'end')
        update_text.insert('end', time.strftime('%Y-%m-%d %H:%M:%S') + '\n' + str(value))
        update_text.configure(state='disabled')
    bar = ttk.Frame(p); bar.pack(fill='x')
    for label, method in [('Software version', 'GetSwVersion'), ('Android version', 'GetAospVersion'), ('Vehicle identifiers', 'GetVehicleIdentifiers'), ('Update status', 'SwUpdateCheckStatus')]:
        ttk.Button(bar, text=label, command=lambda m=method: app.run(m, lambda: app.scooter.rpc(m), result)).pack(side='left', padx=4)
    update_text.pack(fill='both', expand=True, pady=12)
