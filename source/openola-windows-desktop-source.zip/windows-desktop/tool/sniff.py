"""
Passive CAN sniff over wifican CanDumpStream. Tells us whether the vehicle
bus is alive at all: counts frames, lists CAN IDs seen, DBC-names the known ones.
Purely listens - no UDS, no writes.

Usage:  python sniff.py <host> <port> [seconds] [secure]
"""
import sys, time, json, os
from oladiag.transport import WifiCanTransport

def load_names():
    p = os.path.join(os.path.dirname(__file__), "oladiag", "config", "da_can_dbc.json")
    names = {}
    if os.path.exists(p):
        d = json.load(open(p))
        for m in d.get("messages", []):
            names[int(m["id"])] = m.get("name", "")
    return names

def main():
    host = sys.argv[1] if len(sys.argv) > 1 else ""
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 50005
    secs = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    secure = len(sys.argv) > 4 and sys.argv[4].lower() == "secure"
    names = load_names()

    print(f"Sniffing {host}:{port} ({'mTLS' if secure else 'plaintext'}) for {secs}s ...")
    t = WifiCanTransport(host, port, secure=secure)
    t.connect()
    t.start_reader(dump=True)           # CanDumpStream = unfiltered

    prev = 0
    deadline = time.time() + secs
    while time.time() < deadline:
        time.sleep(1.0)
        total = sum(q.qsize() for q in t._queues.values())
        print(f"  ... {total} frames, {len(t._queues)} distinct IDs (+{total-prev}/s)")
        prev = total

    # snapshot
    ids = sorted(t._queues.keys())
    counts = {cid: t._queues[cid].qsize() for cid in ids}
    last = {}
    for cid in ids:
        q = t._queues[cid]; d = None
        while not q.empty():
            try: d = q.get_nowait()
            except Exception: break
        if d is not None: last[cid] = d.hex()
    err = t._err
    t.close()

    total = sum(counts.values())
    print()
    print(f"==== RESULT: {total} frames, {len(ids)} distinct CAN IDs ====")
    if err: print(f"(stream note: {err})")
    if total == 0:
        print("NO CAN TRAFFIC. The gRPC bridge is up but the vehicle bus is silent.")
        print("Most likely the scooter is off / ECUs asleep, or the head unit is")
        print("not bridging vehicle CAN. Power the scooter ON (ignition / diag mode)")
        print("and run this again.")
        return
    print("Bus is ALIVE. CAN IDs by frame count:")
    for cid in sorted(ids, key=lambda c: -counts[c])[:30]:
        print(f"   0x{cid:03X}  x{counts[cid]:<6} {names.get(cid,'')}  last={last.get(cid,'')}")
    diag = [c for c in (0x7B0, 0x7B1, 0x7B4) if c in counts]
    print()
    print("Diagnostic response IDs seen:", [hex(c) for c in diag] or "none")
    if not diag:
        print("-> ECUs broadcast but don't answer UDS: diag-mode / session issue,")
        print("   not transport. The bus data itself is still usable for live signals.")

if __name__ == "__main__":
    main()
