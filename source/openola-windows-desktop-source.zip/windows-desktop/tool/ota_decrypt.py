"""Decrypt an Ola OTA/FOTA ECU payload — the no-hardware firmware-dump path.

Recovered from OTAManger PackageDecryptor/PackageVerifier (MoveOS 5):
  pipeline  = verify signature (OEM_FOTA_pre_public.pem) -> AES/CBC decrypt -> unzip -> untar
  cipher    = AES/CBC/PKCS5Padding
  key / iv  = HEX strings in key.txt / iv.txt, shipped INSIDE the OTA bundle
  bundle    = the OTA app's external files dir on the head unit:
              /sdcard/Android/data/com.olaelectric.ota/files/   (pull via adb)

The signature only gates *re-flashing* a modified package (needs the OEM private key).
Reading/decrypting for reverse engineering needs only key.txt + iv.txt + the *.enc,
which travel together in the downloaded bundle.

Usage:
  python ota_decrypt.py <payload.enc> <key.txt> <iv.txt> [out.bin]
Then: the output is usually a tar (often gz) -> `tar xf out.bin` -> per-ECU *.bin
(e.g. E2_BCM_APP_FOTA_*.bin) -> load in Ghidra/IDA.
"""
import sys
from pathlib import Path
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


def _hexfile(p):
    txt = Path(p).read_text(encoding='utf-8').strip()
    return bytes.fromhex(txt)


def decrypt(enc_path, key_path, iv_path, out_path=None):
    key = _hexfile(key_path)
    iv = _hexfile(iv_path)
    if len(key) not in (16, 24, 32):
        raise ValueError(f'key.txt decodes to {len(key)} bytes; expected 16/24/32 (AES)')
    if len(iv) != 16:
        raise ValueError(f'iv.txt decodes to {len(iv)} bytes; expected 16')
    ct = Path(enc_path).read_bytes()
    if len(ct) % 16:
        raise ValueError(f'ciphertext {len(ct)} B is not a multiple of 16 — wrong file?')
    dec = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    pt = dec.update(ct) + dec.finalize()
    # strip PKCS5/7 padding
    pad = pt[-1]
    if 1 <= pad <= 16 and pt[-pad:] == bytes([pad]) * pad:
        pt = pt[:-pad]
    out = Path(out_path) if out_path else Path(enc_path).with_suffix('.dec')
    out.write_bytes(pt)
    kind = 'gzip' if pt[:2] == b'\x1f\x8b' else 'tar' if pt[257:262] == b'ustar' else '?'
    return {'out': str(out), 'len': len(pt), 'looks_like': kind, 'key_bits': len(key) * 8}


if __name__ == '__main__':
    if len(sys.argv) < 4:
        print(__doc__)
        sys.exit(1)
    r = decrypt(*sys.argv[1:5])
    print(f"decrypted {r['len']} B (AES-{r['key_bits']}) -> {r['out']}  [{r['looks_like']}]")
    if r['looks_like'] == 'gzip':
        print("  next: gunzip then untar")
    elif r['looks_like'] == 'tar':
        print("  next: tar xf", r['out'])
