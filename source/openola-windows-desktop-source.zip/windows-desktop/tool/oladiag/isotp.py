"""
ISO-TP (ISO 15765-2) helpers for UDS over the 8-byte CAN data field.

The app models the four PCI frame types (SingleFrame / FirstFrame /
ConsecutiveFrame / FlowControlFrame). Single frames cover requests here;
DTC responses arrive as First + Consecutive frames and are reassembled.

Note on the single-frame PCI: the app builds it with String.format("%02d", len)
(decimal), which for the small UDS payloads used here (len <= 7) yields the same
byte as the ISO-TP 0x0N single-frame PCI. We keep to the standard 0x0N.
"""

SINGLE = 0x0
FIRST = 0x1
CONSECUTIVE = 0x2
FLOW = 0x3

# Flow control the app sends: 30 00 14  (CTS, block size 0, STmin 0x14)
FLOW_CONTROL = bytes([0x30, 0x00, 0x14, 0, 0, 0, 0, 0])


def encode_single(payload: bytes) -> bytes:
    """Payload (<=7 bytes) -> 8-byte single frame, zero padded."""
    if len(payload) > 7:
        raise ValueError("payload too long for single frame")
    return bytes([len(payload)]) + payload + bytes(7 - len(payload))


def frame_type(data8: bytes) -> int:
    return (data8[0] >> 4) & 0xF


class IsoTpReassembler:
    """
    Feed 8-byte CAN data fields from one responder; yields a full UDS message
    once a Single frame completes or a First+Consecutive sequence finishes.

    Returns the reassembled payload bytes, or None if still in progress.
    A FlowControlFrame (from the responder) is ignored here.
    """

    def __init__(self):
        self._buf = bytearray()
        self._expected = 0
        self._next_sn = 1
        self._active = False

    def feed(self, data8: bytes):
        if len(data8) < 1:
            return None
        ft = frame_type(data8)
        if ft == SINGLE:
            length = data8[0] & 0x0F
            return bytes(data8[1:1 + length])
        if ft == FIRST:
            self._expected = ((data8[0] & 0x0F) << 8) | data8[1]
            self._buf = bytearray(data8[2:8])
            self._next_sn = 1
            self._active = True
            return None  # caller must send flow control, then keep feeding
        if ft == CONSECUTIVE:
            if not self._active:
                return None
            self._buf.extend(data8[1:8])
            if len(self._buf) >= self._expected:
                out = bytes(self._buf[:self._expected])
                self._active = False
                return out
            return None
        # flow control or unknown -> ignore
        return None

    @property
    def waiting_for_more(self) -> bool:
        return self._active
