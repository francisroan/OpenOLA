"""
Ola S1 offline diagnostics - read fault codes (DTCs) from BMS / VCU / MCU.

Usage (after `adb forward tcp:50051 tcp:<vehicle-grpc-port>`):

    python -m oladiag --host 127.0.0.1 --port 50051 read
    python -m oladiag --host 127.0.0.1 --port 50051 --secure read
    python -m oladiag --host 127.0.0.1 --port 50051 read --ecu BMS --ecu VCU
    python -m oladiag ... clear            # clears DTCs on all/selected ECUs
    python -m oladiag ... read --json report.json

The wifican gRPC port on the vehicle is discovered by step 01 capture
(netstat on the SOM). If the server needs mTLS, add --secure (uses the
certs bundled from the app).
"""

import argparse
import json
import sys

from .seedkey import Ecu
from .transport import WifiCanTransport
from .uds import UdsClient, UdsError


def main(argv=None):
    p = argparse.ArgumentParser(prog="oladiag", description="Ola S1 offline DTC reader")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=50051)
    p.add_argument("--secure", action="store_true", help="use mTLS (bundled certs)")
    p.add_argument("--ecu", action="append", choices=[e.name for e in Ecu],
                   help="limit to these ECUs (default: all)")
    p.add_argument("--timeout", type=float, default=3.0)
    p.add_argument("--dump", action="store_true",
                   help="read via CanDumpStream (all frames) instead of filtered stream")
    sub = p.add_subparsers(dest="cmd", required=True)
    pr = sub.add_parser("read", help="read DTCs")
    pr.add_argument("--json", metavar="FILE", help="also write a JSON report")
    sub.add_parser("clear", help="clear DTCs")
    sub.add_parser("selftest", help="no vehicle: verify seed/key + DTC table load")

    args = p.parse_args(argv)
    ecus = [Ecu[n] for n in (args.ecu or [e.name for e in Ecu])]

    if args.cmd == "selftest":
        return _selftest(ecus)

    t = WifiCanTransport(args.host, args.port, secure=args.secure)
    try:
        t.connect()
    except Exception as e:
        print(f"ERROR: could not connect to {args.host}:{args.port} "
              f"({'mTLS' if args.secure else 'plaintext'}): {e}", file=sys.stderr)
        print("  * Is `adb forward tcp:%d tcp:<vehicle-port>` set up?" % args.port, file=sys.stderr)
        print("  * If the server needs TLS, add --secure; if not, drop it.", file=sys.stderr)
        return 2

    # subscribe to all ECU response ids (and request ids, harmless) then start reader
    ids = []
    for e in Ecu:
        ids += [e.req_id, e.resp_id]
    try:
        t.init(ids)
    except Exception as e:
        print(f"WARNING: Init() failed ({e}); continuing, some servers don't require it",
              file=sys.stderr)
    t.start_reader(dump=args.dump)

    client = UdsClient(t, timeout=args.timeout)
    report = {}
    rc = 0
    try:
        for ecu in ecus:
            print(f"\n=== {ecu.name} (req {ecu.req_id:#05x} / resp {ecu.resp_id:#05x}) ===")
            try:
                client.enter_extended_session(ecu)
                if args.cmd == "clear":
                    client.clear_dtcs(ecu)
                    print("  DTCs cleared.")
                    report[ecu.name] = {"cleared": True}
                    continue
                faults = client.read_dtcs(ecu)
                report[ecu.name] = faults
                if not faults:
                    print("  No active fault codes.")
                for fdct in faults:
                    flag = "" if fdct["known"] else "  [unmapped]"
                    print(f"  {fdct['code']}  {fdct['description']}{flag}")
                    print(f"           status {fdct['status']:#04x}: "
                          f"{', '.join(fdct['status_flags']) or 'none'}")
            except UdsError as e:
                print(f"  ! {e}")
                report[ecu.name] = {"error": str(e)}
                rc = 1
    finally:
        t.close()

    if args.cmd == "read" and getattr(args, "json", None):
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        print(f"\nJSON report written to {args.json}")
    return rc


def _selftest(ecus):
    from .seedkey import generate_key
    from .dtc import load_table
    print("Seed/key (deterministic):")
    for e in ecus:
        s = bytes(range(1, 9))
        print(f"  {e.name}: key(seed=01..08, lvl01) = {generate_key(s, e, '01').hex()}")
    tbl = load_table()
    print("DTC table loaded:")
    for k, v in tbl.items():
        print(f"  {k}: {len(v)} codes")
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
