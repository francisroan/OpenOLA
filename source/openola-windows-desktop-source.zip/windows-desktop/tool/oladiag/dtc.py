"""
DTC decoding: turn a UDS 19 02 (ReadDTCInformation) response into a list of
faults with human-readable descriptions from the app's bundled table
(res/raw/dtc_ecu_list.json).

UDS ReadDTCInformation, sub-function 02 (reportDTCByStatusMask):
  request : 19 02 09          (status mask 0x09)
  response: 59 02 <mask> then repeated 4-byte records:
              3 bytes DTC + 1 byte statusOfDTC

The app looks up each 3-byte DTC (6 hex chars, upper-case) in the per-ECU
table. Codes there look like "110109", "D10108", etc.
"""

import json
import os

_CONFIG = os.path.join(os.path.dirname(__file__), "config", "dtc_ecu_list.json")

# statusOfDTC bit meanings (ISO 14229-1 Annex D)
_STATUS_BITS = [
    (0x01, "testFailed"),
    (0x02, "testFailedThisOperationCycle"),
    (0x04, "pendingDTC"),
    (0x08, "confirmedDTC"),
    (0x10, "testNotCompletedSinceLastClear"),
    (0x20, "testFailedSinceLastClear"),
    (0x40, "testNotCompletedThisOperationCycle"),
    (0x80, "warningIndicatorRequested"),
]


def load_table(path: str = _CONFIG) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    # normalise -> {ECU: {code_upper: description}}
    table = {}
    for ecu, entries in raw.items():
        table[ecu.upper()] = {
            e["DTC Code"].upper(): e["Description"] for e in entries
        }
    return table


def decode_status(status: int):
    return [name for bit, name in _STATUS_BITS if status & bit]


def parse_dtc_response(payload: bytes, ecu_name: str, table: dict):
    """
    payload : full UDS response bytes starting at the service id (0x59 ...)
    ecu_name: "BMS" / "VCU" / "MCU" (selects the description table)
    returns : list of dicts {code, description, status, status_flags, known}
    """
    faults = []
    if not payload:
        return faults
    # Expect 59 02 <availabilityMask> then records. Be tolerant if header differs.
    body = payload
    if len(payload) >= 3 and payload[0] == 0x59 and payload[1] == 0x02:
        body = payload[3:]
    elif len(payload) >= 1 and payload[0] == 0x59:
        body = payload[2:]
    ecu_tbl = table.get(ecu_name.upper(), {})
    for i in range(0, len(body) - 3, 4):
        code = body[i:i + 3].hex().upper()
        status = body[i + 3]
        if code == "000000":
            continue
        faults.append({
            "code": code,
            "description": ecu_tbl.get(code, "(unknown code - not in bundled table)"),
            "known": code in ecu_tbl,
            "status": status,
            "status_flags": decode_status(status),
        })
    return faults
