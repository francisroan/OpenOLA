"""
gRPC transport to the scooter's wifican server (the WifiCanRpc service).

Mirrors GrpcManager:
  * plaintext:  ManagedChannelBuilder.forAddress(ip, port).usePlaintext()
  * mTLS:       client cert ecos.crt/ecos.key, trust OLA_DIAG_root.crt,
                authority override "ola.scooter.diag"

We subscribe with Init(can_ids), read the filtered CAN stream in a background
thread (ReadCanStream), and send requests with WriteCanFrame. Incoming frames
are dispatched into per-CAN-id queues so UDS request/response is synchronous.
"""

import os
import queue
import time
import threading

import grpc

from .wifican import wifican_pb2 as pb
from .wifican import wifican_pb2_grpc as pbg
from .canframe import build_frame, parse_frame

_CERT_DIR = os.path.join(os.path.dirname(__file__), "certs")
TLS_AUTHORITY = "ola.scooter.diag"


class WifiCanTransport:
    def __init__(self, host="127.0.0.1", port=50051, secure=False, cert_dir=_CERT_DIR):
        self.host = host
        self.port = port
        self.secure = secure
        self.cert_dir = cert_dir
        self.channel = None
        self.stub = None
        self._queues = {}
        self._qlock = threading.Lock()
        self._reader = None
        self._stream = None
        self._stop = threading.Event()
        self._started = threading.Event()
        self._err = None

    # ---- channel ----
    def connect(self):
        target = f"{self.host}:{self.port}"
        if self.secure:
            with open(os.path.join(self.cert_dir, "ecos.key"), "rb") as f:
                key = f.read()
            with open(os.path.join(self.cert_dir, "ecos.crt"), "rb") as f:
                crt = f.read()
            with open(os.path.join(self.cert_dir, "OLA_DIAG_root.crt"), "rb") as f:
                root = f.read()
            creds = grpc.ssl_channel_credentials(
                root_certificates=root, private_key=key, certificate_chain=crt
            )
            opts = (("grpc.ssl_target_name_override", TLS_AUTHORITY),
                    ("grpc.default_authority", TLS_AUTHORITY))
            self.channel = grpc.secure_channel(target, creds, options=opts)
        else:
            self.channel = grpc.insecure_channel(target)
        grpc.channel_ready_future(self.channel).result(timeout=10)
        self.stub = pbg.WifiCanRpcStub(self.channel)
        return self

    # ---- subscription + stream reader ----
    def init(self, can_ids):
        resp = self.stub.Init(pb.Register(can_ids=list(can_ids)))
        return resp

    def _dispatch(self, can_id, data):
        with self._qlock:
            q = self._queues.get(can_id)
            if q is None:
                q = queue.Queue()
                self._queues[can_id] = q
        q.put(data)

    def start_reader(self, dump=False):
        """Background thread pumping ReadCanStream (filtered) or CanDumpStream (all)."""
        def run():
            try:
                if dump:
                    self._stream = self.stub.CanDumpStream(_empty())
                else:
                    self._stream = self.stub.ReadCanStream(_empty())
                self._started.set()
                for pkt in self._stream:
                    if self._stop.is_set():
                        break
                    try:
                        cid, data = parse_frame(pkt.can_frame)
                    except Exception:
                        continue
                    self._dispatch(cid, data)
            except Exception as e:
                if not self._stop.is_set():
                    self._err = e
        self._reader = threading.Thread(target=run, daemon=True)
        self._reader.start()
        # wait until the stream RPC is actually open so early requests aren't lost
        self._started.wait(timeout=5)
        time.sleep(0.05)

    def queue_for(self, can_id):
        with self._qlock:
            q = self._queues.get(can_id)
            if q is None:
                q = queue.Queue()
                self._queues[can_id] = q
        return q

    # ---- writing ----
    def write_frame(self, can_id, data8):
        frame = build_frame(can_id, data8)
        return self.stub.WriteCanFrame(pb.CANPacket(can_frame=frame))

    def close(self):
        self._stop.set()
        try:
            if self._stream is not None:
                self._stream.cancel()
        except Exception:
            pass
        try:
            self.stub.Deinit(_empty())
        except Exception:
            pass
        if self.channel:
            self.channel.close()


def _empty():
    from google.protobuf import empty_pb2
    return empty_pb2.Empty()
