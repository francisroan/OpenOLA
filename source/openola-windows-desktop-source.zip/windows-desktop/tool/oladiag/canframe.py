"""
CAN frame <-> bytes codec for the wifican gRPC transport.

The wifican CANPacket carries a 16-byte "RAW CAN frame". From the app's
ByteHelper + getRequestResponseFirstEightBytes the layout is the classic
Linux struct can_frame, but with can_id serialised BIG-endian:

    offset 0..3   can_id   (4 bytes, big-endian)   e.g. 0000078E -> 0x78E
    offset 4      dlc/len  (0x08 for our requests)
    offset 5..7   padding  (00 00 00)
    offset 8..15  data     (8 bytes, ISO-TP payload)

Requests are built as a 32-hex-char string and sent verbatim; responses come
back as the same 16 bytes (getDataBytes takes bytes[8:16]).
"""

import struct


def build_frame(can_id: int, data: bytes) -> bytes:
    """Build the 16-byte can_frame for a request. data is padded/truncated to 8."""
    d = bytes(data[:8]).ljust(8, b"\x00")
    return struct.pack(">I", can_id & 0xFFFFFFFF) + bytes([0x08, 0x00, 0x00, 0x00]) + d


def parse_frame(frame: bytes):
    """
    Parse a raw can_frame -> (can_id, data8).

    Accepts either the 16-byte raw frame or the 18-byte protobuf-serialised
    CANPacket (2-byte tag/len header 0A 10 then 16 bytes), matching the app's
    ByteHelper which special-cases length 18.
    """
    if len(frame) == 18:
        frame = frame[2:]
    if len(frame) < 16:
        raise ValueError(f"short can_frame: {len(frame)} bytes")
    can_id = struct.unpack(">I", frame[0:4])[0]
    data = frame[8:16]
    return can_id, data


def hex_frame(can_id: int, data: bytes) -> str:
    """Request as the 32-char hex string the app's operateVehicle() expects."""
    return build_frame(can_id, data).hex().upper()
