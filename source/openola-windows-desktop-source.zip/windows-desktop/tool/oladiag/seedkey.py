"""
Seed/key security-access algorithm for Ola S1 UDS diagnostics.

Ported 1:1 from the Ola Diagnostic app:
  com.olaelectric.dataparserengine.uds.helpers.SeedKeyAlgoHelper

Two variants, chosen by seed length:
  * seed length != 8 bytes  -> "old key": per-byte ((b ^ 0x33) + 1) ^ 0x96
  * seed length == 8 bytes  -> "new key": ECU/level-keyed transform

The new-key path uses a 4-element constant vector that depends on the ECU
(BMS/VCU/MCU) and the security level ("01" vs anything else). Those constants
were lifted verbatim from getKey() in the decompiled helper.
"""

from enum import Enum


class Ecu(Enum):
    # (request_can_id, response_can_id) as hex strings, from EcuCanId
    BMS = ("078E", "07B1")
    VCU = ("0786", "07B0")
    MCU = ("07A6", "07B4")

    @property
    def req_id(self) -> int:
        return int(self.value[0], 16)

    @property
    def resp_id(self) -> int:
        return int(self.value[1], 16)


# getKey() constant vectors: {Ecu: {"01": [...], "other": [...]}}
_KEY_CONST = {
    Ecu.BMS: {"01": [54, 43, 79, 19], "other": [77, 13, 53, 47]},
    Ecu.VCU: {"01": [99, 61, 69, 19], "other": [30, 43, 5, 62]},
    Ecu.MCU: {"01": [39, 67, 2, 23], "other": [39, 67, 2, 23]},  # level-independent
}


def _old_key(seed: bytes) -> bytes:
    """seed length != 8. Same transform for levels 01 and 03."""
    out = bytearray(len(seed))
    for i, b in enumerate(seed):
        out[i] = (((b ^ 0x33) + 1) ^ 0x96) & 0xFF
    return bytes(out)


def _dec2hex(val: int):
    """Return [low_nibble_char, high_nibble_char] as ASCII codes, matching dec2hex()."""
    v = val % 16
    lo = v + 55 if v >= 10 else v + 48
    v2 = (val // 16) % 16
    hi = v2 + 55 if v2 >= 10 else v2 + 48
    return [lo, hi]


def _hex2dec(pair):
    """Inverse of dec2hex: [c0, c1] ASCII codes -> int. Matches hex2dec()."""
    c0, c1 = pair[0], pair[1]
    v = 0
    if 48 <= c0 < 58:
        v += (c0 - 48) * 1
    elif 65 <= c0 < 71:
        v += (c0 - 55) * 1
    if 48 <= c1 < 58:
        v += (c1 - 48) * 16
    elif 65 <= c1 < 71:
        v += (c1 - 55) * 16
    return v


def _random_number_tester(seed_ints, consts):
    """Port of getRandomNumberTester(Integer[] p14 seed, Integer[] p15 consts)."""
    d = list(seed_ints)  # copy of 8 seed ints
    m = [[0, 0] for _ in range(4)]
    m[0][0] = d[0]; m[0][1] = d[1]
    m[1][0] = d[2]; m[1][1] = d[3]
    m[2][0] = d[4]; m[2][1] = d[5]
    m[3][0] = d[6]; m[3][1] = d[7]
    # rotate first column up
    tmp = m[0][0]
    m[0][0] = m[1][0]
    m[1][0] = m[2][0]
    m[2][0] = m[3][0]
    m[3][0] = tmp
    x = [_hex2dec(m[0]), _hex2dec(m[1]), _hex2dec(m[2]), _hex2dec(m[3])]
    y = [((x[i] - consts[i] + 127) % 127) for i in range(4)]
    z = [(((y[i] * 91) + 75 + 127) % 127) for i in range(4)]
    return z


def _key_p(p):
    """Port of getKeyP(Integer[] p29 length4) -> Integer[4][2]."""
    a = ((((p[0] * 7) + 255) % 255) ^ 23)
    b = ((((p[1] * 5) + 255) % 255) ^ 67)
    c = ((((p[2] * 1) + 255) % 255) ^ 8)
    dd = ((((8 * p[3]) + 255) % 255) ^ 45)
    v9 = a ^ b
    v14 = b ^ c
    v1 = c ^ dd
    v2 = dd ^ a
    out = [None] * 4
    out[0] = _dec2hex(v9)
    out[1] = _dec2hex(v14)
    out[2] = _dec2hex(v1)
    out[3] = _dec2hex(v2)
    return out


def _tester_key(seed_ints, consts):
    """Port of getTesterKey -> fills key[8] from getKeyP(getRandomNumberTester())."""
    grid = _key_p(_random_number_tester(seed_ints, consts))
    key = [0] * 8
    for r in range(4):
        for col in range(2):
            key[r * 2 + col] = grid[r][col]
    return key


def _new_key(seed: bytes, ecu: Ecu, level: str) -> bytes:
    """seed length == 8. Port of getKey() + the app's on-wire key encoding.

    getKey() builds an 8-element grid whose values are ASCII codes of hex digits
    (e.g. 52='4', 56='8', ...), then packs each via parseInt(toHexString(v), 10).
    BUT the seed>=8 send path in VehicleEcuTestViewModel.onReceivedSeed does NOT
    send that packed value - it calls getTypeSafeString(key) (decimal-concat of
    the packed bytes) and writes it as NEW_SEED_DATA, which decodeHexString's it
    back. That round-trip exactly UNDOES the packing, so the real wire key is the
    grid ASCII values themselves. (Sending the packed bytes was rejected NRC 0x35.)
    """
    seed_ints = [b for b in seed]  # ASCII codes of the seed's hex chars (0..255)
    consts = _KEY_CONST[ecu]["01" if level == "01" else "other"]
    key_ints = _tester_key(seed_ints, consts)  # grid ASCII codes of hex digits
    return bytes(key_ints)


def generate_key(seed: bytes, ecu: Ecu, level: str = "01") -> bytes:
    """
    Compute the security-access key from the seed the ECU returned.

    seed  : seed bytes (from the 67 01 <seed> response). Firmware 5.0.0's VCU
            sends this as an 8-char ASCII hex string (e.g. b"E6E15700"); those
            8 ASCII bytes ARE the input the getKey transform expects.
    ecu   : which ECU (BMS/VCU/MCU) - selects the constant vector
    level : security level string, "01" / "02" / "03"
    """
    if len(seed) != 8:
        return _old_key(seed)
    return _new_key(seed, ecu, level)


if __name__ == "__main__":
    # smoke test - deterministic, no vehicle needed
    for ecu in Ecu:
        s8 = bytes([0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88])
        print(ecu.name, "seed8 ->", generate_key(s8, ecu, "01").hex())
    s4 = bytes([0xDE, 0xAD, 0xBE, 0xEF])
    print("old-key seed4 ->", generate_key(s4, Ecu.BMS, "01").hex(),
          "(expect ((b^0x33)+1)^0x96 per byte)")
