"""
UDS-over-CAN session logic for the Ola S1 ECUs, on top of WifiCanTransport.

Sequence per ECU (matching the app's UdsParserEngine command strings):
  1. Extended session      : 10 03   -> expect 50 03
  2. Security access seed   : 27 01   -> expect 67 01 <seed>
  3. Compute key (seedkey)  ; send    : 27 02 <key> -> expect 67 02
  4. Read DTCs              : 19 02 09 -> 59 02 <mask> <records...>  (ISO-TP multi)
  5. (optional) Clear DTCs  : 14 FF FF FF -> 54

Security access is only needed for some operations; ReadDTCInformation often
works in the extended session without it, so read_dtcs() attempts the read
first and only unlocks if the ECU replies with NRC 0x33 (securityAccessDenied).
"""

import queue
import time

from .seedkey import Ecu, generate_key
from .isotp import encode_single, IsoTpReassembler, FLOW_CONTROL, frame_type, FIRST
from .dtc import parse_dtc_response, load_table

# UDS service ids / sub-functions (from decompiled constants)
SVC_SESSION = 0x10
SUB_EXTENDED = 0x03
SVC_SECURITY = 0x27
SUB_SEED = 0x01
SUB_KEY = 0x02
SVC_READ_DTC = 0x19
SUB_DTC_BY_STATUS = 0x02
DTC_STATUS_MASK = 0x09
SVC_CLEAR_DTC = 0x14
CLEAR_ALL = bytes([0xFF, 0xFF, 0xFF])
NRC = 0x7F
NRC_SECURITY_DENIED = 0x33
NRC_RESPONSE_PENDING = 0x78

POSITIVE = lambda sid: sid + 0x40


SVC_ECU_RESET = 0x11
SUB_HARD_RESET = 0x01

# InputOutputControlByIdentifier (service 0x2F) - actuator / component tests.
# From the diagnostic app's ODX: horn/light commands are "2F <DID> 03 <state>",
# i.e. controlOption 0x03 = shortTermAdjustment, then a 1-byte Control Status
# (0 = off, 1 = on). Positive response is 0x6F <DID>.
SVC_IO_CONTROL = 0x2F
IO_RETURN_CONTROL_TO_ECU = 0x00
IO_SHORT_TERM_ADJUSTMENT = 0x03

# TesterPresent (service 0x3E). Sub-function 0x80 sets the
# suppressPositiveResponseMessageIndicationBit, so the ECU stays silent - the
# app sends this every 4000 ms to keep the session/security-access alive.
SVC_TESTER_PRESENT = 0x3E
SUB_TP_SUPPRESS = 0x80


class UdsError(Exception):
    pass


class UdsClient:
    def __init__(self, transport, timeout=3.0):
        self.t = transport
        self.timeout = timeout
        self.dtc_table = load_table()

    # ---- ISO-TP multi-frame request TX ----
    def _send_payload(self, ecu: Ecu, payload: bytes, q):
        """Send a UDS payload, single- or multi-frame (ISO-TP), honouring the
        ECU's flow-control frame for multi-frame requests."""
        if len(payload) <= 7:
            self.t.write_frame(ecu.req_id, encode_single(payload))
            return
        # First frame: PCI 0x1LLL (12-bit length) + first 6 bytes
        total = len(payload)
        ff = bytes([0x10 | ((total >> 8) & 0x0F), total & 0xFF]) + payload[:6]
        self.t.write_frame(ecu.req_id, ff)
        # wait for flow control (frame_type 3) from the ECU
        bs, stmin = 0, 0
        deadline = time.time() + self.timeout
        while time.time() < deadline:
            try:
                d = q.get(timeout=max(0.05, deadline - time.time()))
            except queue.Empty:
                break
            if frame_type(d) == 0x3:
                bs = d[1]
                stmin = d[2]
                break
        rest = payload[6:]
        sn = 1
        sent_since_fc = 0
        while rest:
            chunk = rest[:7]
            rest = rest[7:]
            cf = bytes([0x20 | (sn & 0x0F)]) + chunk + bytes(7 - len(chunk))
            self.t.write_frame(ecu.req_id, cf)
            sn = (sn + 1) & 0x0F
            self._stmin_delay(stmin)
            sent_since_fc += 1
            if bs and sent_since_fc >= bs and rest:
                # wait for next flow control
                sent_since_fc = 0
                while time.time() < deadline:
                    try:
                        d = q.get(timeout=max(0.05, deadline - time.time()))
                    except queue.Empty:
                        break
                    if frame_type(d) == 0x3:
                        break

    @staticmethod
    def _stmin_delay(stmin):
        if stmin == 0:
            return
        if stmin <= 0x7F:
            time.sleep(stmin / 1000.0)      # ms
        elif 0xF1 <= stmin <= 0xF9:
            time.sleep((stmin - 0xF0) / 10000.0)  # 100-900 us

    # ---- low level request/response with ISO-TP reassembly ----
    def _request(self, ecu: Ecu, payload: bytes) -> bytes:
        """Send a UDS request (single or multi-frame); return reassembled response."""
        q = self.t.queue_for(ecu.resp_id)
        # drain stale
        try:
            while True:
                q.get_nowait()
        except queue.Empty:
            pass

        self._send_payload(ecu, payload, q)

        reasm = IsoTpReassembler()
        deadline = time.time() + self.timeout
        sent_fc = False
        while time.time() < deadline:
            try:
                data8 = q.get(timeout=max(0.05, deadline - time.time()))
            except queue.Empty:
                break
            # First frame -> we must send flow control to keep data coming
            if frame_type(data8) == FIRST and not sent_fc:
                out = reasm.feed(data8)
                self.t.write_frame(ecu.req_id, FLOW_CONTROL)
                sent_fc = True
                continue
            out = reasm.feed(data8)
            if out is not None:
                # handle negative response with responsePending (0x78): keep waiting
                if len(out) >= 3 and out[0] == NRC and out[2] == NRC_RESPONSE_PENDING:
                    reasm = IsoTpReassembler()
                    sent_fc = False
                    deadline = time.time() + self.timeout
                    continue
                return out
        raise UdsError(f"timeout waiting for response from {ecu.name} "
                       f"(req_id={ecu.req_id:#05x}, resp_id={ecu.resp_id:#05x})")

    @staticmethod
    def _check_positive(resp: bytes, service: int, ecu: Ecu):
        if not resp:
            raise UdsError(f"{ecu.name}: empty response")
        if resp[0] == NRC:
            svc = resp[1] if len(resp) > 1 else 0
            code = resp[2] if len(resp) > 2 else 0
            raise UdsError(f"{ecu.name}: negative response to {svc:#04x}, NRC {code:#04x}")
        if resp[0] != POSITIVE(service):
            raise UdsError(f"{ecu.name}: unexpected SID {resp[0]:#04x} "
                           f"(wanted {POSITIVE(service):#04x})")
        return resp

    # ---- operations ----
    def enter_extended_session(self, ecu: Ecu):
        r = self._request(ecu, bytes([SVC_SESSION, SUB_EXTENDED]))
        return self._check_positive(r, SVC_SESSION, ecu)

    def security_access(self, ecu: Ecu, level: str = "01"):
        seed_resp = self._request(ecu, bytes([SVC_SECURITY, SUB_SEED]))
        self._check_positive(seed_resp, SVC_SECURITY, ecu)
        seed = seed_resp[2:]  # after 67 01
        if not any(seed):
            return seed_resp  # already unlocked (all-zero seed)
        key = generate_key(seed, ecu, level)
        key_resp = self._request(ecu, bytes([SVC_SECURITY, SUB_KEY]) + key)
        return self._check_positive(key_resp, SVC_SECURITY, ecu)

    def read_dtcs(self, ecu: Ecu, unlock=True):
        req = bytes([SVC_READ_DTC, SUB_DTC_BY_STATUS, DTC_STATUS_MASK])
        try:
            resp = self._request(ecu, req)
        except UdsError as e:
            if unlock and "NRC 0x33" in str(e):
                self.security_access(ecu)
                resp = self._request(ecu, req)
            else:
                raise
        # if negative with security denied, unlock and retry
        if resp and resp[0] == NRC and len(resp) > 2 and resp[2] == NRC_SECURITY_DENIED and unlock:
            self.security_access(ecu)
            resp = self._request(ecu, req)
        self._check_positive(resp, SVC_READ_DTC, ecu)
        return parse_dtc_response(resp, ecu.name, self.dtc_table)

    def clear_dtcs(self, ecu: Ecu):
        r = self._request(ecu, bytes([SVC_CLEAR_DTC]) + CLEAR_ALL)
        return self._check_positive(r, SVC_CLEAR_DTC, ecu)

    def ecu_reset(self, ecu: Ecu):
        r = self._request(ecu, bytes([SVC_ECU_RESET, SUB_HARD_RESET]))
        return self._check_positive(r, SVC_ECU_RESET, ecu)

    # ---- actuator / component tests (IOControlByIdentifier, 0x2F) ----
    def tester_present(self, ecu: Ecu):
        """Fire-and-forget 3E 80 (suppressed response) to keep the session alive."""
        self.t.write_frame(
            ecu.req_id, encode_single(bytes([SVC_TESTER_PRESENT, SUB_TP_SUPPRESS]))
        )

    def io_control(self, ecu: Ecu, did: int,
                   control_option: int = IO_SHORT_TERM_ADJUSTMENT,
                   state: bytes = b"") -> bytes:
        """Send 2F <DID_hi> <DID_lo> <control_option> [state...]; expect 6F <DID>.

        For the Ola VCU actuators, control_option is 0x03 (shortTermAdjustment)
        with a 1-byte state (b"\\x01" on / b"\\x00" off), or 0x00
        (returnControlToECU) with no state to hand control back to the ECU.
        """
        payload = bytes([SVC_IO_CONTROL, (did >> 8) & 0xFF, did & 0xFF,
                         control_option]) + state
        r = self._request(ecu, payload)
        return self._check_positive(r, SVC_IO_CONTROL, ecu)


class TesterPresentKeepalive:
    """Background 3E 80 sender, matching the app's 4 s keepalive. Keeps the
    diagnostic session / security access from expiring between UDS commands."""

    def __init__(self, uds: "UdsClient", ecu: Ecu, interval: float = 2.0):
        import threading
        self._uds = uds
        self._ecu = ecu
        self._interval = interval
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self._stop.wait(self._interval):
            try:
                self._uds.tester_present(self._ecu)
            except Exception:
                pass

    def start(self):
        self._thread.start()
        return self

    def stop(self):
        self._stop.set()

    def alive(self) -> bool:
        return self._thread.is_alive() and not self._stop.is_set()

    def __enter__(self):
        return self.start()

    def __exit__(self, *exc):
        self.stop()
