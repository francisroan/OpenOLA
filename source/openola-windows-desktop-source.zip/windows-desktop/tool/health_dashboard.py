"""Passive diagnostic presentation. No CAN writes or inferred interlock bypasses."""
import json
import re
import time
from collections import deque
import tkinter as tk
from tkinter import ttk, filedialog
from scooter_backend import Ecu

FAULT = re.compile(r'fault|error|fail|warn|inhibit|derat|overcurrent|overvolt|undervolt|short|timeout|disconnect|protection', re.I)
BATTERY = re.compile(r'bms|battery|cell|pack|soc|soh|contactor', re.I)
INPUTS = {'Side_Stand_Status', 'Front_Brake_Status', 'Rear_Brake_Status', 'Drive_Request',
          'Contactor_state_00', 'Throttle_Value1', 'Throttle_Value2', 'Vehicle_Mode_Level_1'}


def snapshot(dbc, rows, now, connected, live, replay):
    indexed = {(int(r[0], 16), r[2]): r for r in rows}
    groups = {'Fault signals': [], 'Battery': [], 'Drive inputs': [], 'Communication': []}
    for cid, message in dbc.items():
        stamps = []
        for signal in message['signals']:
            name = signal['name']
            row = indexed.get((cid, name))
            if row: stamps.append(row[5])
            state = 'Not received'
            age = None
            if row:
                age = max(0, now-row[5])
                state = 'Offline' if replay else 'Disconnected' if not connected else 'Paused' if not live else 'Stale' if age > 3 else 'Fresh'
            value = row[3] if row else None
            item = {'id': f'{cid:03X}', 'signal': name, 'value': value, 'unit': row[4] if row else signal.get('units', ''),
                    'state': state, 'age': age, 'received': row[5] if row else None, 'message': message.get('name', f'0x{cid:03X}')}
            if FAULT.search(name):
                item = dict(item)
                item['flag'] = ('Asserted' if value == 1 else 'Not asserted' if value == 0 else 'Unexpected value') if state == 'Fresh' and signal['bitlength'] == 1 else 'Unknown' if state != 'Fresh' else 'Raw status'
                groups['Fault signals'].append(item)
            if BATTERY.search(name+' '+message.get('name', f'0x{cid:03X}')): groups['Battery'].append(item)
            if name in INPUTS: groups['Drive inputs'].append(item)
        stamp = max(stamps) if stamps else None
        state = 'Not received' if stamp is None else 'Offline' if replay else 'Disconnected' if not connected else 'Paused' if not live else 'Stale' if now-stamp > 3 else 'Fresh'
        groups['Communication'].append({'id':f'{cid:03X}', 'signal':message.get('name', f'0x{cid:03X}'), 'value':None, 'unit':'', 'state':state,
                                        'age':max(0,now-stamp) if stamp is not None else None})
    return groups


class HealthDashboard(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.pack(fill='both', expand=True)
        self.events = deque(maxlen=1000)
        self.previous = {}
        self.stored = {}
        self.last = {}
        self.timer = None
        self.bind('<Destroy>', self.on_destroy, add='+')
        self.summary = tk.StringVar(value='Start monitoring to receive broadcast diagnostics')
        self.query = tk.StringVar()
        self.only = tk.BooleanVar()
        bar = ttk.Frame(self); bar.pack(fill='x', pady=(0,8))
        ttk.Button(bar, text='Start monitoring', style='Accent.TButton', command=app.start_live).pack(side='left')
        ttk.Button(bar, text='Pause', command=app.pause_live).pack(side='left', padx=5)
        ttk.Button(bar, text='Export report', command=self.export).pack(side='left')
        ttk.Button(bar, text='ECU details…', command=app.app_details).pack(side='left', padx=5)
        ttk.Label(self, textvariable=self.summary, wraplength=900).pack(anchor='w')
        ttk.Label(self, text='Signal observations only: no “safe to drive” verdict. Freshness uses a 3 s display threshold, not ECU timeout specifications.', wraplength=900, style='Muted.TLabel').pack(anchor='w', pady=5)
        filters = ttk.Frame(self); filters.pack(fill='x', pady=5)
        ttk.Label(filters,text='Search').pack(side='left')
        ttk.Entry(filters,textvariable=self.query).pack(side='left',fill='x',expand=True,padx=8)
        ttk.Checkbutton(filters,text='Asserted fault flags only',variable=self.only).pack(side='left')
        self.tabs = ttk.Notebook(self); self.tabs.pack(fill='both',expand=True)
        self.tables = {}
        for name in ('Fault signals','Stored DTCs','Battery','Drive inputs','Communication','Events'):
            page=ttk.Frame(self.tabs);self.tabs.add(page,text=name)
            if name=='Stored DTCs':
                controls=ttk.Frame(page);controls.pack(fill='x',pady=5)
                for ecu in Ecu:
                    ttk.Button(controls,text=f'Read {ecu.name}',command=lambda e=ecu:self.read_dtc(e)).pack(side='left',padx=4)
                ttk.Label(page,text='Explicit reads use existing bench confirmation. No automatic session, unlock, or clearing.').pack(anchor='w')
            frame=ttk.Frame(page);frame.pack(fill='both',expand=True)
            table=ttk.Treeview(frame,columns=('id','signal','value','state','age'),show='headings',height=8)
            for col,label,width in [('id','CAN / ECU',85),('signal','Signal / description',390),('value','Value / code',125),('state','Observation / status',180),('age','Age / time',135)]:
                table.heading(col,text=label);table.column(col,width=width,minwidth=60)
            table.pack(side='left',fill='both',expand=True)
            scroll=ttk.Scrollbar(frame,command=table.yview);scroll.pack(side='right',fill='y');table.configure(yscrollcommand=scroll.set)
            table.tag_configure('unknown',foreground='#737b85');table.tag_configure('asserted',foreground='#b42318')
            self.tables[name]=table
        self.refresh()

    def fill(self,name,rows):
        table=self.tables[name]; desired=set()
        for i,(values,tag) in enumerate(rows):
            iid=str(i);desired.add(iid)
            if table.exists(iid):table.item(iid,values=values,tags=(tag,))
            else:table.insert('','end',iid=iid,values=values,tags=(tag,))
        for iid in table.get_children():
            if iid not in desired:table.delete(iid)

    def refresh(self):
        if not self.winfo_exists():return
        now=time.time();a=self.app
        self.last=snapshot(a.scooter.dbc,list(a.rows.values()),now,a.connected,a.live,a.replay)
        faults=self.last['Fault signals'];asserted=sum(x['flag']=='Asserted' for x in faults)
        unknown=sum(x['state']!='Fresh' for x in faults)
        self.summary.set(f'{asserted} asserted fault flags · {unknown}/{len(faults)} unavailable as current data · stored DTCs read separately')
        current={ (x['id'],x['signal']): (x['state'],x.get('flag'),x['value']) for x in faults }
        if not a.replay:
            for key,value in current.items():
                old=self.previous.get(key)
                if old is not None and old != value:
                    self.events.append({'time':time.strftime('%Y-%m-%d %H:%M:%S'), 'id':key[0],'signal':key[1], 'before':old,'after':value})
        self.previous={} if a.replay else current
        query=self.query.get().lower()
        for name,items in self.last.items():
            shown=[]
            for x in items:
                if query not in f'{x["id"]} {x["signal"]}'.lower():continue
                if name=='Fault signals' and self.only.get() and x['flag']!='Asserted':continue
                state=x.get('flag',x['state'])
                if state=='Unknown':state=x['state']
                value='—' if x['value'] is None else f'{x["value"]} {x["unit"]}'.strip()
                shown.append(((x['id'],x['signal'],value,state,'—' if x['age'] is None else f'{x["age"]:.1f}s'), 'asserted' if state=='Asserted' else 'unknown' if x['state']!='Fresh' else ''))
            self.fill(name,shown)
        self.fill('Events',[((e['id'],e['signal'],str(e['after'][2]),f'{e["before"][0]} → {e["after"][0]} / {e["after"][1]}',e['time']), '') for e in reversed(self.events)])
        if self.timer is not None:
            self.after_cancel(self.timer)
        self.timer = self.after(1000,self.refresh)

    def on_destroy(self,event):
        if event.widget is self and self.timer is not None:
            self.after_cancel(self.timer)
            self.timer = None

    def read_dtc(self,ecu):
        if self.app.busy:return
        self.app.live=False
        def read():
            try:return {'time':time.strftime('%Y-%m-%d %H:%M:%S'),'faults':self.app.scooter.read_faults(ecu),'error':None}
            except Exception as exc:return {'time':time.strftime('%Y-%m-%d %H:%M:%S'),'faults':None,'error':str(exc)}
        def done(result):
            self.stored[ecu.name]=result
            rows=[]
            for name,r in self.stored.items():
                if r['error']:rows.append(((name,r['error'],'—','Read failed',r['time']),'unknown'))
                elif not r['faults']:rows.append(((name,'No DTCs returned for requested mask','—','Snapshot',r['time']),''))
                else:
                    for f in r['faults']:rows.append(((name,f['description'],f['code'],', '.join(f['status_flags']),r['time']),''))
            self.fill('Stored DTCs',rows)
        self.app.run(f'{ecu.name} DTC snapshot',read,done)

    def export(self):
        path=filedialog.asksaveasfilename(defaultextension='.json',filetypes=[('Diagnostic report','*.json')])
        if not path:return
        self.refresh()
        report={'time':time.strftime('%Y-%m-%d %H:%M:%S'),'mode':self.app.mode_text.get(),'offline':self.app.replay,
                'observations':self.last,'stored_dtcs':self.stored,'events':list(self.events),'event_limit':1000}
        try:
            with open(path,'w',encoding='utf-8') as f:json.dump(report,f,indent=2)
            self.app.report('Saved diagnostic report: '+path)
        except OSError as exc:self.app.report('Export failed: '+str(exc))

