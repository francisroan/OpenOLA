# Windows GUI build

Requirements: Windows 10/11, Python 3.12 x64 with Tcl/Tk, and the dependencies listed in `tool/oladiag/requirements.txt`.

From the repository root, run `source/windows-desktop/30_scooter_gui.cmd`. For a developer setup, install the listed dependencies in a virtual environment, then run the entry point. The full source/build inventory and open validation items are in the repository root `SOURCE_BUILD_MANIFEST.md` and `VALIDATION_PLAN.md`.
