# Kotlin Android build

Open `source/android-kotlin/apk/` in Android Studio with JDK 17 and an installed Android SDK, or run `gradlew.bat assembleDebug` from that directory after configuring the local SDK. The debug APK is written under `app/build/outputs/apk/debug/`.

The Gradle wrapper and dependency versions are part of this source tree. Keep local SDK paths and signing credentials outside the repository. The root `SOURCE_BUILD_MANIFEST.md` describes build inputs and exclusions; `VALIDATION_PLAN.md` lists checks not yet established for a release.
