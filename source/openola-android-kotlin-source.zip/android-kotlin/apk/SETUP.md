# S1 Diag — set up the toolchain & build the APK

You don't need to be an Android developer. This is a one-time setup; after that,
building a new APK is two clicks. **You build on your laptop** — an APK can't be
compiled in the cloud sandbox (it needs Google/Gradle/Maven, which the sandbox
can't reach).

---

## 1. Install Android Studio (one time, ~30 min incl. downloads)

1. Download **Android Studio** (free) from https://developer.android.com/studio
   and run the installer. Accept the defaults.
2. On first launch it runs a **Setup Wizard** — pick **Standard**, accept the
   licenses, and let it download the **Android SDK**, **build-tools** and an
   emulator. This is the only big download.
   - Android Studio **bundles its own JDK 17 and Gradle**, so you do NOT need to
     install Java or Gradle separately.

That's the whole toolchain. Nothing else to install.

---

## 2. Open this project

1. Android Studio → **File ▸ Open** → select the **`apk/`** folder (this folder).
2. It will say "Gradle sync" and start downloading the app's libraries
   (Compose, gRPC, protobuf…) — first time only, a few minutes. Let it finish.
   - It also auto-creates the Gradle wrapper and `local.properties` (pointing at
     your SDK) for you.
3. If it prompts to **upgrade the Android Gradle Plugin**, click **Don't upgrade**
   (the versions here are already matched).

If sync fails with "SDK location not found", do **File ▸ Sync Project with Gradle
Files** once more, or set **File ▸ Settings ▸ Languages & Frameworks ▸ Android
SDK** to your installed SDK.

---

## 3. Build the APK

1. **Build ▸ Build App Bundle(s) / APK(s) ▸ Build APK(s)**.
2. When it finishes, a small popup says "APK(s) generated" — click **locate**.
   The file is:
   ```
   apk/app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 4. Put it on your phone

- **Easiest:** plug the phone in by USB, enable **Developer options ▸ USB
  debugging** on the phone, then in Android Studio press the green **Run ▶**
  button — it installs and launches directly.
- **Or:** copy `app-debug.apk` to the phone (USB, Drive, email), tap it in a file
  manager, and allow "install from unknown sources" when prompted.

---

## 5. Use it

1. Join the **scooter's diagnostic Wi-Fi** on the phone.
2. Open **S1 Diag**. The host/port are pre-filled (`192.168.4.1:50005`); tap
   **Connect**.
3. Tick **"Parked & charger disconnected"** at the top.
4. **Scooter tab ▸ Enter Service**, then test indicators/lights, read faults,
   or edit parameters. (Same flow and safety as the desktop GUI.)

---

## Command-line build (optional, if you prefer no IDE)

You still need the **Android SDK** (install via Android Studio once, or the
command-line tools) and **JDK 17**. Then, from `apk/`:

```bash
# one time: generate the Gradle wrapper (needs a system 'gradle' once)
gradle wrapper --gradle-version 8.9
# then build:
./gradlew assembleDebug        # macOS/Linux
gradlew.bat assembleDebug      # Windows
```
Create `apk/local.properties` pointing at your SDK:
```
sdk.dir=C\:\\Users\\<you>\\AppData\\Local\\Android\\Sdk
```

## Requirements summary
- Android Studio (bundles JDK 17 + Gradle 8.9) — **or** SDK + JDK 17 for CLI.
- Android SDK Platform 34, Build-Tools 34.
- `minSdk 26` (Android 8.0+) — any modern phone.

See `README.md` for what's inside and how to change it.
