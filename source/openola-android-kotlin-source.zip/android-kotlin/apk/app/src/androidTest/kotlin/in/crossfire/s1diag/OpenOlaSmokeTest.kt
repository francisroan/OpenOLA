package `in`.crossfire.s1diag

import android.graphics.Bitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import java.io.File

class OpenOlaSmokeTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()
    @Before fun resetUiPreferences() {
        compose.runOnUiThread {
            compose.activity.getSharedPreferences("openola_ui", 0).edit().clear().commit()
        }
        compose.activityRule.scenario.recreate()
        compose.waitForIdle()
    }
    private fun tab(label: String) = compose.onNode(hasText(label) and hasClickAction()).performClick()
    private fun scrollTo(label: String) = compose.onNode(hasScrollAction()).performScrollToNode(hasText(label))
    private fun waitForText(label: String) = compose.waitUntil(15_000) { compose.onAllNodesWithText(label).fetchSemanticsNodes().isNotEmpty() }
    private fun screenshot(name: String) {
        compose.waitForIdle()
        // Capture the app's Compose surface; system-app dialogs are separate QA evidence.
        val bitmap = compose.onNode(isRoot() and hasAnyDescendant(hasText("OpenOLA")))
            .captureToImage().asAndroidBitmap()
        val dir = compose.activity.getExternalFilesDir("qa")!!
        dir.mkdirs()
        File(dir, "$name.png").outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
    @Test fun demoScanReportAndThemes() {
        compose.onNodeWithText("OpenOLA").assertIsDisplayed()
        screenshot("01-connect-light")
        scrollTo("Open demo")
        compose.onNodeWithText("Open demo").performClick()
        waitForText("Overview")
        compose.onNodeWithText("Overview").assertIsDisplayed()
        compose.onNodeWithText("Demo · simulated data").assertIsDisplayed()
        screenshot("02-home-light")
        tab("Faults")
        compose.onNodeWithText("Scan all controllers").performClick()
        compose.waitUntil(15_000) {
            androidx.lifecycle.ViewModelProvider(compose.activity)[`in`.crossfire.s1diag.vm.DiagViewModel::class.java].ui.value.faults.isNotEmpty()
        }
        scrollTo("P0A80")
        compose.onNodeWithText("P0A80").assertIsDisplayed()
        screenshot("03-faults-light")
        tab("Reports")
        compose.onNodeWithText("Capture report").performClick()
        scrollTo("Save JSON")
        compose.onNodeWithText("Save JSON").assertIsDisplayed()
        screenshot("04-reports-light")
        tab("Settings")
        compose.onNodeWithText("Dark").performClick()
        screenshot("05-settings-dark")
        tab("Reports")
        scrollTo("Save JSON")
        compose.onNodeWithText("Save JSON").assertIsDisplayed()
        tab("Home")
        screenshot("06-home-dark")
        // The theme preference survives an Activity recreation.
        compose.activityRule.scenario.recreate()
        compose.waitForIdle()
        tab("Settings")
        compose.onNodeWithText("Dark").assertIsSelected()
        // Demo already receives live data. Enabling its page remains possible,
        // while disabling a visible tool with an active operation stays guarded.
        scrollTo("Live signals")
        compose.onNodeWithContentDescription("Live signals").assertIsEnabled().performClick().assertIsOn().assertIsNotEnabled()
    }
    @Test fun advancedToolsAreOptInAndReachable() {
        compose.onNodeWithContentDescription("Advanced tools").performClick()
        compose.onNodeWithText("Enable tools in Settings").performClick()
        scrollTo("Live signals")
        compose.onNodeWithContentDescription("Live signals").performClick()
        compose.onNodeWithContentDescription("Advanced tools").performClick()
        compose.onNode(hasText("Live signals") and hasClickAction()).assertExists()
        screenshot("07-settings-tools")
        compose.onNode(hasText("Live signals") and hasClickAction()).performClick()
        compose.onNodeWithText("Connect for Live signals").assertIsDisplayed()
    }
}
