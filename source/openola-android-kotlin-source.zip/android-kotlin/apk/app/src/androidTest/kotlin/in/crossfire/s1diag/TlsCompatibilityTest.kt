package `in`.crossfire.s1diag

import androidx.test.platform.app.InstrumentationRegistry
import `in`.crossfire.s1diag.net.TlsFactory
import org.conscrypt.Conscrypt
import org.junit.Assert.*
import org.junit.Test
import java.net.InetAddress
import java.security.KeyFactory
import java.security.KeyStore
import java.security.Security
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.net.ssl.*

/** Native provider regression checks. Loopback only; never connects to a scooter. */
class TlsCompatibilityTest {
    @Test fun bundledMutualTlsFactoryLoadsWithUpdatedNativeProvider() {
        val provider = Conscrypt.newProvider()
        if (Security.getProvider(provider.name) == null) Security.insertProviderAt(provider, 1)
        assertEquals(2, Conscrypt.version().major())
        assertEquals(6, Conscrypt.version().minor())
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        (TlsFactory.socketFactory(context).createSocket() as SSLSocket).use { socket ->
            assertTrue(Conscrypt.isConscrypt(socket))
            assertTrue("TLSv1.2" in socket.supportedProtocols)
        }
    }

    @Test fun localMutualTlsHandshakeAndEncryptedRoundTrip() {
        val assets = InstrumentationRegistry.getInstrumentation().context.assets
        // Self-signed test credentials are packaged only in the test APK.
        val cert = assets.open("tls/local-test-cert.der").use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
        val key = assets.open("tls/local-test-key.der").use { KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(it.readBytes())) }
        val store = KeyStore.getInstance("PKCS12").apply {
            load(null, null)
            setKeyEntry("test", key, CharArray(0), arrayOf(cert))
            setCertificateEntry("test-root", cert)
        }
        val km = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply { init(store, CharArray(0)) }
        val tm = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).apply { init(store) }
        val context = SSLContext.getInstance("TLS", Conscrypt.newProvider()).apply { init(km.keyManagers, tm.trustManagers, null) }
        for (protocol in listOf("TLSv1.2", "TLSv1.3")) {
            val executor = Executors.newSingleThreadExecutor()
            try {
                (context.serverSocketFactory.createServerSocket(0, 1, InetAddress.getLoopbackAddress()) as SSLServerSocket).use { server ->
                    server.enabledProtocols = arrayOf(protocol)
                    server.needClientAuth = true
                    server.soTimeout = 10_000
                    val response = executor.submit<Int> {
                        (server.accept() as SSLSocket).use { accepted ->
                            accepted.soTimeout = 10_000
                            accepted.startHandshake()
                            assertEquals(protocol, accepted.session.protocol)
                            assertNotNull(accepted.session.peerPrincipal)
                            val value = accepted.inputStream.read()
                            accepted.outputStream.write(value + 1)
                            accepted.outputStream.flush()
                            value
                        }
                    }
                    (context.socketFactory.createSocket(InetAddress.getLoopbackAddress(), server.localPort) as SSLSocket).use { client ->
                        client.enabledProtocols = arrayOf(protocol)
                        client.soTimeout = 10_000
                        client.startHandshake()
                        assertTrue(Conscrypt.isConscrypt(client))
                        assertEquals(protocol, client.session.protocol)
                        client.outputStream.write(41)
                        client.outputStream.flush()
                        assertEquals(42, client.inputStream.read())
                    }
                    assertEquals(41, response.get(15, TimeUnit.SECONDS).toInt())
                }
            } finally { executor.shutdownNow() }
        }
    }
}
