package `in`.crossfire.s1diag.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.DiagViewModel
import `in`.crossfire.s1diag.vm.SelfTest
import java.text.SimpleDateFormat
import java.util.*

private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

@Composable
fun ToolsScreen(vm: DiagViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var pendingTest by remember { mutableStateOf<SelfTest?>(null) }
    var showWarn by remember { mutableStateOf(false) }
    var pendingMcuCal by remember { mutableStateOf<Boolean?>(null) } // true=start, false=stop
    var odoInput by remember { mutableStateOf("") }
    var pendingOdo by remember { mutableStateOf<Int?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Vehicle info") {
            Button(
                onClick = { vm.loadInfo() },
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
            ) { Text("Load info") }
            ui.info?.let { i ->
                InfoRow("VIN", i.vin); InfoRow("Firmware", i.sw); InfoRow("AOSP", i.aosp)
                Text("Identifiers", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                Text(i.manifest, color = TextHi, fontFamily = Mono, style = MaterialTheme.typography.bodyMedium)
            } ?: Text(
                "Reads VIN, SW/AOSP and identifiers. Retries flaky RPCs automatically.",
                color = TextMut, style = MaterialTheme.typography.bodyMedium,
            )
        }

        SectionCard("MCU calibration · RED") {
            Text(
                "Motor AutoTune (resolver/encoder angle). Same as CLI mcu-cal / ODX " +
                    "31 01 05 F1 start · 31 02 06 F1 stop · DID B113. " +
                    "Centre-stand only — wheel clear, charger unplugged, parked checkbox on.",
                color = TextMut, style = MaterialTheme.typography.bodyMedium,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                val angle = ui.motorAngleDeg
                Text(
                    if (angle != null) "%.1f°".format(angle) else "—",
                    color = TextHi,
                    fontFamily = Mono,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text("B113 angle (0–360 · 0.1°)", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = { vm.readMotorAngle() },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
                ) { Text("Read B113") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { pendingMcuCal = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Danger, contentColor = MaterialTheme.colorScheme.onError),
                    modifier = Modifier.weight(1f),
                ) { Text("Start AutoTune") }
                Button(
                    onClick = { pendingMcuCal = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Danger, contentColor = MaterialTheme.colorScheme.onError),
                    modifier = Modifier.weight(1f),
                ) { Text("Stop AutoTune") }
            }
            Text(
                "After a successful run, re-read B113. Wrong/skipped cal → overcurrent / bad commutation.",
                color = Warn, style = MaterialTheme.typography.bodySmall,
            )
        }

        SectionCard("Odometer (VCU 0103) · RED") {
            Text(
                "Reads/writes the VCU odometer exactly as the factory app does: " +
                    "22 0103 read · 2E 0103 + 4-byte little-endian km write (security access). " +
                    "Write is a real change to the vehicle — intended for restoring correct mileage " +
                    "to a replacement VCU board on your own scooter. Falsifying an odometer is illegal.",
                color = TextMut, style = MaterialTheme.typography.bodyMedium,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                val km = ui.odometerKm
                Text(
                    if (km != null) "$km km" else "—",
                    color = TextHi,
                    fontFamily = Mono,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.headlineSmall,
                )
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = { vm.readOdometer() },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
                ) { Text("Read") }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                OutlinedTextField(
                    value = odoInput,
                    onValueChange = { s -> odoInput = s.filter { it.isDigit() }.take(6) },
                    label = { Text("New km") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Button(
                    onClick = { odoInput.toIntOrNull()?.let { pendingOdo = it } },
                    enabled = odoInput.toIntOrNull() != null,
                    colors = ButtonDefaults.buttonColors(containerColor = Danger, contentColor = MaterialTheme.colorScheme.onError),
                ) { Text("Write") }
            }
            Text(
                "If the VCU rejects it you'll see a UDS negative response (e.g. 0x33 security, " +
                    "0x31 out-of-range, 0x22 conditions) in the result line — that answers whether it's writable offline.",
                color = Warn, style = MaterialTheme.typography.bodySmall,
            )
        }

        SectionCard("Head-unit self-tests") {
            Text(
                "Speaker, screen, radios… Needs parked confirmation. Open the scooter’s diagnostic UI if a test fails.",
                color = TextMut, style = MaterialTheme.typography.bodyMedium,
            )
            FlowButtons(SelfTest.values().toList()) { t ->
                if (vm.showSelfTestWarning()) {
                    pendingTest = t
                    showWarn = true
                } else vm.selfTest(t)
            }
        }

        SectionCard("Fault-watch (wiggle-test)") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (ui.watchOn) OutlinedButton(onClick = { vm.stopWatch() }) { Text("Stop") }
                else Button(
                    onClick = { vm.startWatch() },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
                ) { Text("Start watch") }
                StatusLine(if (ui.watchOn) "watching fault bits" else "stopped", if (ui.watchOn) Ok else TextMut)
            }
            Text(
                "Flex the motor harness; SET/CLEAR appear when a fault bit flips.",
                color = TextMut, style = MaterialTheme.typography.bodyMedium,
            )
            if (ui.watchActive.isNotEmpty()) {
                Text("Active now:", color = Danger, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                for (a in ui.watchActive) Text("• $a", color = Danger, fontFamily = Mono, style = MaterialTheme.typography.bodyMedium)
            } else if (ui.watchOn) Text("No active fault bits.", color = Ok, style = MaterialTheme.typography.bodyMedium)
            if (ui.watchLog.isNotEmpty()) {
                Text("Transitions", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                for (e in ui.watchLog.take(30)) Text(
                    "${clock.format(Date(e.ts))}  ${if (e.set) "SET " else "CLR "} ${e.name}",
                    color = if (e.set) Danger else Ok, fontFamily = Mono, style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        SectionCard("Ride-mode sniffer") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (ui.modeOn) OutlinedButton(onClick = { vm.stopModeSniff() }) { Text("Stop") }
                else Button(
                    onClick = { vm.startModeSniff() },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
                ) { Text("Start") }
                Text("Current: ${ui.rideMode}", color = Accent, fontWeight = FontWeight.SemiBold)
            }
            Text(
                "Cycle Eco→Normal→Sport→Hyper on the handlebar to confirm mode indices.",
                color = TextMut, style = MaterialTheme.typography.bodyMedium,
            )
            for (e in ui.modeLog.take(20)) Text(
                "${clock.format(Date(e.ts))}  ${e.text}",
                color = TextHi, fontFamily = Mono, style = MaterialTheme.typography.bodyMedium,
            )
        }
    }

    if (showWarn && pendingTest != null) {
        SelfTestWarningDialog(
            onContinue = {
                val t = pendingTest!!
                showWarn = false; pendingTest = null
                vm.selfTest(t)
            },
            onNever = {
                vm.hideSelfTestWarningForever()
                val t = pendingTest!!
                showWarn = false; pendingTest = null
                vm.selfTest(t)
            },
            onDismiss = { showWarn = false; pendingTest = null },
        )
    }

    pendingMcuCal?.let { start ->
        val word = if (start) "START" else "STOP"
        ConfirmWithTimer(
            title = "MCU AutoTune $word",
            message = "This sends RMT_CMD_MCU_CAL ($word).\n\n" +
                "Parked on centre stand · wheel free to turn · charger unplugged · " +
                "SERVICE mode recommended.\n\n" +
                "Motor may spin during learn. Wrong angle → overcurrent / runaway torque.",
            confirmLabel = "$word AutoTune",
            seconds = 3,
            onConfirm = {
                pendingMcuCal = null
                vm.mcuCal(start)
            },
            onDismiss = { pendingMcuCal = null },
        )
    }

    pendingOdo?.let { km ->
        ConfirmWithTimer(
            title = "Write odometer = $km km",
            message = "This writes 2E 0103 to the VCU (real change to the vehicle's stored mileage).\n\n" +
                "Only legitimate for restoring the correct reading to a replacement VCU board on your " +
                "own scooter. Falsifying an odometer is illegal in most places.\n\n" +
                "Requires SERVICE mode + security access. Result line shows accept vs. NRC.",
            confirmLabel = "Write $km km",
            seconds = 3,
            onConfirm = {
                pendingOdo = null
                vm.writeOdometer(km)
            },
            onDismiss = { pendingOdo = null },
        )
    }
}

@Composable
private fun SelfTestWarningDialog(
    onContinue: () -> Unit,
    onNever: () -> Unit,
    onDismiss: () -> Unit,
) {
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2000)
        armed = true
    }
    GlassDialog(onDismissRequest = onDismiss) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Head-unit self-test", style = MaterialTheme.typography.titleLarge, color = TextHi)
            Text("Keep the scooter’s diagnostic app open on the dash while running these tests. Some firmwares only respond while that UI is foregrounded.", color = TextMut)
            if (!armed) Text("Please read… (2s)", color = Warn, style = MaterialTheme.typography.bodySmall)
            Button(onClick = onContinue, enabled = armed, modifier = Modifier.fillMaxWidth()) { Text("Continue") }
            TextButton(onClick = onNever, enabled = armed, modifier = Modifier.fillMaxWidth()) { Text("Never show again", color = TextMut) }
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Cancel", color = TextMut) }
        }
    }
}

@Composable
private fun InfoRow(k: String, v: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(k, color = TextMut, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.width(90.dp))
        Text(v, color = TextHi, fontFamily = Mono, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun FlowButtons(tests: List<SelfTest>, onClick: (SelfTest) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        tests.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (t in row) {
                    OutlinedButton(
                        onClick = { onClick(t) },
                        modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 12.dp),
                    ) { Text(t.label) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
