package `in`.crossfire.s1diag.ble

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Battery / lock / range peeked from the scooter's BLE status broadcasts.
 *
 * The consumer app's ScooterAliveResponse parses these plaintext status frames:
 *   data[0:2] vehicle state · data[2] lock · data[3] SOC% · data[4:8] range(per-mode)
 * We peek the same frames as they pass through the notification path (no second
 * channel consumer — see BLE_CHECKPOINT.md).
 *
 * Lock byte (data[2]): observed as non-zero when locked on MY2022; treated as
 * locked when != 0. If absent / unparsed, UI falls back to last command.
 */
object BleStatus {
    data class Snapshot(
        val soc: Int?,
        val locked: Boolean?,
        val rangeBytes: List<Int>,
        val ts: Long,
    )

    /** @deprecated Prefer [Snapshot]; kept for call-site compatibility. */
    data class Batt(
        val soc: Int?,
        val rangeBytes: List<Int>,
        val ts: Long,
        val locked: Boolean? = null,
    )

    private val _state = MutableStateFlow<Batt?>(null)
    val state: StateFlow<Batt?> = _state

    fun reset() { _state.value = null }

    /** frame = Len|Id|Time4|IV2|Type|Data|EOF|CRC (plaintext status uses IV 01 02). */
    fun peek(frame: ByteArray) {
        try {
            if (frame.size < 12) return
            if (frame[6] != 0x01.toByte() || frame[7] != 0x02.toByte()) return  // plaintext only
            val type = frame[8].toInt() and 0xFF
            if (type == 0x70 || type == 0x71 || type == 0x72) return            // seed/key/aes ack
            val data = frame.copyOfRange(9, frame.size - 3)
            if (data.size < 4) return
            val soc = data[3].toInt() and 0xFF
            if (soc !in 0..100) return                                          // ScooterAlive data[3] = SOC%
            val locked = if (data.size > 2) (data[2].toInt() and 0xFF) != 0 else null
            val ranges = (4 until minOf(8, data.size)).map { data[it].toInt() and 0xFF }
            _state.value = Batt(soc, ranges, System.currentTimeMillis(), locked)
        } catch (_: Exception) {}
    }
}
