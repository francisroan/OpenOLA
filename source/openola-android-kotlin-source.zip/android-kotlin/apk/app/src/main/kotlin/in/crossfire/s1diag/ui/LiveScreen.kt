package `in`.crossfire.s1diag.ui

import androidx.compose.material.icons.outlined.BatteryFull
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.DiagViewModel
import `in`.crossfire.s1diag.vm.LiveRow

private val CATEGORIES: Map<String, List<String>?> = linkedMapOf(
    "All" to null,
    "Battery" to listOf("soc", "cell", "pack", "bms", "contactor", "charge", "battery"),
    "Motor" to listOf("mcu", "motor", "rpm", "speed", "torque", "throttle", "drive"),
    "Power" to listOf("voltage", "current", "dcdc", "dc_dc", "bus", "power"),
    "Temp" to listOf("temp"),
    "Faults" to listOf("fault", "error", "warn", "protect", "abnormal", "fail"),
    "Vehicle" to listOf("odom", "mode", "indicator", "brake", "light", "horn", "lamp", "stand", "lock"),
)

private val TILES = listOf(
    "Overall_SOC" to ("SOC" to true),
    "MCU_Voltage" to ("Bus V" to false),
    "BMS0_Cell_Min_Voltage" to ("Min cell" to true),
    "BMS0_Cell_Max_Voltage" to ("Max cell" to true),
    "Motor_Temprature" to ("Motor °C" to false),
    "MCU_Temperatute" to ("MCU °C" to false),
)

@Composable
fun LiveScreen(vm: DiagViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val now by rememberUiClock()
    var cat by remember { mutableStateOf("All") }
    var search by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val ctx = androidx.compose.ui.platform.LocalContext.current
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (ui.liveOn) OutlinedButton(onClick = { vm.stopLive() }) { Text("Pause") }
            else Button(
                onClick = { vm.startLive() },
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
            ) { Text("Start live") }
            OutlinedButton(onClick = { shareText(ctx, "OpenOLA — live CSV", vm.liveCsv()) }) { Text("Share") }
            Spacer(Modifier.weight(1f))
            Text(
                if (ui.liveOn) "Streaming · ${ui.live.size}" else "Paused",
                color = if (ui.liveOn) Ok else TextMut,
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        val tiles = TILES.mapNotNull { (k, meta) ->
            val (lbl, battery) = meta
            ui.live.firstOrNull { it.signal == k }?.let { Triple(lbl, fmt(it.value), battery) }
        }
        if (tiles.isNotEmpty()) {
            SectionCard {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for ((lbl, v, battery) in tiles) {
                        MetricTile(lbl, v, leading = if (battery) ({ BatteryGlyph() }) else null)
                    }
                }
            }
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            for (c in CATEGORIES.keys) Chip(c, cat == c) { cat = c }
        }
        OutlinedTextField(
            search, { search = it }, label = { Text("Search signal / message") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )

        val kw = CATEGORIES[cat]
        val q = search.lowercase()
        val rows = remember(ui.live, cat, search) { ui.live.filter { r ->
            val hay = "${"%03X".format(r.id)} ${r.message} ${r.signal}".lowercase()
            (kw == null || kw.any { hay.contains(it) }) && (q.isEmpty() || hay.contains(q))
        }
        }
        Text("${rows.size} shown", style = MaterialTheme.typography.bodyMedium, color = TextMut)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(1.dp), modifier = Modifier.weight(1f)) {
            items(rows, key = { "${it.id}:${it.message}:${it.signal}" }) { SignalRow(it, now) }
        }
    }
}

@Composable
private fun BatteryGlyph() {
    androidx.compose.material3.Icon(
        androidx.compose.material.icons.Icons.Outlined.BatteryFull, null,
        tint = Accent, modifier = Modifier.size(22.dp),
    )
}

@Composable
private fun SignalRow(r: LiveRow, now: Long) {
    val battery = r.signal.contains("soc", true) || r.signal.contains("cell", true) || r.signal.contains("pack", true)
    Surface(color = Surface1, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (battery) {
                BatteryGlyph()
                Spacer(Modifier.width(8.dp))
            }
            Text("%03X".format(r.id), color = TextMut, fontFamily = Mono, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.width(42.dp))
            Column(Modifier.weight(1f)) {
                Text(r.signal, color = TextHi, style = MaterialTheme.typography.bodyMedium)
                Text(r.message + if (now - r.ts > STALE_AFTER_MS) " · stale" else "", color = TextMut, style = MaterialTheme.typography.bodySmall)
            }
            Text(
                fmt(r.value) + (if (r.unit.isNotEmpty()) " ${r.unit}" else ""),
                color = Accent, fontFamily = Mono, fontWeight = FontWeight.Medium,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

private fun fmt(v: Double): String = if (v == v.toLong().toDouble()) v.toLong().toString() else "%.3f".format(v)
