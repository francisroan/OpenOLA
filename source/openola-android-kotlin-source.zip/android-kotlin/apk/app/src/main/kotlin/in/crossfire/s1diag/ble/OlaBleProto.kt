package `in`.crossfire.s1diag.ble

import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Ola consumer BLE proximity protocol -- seed/key + AES-CTR + framing.
 *
 * Ported 1:1 from the reverse-engineered consumer app and VERIFIED end-to-end
 * against a real capture (Nothing Phone 2, 2026-09-15): the session key derived
 * here decrypts the app's real LOCK/UNLOCK/TRUNK presses, and the frame builder
 * reproduces the captured seed-request/key bytes incl. CRC.
 *
 *   frame = Len | Id | Time(4 BE) | IV(2) | Type | Data | [EOF=01 if data] | CRC(2 BE)
 *   Len   = total_len - 1;  CRC = CRC-16/CCITT-FALSE over Len..EOF
 *   plain IV = 01 02;  encrypted IV = 2 random bytes (carried in header)
 *   session key = HKDF-SHA256(salt=FIXED_IV, ikm = seed||seedKey, L=16), AES-128-CTR
 *   per-message cipher IV = RANDOM_SALT(14) || the 2 IV bytes
 *
 * Own-vehicle use only.
 */
object OlaBleProto {

    // ----- command catalogue (CommandDataTypes.data) -----
    val COMMANDS = linkedMapOf(
        "Unlock" to 2, "Lock" to 1, "Open trunk" to 3,
        "Flash lights" to 6, "Flash + horn" to 7,
    )
    const val SEED_REQUEST = 48
    const val SEED_KEY = 49
    const val TEST_AES = 50
    const val DIRECT_COMMAND = 1
    const val SEED_REPLY = 0x70
    const val KEY_ACK = 0x71
    val TEST_AES_DATA = "D_ALIVE".toByteArray(Charsets.US_ASCII)

    private val FIXED_IV = byteArrayOf(
        0x2f, 0xb1.toByte(), 0x9e.toByte(), 0x76, 0x6b, 0xa2.toByte(), 0x5d, 0x80.toByte(),
        0x4e, 0xf4.toByte(), 0xd7.toByte(), 0xc1.toByte(), 0x53, 0x17, 0x68, 0x3e)
    private val RANDOM_SALT = FIXED_IV.copyOfRange(0, 14)

    // BLE getKey() constant vectors (level "01" / other)
    private val BLE_01 = intArrayOf(78, 99, 67, 22)
    private val BLE_OTHER = intArrayOf(13, 31, 90, 96)

    // ---------- seed -> key (grid-ASCII transform) ----------
    fun generateKey(seed: ByteArray, level: String = "01"): ByteArray {
        require(seed.size == 8) { "BLE seed must be 8 bytes" }
        val consts = if (level == "01") BLE_01 else BLE_OTHER
        val grid = keyP(randomNumberTester(IntArray(8) { seed[it].toInt() and 0xFF }, consts))
        val out = ByteArray(8)
        for (r in 0 until 4) for (c in 0 until 2) out[r * 2 + c] = grid[r][c].toByte()
        return out
    }

    private fun hex2dec(p: IntArray): Int {
        var v = 0
        if (p[0] in 48..57) v += p[0] - 48 else if (p[0] in 65..70) v += p[0] - 55
        if (p[1] in 48..57) v += (p[1] - 48) * 16 else if (p[1] in 65..70) v += (p[1] - 55) * 16
        return v
    }
    private fun dec2hex(v: Int): IntArray {
        val lo = v % 16; val hi = (v / 16) % 16
        return intArrayOf(if (lo >= 10) lo + 55 else lo + 48, if (hi >= 10) hi + 55 else hi + 48)
    }
    private fun randomNumberTester(s: IntArray, k: IntArray): IntArray {
        val m = arrayOf(intArrayOf(s[0], s[1]), intArrayOf(s[2], s[3]),
                        intArrayOf(s[4], s[5]), intArrayOf(s[6], s[7]))
        val tmp = m[0][0]; m[0][0] = m[1][0]; m[1][0] = m[2][0]; m[2][0] = m[3][0]; m[3][0] = tmp
        val x = IntArray(4) { hex2dec(m[it]) }
        val y = IntArray(4) { (x[it] - k[it] + 127) % 127 }
        return IntArray(4) { ((y[it] * 91) + 202) % 127 }
    }
    private fun keyP(p: IntArray): Array<IntArray> {
        val a = ((((p[0] * 7) + 255) % 255) xor 23)
        val b = ((((p[1] * 5) + 255) % 255) xor 67)
        val c = ((((p[2] * 1) + 255) % 255) xor 8)
        val d = ((((8 * p[3]) + 255) % 255) xor 45)
        return arrayOf(dec2hex(a xor b), dec2hex(b xor c), dec2hex(c xor d), dec2hex(d xor a))
    }

    // ---------- crypto ----------
    fun sessionKey(seed: ByteArray, seedKey: ByteArray): ByteArray =
        hkdfSha256(seed + seedKey, FIXED_IV, 16)

    private fun hkdfSha256(ikm: ByteArray, salt: ByteArray, len: Int): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(salt, "HmacSHA256"))
        val prk = mac.doFinal(ikm)
        mac.init(SecretKeySpec(prk, "HmacSHA256"))
        var t = ByteArray(0); val out = ByteArray(len); var filled = 0; var c = 1
        while (filled < len) {
            mac.update(t); mac.update(byteArrayOf(c.toByte()))
            t = mac.doFinal()
            val n = minOf(t.size, len - filled)
            System.arraycopy(t, 0, out, filled, n); filled += n; c++
        }
        return out
    }

    /** AES-128-CTR of [data]; returns Pair(ciphertext, rand2). */
    fun encrypt(key: ByteArray, data: ByteArray, rand2: ByteArray = randomBytes(2)): Pair<ByteArray, ByteArray> {
        val iv = RANDOM_SALT + rand2
        val c = Cipher.getInstance("AES/CTR/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        return c.doFinal(data) to rand2
    }

    private fun randomBytes(n: Int) = ByteArray(n).also { java.security.SecureRandom().nextBytes(it) }

    // ---------- framing ----------
    fun crc16(data: ByteArray): Int {
        var crc = 0xFFFF
        for (b in data) {
            crc = crc xor ((b.toInt() and 0xFF) shl 8)
            repeat(8) { crc = if (crc and 0x8000 != 0) ((crc shl 1) xor 0x1021) and 0xFFFF else (crc shl 1) and 0xFFFF }
        }
        return crc
    }

    private var pid = 0
    private fun nextId(): Int { pid = (pid + 1) and 0xFF; return pid }

    private fun assemble(type: Int, iv: ByteArray, body: ByteArray, eof: Boolean): ByteArray {
        val t = (System.currentTimeMillis() / 1000L).toInt()
        val time = byteArrayOf((t ushr 24).toByte(), (t ushr 16).toByte(), (t ushr 8).toByte(), t.toByte())
        var inner = byteArrayOf(nextId().toByte()) + time + iv + byteArrayOf(type.toByte()) + body
        if (eof) inner += byteArrayOf(0x01)
        val len = inner.size + 2
        val head = byteArrayOf(len.toByte()) + inner
        val crc = crc16(head)
        return head + byteArrayOf((crc ushr 8).toByte(), crc.toByte())
    }

    fun buildPlain(type: Int, payload: ByteArray = ByteArray(0)): ByteArray =
        assemble(type, byteArrayOf(0x01, 0x02), payload, payload.isNotEmpty())

    fun buildEncrypted(key: ByteArray, type: Int, payload: ByteArray): ByteArray {
        val (ct, rand2) = encrypt(key, byteArrayOf(type.toByte()) + payload)
        return assemble(ct[0].toInt() and 0xFF, rand2, ct.copyOfRange(1, ct.size), true)
    }

    /** app-layer type byte of a received frame, or -1. */
    fun frameType(b: ByteArray): Int = if (b.size > 8) b[8].toInt() and 0xFF else -1
    /** data field of a received frame (Type..EOF/CRC stripped). */
    fun frameData(b: ByteArray): ByteArray = if (b.size > 11) b.copyOfRange(9, b.size - 3) else ByteArray(0)
}
