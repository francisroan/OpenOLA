package `in`.crossfire.s1diag.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

/**
 * Where activity + charge logs are written.
 *
 * Default: app-specific external files (`…/files/logs`, `…/files/charging`) —
 * no extra permission needed.
 *
 * Custom: user picks a folder via SAF (Storage Access Framework). The tree URI
 * is persisted so Downloads / SD card / shared folders work across reboots.
 */
object LogStorage {
    private const val PREFS = "s1diag"
    private const val KEY_ACTIVITY_TREE = "log_activity_tree_uri"
    private const val KEY_CHARGE_TREE = "log_charge_tree_uri"

    fun defaultActivityDir(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "logs").also { it.mkdirs() }

    fun defaultChargeDir(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "charging").also { it.mkdirs() }

    fun activityLabel(ctx: Context): String =
        treeLabel(ctx, KEY_ACTIVITY_TREE) ?: defaultActivityDir(ctx).absolutePath

    fun chargeLabel(ctx: Context): String =
        treeLabel(ctx, KEY_CHARGE_TREE) ?: defaultChargeDir(ctx).absolutePath

    fun usingCustomActivity(ctx: Context): Boolean =
        prefs(ctx).getString(KEY_ACTIVITY_TREE, null) != null

    fun usingCustomCharge(ctx: Context): Boolean =
        prefs(ctx).getString(KEY_CHARGE_TREE, null) != null

    fun setActivityTree(ctx: Context, uri: Uri) {
        takePersistable(ctx, uri)
        prefs(ctx).edit().putString(KEY_ACTIVITY_TREE, uri.toString()).apply()
    }

    fun setChargeTree(ctx: Context, uri: Uri) {
        takePersistable(ctx, uri)
        prefs(ctx).edit().putString(KEY_CHARGE_TREE, uri.toString()).apply()
    }

    fun resetActivity(ctx: Context) {
        prefs(ctx).edit().remove(KEY_ACTIVITY_TREE).apply()
    }

    fun resetCharge(ctx: Context) {
        prefs(ctx).edit().remove(KEY_CHARGE_TREE).apply()
    }

    /** Create/open an appendable activity log file in the configured location. */
    fun openActivityFile(ctx: Context, fileName: String): LogSink =
        openInTreeOrDefault(ctx, KEY_ACTIVITY_TREE, defaultActivityDir(ctx), fileName, "text/plain")

    /** Create/open an appendable charge JSONL in the configured location. */
    fun openChargeFile(ctx: Context, fileName: String): LogSink =
        openInTreeOrDefault(ctx, KEY_CHARGE_TREE, defaultChargeDir(ctx), fileName, "text/plain")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun takePersistable(ctx: Context, uri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, flags)
        } catch (_: SecurityException) {
        }
    }

    private fun treeLabel(ctx: Context, key: String): String? {
        val raw = prefs(ctx).getString(key, null) ?: return null
        return try {
            val uri = Uri.parse(raw)
            val doc = DocumentFile.fromTreeUri(ctx, uri) ?: return raw
            doc.name?.let { "SAF: $it" } ?: raw
        } catch (_: Exception) {
            raw
        }
    }

    private fun openInTreeOrDefault(
        ctx: Context,
        treeKey: String,
        defaultDir: File,
        fileName: String,
        mime: String,
    ): LogSink {
        val treeRaw = prefs(ctx).getString(treeKey, null)
        if (treeRaw != null) {
            try {
                val tree = DocumentFile.fromTreeUri(ctx, Uri.parse(treeRaw))
                if (tree != null && tree.canWrite()) {
                    val existing = tree.findFile(fileName)
                    val doc = existing ?: tree.createFile(mime, fileName)
                    if (doc != null) {
                        return DocumentSink(ctx, doc, display = "${treeLabel(ctx, treeKey)}/$fileName")
                    }
                }
            } catch (_: Exception) {
                // Fall through to app-default dir.
            }
        }
        defaultDir.mkdirs()
        val f = File(defaultDir, fileName)
        return FileSink(f)
    }
}

/** Append-only sink used by AutoLog / ChargeSessionLog. */
interface LogSink {
    val displayPath: String
    val name: String
    fun append(text: String)
    fun length(): Long
    fun truncate()
}

private class FileSink(private val file: File) : LogSink {
    override val displayPath: String = file.absolutePath
    override val name: String = file.name
    override fun append(text: String) {
        file.appendText(text)
    }
    override fun length(): Long = file.length()
    override fun truncate() {
        file.writeText("")
    }
}

private class DocumentSink(
    private val ctx: Context,
    private val doc: DocumentFile,
    display: String,
) : LogSink {
    override val displayPath: String = display
    override val name: String = doc.name ?: "log"
    override fun append(text: String) {
        // "wa" = write+append (API 26+). Fallback: read-modify via "wt" is lossy for
        // concurrent writers; we only append from one thread per sink.
        val mode = "wa"
        ctx.contentResolver.openOutputStream(doc.uri, mode)?.use { os ->
            OutputStreamWriter(os, StandardCharsets.UTF_8).use { it.write(text); it.flush() }
        }
    }
    override fun length(): Long = doc.length()
    override fun truncate() {
        ctx.contentResolver.openOutputStream(doc.uri, "wt")?.use { it.write(ByteArray(0)) }
    }
}
