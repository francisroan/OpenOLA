package `in`.crossfire.s1diag.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.DiagViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

@Composable
fun ReportsScreen(vm: DiagViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var includeVin by rememberSaveable { mutableStateOf(false) }
    var includeActivity by rememberSaveable { mutableStateOf(false) }
    var reportText by rememberSaveable { mutableStateOf<String?>(null) }
    var reportJson by rememberSaveable { mutableStateOf<String?>(null) }
    var reportAt by rememberSaveable { mutableLongStateOf(0L) }
    var pendingExport by rememberSaveable { mutableStateOf("") }
    var saveMessage by rememberSaveable { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    fun save(uri: android.net.Uri?) {
        if (uri == null) { pendingExport = ""; return }
        val content = pendingExport
        pendingExport = ""
        saving = true
        scope.launch {
            saveMessage = withContext(Dispatchers.IO) {
                runCatching {
                    val stream = context.contentResolver.openOutputStream(uri, "wt") ?: error("Cannot open the selected document.")
                    stream.bufferedWriter(Charsets.UTF_8).use { it.write(content) }
                    "Report saved."
                }.getOrElse { "Could not save report: ${it.message}" }
            }
            saving = false
        }
    }
    val saveText = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain"), ::save)
    val saveJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json"), ::save)
    val capture: () -> Unit = {
        val report = DiagnosticReport.capture(withDemoBattery(ui), System.currentTimeMillis(), includeVin, if (includeActivity) vm.autoLogText() else null)
        reportAt = report.capturedAt; reportText = report.text; reportJson = report.json; saveMessage = null
    }
    // Invalidate only on a user change; returning to this screen retains its frozen snapshot.
    fun invalidateReport() { reportText = null; reportJson = null; reportAt = 0L }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageHeading("Diagnostic reports", "Capture once. Review, save or share.") }
        item {
            SectionCard("Report contents") {
                Text("Battery snapshot, stored fault codes, scan coverage and CAN freshness. A report uses data already in the app; it does not start a scan or send a command.", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                SettingToggle("Include VIN", if (ui.info == null) "VIN has not been read. Read vehicle info in Engineering tools if needed." else "Vehicle identifiers can identify your scooter.", includeVin) { includeVin = it; invalidateReport() }
                SettingToggle("Include activity log", "Logs may contain identifiers and raw diagnostic details.", includeActivity) { includeActivity = it; invalidateReport() }
                Button(onClick = capture, enabled = !saving, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                    Icon(GlassIcons.Reports, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
                    Text(if (reportText == null) "Capture report" else "Capture a new snapshot")
                }
                if (ui.demo) Text("Demo report: every export is marked as simulated.", color = Accent, style = MaterialTheme.typography.bodySmall)
                Text("Scan controllers in Faults first for stored-code coverage. Missing readings and unscanned controllers remain explicit.", color = TextMut, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (reportText != null) {
            item {
                SectionCard("Export") {
                    Text("Snapshot: ${Instant.ofEpochMilli(reportAt)}", color = TextMut, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            pendingExport = reportText.orEmpty()
                            saveText.launch(reportFilename(reportAt, "txt"))
                        }, enabled = !saving, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("Save TXT") }
                        OutlinedButton(onClick = {
                            pendingExport = reportJson.orEmpty()
                            saveJson.launch(reportFilename(reportAt, "json"))
                        }, enabled = !saving, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("Save JSON") }
                    }
                    Button(onClick = { shareText(context, "OpenOLA diagnostic report", reportText.orEmpty()) }, enabled = !saving, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Icon(Icons.Outlined.Share, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Share report")
                    }
                    saveMessage?.let { Text(it, color = TextMut, style = MaterialTheme.typography.bodyMedium) }
                    if (saving) LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
            item {
                SectionCard("Preview") {
                    SelectionContainer { Text(reportText.orEmpty(), style = MaterialTheme.typography.bodySmall, fontFamily = Mono, color = TextHi) }
                }
            }
        }
    }
}
private fun reportFilename(at: Long, extension: String): String =
    "OpenOLA-${DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(ZoneOffset.UTC).format(Instant.ofEpochMilli(at))}.$extension"
