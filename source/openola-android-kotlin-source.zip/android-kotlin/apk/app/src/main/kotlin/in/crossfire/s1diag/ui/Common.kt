package `in`.crossfire.s1diag.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.ui.theme.*

@Composable
fun SectionCard(
    title: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    GlassSurface(modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (title != null) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = TextHi, fontWeight = FontWeight.SemiBold)
            }
            content()
        }
    }
}

@Composable
fun MetricTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    leading: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Surface2)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (leading != null) leading()
        Column {
            Text(label, style = MaterialTheme.typography.labelMedium, color = TextMut)
            Text(value, style = MaterialTheme.typography.titleMedium, color = Accent, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Accent else Surface2, label = "chipBg")
    val fg by animateColorAsState(if (selected) Color.White else TextMut, label = "chipFg")
    Surface(
        color = bg,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, if (selected) Accent else Line),
    ) {
        Text(
            text, color = fg, style = MaterialTheme.typography.labelLarge,
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .clickableNoRipple(onClick)
                .heightIn(min = 48.dp)
                .wrapContentHeight(Alignment.CenterVertically)
                .padding(horizontal = 14.dp, vertical = 10.dp),
        )
    }
}

@Composable
fun EcuSelector(selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (e in listOf("BMS", "VCU", "MCU")) Chip(e, selected == e) { onSelect(e) }
    }
}

@Composable
fun StatusLine(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = TextMut)
    }
}

/** Medium control tile: icon + label, lit when active / latched. */
@Composable
fun ControlTile(
    title: String,
    glyph: ControlGlyph,
    active: Boolean,
    subtitle: String? = null,
    danger: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scale by animateFloatAsState(if (active) 1.01f else 1f, tween(if (LocalReduceMotion.current) 0 else 180), label = "tileScale")
    val border = when {
        active -> Accent
        danger -> Danger.copy(alpha = 0.55f)
        else -> Line
    }
    val bg = if (active) {
        Brush.verticalGradient(listOf(Accent.copy(alpha = 0.22f), Surface2))
    } else {
        Brush.verticalGradient(listOf(Surface2, Surface1))
    }
    Column(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .border(BorderStroke(1.5.dp, border), RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(if (active) AccentGlow else Surface3),
            contentAlignment = Alignment.Center,
        ) {
            ControlIcon(glyph, active = active, size = 36.dp)
        }
        Text(
            title,
            color = if (danger && !active) Danger else TextHi,
            style = MaterialTheme.typography.labelLarge,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        if (subtitle != null) {
            Text(subtitle, color = if (active) Accent else TextMut, style = MaterialTheme.typography.labelMedium)
        }
    }
}

fun shareText(context: android.content.Context, subject: String, text: String) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(android.content.Intent.EXTRA_SUBJECT, subject)
        putExtra(android.content.Intent.EXTRA_TEXT, text)
    }
    context.startActivity(
        android.content.Intent.createChooser(intent, subject).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = composed {
    clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick,
    )
}
