package `in`.crossfire.s1diag.data

/**
 * Broadcast fault registers (no UDS/no unlock — always live). Ported from the
 * Python faults_live.py / watch.py: single-bit named flags whose name matches a
 * "faulty" word and isn't a benign operating-state bit. Used by the live
 * fault-watch (wiggle-test) to flag SET/CLEAR transitions as you flex a harness.
 */
object FaultBits {
    val REGISTER_IDS = listOf(0x410, 0x411, 0x122, 0x430, 0x431, 0x333, 0x213, 0x210, 0x642, 0x11C, 0x353, 0x640)

    private val FAULTY = Regex(
        "fault|error|fail|warn|protect|abnormal|overcurrent|overvolt|undervolt|overtemp|short|disconnect|timeout|corrupt|stall|deviation",
        RegexOption.IGNORE_CASE,
    )
    private val BENIGN = Regex("demand|status_signal|counter|calibration|balancing|indicator_ttl", RegexOption.IGNORE_CASE)

    fun isFaultBit(name: String, bitLength: Int): Boolean =
        bitLength == 1 && FAULTY.containsMatchIn(name) && !BENIGN.containsMatchIn(name)

    /** Currently-set fault bits across the received registers -> "0x%03X / signal". */
    fun active(dbc: Dbc, latest: Map<Int, ByteArray>): Set<String> {
        val out = LinkedHashSet<String>()
        for (id in REGISTER_IDS) {
            val data = latest[id] ?: continue
            val msg = dbc.message(id) ?: continue
            for (sv in dbc.decode(id, data)) {
                val sig = msg.signals.firstOrNull { it.name == sv.name } ?: continue
                if (isFaultBit(sig.name, sig.bitLength) && sv.value.toInt() == 1)
                    out.add("0x%03X / %s".format(id, sig.name))
            }
        }
        return out
    }
}
