package `in`.crossfire.s1diag

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.foundation.selection.selectable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import dev.chrisbanes.haze.HazeState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import `in`.crossfire.s1diag.ui.*
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.Conn
import `in`.crossfire.s1diag.vm.DiagViewModel
import java.security.Security

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { Security.insertProviderAt(org.conscrypt.Conscrypt.newProvider(), 1) } catch (_: Throwable) {}
        enableEdgeToEdge()
        setContent {
            val prefs = remember { AppPreferences(applicationContext) }
            S1DiagTheme(prefs.appearance, prefs.reduceMotion) { AppRoot(prefs) }
        }
    }
}
private enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("Home", GlassIcons.Home),
    FAULTS("Faults", GlassIcons.Faults),
    REPORTS("Reports", GlassIcons.Reports),
    SETTINGS("Settings", GlassIcons.Settings),
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot(prefs: AppPreferences) {
    val vm: DiagViewModel = viewModel()
    val ui by vm.ui.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(MainTab.HOME) }
    var tool by rememberSaveable { mutableStateOf<AdvancedFeature?>(null) }
    var toolsMenu by remember { mutableStateOf(false) }
    var showConnect by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(prefs.enabled) { if (tool != null && !prefs.isEnabled(tool!!)) tool = null }
    LaunchedEffect(ui.conn) { if (ui.conn == Conn.CONNECTED) showConnect = false }
    BackHandler(enabled = toolsMenu || tool != null || tab != MainTab.HOME || showConnect) {
        when { toolsMenu -> toolsMenu = false; tool != null -> tool = null; showConnect -> showConnect = false; else -> tab = MainTab.HOME }
    }
    val navigate: (MainTab) -> Unit = { tab = it; tool = null; showConnect = false }
    val duration = if (prefs.reduceMotion) 0 else 180
    val screenState = rememberSaveableStateHolder()
    val glass = remember { HazeState() }
    CompositionLocalProvider(LocalGlassState provides glass) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        GlassWallpaper(glass, Modifier.matchParentSize())
        val wide = maxWidth >= 720.dp
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                GlassSurface(Modifier.statusBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp), radius = 24.dp) {
                Column {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OpenOlaMark()
                                Column {
                                    Text("OpenOLA", style = MaterialTheme.typography.titleLarge)
                                    ConnectionLabel(ui.conn, ui.demo, ui.lastCanFrameAt)
                                }
                            }
                        },
                        actions = {
                            if (ui.conn == Conn.CONNECTED) IconButton(onClick = { vm.disconnect() }) {
                                Icon(Icons.Outlined.LinkOff, "Disconnect scooter")
                            } else if (tab != MainTab.HOME) IconButton(onClick = { showConnect = true; tool = null }) {
                                Icon(Icons.Outlined.Wifi, "Connect scooter")
                            }
                            IconButton(onClick = { toolsMenu = true }) { Icon(GlassIcons.Settings, "Advanced tools") }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                        windowInsets = WindowInsets(0, 0, 0, 0),
                    )
                    if (ui.busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent, trackColor = Surface2)
                    if ((tool != null && tool != AdvancedFeature.BLE) || tab == MainTab.FAULTS) {
                        if (ui.conn == Conn.CONNECTED) ServicePrerequisite(vm)
                    }
                    if (ui.conn == Conn.CONNECTED && ui.mode == "SERVICE") {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Service mode", color = Warn, style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                            TextButton(onClick = { vm.setMode("CUST") }, enabled = !ui.busy && (ui.bench || ui.demo)) { Text("Return to Customer") }
                        }
                    }
                }
                }
            },
            bottomBar = {
                if (!wide) GlassSurface(
                    Modifier.navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp).fillMaxWidth(),
                    radius = 28.dp,
                ) {
                    Row(Modifier.padding(7.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        MainTab.entries.forEach { destination ->
                            DockItem(destination, tab == destination && tool == null && !showConnect,
                                { navigate(destination) }, Modifier.weight(1f))
                        }
                    }
                }
            },
        ) { padding ->
            Row(Modifier.padding(padding).fillMaxSize()) {
                if (wide) GlassSurface(Modifier.padding(start = 14.dp, top = 12.dp, bottom = 16.dp)
                    .fillMaxHeight().width(104.dp), radius = 26.dp) {
                    Column(Modifier.padding(horizontal = 7.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        MainTab.entries.forEach { destination ->
                            DockItem(destination, tab == destination && tool == null && !showConnect, { navigate(destination) }, Modifier.fillMaxWidth())
                        }
                    }
                }
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
                    Column(Modifier.widthIn(max = if (wide) 1160.dp else 680.dp).fillMaxWidth().fillMaxHeight()) {
                        AnimatedContent(
                            targetState = Triple(tab, tool, showConnect),
                            transitionSpec = {
                                (fadeIn(tween(duration)) + slideInVertically(
                                    animationSpec = if (prefs.reduceMotion) tween(0) else spring(dampingRatio = .88f, stiffness = 500f),
                                    initialOffsetY = { if (prefs.reduceMotion) 0 else 20 },
                                )) togetherWith fadeOut(tween(duration / 2))
                            },
                            modifier = Modifier.weight(1f), label = "workspace",
                        ) { (destination, selectedTool, connection) ->
                            screenState.SaveableStateProvider(if (connection) "connect" else selectedTool?.name ?: destination.name) {
                            when {
                                connection -> ConnectScreen(vm)
                                selectedTool == AdvancedFeature.BLE -> BluetoothScreen(ui.bleMac, vm::setBleMac) { tool = null }
                                selectedTool != null && ui.conn != Conn.CONNECTED -> ConnectScreen(vm, selectedTool.label)
                                selectedTool != null -> when (selectedTool) {
                                    AdvancedFeature.LIVE -> LiveScreen(vm)
                                    AdvancedFeature.CHARGING -> ChargingScreen(vm)
                                    AdvancedFeature.ACTUATORS -> ScooterScreen(vm)
                                    AdvancedFeature.PARAMETERS -> WriteScreen(vm)
                                    AdvancedFeature.FEATURES -> FeaturesScreen(vm)
                                    AdvancedFeature.ENGINEERING -> ToolsScreen(vm)
                                    else -> {}
                                }
                                destination == MainTab.HOME -> if (ui.conn == Conn.CONNECTED) StatusScreen(
                                    vm, onFaults = { navigate(MainTab.FAULTS) }, onReports = { navigate(MainTab.REPORTS) },
                                ) else ConnectScreen(vm)
                                destination == MainTab.FAULTS -> FaultsScreen(vm, prefs.isEnabled(AdvancedFeature.FAULT_ACTIONS))
                                destination == MainTab.REPORTS -> ReportsScreen(vm)
                                else -> SettingsScreen(vm, prefs)
                            }
                            }
                        }
                        // A message only occupies its own surface; navigation and controls stay accessible.
                        ui.message?.let { message ->
                            Surface(color = Surface2, shape = RoundedCornerShape(18.dp), modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(message, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                    IconButton(onClick = vm::dismissMessage) { Icon(Icons.Outlined.Close, "Dismiss message") }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (toolsMenu) {
            Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = .08f)).clickable { toolsMenu = false })
            GlassSurface(Modifier.align(Alignment.TopEnd).statusBarsPadding()
                .padding(top = 78.dp, end = 14.dp, start = 14.dp, bottom = 24.dp)
                .widthIn(max = 310.dp).heightIn(max = maxHeight - 150.dp), radius = 24.dp, strong = true) {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Tools", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(8.dp))
                    val available = AdvancedFeature.entries.filter { prefs.isEnabled(it) }
                    if (available.isEmpty()) TextButton(onClick = { navigate(MainTab.SETTINGS); toolsMenu = false }) {
                        Text("Enable tools in Settings")
                    }
                    AdvancedGroups.forEach { group ->
                        val enabled = group.features.filter { it in available }
                        if (enabled.isNotEmpty()) {
                            Text(group.title, color = TextMut, style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(start = 8.dp, top = 8.dp))
                            enabled.forEach { feature ->
                                TextButton(onClick = {
                                    if (feature == AdvancedFeature.FAULT_ACTIONS) navigate(MainTab.FAULTS)
                                    else { tool = feature; showConnect = false }
                                    toolsMenu = false
                                }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                                    Text(feature.label, modifier = Modifier.weight(1f), color = TextHi)
                                }
                            }
                        }
                    }
                    if (available.isNotEmpty()) {
                        HorizontalDivider(color = Line, modifier = Modifier.padding(vertical = 6.dp))
                        TextButton(onClick = { navigate(MainTab.SETTINGS); toolsMenu = false }, modifier = Modifier.fillMaxWidth()) {
                            Text("Manage tools in Settings")
                        }
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun DockItem(tab: MainTab, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val dark = LocalPalette.current.dark
    val selectedFill = if (dark) Color.White.copy(alpha = .12f) else Color.White.copy(alpha = .84f)
    Column(modifier.clip(RoundedCornerShape(22.dp))
        .background(if (selected) selectedFill else Color.Transparent)
        .selectable(selected = selected, role = Role.Tab, onClick = onClick)
        .heightIn(min = 62.dp).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Icon(tab.icon, null, tint = if (selected) Accent else TextMut, modifier = Modifier.size(23.dp))
        Text(tab.label, color = if (selected) Accent else TextMut, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun ConnectionLabel(conn: Conn, demo: Boolean, lastFrameAt: Long) {
    val now by rememberUiClock()
    val text = when {
        demo && conn == Conn.CONNECTED -> "Demo · simulated data"
        conn == Conn.CONNECTING -> "Connecting…"
        conn == Conn.ERROR -> "Connection failed"
        conn != Conn.CONNECTED -> "Offline diagnostics"
        lastFrameAt == 0L -> "Connected · awaiting CAN"
        now - lastFrameAt > STALE_AFTER_MS -> "Connected · CAN data stale"
        else -> "Connected · CAN receiving"
    }
    val color = when { demo -> Accent; conn == Conn.ERROR -> Danger; conn == Conn.CONNECTED && lastFrameAt > 0 && now - lastFrameAt <= STALE_AFTER_MS -> Ok; else -> TextMut }
    Text(text, color = color, style = MaterialTheme.typography.labelMedium)
}
@Composable
private fun ServicePrerequisite(vm: DiagViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(ui.bench, vm::setBench)
        Column(Modifier.weight(1f)) {
            Text("Parked & charger disconnected", style = MaterialTheme.typography.labelLarge)
            Text("Confirming this enters Service mode for active tests.", color = TextMut, style = MaterialTheme.typography.bodySmall)
        }
        if (ui.bench && ui.mode != "SERVICE") {
            TextButton(onClick = { vm.setMode("SERVICE") }, enabled = !ui.busy) { Text("Enter Service") }
        }
    }
}
