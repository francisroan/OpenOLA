package `in`.crossfire.s1diag.data

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Dedicated charge-session capture (separate from the activity text log).
 *
 * Default folder: app `…/files/charging/`. Override via [LogStorage] (SAF folder pick).
 * JSONL lines: raw frames + decoded signals, plus periodic `vitals` snapshots.
 */
object ChargeSessionLog {
    private val fmt = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
    private val active = AtomicBoolean(false)
    private var sink: LogSink? = null
    private var frames = 0
    private var vitalsWrites = 0
    private var startedAt = 0L
    private val lastRaw = HashMap<Int, String>()
    private var dbc: Dbc? = null
    private val lastVitalsAt = AtomicLong(0L)
    private const val VITALS_MIN_MS = 2000L

    val WATCH_IDS: Set<Int> = (
        listOf(
            0x00B, 0x014, 0x080, 0x081, 0x083, 0x11C, 0x120, 0x121, 0x130, 0x143,
            0x180, 0x190, 0x213, 0x411, 0x62D, 0x640, 0x353, 0x543, 0x553, 0x563,
        ) + (0x500..0x510) + (0x530..0x536) + (0x580..0x587)
        ).toSet()

    fun bindDbc(d: Dbc) { dbc = d }

    fun isActive(): Boolean = active.get()
    fun currentDisplayPath(): String? = sink?.displayPath
    fun currentFileName(): String? = sink?.name
    fun frameCount(): Int = frames

    @Synchronized
    fun start(ctx: Context): LogSink {
        stop()
        val name = "charge_session_${fmt.format(Date())}.jsonl"
        val s = LogStorage.openChargeFile(ctx, name)
        sink = s
        frames = 0
        vitalsWrites = 0
        startedAt = System.currentTimeMillis()
        lastRaw.clear()
        lastVitalsAt.set(0L)
        write(
            JSONObject()
                .put("event", "session_start")
                .put("t", startedAt / 1000.0)
                .put("note", "Vehicle-CAN sniff via Wi-Fi. Auth/FC on ch_can may be absent.")
                .put("dir", LogStorage.chargeLabel(ctx))
                .put("watch_ids", WATCH_IDS.sorted().joinToString(",") { "%03X".format(it) })
        )
        active.set(true)
        AutoLog.log(AutoLog.Cat.CHARGE, "session start → ${s.displayPath}")
        return s
    }

    @Synchronized
    fun stop(): LogSink? {
        if (!active.getAndSet(false)) return sink
        val s = sink
        write(
            JSONObject()
                .put("event", "session_stop")
                .put("t", System.currentTimeMillis() / 1000.0)
                .put("frames", frames)
                .put("vitals", vitalsWrites)
                .put("duration_s", (System.currentTimeMillis() - startedAt) / 1000.0)
        )
        AutoLog.log(
            AutoLog.Cat.CHARGE,
            "session stop → ${s?.displayPath} frames=$frames vitals=$vitalsWrites",
        )
        return s
    }

    fun onFrame(canId: Int, data: ByteArray) {
        if (!active.get() || canId !in WATCH_IDS) return
        val hex = data.joinToString("") { "%02X".format(it) }
        synchronized(this) {
            if (lastRaw[canId] == hex) return
            lastRaw[canId] = hex
            frames++
            val obj = JSONObject()
                .put("t", System.currentTimeMillis() / 1000.0)
                .put("id", "%03X".format(canId))
                .put("data", hex.lowercase())
            val signals = decodeSignals(canId, data)
            if (signals != null) obj.put("signals", signals)
            write(obj)
        }
    }

    fun onVitals(fields: Map<String, Any?>) {
        if (!active.get()) return
        val now = System.currentTimeMillis()
        val prev = lastVitalsAt.get()
        if (now - prev < VITALS_MIN_MS) return
        if (!lastVitalsAt.compareAndSet(prev, now)) return
        val obj = JSONObject().put("event", "vitals").put("t", now / 1000.0)
        for ((k, v) in fields) {
            when (v) {
                null -> {}
                is Number -> obj.put(k, v)
                is Boolean -> obj.put(k, v)
                else -> obj.put(k, v.toString())
            }
        }
        synchronized(this) {
            vitalsWrites++
            write(obj)
        }
    }

    private fun decodeSignals(canId: Int, data: ByteArray): JSONObject? {
        val d = dbc ?: return null
        val vals = d.decode(canId, data)
        if (vals.isEmpty()) return null
        val o = JSONObject()
        for (s in vals) {
            val n = s.name
            if (n.contains("spare", true) || n.contains("reserved", true)) continue
            o.put(n, s.value)
        }
        return if (o.length() == 0) null else o
    }

    private fun write(obj: JSONObject) {
        try {
            sink?.append(obj.toString() + "\n")
        } catch (_: Exception) {
        }
    }
}
