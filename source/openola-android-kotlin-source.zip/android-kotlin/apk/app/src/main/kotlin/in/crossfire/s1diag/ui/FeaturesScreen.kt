package `in`.crossfire.s1diag.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.data.MoveOs5
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.DiagViewModel

@Composable
fun FeaturesScreen(vm: DiagViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var pending by remember { mutableStateOf<Triple<Int, String, Boolean>?>(null) } // ordinal,label,danger

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            SectionCard("Features enabled (0x660)") {
                if (ui.featuresBool.isEmpty() && ui.featuresTp.isEmpty()) {
                    Text("Waiting for 0x660 broadcast…", color = TextMut)
                } else {
                    FlowChips(ui.featuresBool.map { it.first to it.second })
                    if (ui.featuresTp.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Tech packs (0 = not entitled)", color = TextMut,
                            style = MaterialTheme.typography.labelMedium)
                        for ((name, v) in ui.featuresTp) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name, color = if (v > 0) TextHi else TextMut,
                                    style = MaterialTheme.typography.bodyMedium)
                                Text("$v", color = if (v > 0) Accent else TextMut,
                                    fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Text("Read-only entitlement flags. A toggle below only takes if the feature " +
                        "is entitled here; otherwise watch Status → notifications for UPGRADE_/N-A.",
                        color = TextMut, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            SectionCard("Feature toggles (0x6BC)") {
                Text("One-shot CommandFromHMI. Unverified on MoveOS 5 — needs Service mode & the " +
                    "parked checkbox. Check the scooter after each.", color = TextMut,
                    style = MaterialTheme.typography.bodySmall)
                for (t in MoveOs5.FEATURE_TOGGLES) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(t.label, color = TextHi, modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium)
                        OutlinedButton(onClick = { pending = Triple(t.enable, "${t.label} enable", false) }) {
                            Text("On", color = Accent)
                        }
                        Spacer(Modifier.width(6.dp))
                        OutlinedButton(onClick = { pending = Triple(t.disable, "${t.label} disable", false) }) {
                            Text("Off", color = TextMut)
                        }
                    }
                }
            }
        }
        item {
            SectionCard("Regen type") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for ((name, ord) in MoveOs5.REGEN_TYPES) {
                        OutlinedButton(
                            onClick = { pending = Triple(ord, "Regen: $name", false) },
                            modifier = Modifier.weight(1f),
                        ) { Text(name) }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }

    pending?.let { (ord, label, _) ->
        ConfirmWithTimer(
            title = "Send \"$label\"?",
            message = "CommandFromHMI 0x6BC #$ord. Unverified — one-shot, no retry. " +
                "Verify on the scooter afterward.",
            confirmLabel = "Send",
            onConfirm = { vm.sendHmiCommand(ord, label); pending = null },
            onDismiss = { pending = null },
        )
    }
}

@Composable
private fun FlowChips(items: List<Pair<String, Boolean>>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                for ((name, on) in row) {
                    Surface(
                        color = if (on) Accent.copy(alpha = 0.16f) else Surface2,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (on) Accent else Line),
                        modifier = Modifier.weight(1f),
                    ) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                            Text(if (on) "● " else "○ ", color = if (on) Accent else TextMut)
                            Text(name, color = if (on) TextHi else TextMut,
                                style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                repeat(2 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
