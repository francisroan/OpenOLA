package `in`.crossfire.s1diag.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.crossfire.s1diag.uds.Ecu
import `in`.crossfire.s1diag.uds.Fault
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.Conn
import `in`.crossfire.s1diag.vm.DiagViewModel

@Composable
fun FaultsScreen(vm: DiagViewModel, allowActions: Boolean = false) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var ecuName by rememberSaveable { mutableStateOf("BMS") }
    val ecu = Ecu.valueOf(ecuName)
    var confirm by remember { mutableStateOf<String?>(null) }
    val ready = ui.conn == Conn.CONNECTED && !ui.busy && (ui.demo || (ui.bench && ui.mode == "SERVICE"))
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageHeading("Understand faults", "Stored trouble codes and live fault flags.") }
        item {
            SectionCard("Diagnostic scan") {
                Text(if (ui.conn != Conn.CONNECTED) "Connect to your scooter to read stored faults." else if (!ui.demo && !ready) "Park the scooter, disconnect the charger and confirm the Service prerequisite above to scan." else "Read the battery, vehicle and motor controllers.", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                Button(onClick = vm::scanAll, enabled = ready, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                    Icon(Icons.Outlined.Search, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
                    Text(if (ui.busy) "Operation in progress…" else "Scan all controllers")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Ecu.values().forEach { e ->
                        val codes = ui.faults[e]
                        MetricTile(e.name, codes?.let { "${it.size} codes" } ?: "Not scanned", Modifier.weight(1f))
                    }
                }
                Text("A result of zero codes means this read returned none. It is not a complete battery health assessment.", color = TextMut, style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("Stored codes") {
                EcuSelector(ecuName) { ecuName = it }
                Text(when (ecu) { Ecu.BMS -> "BMS · Battery management system"; Ecu.VCU -> "VCU · Vehicle control unit"; else -> "MCU · Motor controller" }, color = TextMut, style = MaterialTheme.typography.bodyMedium)
                OutlinedButton(onClick = { vm.readFaults(ecu) }, enabled = ready, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Read ${ecu.name} codes") }
                Text("Latest completed read in this app session. Scan time is not supplied by the current backend.", color = TextMut, style = MaterialTheme.typography.bodySmall)
            }
        }
        val faults = ui.faults[ecu]
        when {
            faults == null -> item { SectionCard { Text("Not scanned yet", style = MaterialTheme.typography.titleMedium); Text("Run a scan or read this controller.", color = TextMut) } }
            faults.isEmpty() -> item { SectionCard { Text("No stored codes returned", color = Ok, style = MaterialTheme.typography.titleMedium); Text("This result applies to ${ecu.name} and this read only.", color = TextMut) } }
            else -> items(faults, key = { "${it.code}:${it.status}" }) { FaultCard(it) }
        }
        if (ui.activeFaults.isNotEmpty()) item {
            SectionCard("Broadcast fault flags") {
                ui.activeFaults.forEach { Text(it, color = Danger, style = MaterialTheme.typography.bodyMedium) }
                Text("These broadcast flags are separate from stored UDS trouble codes.", color = TextMut, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (allowActions) item {
            SectionCard("Service actions") {
                Text("Export a report before clearing fault history. ECU restart does not establish deep-sleep BMS recovery.", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { confirm = "clear" }, enabled = ready, modifier = Modifier.weight(1f)) { Text("Clear codes", color = Danger) }
                    OutlinedButton(onClick = { confirm = "reset" }, enabled = ready, modifier = Modifier.weight(1f)) { Text("Restart ECU", color = Danger) }
                }
                OutlinedButton(onClick = { confirm = "recover" }, enabled = ready, modifier = Modifier.fillMaxWidth()) { Text("Existing fault recovery", color = Warn) }
                OutlinedButton(onClick = { confirm = "restart" }, enabled = ready, modifier = Modifier.fillMaxWidth()) { Text("Restart head unit · unverified", color = Danger) }
            }
        }
    }
    confirm?.let { kind ->
        val title = when (kind) { "clear" -> "Clear ${ecu.name} fault history?"; "reset" -> "Restart ${ecu.name}?"; "restart" -> "Restart head unit?"; else -> "Run existing fault recovery?" }
        val message = when (kind) {
            "clear" -> "Erases stored trouble codes on ${ecu.name}. Export a report first; history will be lost."
            "reset" -> "Sends the existing hard ECU reset (11 01) to ${ecu.name}. Deep-sleep BMS wake has not been validated."
            "restart" -> "Unverified head-unit reboot command. The connection may drop. Keep the scooter parked and reconnect after it restarts."
            else -> "Enters Service, clears and restarts the faulting ECUs (or VCU if none), then returns to Customer mode. This is not a validated deep-sleep BMS wake procedure."
        }
        ConfirmWithTimer(title, message, "Confirm", seconds = if (kind == "restart") 4 else 3,
            onConfirm = { when (kind) { "clear" -> vm.clearFaults(ecu); "reset" -> vm.ecuReset(ecu); "restart" -> vm.restartHeadUnit(); else -> vm.recover() }; confirm = null },
            onDismiss = { confirm = null })
    }
}
@Composable
private fun FaultCard(f: Fault) {
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(f.code, color = Danger, fontFamily = Mono, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.weight(1f))
            Text(if (f.known) "Catalog match" else "Unknown code", color = TextMut, style = MaterialTheme.typography.labelMedium)
        }
        Text(f.description, style = MaterialTheme.typography.bodyLarge, color = TextHi)
        Text(f.statusFlags.joinToString(" · ") { friendlyFaultFlag(it) }.ifBlank { "No decoded status flags" }, style = MaterialTheme.typography.bodyMedium, color = TextMut)
        Text("Status byte: %02X".format(f.status), color = TextMut, style = MaterialTheme.typography.bodySmall, fontFamily = Mono)
        Text("A code describes a detected condition; it does not identify the failed component by itself.", style = MaterialTheme.typography.bodySmall, color = TextMut)
    }
}
fun friendlyFaultFlag(flag: String): String = when (flag) {
    "testFailed" -> "Test failed"
    "testFailedThisOperationCycle" -> "Failed in this cycle"
    "pendingDTC" -> "Pending"
    "confirmedDTC" -> "Confirmed"
    "testNotCompletedSinceLastClear" -> "Test not completed since clearing"
    "testFailedSinceLastClear" -> "Failed since clearing"
    "testNotCompletedThisOperationCycle" -> "Test not completed this cycle"
    "warningIndicatorRequested" -> "Warning requested"
    else -> flag
}
