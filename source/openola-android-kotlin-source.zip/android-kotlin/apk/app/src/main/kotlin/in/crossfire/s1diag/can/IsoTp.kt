package `in`.crossfire.s1diag.can

/**
 * ISO-TP (ISO 15765-2) framing over the 8-byte CAN data field.
 * Ported from the verified Python (oladiag/isotp.py).
 */
object IsoTp {
    const val SINGLE = 0x0
    const val FIRST = 0x1
    const val CONSECUTIVE = 0x2
    const val FLOW = 0x3

    /** Flow control the app sends: 30 00 14 (CTS, block size 0, STmin 0x14). */
    val FLOW_CONTROL = byteArrayOf(0x30, 0x00, 0x14, 0, 0, 0, 0, 0)

    fun frameType(data8: ByteArray): Int = (data8[0].toInt() ushr 4) and 0xF

    fun encodeSingle(payload: ByteArray): ByteArray {
        require(payload.size <= 7) { "payload too long for single frame" }
        val out = ByteArray(8)
        out[0] = payload.size.toByte()
        System.arraycopy(payload, 0, out, 1, payload.size)
        return out
    }
}

/**
 * Reassembles a UDS message from incoming 8-byte data fields.
 * feed() returns the full payload once complete, or null while in progress.
 */
class IsoTpReassembler {
    private var buf = ByteArray(0)
    private var expected = 0
    private var active = false

    val waitingForMore: Boolean get() = active

    fun feed(data8: ByteArray): ByteArray? {
        if (data8.isEmpty()) return null
        when (IsoTp.frameType(data8)) {
            IsoTp.SINGLE -> {
                val len = data8[0].toInt() and 0x0F
                return data8.copyOfRange(1, 1 + len)
            }
            IsoTp.FIRST -> {
                expected = ((data8[0].toInt() and 0x0F) shl 8) or (data8[1].toInt() and 0xFF)
                buf = data8.copyOfRange(2, 8)
                active = true
                return null // caller sends flow control, then keeps feeding
            }
            IsoTp.CONSECUTIVE -> {
                if (!active) return null
                buf += data8.copyOfRange(1, 8)
                if (buf.size >= expected) {
                    active = false
                    return buf.copyOfRange(0, expected)
                }
                return null
            }
            else -> return null // flow control / unknown
        }
    }
}
