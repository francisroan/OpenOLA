package `in`.crossfire.s1diag.data

import android.content.Context
import `in`.crossfire.s1diag.uds.Ecu
import org.json.JSONArray
import org.json.JSONObject

/**
 * Data-driven capability catalog, loaded from the bundled ODX (assets/odx.json).
 *
 * Everything the UI offers — the 52 VCU actuator tests and every writable (2E)
 * parameter — comes from this file at runtime. To add/adjust a control or a
 * parameter you edit odx.json (or drop in a newer one); no Kotlin change needed.
 */

/** One VCU actuator test: 2F <did> 03 <state>. */
data class Actuator(val label: String, val did: Int, val group: String, val danger: Boolean)

/** One field inside a writable parameter. */
data class ParamField(
    val name: String,
    val unit: String,
    val min: Double?,
    val max: Double?,
    val resolution: Double,
    val offset: Double,
    val bits: Int,
    val startBit: Int,
    val dataType: String,
)

/** One writable configuration parameter: 2E <did> <bytes>. */
data class Setting(
    val ecu: Ecu,
    val did: Int,
    val name: String,
    val lengthBytes: Int,
    val fields: List<ParamField>,
    val danger: Boolean,
)

class Catalog private constructor(
    val actuators: List<Actuator>,
    val actuatorGroups: List<String>,
    val settings: List<Setting>,
) {
    fun actuatorsIn(group: String) = actuators.filter { it.group == group }
    fun settingsFor(ecu: Ecu) = settings.filter { it.ecu == ecu }

    companion object {
        // Preferred group order (safe first, danger last).
        val GROUP_ORDER = listOf(
            "Lights & signals", "Switches & sensors", "Locks & security",
            "System & module", "Power & HV",
        )
        private val DANGER_KW = listOf(
            "contactor", "steering lock", "seat lock", "cpw", "control pilot",
            "charger", "aux battery", "alarm", "brake supply", "brake suppy",
            "fault reset", "power key", "power boot", "ble module reset", "ble boot",
            "dc-dc", "dcdc", "3.8v", "3v3", "level shifter",
        )

        private fun cleanName(raw: String): String {
            var n = if (raw.startsWith("IO")) raw.substringAfter('_') else raw
            for (junk in listOf(
                " 12V supply control command", " supply control command", " supply command",
                " control command", " Control command", " 12V supply Control command",
                " command", " Command",
            )) if (n.endsWith(junk)) n = n.dropLast(junk.length)
            return n.trim()
        }

        private fun groupOf(name: String): String {
            val n = name.lowercase()
            fun has(vararg k: String) = k.any { n.contains(it) }
            return when {
                has("beam", "indicator", "light", "drl", "lamp", "horn") -> "Lights & signals"
                has("contactor", "cpw", "control pilot", "charger", "aux battery",
                    "dc-dc", "dcdc", "3.8v", "3v3", "level shifter") -> "Power & HV"
                has("lock", "alarm", "seat occupant") -> "Locks & security"
                has("switch", "sensor", "stand", "pad wear", "brake sup", "occupant", "ssb") -> "Switches & sensors"
                else -> "System & module"
            }
        }

        private fun didOf(rf: String): Int {
            val hex = rf.replace(" ", "")
            return hex.substring(2, 6).toInt(16)
        }

        private fun dOrNull(o: JSONObject, key: String): Double? =
            if (o.isNull(key)) null else o.optString(key).toDoubleOrNull()

        fun load(ctx: Context): Catalog {
            var text = ctx.assets.open("odx.json").bufferedReader().use { it.readText() }
            if (text.isNotEmpty() && text[0] == '\uFEFF') text = text.substring(1)
            val root = JSONObject(text)

            val actuators = ArrayList<Actuator>()
            val settings = ArrayList<Setting>()
            val seenAct = HashSet<String>()

            for (ecu in Ecu.values()) {
                val arr: JSONArray = root.optJSONArray(ecu.name) ?: continue
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    val rf = c.optString("RequestFormat").replace(" ", "").uppercase()
                    if (rf.length < 6) continue
                    when {
                        ecu == Ecu.VCU && rf.startsWith("2F") && c.optInt("ECUTest", 0) == 1 -> {
                            val label = cleanName(c.optString("Command"))
                            if (label.isEmpty() || !seenAct.add(label)) continue
                            val group = groupOf(label)
                            val danger = group == "Power & HV" || DANGER_KW.any { label.lowercase().contains(it) }
                            actuators.add(Actuator(label, didOf(rf), group, danger))
                        }
                        rf.startsWith("2E") -> {
                            val fields = ArrayList<ParamField>()
                            val ps = c.optJSONArray("Parameters")
                            if (ps != null) for (j in 0 until ps.length()) {
                                val p = ps.getJSONObject(j)
                                fields.add(
                                    ParamField(
                                        name = p.optString("Parameter").trim(),
                                        unit = if (p.isNull("Unit")) "" else p.optString("Unit"),
                                        min = dOrNull(p, "Physical Minimum"),
                                        max = dOrNull(p, "Physical Maximum"),
                                        resolution = dOrNull(p, "Resolution") ?: 1.0,
                                        offset = dOrNull(p, "Offset") ?: 0.0,
                                        bits = p.optString("Size (Bits)").toIntOrNull() ?: 0,
                                        startBit = p.optString("StartBit").toIntOrNull() ?: 0,
                                        dataType = p.optString("DataType"),
                                    )
                                )
                            }
                            val name = c.optString("Command")
                            val len = c.optInt("AttachedDatalength (Bytes)", 0)
                            val danger = ecu != Ecu.VCU  // all BMS/MCU config writes are risky
                            settings.add(Setting(ecu, didOf(rf), name, len, fields, danger))
                        }
                    }
                }
            }
            val groups = GROUP_ORDER.filter { g -> actuators.any { it.group == g } }
            return Catalog(actuators, groups, settings)
        }
    }
}
