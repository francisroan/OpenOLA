package `in`.crossfire.s1diag.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * Always-on activity log once a Wi-Fi session starts.
 *
 * Default folder: app `…/files/logs/`. Override via [LogStorage] (SAF folder pick).
 * Lines tagged [CMD]/FAULT]/LIVE]/CHARGE]/CONN]/CAL]/SYS] for grep.
 */
object AutoLog {
    enum class Cat { CMD, FAULT, LIVE, CHARGE, CONN, CAL, SYS }

    private val lineFmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)
    private val fileFmt = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
    private const val MAX_BYTES = 2_000_000L
    private const val TAIL = 500

    private var appCtx: Context? = null
    private var sink: LogSink? = null
    private var rotateName: String? = null
    private val tail = ArrayDeque<String>()
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines

    private val _sessionPath = MutableStateFlow<String?>(null)
    val sessionPath: StateFlow<String?> = _sessionPath

    fun init(ctx: Context) {
        if (appCtx == null) appCtx = ctx.applicationContext
    }

    fun logsDirectoryLabel(ctx: Context? = appCtx): String {
        val c = ctx ?: return "(logs)"
        return LogStorage.activityLabel(c)
    }
    fun currentSessionPath(): String? = _sessionPath.value

    /** Open a fresh activity file for this Wi-Fi connection. */
    @Synchronized
    fun beginSession(ctx: Context, host: String, note: String = "") {
        init(ctx)
        val name = "activity_${fileFmt.format(Date())}.log"
        rotateName = name
        sink = LogStorage.openActivityFile(ctx, name)
        _sessionPath.value = sink!!.displayPath
        log(Cat.CONN, "session start host=$host dir=${LogStorage.activityLabel(ctx)} ${note.trim()}".trim())
    }

    @Synchronized
    fun endSession(reason: String = "disconnect") {
        if (sink == null) return
        log(Cat.CONN, "session end ($reason)")
    }

    fun log(msg: String) = log(Cat.SYS, msg)

    @Synchronized
    fun log(cat: Cat, msg: String) {
        val line = "${lineFmt.format(Date())}  [${cat.name}]  $msg"
        try {
            sink?.let { s ->
                if (s.length() > MAX_BYTES) {
                    // Rotate: truncate current; keep writing same name in SAF/default.
                    try { s.truncate() } catch (_: Exception) {}
                    s.append("${lineFmt.format(Date())}  [SYS]  log rotated (size cap)\n")
                }
                s.append(line + "\n")
            }
        } catch (_: Exception) {
        }
        tail.addLast(line)
        while (tail.size > TAIL) tail.removeFirst()
        _lines.value = tail.toList()
    }

    @Synchronized
    fun exportText(): String {
        return try {
            val path = sink?.displayPath
            if (path != null && (path.startsWith("/") || path.contains(":\\"))) {
                val f = File(path)
                if (f.isFile) return f.readText().ifBlank { tail.joinToString("\n") }
            }
            tail.joinToString("\n")
        } catch (_: Exception) {
            tail.joinToString("\n")
        }
    }

    @Synchronized
    fun clear() {
        try { sink?.truncate() } catch (_: Exception) {}
        tail.clear()
        _lines.value = emptyList()
        log(Cat.SYS, "log cleared")
    }
}
