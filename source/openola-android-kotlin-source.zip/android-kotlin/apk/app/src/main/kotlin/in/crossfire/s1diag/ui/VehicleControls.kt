package `in`.crossfire.s1diag.ui

import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.material.icons.outlined.TwoWheeler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.R
import `in`.crossfire.s1diag.ui.theme.*

enum class ActionPhase { Idle, Pending, Success, Error }

fun View.olaHaptic(success: Boolean = true) {
    val code = if (android.os.Build.VERSION.SDK_INT >= 30) {
        if (success) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.REJECT
    } else {
        if (success) HapticFeedbackConstants.VIRTUAL_KEY else HapticFeedbackConstants.LONG_PRESS
    }
    performHapticFeedback(code)
}

@Composable
fun ScooterHero(
    locked: Boolean,
    modifier: Modifier = Modifier,
) {
    Box(modifier.fillMaxWidth().height(140.dp), contentAlignment = Alignment.Center) {
        androidx.compose.material3.Icon(
            androidx.compose.material.icons.Icons.Outlined.TwoWheeler,
            contentDescription = "Scooter",
            tint = Accent,
            modifier = Modifier.size(104.dp),
        )
    }
}

@Composable
fun VehicleStatusHeader(
    locked: Boolean?,
    vehicleName: String = "Scooter",
    modifier: Modifier = Modifier,
) {
    val known = locked != null
    val status = when (locked) {
        true -> "Locked"
        false -> "Unlocked"
        null -> "Awaiting status…"
    }
    Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$vehicleName is", style = MaterialTheme.typography.bodyLarge, color = TextMut)
        Spacer(Modifier.height(4.dp))
        Text(
            status,
            style = MaterialTheme.typography.headlineMedium,
            color = TextHi,
            fontWeight = FontWeight.Bold,
            fontStyle = FontStyle.Normal,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier
                .width(if (known) 168.dp else 96.dp)
                .height(4.dp)
                .clip(CircleShape)
                .background(
                    when (locked) {
                        false -> NeonBar
                        true -> AccentSoft
                        null -> Line
                    }
                ),
        )
    }
}

@Composable
fun RingActionButton(
    glyph: ControlGlyph,
    active: Boolean,
    phase: ActionPhase,
    caption: String? = null,
    size: Dp = 72.dp,
    enabled: Boolean = true,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val view = LocalView.current
    Column(
        modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .background(if (active) Accent.copy(alpha = 0.16f) else Surface2)
                .border(
                    width = 1.5.dp,
                    color = when (phase) {
                        ActionPhase.Error -> Danger
                        ActionPhase.Success -> Ok
                        ActionPhase.Pending -> Accent.copy(alpha = 0.55f)
                        else -> if (active) Accent else Line
                    },
                    shape = CircleShape,
                )
                .clickable(
                    enabled = enabled && phase != ActionPhase.Pending,
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() },
                ) {
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    onClick()
                },
            contentAlignment = Alignment.Center,
        ) {
            if (phase == ActionPhase.Pending) {
                GlassSpinner(modifier = Modifier.fillMaxSize().padding(3.dp), color = Accent)
            }
            ControlIcon(
                glyph = glyph,
                active = active || phase == ActionPhase.Success,
                size = size * 0.42f,
            )
        }
        if (caption != null) {
            Text(caption, color = TextMut, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun OlaControlCluster(
    locked: Boolean,
    soc: Int?,
    rangeHint: String?,
    trunkOpen: Boolean,
    lockPhase: ActionPhase,
    trunkPhase: ActionPhase,
    enabled: Boolean,
    onLockToggle: () -> Unit,
    onTrunk: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RingActionButton(
            glyph = ControlGlyph.Battery,
            active = soc != null,
            phase = ActionPhase.Idle,
            caption = when {
                rangeHint != null -> rangeHint
                soc != null -> "$soc%"
                else -> "—"
            },
            size = 64.dp,
            enabled = false,
            onClick = {},
        )
        RingActionButton(
            glyph = if (locked) ControlGlyph.Lock else ControlGlyph.Unlock,
            active = true,
            phase = lockPhase,
            caption = if (locked) "Locked" else "Unlocked",
            size = 88.dp,
            enabled = enabled,
            onClick = onLockToggle,
        )
        RingActionButton(
            glyph = ControlGlyph.Trunk,
            active = trunkOpen,
            phase = trunkPhase,
            caption = if (trunkOpen) "Open" else "Closed",
            size = 64.dp,
            enabled = enabled,
            onClick = onTrunk,
        )
    }
}
