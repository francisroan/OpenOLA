package `in`.crossfire.s1diag.net

import android.content.Context
import java.io.ByteArrayInputStream
import java.security.KeyFactory
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManagerFactory

/**
 * Builds the mTLS SSLSocketFactory from the certs bundled in assets/certs,
 * mirroring the app's GrpcManager.createSecureChannel:
 *   keyManager(ecos.crt, ecos.key), trustManager(ola_diag_root.crt),
 *   authority overridden to "ola.scooter.diag".
 *
 * ecos.key is an EC private key in PKCS#8 PEM.
 */
object TlsFactory {
    const val AUTHORITY = "ola.scooter.diag"

    fun socketFactory(ctx: Context): SSLSocketFactory {
        val cf = CertificateFactory.getInstance("X.509")
        val clientCert = ctx.assets.open("certs/ecos.crt").use {
            cf.generateCertificate(it) as X509Certificate
        }
        val caCert = ctx.assets.open("certs/ola_diag_root.crt").use {
            cf.generateCertificate(it) as X509Certificate
        }
        val keyDer = pemToDer(ctx.assets.open("certs/ecos.key").bufferedReader().use { it.readText() })
        val privateKey = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(keyDer))

        val clientStore = KeyStore.getInstance("PKCS12").apply {
            load(null, null)
            setKeyEntry("client", privateKey, CharArray(0), arrayOf(clientCert))
        }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply {
            init(clientStore, CharArray(0))
        }

        val trustStore = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
            load(null, null)
            setCertificateEntry("ca", caCert)
        }
        val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).apply {
            init(trustStore)
        }

        val sc = SSLContext.getInstance("TLS")
        sc.init(kmf.keyManagers, tmf.trustManagers, null)
        return sc.socketFactory
    }

    private fun pemToDer(pem: String): ByteArray {
        val body = pem
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replace("\\s".toRegex(), "")
        return android.util.Base64.decode(body, android.util.Base64.DEFAULT)
    }
}
