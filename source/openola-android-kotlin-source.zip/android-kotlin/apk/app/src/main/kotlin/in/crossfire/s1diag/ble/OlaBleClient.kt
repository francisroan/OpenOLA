package `in`.crossfire.s1diag.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.util.UUID

/**
 * Android GATT client for OLAS1 (own scooter).
 *
 * Desktop WinRT/Bleak work; APK "no seed reply" is an Android link issue:
 *  1. connect ≠ encrypted — TX/RX are encryption-required (Ola never createBond;
 *     stack bonds on first encrypted access). Seed writes can "succeed" while the
 *     module ignores unencrypted ATT.
 *  2. getRemoteDevice(MAC) without a fresh scan often yields a half-dead GATT on
 *     OEMs; Bleak always rediscovers by address first.
 *  3. Only one GATT op at a time — no priority/MTU races before CCCD.
 *  4. CCCD = NOTIFY 0100 (capture + props 0x30).
 *
 * Working vehicle checkpoint: apk/BLE_CHECKPOINT.md — revert to that path
 * if a “speed” change brings back no-seed-reply.
 */
@SuppressLint("MissingPermission")
class OlaBleClient(ctx: Context, private val mac: String) {

    companion object {
        fun serviceUuidFor(mac: String): UUID {
            val hex = mac.replace(":", "").replace("-", "").lowercase()
            require(hex.length == 12) { "bad MAC $mac" }
            return UUID.fromString("6e400001-b5a3-f393-e0a9-$hex")
        }

        val RX: UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e")
        val TX: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        private const val TAG = "S1Diag/Ble"
    }

    private val appCtx = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var rx: BluetoothGattCharacteristic? = null
    private var tx: BluetoothGattCharacteristic? = null
    private var sessionKey: ByteArray? = null
    private var bonded = false
    private var cccdMode = "none"
    private var diag = Diag()

    private data class Diag(
        var notifyChunks: Int = 0,
        var notifyBytes: Int = 0,
        var frames: Int = 0,
        var lastWriteStatus: Int = -1,
        var lastCccdStatus: Int = -1,
        var encryptTouched: Boolean = false,
        var scanned: Boolean = false,
    )

    private val notifications = Channel<ByteArray>(Channel.UNLIMITED)
    private val rxBuf = ByteArrayOutputStream()

    @Volatile private var connGen = 0
    private var connected = CompletableDeferred<Boolean>()
    private var discovered = CompletableDeferred<Boolean>()
    private var disconnected = CompletableDeferred<Unit>()
    private var written = CompletableDeferred<Boolean>()
    private var cccdWritten = CompletableDeferred<Boolean>()
    private var readDone = CompletableDeferred<Boolean>()
    @Volatile private var modernNotify = false
    @Volatile private var activeGen = 0
    @Volatile private var linkUp = false
    private var lastCmdDoneAt = 0L

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (g !== gatt) return
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    linkUp = status == BluetoothGatt.GATT_SUCCESS
                    if (!connected.isCompleted) {
                        connected.complete(status == BluetoothGatt.GATT_SUCCESS)
                    }
                    if (status == BluetoothGatt.GATT_SUCCESS) {
                        val settle = if (bonded) 300L else 150L
                        val gen = activeGen
                        main.postDelayed({
                            if (gen != activeGen || gatt !== g) return@postDelayed
                            try { g.discoverServices() } catch (_: Exception) {}
                        }, settle)
                    }
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    logw("GATT disconnected st=$status")
                    linkUp = false
                    if (!connected.isCompleted) connected.complete(false)
                    if (!discovered.isCompleted) discovered.complete(false)
                    if (!written.isCompleted) written.complete(false)
                    if (!disconnected.isCompleted) disconnected.complete(Unit)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (g !== gatt) return
            resolveChars(g)
            val ok = status == BluetoothGatt.GATT_SUCCESS && rx != null && tx != null
            if (!ok && status == BluetoothGatt.GATT_SUCCESS) {
                val gen = activeGen
                main.postDelayed({
                    if (gen != activeGen || gatt !== g) return@postDelayed
                    try { g.discoverServices() } catch (_: Exception) {}
                }, 500)
                return
            }
            if (!discovered.isCompleted) discovered.complete(ok)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (g !== gatt) return
            diag.lastWriteStatus = status
            if (!written.isCompleted) written.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            if (g !== gatt) return
            diag.lastCccdStatus = status
            if (!cccdWritten.isCompleted) cccdWritten.complete(status == BluetoothGatt.GATT_SUCCESS)
            if (!readDone.isCompleted && d.uuid == CCCD) {
                // some stacks complete a prior read via this path; ignore
            }
        }

        override fun onDescriptorRead(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            if (g !== gatt) return
            if (!readDone.isCompleted) readDone.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        override fun onDescriptorRead(
            g: BluetoothGatt,
            d: BluetoothGattDescriptor,
            status: Int,
            value: ByteArray,
        ) {
            onDescriptorRead(g, d, status)
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (g !== gatt) return
            if (!readDone.isCompleted) readDone.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            c: BluetoothGattCharacteristic,
            value: ByteArray,
            status: Int,
        ) {
            onCharacteristicRead(g, c, status)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            if (g !== gatt) return
            modernNotify = true
            logi("notify33 ${c.uuid} ${value.size}b ${value.joinToString("") { "%02X".format(it) }}")
            if (c.uuid == RX || c === rx) ingestNotify(value)
        }

        @Deprecated("legacy")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (g !== gatt) return
            if (modernNotify) return
            @Suppress("DEPRECATION")
            val value = c.value ?: return
            logi("notify18 ${c.uuid} ${value.size}b ${value.joinToString("") { "%02X".format(it) }}")
            if (c.uuid == RX || c === rx) ingestNotify(value)
        }
    }

    private fun resolveChars(g: BluetoothGatt) {
        val wantSvc = serviceUuidFor(mac)
        var svc = g.getService(wantSvc)
        if (svc == null) {
            svc = g.services?.firstOrNull { s ->
                val u = s.uuid.toString().lowercase()
                u.startsWith("6e400001-") || u.contains(mac.replace(":", "").lowercase())
            }
        }
        rx = svc?.getCharacteristic(RX)
        tx = svc?.getCharacteristic(TX)
        if (rx == null || tx == null) {
            val chars = svc?.characteristics ?: emptyList()
            if (rx == null) {
                rx = chars.firstOrNull {
                    val p = it.properties
                    (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                        (p and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0
                }
            }
            if (tx == null) {
                tx = chars.firstOrNull {
                    val p = it.properties
                    (p and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ||
                        (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                }
            }
        }
    }

    private fun ingestNotify(chunk: ByteArray) {
        if (chunk.isEmpty()) return
        diag.notifyChunks++
        diag.notifyBytes += chunk.size
        synchronized(rxBuf) {
            rxBuf.write(chunk)
            while (true) {
                val buf = rxBuf.toByteArray()
                if (buf.isEmpty()) break
                var start = 0
                while (start < buf.size && buf[start] == 0.toByte()) start++
                if (start > 0) {
                    rxBuf.reset()
                    if (start < buf.size) rxBuf.write(buf, start, buf.size - start)
                    continue
                }
                val total = (buf[0].toInt() and 0xFF) + 1
                if (total < 11 || total > 64) {
                    rxBuf.reset()
                    if (buf.size > 1) rxBuf.write(buf, 1, buf.size - 1)
                    continue
                }
                if (buf.size < total) break
                val frame = buf.copyOfRange(0, total)
                rxBuf.reset()
                if (buf.size > total) rxBuf.write(buf, total, buf.size - total)
                diag.frames++
                notifications.trySend(frame)
                BleStatus.peek(frame)   // battery/range glance (peek only, no channel consume)
            }
        }
    }

    private suspend fun <T> onMain(block: () -> T): T =
        if (Looper.myLooper() == Looper.getMainLooper()) block()
        else withContext(Dispatchers.Main.immediate) { block() }

    /** GATT start APIs return Boolean pre-33 and Int (BluetoothStatusCodes) on 33+. */
    @Suppress("DEPRECATION")
    private fun gattOpStarted(result: Any?): Boolean = when (result) {
        is Boolean -> result
        is Int -> result == BluetoothGatt.GATT_SUCCESS || result == 0
        else -> false
    }

    /** Bleak-equivalent: refresh the controller cache before connectGatt. */
    private suspend fun scanForDevice(adapter: BluetoothAdapter, address: String, timeoutMs: Long): BluetoothDevice {
        val want = address.trim().uppercase()
        val cached = adapter.getRemoteDevice(want)
        if (timeoutMs <= 0L) return cached
        val scanner = adapter.bluetoothLeScanner ?: return cached

        val hit = CompletableDeferred<BluetoothDevice?>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val d = result.device ?: return
                if (d.address.equals(want, ignoreCase = true) && !hit.isCompleted) {
                    hit.complete(d)
                }
            }
        }
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        try {
            scanner.startScan(null, settings, cb)
            val found = withTimeoutOrNull(timeoutMs) { hit.await() }
            diag.scanned = found != null
            return found ?: cached
        } finally {
            try { scanner.stopScan(cb) } catch (_: Exception) {}
        }
    }

    private suspend fun ensureBonded(device: BluetoothDevice) {
        if (device.bondState == BluetoothDevice.BOND_BONDED) {
            bonded = true
            return
        }
        // Prefer Ola's model: do not createBond() up-front. Encryption-required
        // access during CCCD/read will trigger Just Works. We only force-bond if
        // still unbonded after the first failed encrypt touch (see authenticate).
        bonded = false
    }

    private suspend fun createBondNow(device: BluetoothDevice) {
        if (device.bondState == BluetoothDevice.BOND_BONDED) {
            bonded = true
            return
        }
        val done = CompletableDeferred<Boolean>()
        val filter = IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                if (intent == null) return
                val d = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                } ?: return
                if (!d.address.equals(device.address, ignoreCase = true)) return
                when (intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE)) {
                    BluetoothDevice.BOND_BONDED -> if (!done.isCompleted) done.complete(true)
                    BluetoothDevice.BOND_NONE -> if (!done.isCompleted) done.complete(false)
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 33) {
            appCtx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            appCtx.registerReceiver(receiver, filter)
        }
        try {
            val started = onMain { device.createBond() }
            if (!started) throw IllegalStateException("createBond refused")
            withTimeout(45_000) { check(done.await()) { "bonding failed / cancelled" } }
            bonded = true
            delay(1_200)
        } finally {
            try { appCtx.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    private suspend fun closeGattAndWait(timeoutMs: Long = 700) {
        val g = gatt ?: return
        val alreadyDown = !linkUp
        if (!alreadyDown) {
            disconnected = CompletableDeferred()
            onMain {
                try { g.disconnect() } catch (_: Exception) {}
            }
            withTimeoutOrNull(timeoutMs) { disconnected.await() }
        }
        onMain {
            try { g.close() } catch (_: Exception) {}
        }
        if (gatt === g) gatt = null
        rx = null
        tx = null
        linkUp = false
        delay(if (alreadyDown) 80 else 150)
    }

    fun isReady(): Boolean = linkUp && gatt != null && sessionKey != null

    // Route all BLE trace to both logcat and the in-app BleLog (exportable).
    private fun logi(m: String) { android.util.Log.i(TAG, m); BleLog.add(m) }
    private fun logw(m: String) { android.util.Log.w(TAG, m); BleLog.add("WARN $m") }

    private suspend fun openGatt(device: BluetoothDevice) {
        awaitCloseQuiet()
        activeGen = ++connGen
        connected = CompletableDeferred()
        discovered = CompletableDeferred()
        disconnected = CompletableDeferred()
        modernNotify = false
        linkUp = false
        cccdMode = "none"
        diag = Diag(scanned = diag.scanned)
        synchronized(rxBuf) { rxBuf.reset() }
        while (notifications.tryReceive().isSuccess) { }

        bonded = device.bondState == BluetoothDevice.BOND_BONDED

        // Same 4-arg connectGatt as the official Ola app. PHY+Handler overload
        // is a known no-callback path on ColorOS / OnePlus.
        val g = onMain {
            if (Build.VERSION.SDK_INT >= 23) {
                device.connectGatt(appCtx, false, cb, BluetoothDevice.TRANSPORT_LE)
            } else {
                @Suppress("DEPRECATION")
                device.connectGatt(appCtx, false, cb)
            }
        } ?: throw IllegalStateException("connectGatt returned null")
        gatt = g
        logi("connectGatt ${device.address} bonded=$bonded")

        withTimeout(20_000) {
            check(connected.await()) { "GATT connect failed (is another phone still connected?)" }
        }
        withTimeout(25_000) {
            check(discovered.await()) { "Ola BLE service not found after connect" }
        }
        check(rx != null && tx != null) { "RX/TX characteristics missing" }
        logi("chars rx=${rx?.uuid} tx=${tx?.uuid} rxProps=0x${rx!!.properties.toString(16)} txProps=0x${tx!!.properties.toString(16)}")

        enableCccd(g)
    }

    private suspend fun enableCccd(g: BluetoothGatt) {
        val r = rx ?: throw IllegalStateException("RX missing")
        val props = r.properties
        val canNotify = (props and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
        val value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        cccdMode = "notify(props=0x${props.toString(16)},canNotify=$canNotify)"

        // Android docs order: local subscribe, then CCCD 0100 (capture).
        onMain { g.setCharacteristicNotification(r, true) }
        delay(50)
        cccdWritten = CompletableDeferred()
        onMain {
            val cccd = r.getDescriptor(CCCD)
                ?: r.descriptors?.firstOrNull()
                ?: throw IllegalStateException("CCCD missing")
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeDescriptor(cccd, value)
            } else {
                @Suppress("DEPRECATION")
                cccd.value = value
                @Suppress("DEPRECATION")
                g.writeDescriptor(cccd)
            }
        }
        withTimeout(10_000) { check(cccdWritten.await()) { "enable $cccdMode failed (st=${diag.lastCccdStatus})" } }
        logi("CCCD $cccdMode st=${diag.lastCccdStatus}")
        delay(250)
    }

    private suspend fun awaitCloseQuiet() {
        try { closeGattAndWait() } catch (_: Exception) {}
    }

    suspend fun connect(scanFirst: Boolean = true) {
        diag = Diag()
        val adapter = (appCtx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            ?: throw IllegalStateException("Bluetooth adapter unavailable")
        check(adapter.isEnabled) { "Bluetooth is off" }

        // ColorOS: a classic discovery in progress starves LE connect — cancel it first.
        try { onMain { adapter.cancelDiscovery() } } catch (_: Exception) {}

        // ColorOS: connect without a fresh scan often yields GATT with no notifies.
        val device = scanForDevice(adapter, mac, if (scanFirst) 4_000L else 1_200L)
        ensureBonded(device)

        var last: Exception? = null
        repeat(4) { attempt ->
            try {
                if (attempt > 0) delay(700)
                if (attempt == 1 && device.bondState != BluetoothDevice.BOND_BONDED) {
                    createBondNow(device)
                    awaitCloseQuiet()
                }
                openGatt(device)
                return
            } catch (e: Exception) {
                last = e
                awaitCloseQuiet()
            }
        }
        throw last ?: IllegalStateException("connect failed")
    }

    private suspend fun write(frame: ByteArray, noResponse: Boolean = false) {
        if (!linkUp) throw IllegalStateException("link dropped")
        val g = gatt ?: throw IllegalStateException("not connected")
        val c = tx ?: throw IllegalStateException("TX missing")
        val wType = if (noResponse) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        var i = 0
        while (i < frame.size) {
            val chunk = frame.copyOfRange(i, minOf(i + 20, frame.size))
            written = CompletableDeferred()
            val accepted = onMain {
                if (Build.VERSION.SDK_INT >= 33) {
                    gattOpStarted(g.writeCharacteristic(c, chunk, wType))
                } else {
                    @Suppress("DEPRECATION")
                    c.writeType = wType
                    @Suppress("DEPRECATION")
                    c.value = chunk
                    @Suppress("DEPRECATION")
                    gattOpStarted(g.writeCharacteristic(c))
                }
            }
            if (!accepted) throw IllegalStateException("GATT write rejected")
            if (noResponse) {
                delay(40)
                if (!written.isCompleted) written.complete(true)
            } else {
                withTimeout(8_000) { check(written.await()) { "GATT write failed (st=${diag.lastWriteStatus})" } }
            }
            logi("write ${chunk.size}b st=${diag.lastWriteStatus} noResp=$noResponse")
            delay(20)
            i += 20
        }
    }

    private suspend fun awaitType(want: Int, timeoutMs: Long): ByteArray? =
        withTimeoutOrNull(timeoutMs) {
            while (true) {
                val b = notifications.receive()
                if (OlaBleProto.frameType(b) == want) return@withTimeoutOrNull OlaBleProto.frameData(b)
            }
            @Suppress("UNREACHABLE_CODE") null
        }

    private fun diagSummary(): String =
        "cccd=$cccdMode scan=${diag.scanned} enc=${diag.encryptTouched} " +
            "notify=${diag.notifyChunks}/${diag.notifyBytes}B frames=${diag.frames} " +
            "wSt=${diag.lastWriteStatus} cSt=${diag.lastCccdStatus} bond=$bonded"

    suspend fun authenticate(): Boolean {
        var seedData: ByteArray? = null
        repeat(4) { attempt ->
            synchronized(rxBuf) { rxBuf.reset() }
            while (notifications.tryReceive().isSuccess) { }
            val frame = OlaBleProto.buildPlain(OlaBleProto.SEED_REQUEST)
            logi("SEED_REQUEST attempt=$attempt ${frame.joinToString("") { "%02X".format(it) }}")
            write(frame, noResponse = attempt == 1)
            seedData = awaitType(OlaBleProto.SEED_REPLY, 5_000)
            if (seedData != null && seedData!!.size >= 8) return@repeat
            logw("no seed yet ${diagSummary()}")
            if (attempt == 0 || attempt == 2) {
                val g = gatt ?: return@repeat
                try { enableCccd(g) } catch (_: Exception) {}
            }
        }
        val seed = (seedData ?: throw IllegalStateException(
            "no seed reply — ${diagSummary()}. Force-stop Ola app and close the PC GUI, then retry Pair & auth."
        )).copyOf(8)
        logi("seed ${String(seed, Charsets.US_ASCII)}")
        val key = OlaBleProto.generateKey(seed, "01")
        sessionKey = OlaBleProto.sessionKey(seed, key)
        write(OlaBleProto.buildPlain(OlaBleProto.SEED_KEY, key))
        val ack = awaitType(OlaBleProto.KEY_ACK, 5_000)
            ?: throw IllegalStateException("no key ack — ${diagSummary()}")
        if (ack.isEmpty() || (ack[0].toInt() and 0xFF) != 1) {
            throw IllegalStateException("not authorized (ack=${ack.joinToString(" ") { "%02X".format(it) }})")
        }
        write(OlaBleProto.buildEncrypted(sessionKey!!, OlaBleProto.TEST_AES, OlaBleProto.TEST_AES_DATA))
        if (awaitType(0x72, 800) == null) delay(150)
        return true
    }

    suspend fun command(value: Int) {
        if (!isReady()) throw IllegalStateException("link not ready")
        val k = sessionKey ?: throw IllegalStateException("authenticate first")
        val gap = lastCmdDoneAt + 80L - System.currentTimeMillis()
        if (gap > 0) delay(gap)
        logi("DIRECT_COMMAND $value")
        write(OlaBleProto.buildEncrypted(k, OlaBleProto.DIRECT_COMMAND, byteArrayOf(value.toByte())))
        lastCmdDoneAt = System.currentTimeMillis()
        delay(300)
    }

    /**
     * Idle liveness (BLE_CHECKPOINT.md change #1). Official TEST_AES / D_ALIVE.
     * Missing 0x72 means ColorOS is still “connected” but the module is gone.
     */
    suspend fun keepAlive() {
        if (!isReady()) throw IllegalStateException("link not ready")
        val k = sessionKey ?: throw IllegalStateException("authenticate first")
        write(OlaBleProto.buildEncrypted(k, OlaBleProto.TEST_AES, OlaBleProto.TEST_AES_DATA))
        // 700 ms: long enough that a slow-but-live module is not falsely flagged a zombie,
        // short enough that a real zombie (no reply at all) is caught quickly.
        if (awaitType(0x72, 700) == null) throw IllegalStateException("AES ping timeout")
    }

    suspend fun closeSuspend() {
        sessionKey = null
        awaitCloseQuiet()
    }

    fun close() {
        sessionKey = null
        val g = gatt
        gatt = null
        rx = null
        tx = null
        linkUp = false
        activeGen++
        if (g != null) {
            main.post {
                try { g.disconnect() } catch (_: Exception) {}
                main.postDelayed({
                    try { g.close() } catch (_: Exception) {}
                }, 250)
            }
        }
        synchronized(rxBuf) { rxBuf.reset() }
    }
}
