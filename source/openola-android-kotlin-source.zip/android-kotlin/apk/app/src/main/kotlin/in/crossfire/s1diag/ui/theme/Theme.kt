package `in`.crossfire.s1diag.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import `in`.crossfire.s1diag.ui.Appearance

@Immutable
data class OpenPalette(
    val background: Color, val surface: Color, val inset: Color, val raised: Color,
    val line: Color, val text: Color, val muted: Color, val accent: Color,
    val danger: Color, val warning: Color, val good: Color, val dark: Boolean,
)
private val Light = OpenPalette(
    Color(0xFFEEF1F7), Color.White.copy(alpha = .58f), Color(0xFF787880).copy(alpha = .10f), Color.White.copy(alpha = .78f),
    Color(0xFF3C3C43).copy(alpha = .14f), Color(0xFF1D1D1F), Color(0xFF3C3C43).copy(alpha = .76f), Color(0xFF007AFF),
    Color(0xFFCF2922), Color(0xFF925100), Color(0xFF248A3D), false,
)
private val Dark = OpenPalette(
    Color(0xFF07080C), Color(0xFF1E2028).copy(alpha = .52f), Color(0xFF787880).copy(alpha = .24f), Color(0xFF242630).copy(alpha = .82f),
    Color(0xFF545458).copy(alpha = .55f), Color(0xFFF5F5F7), Color(0xFFEBEBF5).copy(alpha = .72f), Color(0xFF0A84FF),
    Color(0xFFFF6B64), Color(0xFFFFB340), Color(0xFF30D158), true,
)
val LocalPalette = staticCompositionLocalOf { Light }
val LocalReduceMotion = staticCompositionLocalOf { false }
// Compatibility names keep every engineering screen on the same semantic palette.
val Ink: Color @Composable get() = LocalPalette.current.background
val InkLift: Color @Composable get() = LocalPalette.current.surface
val Surface1: Color @Composable get() = LocalPalette.current.surface
val Surface2: Color @Composable get() = LocalPalette.current.inset
val Surface3: Color @Composable get() = LocalPalette.current.raised
val Line: Color @Composable get() = LocalPalette.current.line
val TextHi: Color @Composable get() = LocalPalette.current.text
val TextMut: Color @Composable get() = LocalPalette.current.muted
val Accent: Color @Composable get() = LocalPalette.current.accent
val AccentSoft: Color @Composable get() = LocalPalette.current.accent
val AccentGlow: Color @Composable get() = LocalPalette.current.accent.copy(alpha = 0.12f)
val NeonBar: Color @Composable get() = LocalPalette.current.accent
val Danger: Color @Composable get() = LocalPalette.current.danger
val Warn: Color @Composable get() = LocalPalette.current.warning
val Ok: Color @Composable get() = LocalPalette.current.good
val IndicatorOrange: Color @Composable get() = LocalPalette.current.warning
val BeamBlue: Color @Composable get() = LocalPalette.current.accent
val HornPink: Color @Composable get() = LocalPalette.current.accent
val AppBgBrush: Brush @Composable get() = Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
val CardBrush: Brush @Composable get() = Brush.linearGradient(listOf(Surface1, Surface1))
val AccentBrush: Brush @Composable get() = Brush.horizontalGradient(listOf(Accent, Accent))
val ActiveGlowBrush: Brush @Composable get() = Brush.radialGradient(listOf(AccentGlow, Color.Transparent))
val HeroScrim: Brush @Composable get() = Brush.verticalGradient(listOf(Color.Transparent, Ink))
val Mono = FontFamily.Monospace
private val AppType = Typography(
    displayLarge = TextStyle(fontSize = 64.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-2).sp),
    displayMedium = TextStyle(fontSize = 48.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-1.5).sp),
    headlineLarge = TextStyle(fontSize = 32.sp, lineHeight = 38.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp),
    titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
)
@Composable
fun S1DiagTheme(appearance: Appearance = Appearance.SYSTEM, reduceMotion: Boolean = false, content: @Composable () -> Unit) {
    val dark = when (appearance) { Appearance.SYSTEM -> isSystemInDarkTheme(); Appearance.DARK -> true; Appearance.LIGHT -> false }
    val p = if (dark) Dark else Light
    val scheme = if (dark) darkColorScheme() else lightColorScheme()
    val colors = scheme.copy(
        primary = p.accent, onPrimary = Color.White,
        primaryContainer = p.accent.copy(alpha = 0.13f), onPrimaryContainer = p.accent,
        secondary = p.accent, secondaryContainer = p.inset, onSecondaryContainer = p.text,
        background = p.background, onBackground = p.text,
        surface = p.surface, onSurface = p.text, surfaceVariant = p.inset, onSurfaceVariant = p.muted,
        error = p.danger, onError = if (dark) Color(0xFF3B1015) else Color.White,
        outline = p.line, outlineVariant = p.line.copy(alpha = 0.65f), surfaceTint = Color.Transparent,
    )
    val view = LocalView.current
    if (!view.isInEditMode) SideEffect {
        (view.context as? Activity)?.window?.let { window ->
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    CompositionLocalProvider(LocalPalette provides p, LocalReduceMotion provides reduceMotion, LocalContentColor provides p.text) {
        MaterialTheme(colorScheme = colors, typography = AppType, shapes = Shapes(
            small = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
            medium = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
            large = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
        ), content = content)
    }
}
