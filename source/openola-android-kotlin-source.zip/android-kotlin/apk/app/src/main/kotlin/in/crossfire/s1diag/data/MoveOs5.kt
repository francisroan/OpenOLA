package `in`.crossfire.s1diag.data

/**
 * MoveOS 5 / S2 maps recovered from the decompiled head-unit apps
 * (see reverse_engineering/SYSTEM_APPS_MOVEOS5_FINDINGS.md and tool/moveos5_catalog.json).
 * Kept as plain data so the diagnostic UI can decode and act without the desktop tool.
 */
object MoveOs5 {

    // ---- 0x62D Charger_Connected (byte0 bits 0-1) — 4-state incl Boost ----
    val CHARGER_TYPE = mapOf(0 to "None", 1 to "Fast", 2 to "Slow", 3 to "Boost")

    // ---- 0x143 / 0x130 charging modes ----
    val CHARGING_MODE = mapOf(
        0 to "SNA", 1 to "Idle", 2 to "Safe", 3 to "Slow charge",
        4 to "Fast charge", 5 to "Discharge", 6 to "Boost charge",
    )

    // ---- 0x6BC CommandFromHMI feature toggles (label, enableOrdinal, disableOrdinal) ----
    data class Toggle(val label: String, val enable: Int, val disable: Int)
    val FEATURE_TOGGLES = listOf(
        Toggle("Boost mode", 48, 49),
        Toggle("Hill hold", 66, 67),
        Toggle("Vacation mode", 68, 69),
        Toggle("Proximity lock", 54, 55),
        Toggle("Motor cutoff delay", 64, 65),
        Toggle("Park assist", 103, 104),
        Toggle("Accident detection", 50, 51),
        Toggle("Tow/tamper detection", 52, 53),
        Toggle("Smart DRL", 56, 57),
        Toggle("Hazard feature", 60, 61),
    )
    // Regen type is 3-way (not enable/disable).
    val REGEN_TYPES = listOf("Default" to 41, "City" to 42, "Highway" to 43)
    const val CMD_STOP_CHARGE = 13
    const val CMD_TX_ID = 0x6BC
    const val CMD_ACK_ID = 0x6C0

    // ---- 0x660 feature-status bit map (byte, bit) booleans + (byte, lowBit) tech-packs ----
    data class Bit(val name: String, val byte: Int, val bit: Int)
    val FEATURE_BOOL = listOf(
        Bit("Boost mode", 0, 0), Bit("Fall detection", 0, 1), Bit("Tow/tamper", 0, 2),
        Bit("Proximity lock", 0, 3), Bit("Hill hold", 0, 4), Bit("Smart headlight", 0, 5),
        Bit("Smart DRL", 0, 6), Bit("Auto headlight", 0, 7),
        Bit("Hazard light", 1, 0), Bit("Auto-indicator off", 1, 1),
        Bit("Motor cutoff delay", 1, 2), Bit("Vacation mode", 1, 3),
    )
    val FEATURE_TP = listOf(   // 2-bit tech-pack entitlement fields
        Bit("Advanced regen", 1, 4), Bit("Fast charger", 1, 6),
        Bit("Hyper charger", 2, 0), Bit("Energy insights", 2, 2),
        Bit("Proximity L/U", 2, 4), Bit("Geo-fencing", 2, 6),
        Bit("Time-fencing", 3, 0), Bit("Mode-fencing", 3, 2),
        Bit("New upgrades", 3, 4), Bit("Tow protection", 4, 2),
    )

    // ---- 0x6D0 CommandFromVehicle notifications (byte0). Subset of the 217; the rest
    //      render as "code N". These are the high-value derate / mode / charge / access ones.
    val VEHICLE_NOTIF = mapOf(
        4 to "Derate: charge to ride", 6 to "Higher mode disabled",
        11 to "SoC 3% warning", 12 to "SoC 3%", 16 to "SoC 15% warning", 31 to "SoC 15%",
        32 to "SoC 20% warning", 33 to "SoC 20%", 34 to "General low battery",
        23 to "Trunk open", 24 to "Trunk closed", 25 to "Entering deep sleep",
        42 to "Charge not happening", 59 to "Close side stand to drive", 60 to "Side stand open",
        61 to "Apply side stand to lock", 62 to "Hold brake + SSB to drive",
        107 to "BMS grade-4 cutoff", 111 to "Charge complete — unplug", 112 to "Stop charge: over-temp",
        113 to "Normal mode available", 114 to "Fall detected", 115 to "Fall recovered",
        117 to "User calibration success", 118 to "User calibration fail",
        121 to "Charger permanent fault", 122 to "Charger temporary fault", 123 to "Charger power off",
        124 to "Charger latch not connected", 125 to "Ride access revoked — park in 30s",
        129 to "Hill-hold exit nudge", 130 to "Unplug charger to ride",
        131 to "Safe unplug hyper charger", 132 to "Initialising hyper charger", 133 to "Unplug hyper: fault",
        135 to "Entering vacation mode", 136 to "Exiting vacation mode",
        137 to "Release e-button to charge", 138 to "Access revoked — contact owner",
        139 to "Config mismatch", 140 to "Version mismatch", 141 to "Thermal runaway",
        142 to "Sports mode disabled: fault", 143 to "Sports mode disabled: SoC", 144 to "Sports mode disabled: temp",
        145 to "Geofence access revoked", 146 to "Parental: Sport revoked", 147 to "Parental: Hyper revoked",
        148 to "Parental access reset", 152 to "Accident detected", 159 to "Charging payment due",
        160 to "Side stand down warning", 176 to "Upgrade for boost charger", 177 to "Upgrade for fast charger",
        178 to "Upgrade for hill-hold", 179 to "Tech pack available", 199 to "Test ride",
        203 to "Hyper N/A (tech pack)", 204 to "Sport N/A (tech pack)", 205 to "Eco N/A (tech pack)",
        206 to "Reverse N/A (tech pack)", 207 to "Cruise N/A (tech pack)", 208 to "Charging N/A (tech pack)",
    )

    fun notifName(code: Int): String = VEHICLE_NOTIF[code] ?: "code $code"

    /** true = attention-worthy (red) notification. */
    fun notifAlert(code: Int): Boolean {
        val n = (VEHICLE_NOTIF[code] ?: "").lowercase()
        return listOf("derate", "disabled", "fault", "fail", "cutoff", "revoked", "runaway",
            "mismatch", "payment", "upgrade", "n/a", "stop charge", "not happening",
            "thermal", "accident").any { it in n }
    }
}
