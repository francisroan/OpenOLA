package `in`.crossfire.s1diag.uds

/** A decoded Diagnostic Trouble Code. */
data class Fault(
    val code: String,
    val description: String,
    val known: Boolean,
    val status: Int,
    val statusFlags: List<String>,
)

object Dtc {
    // statusOfDTC bit meanings (ISO 14229-1 Annex D)
    private val STATUS_BITS = listOf(
        0x01 to "testFailed",
        0x02 to "testFailedThisOperationCycle",
        0x04 to "pendingDTC",
        0x08 to "confirmedDTC",
        0x10 to "testNotCompletedSinceLastClear",
        0x20 to "testFailedSinceLastClear",
        0x40 to "testNotCompletedThisOperationCycle",
        0x80 to "warningIndicatorRequested",
    )

    fun decodeStatus(status: Int): List<String> =
        STATUS_BITS.filter { (bit, _) -> status and bit != 0 }.map { it.second }

    /**
     * payload: full UDS response starting at the service id (0x59 ...).
     * table: code(upper) -> description for this ECU.
     */
    fun parse(payload: ByteArray, table: Map<String, String>): List<Fault> {
        if (payload.isEmpty()) return emptyList()
        var body = payload
        if (payload.size >= 3 && payload[0].toInt() and 0xFF == 0x59 && payload[1].toInt() and 0xFF == 0x02) {
            body = payload.copyOfRange(3, payload.size)
        } else if (payload[0].toInt() and 0xFF == 0x59) {
            body = payload.copyOfRange(2, payload.size)
        }
        val faults = ArrayList<Fault>()
        var i = 0
        while (i + 4 <= body.size) {
            val code = buildString {
                for (j in 0 until 3) append("%02X".format(body[i + j].toInt() and 0xFF))
            }
            val status = body[i + 3].toInt() and 0xFF
            i += 4
            if (code == "000000") continue
            val desc = table[code]
            faults.add(
                Fault(
                    code = code,
                    description = desc ?: "Unknown code (not in bundled table)",
                    known = desc != null,
                    status = status,
                    statusFlags = decodeStatus(status),
                )
            )
        }
        return faults
    }
}
