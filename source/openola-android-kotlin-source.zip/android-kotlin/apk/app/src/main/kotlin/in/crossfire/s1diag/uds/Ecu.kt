package `in`.crossfire.s1diag.uds

/** UDS request/response CAN IDs per ECU, from the app's EcuCanId. */
enum class Ecu(val reqId: Int, val respId: Int) {
    BMS(0x078E, 0x07B1),
    VCU(0x0786, 0x07B0),
    MCU(0x07A6, 0x07B4);
}
