package `in`.crossfire.s1diag.ble

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * In-app BLE debug log. Every seed / write / CCCD / ack step is appended here as
 * well as to android Log, so a failed tap is diagnosable on the phone (and can be
 * shared) instead of guessed. Ring buffer; observe [lines] from Compose.
 */
object BleLog {
    private const val MAX = 800
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val buf = ArrayDeque<String>()
    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines

    @Synchronized
    fun add(msg: String) {
        buf.addLast("${fmt.format(Date())}  $msg")
        while (buf.size > MAX) buf.removeFirst()
        _lines.value = buf.toList()
    }

    @Synchronized
    fun clear() {
        buf.clear()
        _lines.value = emptyList()
    }

    fun text(): String = _lines.value.joinToString("\n")
}
