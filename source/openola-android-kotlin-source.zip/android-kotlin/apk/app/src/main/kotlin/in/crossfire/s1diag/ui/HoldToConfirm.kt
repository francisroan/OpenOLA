package `in`.crossfire.s1diag.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import `in`.crossfire.s1diag.ui.theme.*
import kotlinx.coroutines.delay

/**
 * Confirmation dialog for destructive actions. A progress bar fills over 3s;
 * the "Confirm" button only becomes tappable once it completes. This makes an
 * accidental hard change effectively impossible without a deliberate wait.
 */
@Composable
fun ConfirmWithTimer(
    title: String,
    message: String,
    confirmLabel: String,
    seconds: Int = 3,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    var armed by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    val progress by animateFloatAsState(
        targetValue = if (running) 1f else 0f,
        animationSpec = tween(durationMillis = seconds * 1000, easing = LinearEasing),
        label = "arm",
    )
    LaunchedEffect(Unit) {
        running = true
        delay(seconds * 1000L)
        armed = true
    }

    GlassDialog(onDismissRequest = onDismiss) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp)).background(Danger))
                    Text(title, style = MaterialTheme.typography.titleMedium, color = TextHi, fontWeight = FontWeight.SemiBold)
                }
                Text(message, style = MaterialTheme.typography.bodyMedium, color = TextMut)

                // arming bar
                Box(
                    Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Surface2)
                ) {
                    Box(
                        Modifier.fillMaxWidth(progress).fillMaxHeight()
                            .background(if (armed) Danger else Warn)
                    )
                }
                Text(
                    if (armed) "Review complete. Confirm only if the action is intended." else "Review this action for $seconds seconds.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (armed) Danger else TextMut,
                )

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextHi),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Line),
                    ) { Text("Cancel") }
                    Button(
                        onClick = { if (armed) onConfirm() },
                        enabled = armed,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Danger, contentColor = MaterialTheme.colorScheme.onError,
                            disabledContainerColor = Surface2, disabledContentColor = TextMut,
                        ),
                    ) { Text(confirmLabel) }
                }
            }
    }
}
