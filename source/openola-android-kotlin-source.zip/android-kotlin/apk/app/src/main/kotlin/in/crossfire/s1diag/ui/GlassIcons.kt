package `in`.crossfire.s1diag.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import `in`.crossfire.s1diag.R

/** Authored line paths shared with the desktop reference. No Apple font or icon assets. */
object GlassIcons {
    private fun line(name: String, path: String) = ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
        .addPath(addPathNodes(path), fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = 1.8f,
            strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round).build()
    val Home = line("Home", "M3 10.5 12 3l9 7.5 M5 9.5V20h5v-6h4v6h5V9.5")
    val Faults = line("Faults", "M2 12h3l3-7 4 14 3-9 2 2h5")
    val Reports = line("Reports", "M6 3h8l5 5v13H6z M14 3v5h5 M9 13h7 M9 17h5")
    val Settings = line("Settings", "M4 7h16 M4 17h16 M9 4v6 M15 14v6")
    val Bolt = line("Bolt", "M13 2 4 14h7l-1 8 9-12h-7z")
    val Wifi = line("Wifi", "M2 8.5a15 15 0 0 1 20 0 M5 12a10 10 0 0 1 14 0 M8.5 15.5a5 5 0 0 1 7 0 M12 19h.01")
    val Sun = line("Sun", "M16 12a4 4 0 1 1-8 0a4 4 0 1 1 8 0 M12 2v2 M12 20v2 M2 12h2 M20 12h2 M5 5l1.4 1.4 M17.6 17.6L19 19 M5 19l1.4-1.4 M17.6 6.4L19 5")
    val Moon = line("Moon", "M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z")
    val Auto = line("Auto", "M21 12a9 9 0 1 1-18 0a9 9 0 1 1 18 0 M12 3v18")
}

@Composable
fun OpenOlaMark(modifier: Modifier = Modifier) {
    Image(painterResource(R.drawable.scooter_unlocked_upright), null,
        contentScale = ContentScale.Crop, modifier = modifier.size(44.dp).clip(RoundedCornerShape(12.dp)))
}
