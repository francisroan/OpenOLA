package `in`.crossfire.s1diag.ui

import `in`.crossfire.s1diag.vm.UiState
import `in`.crossfire.s1diag.vm.Conn
import `in`.crossfire.s1diag.uds.Ecu
import java.time.Instant

/** Frozen at Capture; sharing/saving never queries a vehicle or changes its state. */
data class DiagnosticReport(val capturedAt: Long, val text: String, val json: String) {
    companion object {
        fun capture(ui: UiState, capturedAt: Long, includeVin: Boolean = false, activity: String? = null): DiagnosticReport {
            val whenCaptured = Instant.ofEpochMilli(capturedAt).toString()
            val vin = if (includeVin) ui.info?.vin else null
            val age = telemetryAgeMs(ui.lastCanFrameAt, capturedAt)
            val source = if (ui.demo) "DEMO — SIMULATED DATA" else "Vehicle diagnostic snapshot"
            val telemetryStatus = when {
                ui.demo -> "SIMULATED"
                ui.conn != Conn.CONNECTED -> "DISCONNECTED — cached data, if present"
                age == null -> "NO CAN FRAMES RECEIVED"
                age > STALE_AFTER_MS -> "STALE — last frame ${age / 1000}s ago"
                else -> "CAN receiving — last frame ${age / 1000}s ago"
            }
            val metrics = linkedMapOf(
                "State of charge (%)" to ui.battery?.soc,
                "Reported range (km)" to ui.battery?.rangeKm,
                "Pack voltage (V)" to ui.battery?.packVolts,
                "Pack current (A)" to ui.battery?.packAmps,
                "Battery temperature (°C)" to ui.battery?.battTemp,
                "Motor temperature (°C)" to ui.battery?.motorTemp,
                "Controller temperature (°C)" to ui.battery?.mcuTemp,
                "Vehicle speed (km/h)" to ui.battery?.speedKmh,
            )
            val text = buildString {
                appendLine("OpenOLA diagnostic report")
                appendLine(source)
                appendLine("Snapshot captured: $whenCaptured")
                appendLine("This is capture/export time, not the time each ECU was scanned.")
                appendLine("Connection: ${ui.conn.name}")
                appendLine("Telemetry: $telemetryStatus")
                appendLine("Firmware: ${ui.firmware}")
                appendLine("Mode: ${ui.mode}")
                appendLine("VIN: ${if (!includeVin) "Excluded" else vin ?: "Unavailable (not read)"}")
                appendLine()
                appendLine("BATTERY / VEHICLE SNAPSHOT")
                metrics.forEach { (label, value) -> appendLine("$label: ${value?.takeIf { it.isFinite() } ?: "Unavailable"}") }
                appendLine("Per-signal freshness and battery state of health are not established.")
                appendLine()
                appendLine("STORED FAULTS — latest completed reads in this app session")
                Ecu.values().forEach { ecu ->
                    val codes = ui.faults[ecu]
                    appendLine("${ecu.name}: ${codes?.let { "${it.size} codes returned" } ?: "NOT SCANNED"}")
                    codes?.forEach { fault ->
                        appendLine("  ${fault.code}: ${fault.description}")
                        appendLine("  Catalog: ${if (fault.known) "matched" else "unknown"}; status 0x${"%02X".format(fault.status)}; ${fault.statusFlags.joinToString(", ")}")
                    }
                }
                appendLine("Zero codes returned is not proof of battery health or successful repair.")
                appendLine()
                appendLine("BROADCAST FAULT FLAGS")
                if (!ui.demo && ui.lastCanFrameAt == 0L) appendLine("Unavailable — no CAN frames received.")
                else if (ui.activeFaults.isEmpty()) appendLine("No flags in this snapshot.")
                else ui.activeFaults.forEach { appendLine(it) }
                appendLine()
                appendLine("Deep-sleep BMS wake/reset has NOT been validated by this report.")
                if (activity != null) { appendLine(); appendLine("ACTIVITY LOG (may include identifying data)"); appendLine(activity) }
            }
            val json = buildString {
                append("{\n  \"schema\": \"openola.diagnostic.v1\",")
                append("\n  \"captured_at\": ${jsonString(whenCaptured)},")
                append("\n  \"demo\": ${ui.demo},")
                append("\n  \"connection\": ${jsonString(ui.conn.name)},")
                append("\n  \"telemetry_status\": ${jsonString(telemetryStatus)},")
                append("\n  \"last_can_frame_at_ms\": ${ui.lastCanFrameAt.takeIf { it > 0 } ?: "null"},")
                append("\n  \"firmware\": ${jsonString(ui.firmware)},")
                append("\n  \"mode\": ${jsonString(ui.mode)},")
                append("\n  \"vin\": ${vin?.let(::jsonString) ?: "null"},")
                append("\n  \"vin_included\": $includeVin,")
                append("\n  \"metrics\": {")
                append(metrics.entries.joinToString(",") { (label, value) -> "\n    ${jsonString(label)}: ${value?.takeIf { it.isFinite() } ?: "null"}" })
                append("\n  },\n  \"controllers\": [")
                append(Ecu.values().joinToString(",") { ecu ->
                    val codes = ui.faults[ecu]
                    "{\"ecu\":${jsonString(ecu.name)},\"scanned\":${codes != null},\"scan_time\":null,\"faults\":[" +
                        codes.orEmpty().joinToString(",") { f ->
                            "{\"code\":${jsonString(f.code)},\"description\":${jsonString(f.description)},\"known\":${f.known},\"status\":${f.status},\"flags\":[" +
                                f.statusFlags.joinToString(",") { jsonString(it) } + "]}"
                        } + "]}"
                })
                append("],\n  \"broadcast_faults_available\": ${ui.demo || ui.lastCanFrameAt > 0},")
                append("\n  \"broadcast_faults\": [${ui.activeFaults.joinToString(",") { jsonString(it) }}],")
                append("\n  \"deep_sleep_bms_wake_validated\": false,")
                append("\n  \"per_signal_freshness_known\": false,")
                append("\n  \"activity_log\": ${activity?.let(::jsonString) ?: "null"}\n}\n")
            }
            return DiagnosticReport(capturedAt, text, json)
        }
    }
}
internal fun jsonString(value: String): String = buildString {
    append('"')
    value.forEach { char ->
        when (char) {
            '"' -> append("\\\"")
            '\\' -> append("\\\\")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> if (char.code < 32) append("\\u%04x".format(char.code)) else append(char)
        }
    }
    append('"')
}
