package `in`.crossfire.s1diag.can

/**
 * CAN frame <-> bytes codec for the wifican gRPC transport.
 *
 * The wifican CANPacket carries a 16-byte "RAW CAN frame" = the Linux
 * struct can_frame, with can_id serialised BIG-endian:
 *   [0..3]  can_id  (4 bytes, big-endian)   e.g. 00 00 07 8E -> 0x78E
 *   [4]     dlc     (0x08 for our requests)
 *   [5..7]  padding (00 00 00)
 *   [8..15] data    (8 bytes = ISO-TP frame)
 *
 * Verified against the app's ByteHelper.getCanId / getDataBytes and
 * getRequestResponseFirstEightBytes.
 */
object CanFrame {

    fun build(canId: Int, data: ByteArray): ByteArray {
        val frame = ByteArray(16)
        frame[0] = ((canId ushr 24) and 0xFF).toByte()
        frame[1] = ((canId ushr 16) and 0xFF).toByte()
        frame[2] = ((canId ushr 8) and 0xFF).toByte()
        frame[3] = (canId and 0xFF).toByte()
        frame[4] = 0x08
        // [5..7] already zero
        val n = minOf(data.size, 8)
        System.arraycopy(data, 0, frame, 8, n)
        return frame
    }

    /** Returns Pair(canId, data8). Accepts 16-byte raw frame or 18-byte protobuf-wrapped. */
    fun parse(frame: ByteArray): Pair<Int, ByteArray> {
        val f = when {
            frame.size >= 18 -> frame.copyOfRange(frame.size - 16, frame.size)
            else -> frame
        }
        require(f.size >= 16) { "short can_frame: ${f.size}" }
        val be = ((f[0].toInt() and 0xFF) shl 24) or
            ((f[1].toInt() and 0xFF) shl 16) or
            ((f[2].toInt() and 0xFF) shl 8) or
            (f[3].toInt() and 0xFF)
        val le = ((f[3].toInt() and 0xFF) shl 24) or
            ((f[2].toInt() and 0xFF) shl 16) or
            ((f[1].toInt() and 0xFF) shl 8) or
            (f[0].toInt() and 0xFF)
        val be11 = be and 0x1FFFFFFF
        val le11 = le and 0x1FFFFFFF
        // Prefer a classic 11-bit diagnostic ID (0x600–0x7FF) if endianness is ambiguous.
        val canId = when {
            be11 in 0x600..0x7FF -> be11
            le11 in 0x600..0x7FF -> le11
            else -> be11
        }
        val data = f.copyOfRange(8, 16)
        return Pair(canId, data)
    }
}
