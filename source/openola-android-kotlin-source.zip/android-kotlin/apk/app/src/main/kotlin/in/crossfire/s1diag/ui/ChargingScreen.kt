package `in`.crossfire.s1diag.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.DiagViewModel
import kotlin.math.roundToInt

@Composable
fun ChargingScreen(vm: DiagViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var confirmStop by remember { mutableStateOf(false) }
    val b = ui.battery
    val ci = ui.chargeInfo

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            SectionCard("Charge status") {
                val state = when {
                    b == null && ci == null -> "Waiting for charge data"
                    b?.charging == true -> "Charging"
                    (ci?.plugged == true) || b?.chargerConnected == true -> "Plugged in"
                    else -> "Not charging"
                }
                Text(state, style = MaterialTheme.typography.headlineMedium, color = TextHi,
                    fontWeight = FontWeight.Bold)
                val v = b?.packVolts; val a = b?.packAmps
                val power = if (v != null && a != null) v * a else null
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Stat("SOC", if (b?.soc == null) "—" else "${b.soc.roundToInt()} %", Modifier.weight(1f))
                    Stat("Power", if (power == null) "—" else "%.0f W".format(power), Modifier.weight(1f))
                    Stat("Current", if (a == null) "—" else "%.1f A".format(a), Modifier.weight(1f))
                }
            }
        }
        item {
            SectionCard("Charger (from vehicle CAN)") {
                KeyVal("Type", ci?.type ?: "—", accent = ci?.type == "Boost" || ci?.type == "Fast")
                KeyVal("Charging mode", ci?.mode ?: "—")
                KeyVal("Plugged in", yn(ci?.plugged))
                KeyVal("Connector latched", yn(ci?.connectorLatched))
                KeyVal("Billing / paid session", yn(ci?.billing), warn = ci?.billing == true)
                KeyVal("EVSE / station id", ci?.evseId ?: "—", mono = true)
                Text(
                    "Decoded from 0x62D / 0x213 / 0x508 / 0x584-585. 'Boost' is a distinct charger " +
                        "type; billing = the station flagged a paid session.",
                    color = TextMut, style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        item {
            SectionCard("Limits") {
                KeyVal("Pack voltage", b?.packVolts?.let { "%.1f V".format(it) } ?: "—")
                KeyVal("Range", b?.rangeKm?.let { "${it.roundToInt()} km" } ?: "—")
            }
        }
        item {
            SectionCard("Charge session log") {
                Text("Records charge CAN frames + vitals to JSONL (Charging folder).",
                    color = TextMut, style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = { vm.toggleChargeSnoop() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (ui.chargeSnoopOn) Danger else Accent,
                        contentColor = if (ui.chargeSnoopOn) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onPrimary,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (ui.chargeSnoopOn) "Stop recording" else "Record charge session") }
                ui.chargeSnoopFile?.let {
                    Text((if (ui.chargeSnoopOn) "Recording → " else "Last → ") + it,
                        color = TextMut, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            SectionCard("Stop charging") {
                Text("Sends CommandFromHMI Stop_Charge (0x6BC #13). Needs Service mode. " +
                    "One-shot, echo-confirmed, no retry.", color = TextMut,
                    style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = { confirmStop = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Danger, contentColor = MaterialTheme.colorScheme.onError),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Stop charge") }
            }
        }
        item { Spacer(Modifier.height(20.dp)) }
    }

    if (confirmStop) {
        ConfirmWithTimer(
            title = "Stop charging?",
            message = "Sends Stop_Charge over CAN. Verify on the scooter afterward.",
            confirmLabel = "Stop",
            onConfirm = { vm.stopCharge(); confirmStop = false },
            onDismiss = { confirmStop = false },
        )
    }
}

private fun yn(b: Boolean?): String = when (b) { true -> "Yes"; false -> "No"; else -> "—" }

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(color = Surface2, shape = RoundedCornerShape(12.dp), modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, color = Accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(label, color = TextMut, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun KeyVal(k: String, v: String, accent: Boolean = false, warn: Boolean = false, mono: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = TextMut, style = MaterialTheme.typography.bodyMedium)
        Text(
            v,
            color = if (warn) Warn else if (accent) Accent else TextHi,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = if (mono) Mono else null,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
