package `in`.crossfire.s1diag.net

import android.content.Context
import android.util.Log
import com.google.protobuf.ByteString
import com.google.protobuf.Empty
import io.grpc.ManagedChannel
import io.grpc.okhttp.OkHttpChannelBuilder
import io.grpc.stub.StreamObserver
import `in`.crossfire.s1diag.can.CanFrame
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import wifican.Wifican
import wifican.WifiCanRpcGrpc

/**
 * gRPC transport to the scooter wifican server.
 *
 * Restored to the pre-rework behaviour that worked on-device:
 *  - init(canIds) + ReadCanStream on connect (not deferred)
 *  - WriteCanFrame without a short deadline (3s deadline caused false DEADLINE_EXCEEDED)
 *  - simple stream start (no GrpcContext cancel tricks that killed the reader)
 */
class WifiCanClient {

    companion object {
        private const val TAG = "S1Diag/Wifi"
    }

    private var channel: ManagedChannel? = null
    private var blocking: WifiCanRpcGrpc.WifiCanRpcBlockingStub? = null
    private var async: WifiCanRpcGrpc.WifiCanRpcStub? = null
    private val streamExec = Executors.newCachedThreadPool { r ->
        Thread(r, "s1diag-grpc-stream").apply { isDaemon = true }
    }

    private val queues = ConcurrentHashMap<Int, LinkedBlockingQueue<ByteArray>>()
    @Volatile var frameListener: ((Int, ByteArray) -> Unit)? = null
    private val activeObserver = AtomicReference<StreamObserver<Wifican.CANPacket>?>(null)
    private val rxCount = AtomicInteger(0)
    @Volatile var lastError: Throwable? = null
        private set
    /** null / "diag" (filtered ReadCanStream) / "dump" (CanDumpStream). */
    @Volatile var streamMode: String? = null
        private set

    fun connect(ctx: Context, host: String, port: Int, secure: Boolean, timeoutSec: Long = 10) {
        val builder = OkHttpChannelBuilder.forAddress(host, port)
        if (secure) {
            builder.useTransportSecurity()
            builder.sslSocketFactory(TlsFactory.socketFactory(ctx))
            builder.overrideAuthority(TlsFactory.AUTHORITY)
        } else {
            builder.usePlaintext()
        }
        builder.maxInboundMessageSize(4 * 1024 * 1024)
        // Do not enable HTTP/2 keepalive pings — the SOM gRPC server RST-streams them.
        val ch = builder.build()
        channel = ch
        blocking = WifiCanRpcGrpc.newBlockingStub(ch)
        async = WifiCanRpcGrpc.newStub(ch).withExecutor(streamExec)
        Log.i(TAG, "channel to $host:$port secure=$secure")
    }

    fun init(canIds: List<Int>): Wifican.Response {
        val req = Wifican.Register.newBuilder().addAllCanIds(canIds).build()
        // Fresh stub without the connect-time short deadline for ongoing use.
        val stub = WifiCanRpcGrpc.newBlockingStub(channel!!)
        val r = stub.init(req)
        Log.i(TAG, "init(${canIds.size} ids) -> ${r.status}")
        blocking = stub
        return r
    }

    fun queueFor(canId: Int): LinkedBlockingQueue<ByteArray> =
        queues.getOrPut(canId) { LinkedBlockingQueue() }

    /**
     * Start the CAN reader. dump=false -> filtered ReadCanStream (call init first);
     * dump=true -> CanDumpStream. UDS must use filtered diag stream — dump starves writes.
     */
    fun startReader(dump: Boolean) {
        stopStream()
        lastError = null
        rxCount.set(0)
        val mode = if (dump) "dump" else "diag"
        val obs = object : StreamObserver<Wifican.CANPacket> {
            override fun onNext(pkt: Wifican.CANPacket) {
                if (activeObserver.get() !== this) return
                val raw = pkt.canFrame.toByteArray()
                val (id, data) = try {
                    CanFrame.parse(raw)
                } catch (e: Exception) {
                    Log.w(TAG, "drop frame len=${raw.size} ${raw.take(8).joinToString("") { "%02X".format(it) }}")
                    return
                }
                val n = rxCount.incrementAndGet()
                if (n <= 30) {
                    Log.i(TAG, "rx #$n id=0x%03X dlc=%d %s".format(id, data.size, data.joinToString("") { "%02X".format(it) }))
                }
                queueFor(id).offer(data)
                val masked = id and 0x1FFFFFFF
                if (masked != id) queueFor(masked).offer(data)
                frameListener?.invoke(id, data)
            }
            override fun onError(t: Throwable) {
                if (activeObserver.get() !== this) return
                lastError = t
                Log.e(TAG, "stream $mode error: ${t.message}", t)
                streamMode = null
            }
            override fun onCompleted() {
                if (activeObserver.get() !== this) return
                Log.i(TAG, "stream $mode completed")
                streamMode = null
            }
        }
        activeObserver.set(obs)
        if (dump) async!!.canDumpStream(Empty.getDefaultInstance(), obs)
        else async!!.readCanStream(Empty.getDefaultInstance(), obs)
        streamMode = mode
        // Python waits until the stream RPC is open so the first UDS write isn't lost.
        try { Thread.sleep(150) } catch (_: InterruptedException) {}
        Log.i(TAG, "started $mode stream")
    }

    fun stopStream() {
        val prev = activeObserver.getAndSet(null)
        streamMode = null
        // Dropping the observer reference is enough for GC; the server-side stream
        // ends when the channel is idle or we open a replacement. Avoid Context.cancel
        // races that killed the working reader after the UI rewrite.
        if (prev != null) Log.i(TAG, "stopped prior stream")
    }

    val readerAlive: Boolean get() = streamMode != null && lastError == null

    fun writeFrame(canId: Int, data8: ByteArray): Wifican.Response {
        val frame = CanFrame.build(canId, data8)
        val pkt = Wifican.CANPacket.newBuilder().setCanFrame(ByteString.copyFrom(frame)).build()
        // Match the working pre-rework client: no ultra-short deadline.
        // (A 3s deadline + dump firehose = DEADLINE_EXCEEDED and "nothing works".)
        val stub = WifiCanRpcGrpc.newBlockingStub(channel!!)
            .withDeadlineAfter(15, TimeUnit.SECONDS)
        return try {
            Log.i(TAG, "tx 0x%03X %s (mode=$streamMode rx=${rxCount.get()})".format(
                canId, data8.joinToString("") { "%02X".format(it) }))
            val r = stub.writeCanFrame(pkt)
            if (r.status != Wifican.RespStatus.RESP_SUCCESS) {
                Log.w(TAG, "write 0x%03X rejected: %s".format(canId, r.statusMsg))
                throw IllegalStateException(
                    "CAN write rejected for 0x%03X: %s (%s)".format(
                        canId, r.statusMsg.ifEmpty { "no message" }, r.status.name))
            }
            r
        } catch (e: Exception) {
            Log.e(TAG, "write 0x%03X failed mode=$streamMode: ${e.message}")
            throw e
        }
    }

    fun setMode(mode: Wifican.VehicleOperationState): Wifican.Response {
        val stub = WifiCanRpcGrpc.newBlockingStub(channel!!).withDeadlineAfter(15, TimeUnit.SECONDS)
        return stub.setVehicleOperationMode(
            Wifican.VehicleOperationMode.newBuilder().setCurMode(mode).build())
    }

    fun getMode(): Wifican.VehicleOperationMode {
        val stub = WifiCanRpcGrpc.newBlockingStub(channel!!).withDeadlineAfter(10, TimeUnit.SECONDS)
        return stub.getVehicleOperationMode(Empty.getDefaultInstance())
    }

    fun swVersion(): Wifican.Response {
        val stub = WifiCanRpcGrpc.newBlockingStub(channel!!).withDeadlineAfter(10, TimeUnit.SECONDS)
        return stub.getSwVersion(Empty.getDefaultInstance())
    }

    fun aospVersion(): Wifican.Response {
        val stub = WifiCanRpcGrpc.newBlockingStub(channel!!).withDeadlineAfter(10, TimeUnit.SECONDS)
        return stub.getAospVersion(Empty.getDefaultInstance())
    }

    fun identifiers(): Wifican.VehicleIdentifiers {
        val stub = WifiCanRpcGrpc.newBlockingStub(channel!!).withDeadlineAfter(10, TimeUnit.SECONDS)
        return stub.getVehicleIdentifiers(Empty.getDefaultInstance())
    }

    fun remoteTest(req: Wifican.RmtCmdReq): Wifican.RmtCmdResp {
        val stub = WifiCanRpcGrpc.newBlockingStub(channel!!).withDeadlineAfter(20, TimeUnit.SECONDS)
        return stub.remoteRunTestCmd(req)
    }

    fun systemCmd(cmd: Wifican.SystemCmdList): Wifican.SystemTestResp {
        val stub = WifiCanRpcGrpc.newBlockingStub(channel!!).withDeadlineAfter(5, TimeUnit.SECONDS)
        return stub.runSystemTestCmd(Wifican.SystemTestCmd.newBuilder().setCmdId(cmd).build())
    }

    fun close() {
        stopStream()
        try {
            channel?.let { WifiCanRpcGrpc.newBlockingStub(it).deinit(Empty.getDefaultInstance()) }
        } catch (_: Exception) {}
        channel?.shutdownNow()
        try { channel?.awaitTermination(2, TimeUnit.SECONDS) } catch (_: Exception) {}
        channel = null
        blocking = null
        async = null
        queues.clear()
        Log.i(TAG, "closed")
    }

    fun rxFrames(): Int = rxCount.get()
}
