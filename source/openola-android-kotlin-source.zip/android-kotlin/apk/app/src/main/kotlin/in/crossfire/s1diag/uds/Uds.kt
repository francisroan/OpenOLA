package `in`.crossfire.s1diag.uds

import `in`.crossfire.s1diag.can.IsoTp
import `in`.crossfire.s1diag.can.IsoTpReassembler
import `in`.crossfire.s1diag.net.WifiCanClient
import java.util.concurrent.TimeUnit

class UdsException(message: String) : Exception(message)

/**
 * UDS-over-CAN session logic, ported from the verified Python (oladiag/uds.py).
 * Command bytes taken from the app's decompiled constants:
 *   extended session 10 03 -> 50 03; security 27 01 / 27 02 -> 67 01/67 02;
 *   read DTC 19 02 09 -> 59 02 ...; clear 14 FF FF FF -> 54; ECU reset 11 01.
 */
class Uds(
    private val client: WifiCanClient,
    private val table: (Ecu) -> Map<String, String>,
    private val timeoutMs: Long = 5000,
) {
    companion object {
        const val SVC_SESSION = 0x10
        const val SUB_EXTENDED = 0x03
        const val SVC_SECURITY = 0x27
        const val SUB_SEED = 0x01
        const val SUB_KEY = 0x02
        const val SVC_READ_DTC = 0x19
        const val SUB_DTC_BY_STATUS = 0x02
        const val DTC_STATUS_MASK = 0x09
        const val SVC_CLEAR_DTC = 0x14
        const val SVC_ECU_RESET = 0x11
        const val SUB_HARD_RESET = 0x01
        const val SVC_READ_DID = 0x22        // ReadDataByIdentifier
        const val SVC_WRITE_DID = 0x2E       // WriteDataByIdentifier
        const val SVC_IO_CONTROL = 0x2F      // InputOutputControlByIdentifier (actuators)
        const val IO_RETURN_TO_ECU = 0x00
        const val IO_SHORT_TERM = 0x03       // shortTermAdjustment (state byte follows)
        const val SVC_ROUTINE = 0x31         // RoutineControl
        const val ROUTINE_START = 0x01
        const val SVC_TESTER_PRESENT = 0x3E
        const val SUB_TP_SUPPRESS = 0x80     // suppressPositiveResponse -> ECU stays silent
        const val NRC = 0x7F
        const val NRC_SECURITY_DENIED = 0x33
        const val NRC_RESPONSE_PENDING = 0x78
        fun positive(sid: Int) = sid + 0x40
    }

    private fun sendPayload(ecu: Ecu, payload: ByteArray) {
        val q = client.queueFor(ecu.respId)
        if (payload.size <= 7) {
            client.writeFrame(ecu.reqId, IsoTp.encodeSingle(payload))
            return
        }
        // multi-frame: first frame, wait for flow control, then consecutive frames
        val total = payload.size
        val ff = ByteArray(8)
        ff[0] = (0x10 or ((total ushr 8) and 0x0F)).toByte()
        ff[1] = (total and 0xFF).toByte()
        System.arraycopy(payload, 0, ff, 2, 6)
        client.writeFrame(ecu.reqId, ff)

        var stmin = 0
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val d = q.poll(maxOf(50, deadline - System.currentTimeMillis()), TimeUnit.MILLISECONDS) ?: break
            if (IsoTp.frameType(d) == IsoTp.FLOW) { stmin = d[2].toInt() and 0xFF; break }
        }
        var rest = payload.copyOfRange(6, payload.size)
        var sn = 1
        while (rest.isNotEmpty()) {
            val chunk = rest.copyOfRange(0, minOf(7, rest.size))
            rest = if (rest.size > 7) rest.copyOfRange(7, rest.size) else ByteArray(0)
            val cf = ByteArray(8)
            cf[0] = (0x20 or (sn and 0x0F)).toByte()
            System.arraycopy(chunk, 0, cf, 1, chunk.size)
            client.writeFrame(ecu.reqId, cf)
            sn = (sn + 1) and 0x0F
            stminDelay(stmin)
        }
    }

    private fun stminDelay(stmin: Int) {
        try {
            if (stmin in 1..0x7F) Thread.sleep(stmin.toLong())
            else if (stmin in 0xF1..0xF9) Thread.sleep(0, (stmin - 0xF0) * 100_000)
        } catch (_: InterruptedException) {}
    }

    private fun request(ecu: Ecu, payload: ByteArray): ByteArray {
        val q = client.queueFor(ecu.respId)
        q.clear()
        sendPayload(ecu, payload)

        var reasm = IsoTpReassembler()
        var deadline = System.currentTimeMillis() + timeoutMs
        var sentFc = false
        while (System.currentTimeMillis() < deadline) {
            val data8 = q.poll(maxOf(50, deadline - System.currentTimeMillis()), TimeUnit.MILLISECONDS)
                ?: continue
            if (IsoTp.frameType(data8) == IsoTp.FIRST && !sentFc) {
                reasm.feed(data8)
                client.writeFrame(ecu.reqId, IsoTp.FLOW_CONTROL)
                sentFc = true
                continue
            }
            val out = reasm.feed(data8)
            if (out != null) {
                if (out.size >= 3 && (out[0].toInt() and 0xFF) == NRC && (out[2].toInt() and 0xFF) == NRC_RESPONSE_PENDING) {
                    reasm = IsoTpReassembler()
                    sentFc = false
                    deadline = System.currentTimeMillis() + timeoutMs
                    continue
                }
                return out
            }
        }
        throw UdsException("Timeout waiting for ${ecu.name} (req=0x%03X resp=0x%03X)".format(ecu.reqId, ecu.respId))
    }

    private fun checkPositive(resp: ByteArray, service: Int, ecu: Ecu): ByteArray {
        if (resp.isEmpty()) throw UdsException("${ecu.name}: empty response")
        val b0 = resp[0].toInt() and 0xFF
        if (b0 == NRC) {
            val svc = if (resp.size > 1) resp[1].toInt() and 0xFF else 0
            val code = if (resp.size > 2) resp[2].toInt() and 0xFF else 0
            throw UdsException("${ecu.name}: negative response to 0x%02X, NRC 0x%02X".format(svc, code))
        }
        if (b0 != positive(service))
            throw UdsException("${ecu.name}: unexpected SID 0x%02X".format(b0))
        return resp
    }

    fun enterExtendedSession(ecu: Ecu): ByteArray =
        checkPositive(request(ecu, byteArrayOf(SVC_SESSION.toByte(), SUB_EXTENDED.toByte())), SVC_SESSION, ecu)

    fun securityAccess(ecu: Ecu, level: String = "01"): ByteArray {
        val seedResp = request(ecu, byteArrayOf(SVC_SECURITY.toByte(), SUB_SEED.toByte()))
        checkPositive(seedResp, SVC_SECURITY, ecu)
        val seed = seedResp.copyOfRange(2, seedResp.size)
        if (seed.all { it.toInt() == 0 }) return seedResp // already unlocked
        val key = SeedKey.generateKey(seed, ecu, level)
        val keyReq = ByteArray(2 + key.size)
        keyReq[0] = SVC_SECURITY.toByte(); keyReq[1] = SUB_KEY.toByte()
        System.arraycopy(key, 0, keyReq, 2, key.size)
        return checkPositive(request(ecu, keyReq), SVC_SECURITY, ecu)
    }

    fun readDtcs(ecu: Ecu, unlock: Boolean = true): List<Fault> {
        val req = byteArrayOf(SVC_READ_DTC.toByte(), SUB_DTC_BY_STATUS.toByte(), DTC_STATUS_MASK.toByte())
        var resp = try {
            request(ecu, req)
        } catch (e: UdsException) {
            if (unlock && e.message?.contains("NRC 0x33") == true) {
                securityAccess(ecu); request(ecu, req)
            } else throw e
        }
        if (resp.isNotEmpty() && (resp[0].toInt() and 0xFF) == NRC &&
            resp.size > 2 && (resp[2].toInt() and 0xFF) == NRC_SECURITY_DENIED && unlock
        ) {
            securityAccess(ecu); resp = request(ecu, req)
        }
        checkPositive(resp, SVC_READ_DTC, ecu)
        return Dtc.parse(resp, table(ecu))
    }

    fun clearDtcs(ecu: Ecu): ByteArray =
        checkPositive(
            request(ecu, byteArrayOf(SVC_CLEAR_DTC.toByte(), 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte())),
            SVC_CLEAR_DTC, ecu
        )

    fun ecuReset(ecu: Ecu): ByteArray =
        checkPositive(
            request(ecu, byteArrayOf(SVC_ECU_RESET.toByte(), SUB_HARD_RESET.toByte())),
            SVC_ECU_RESET, ecu
        )

    /** Fire-and-forget 3E 80 (suppressed response) to keep the session/security alive. */
    fun testerPresent(ecu: Ecu) {
        client.writeFrame(ecu.reqId, IsoTp.encodeSingle(byteArrayOf(SVC_TESTER_PRESENT.toByte(), SUB_TP_SUPPRESS.toByte())))
    }

    /**
     * IOControlByIdentifier: 2F <DID_hi> <DID_lo> <controlOption> [state...] -> 6F <DID>.
     * VCU actuators use controlOption 0x03 (shortTermAdjustment) + a 1-byte state
     * (0x01 on / 0x00 off), or 0x00 (returnControlToECU) with no state.
     */
    fun ioControl(ecu: Ecu, did: Int, controlOption: Int = IO_SHORT_TERM, state: ByteArray = ByteArray(0)): ByteArray {
        val payload = ByteArray(4 + state.size)
        payload[0] = SVC_IO_CONTROL.toByte()
        payload[1] = ((did ushr 8) and 0xFF).toByte()
        payload[2] = (did and 0xFF).toByte()
        payload[3] = controlOption.toByte()
        System.arraycopy(state, 0, payload, 4, state.size)
        return checkPositive(request(ecu, payload), SVC_IO_CONTROL, ecu)
    }

    /** RoutineControl: 31 <sub> <routine_hi> <routine_lo> [data] -> 71 <sub> <routine> [status]. */
    fun routineControl(ecu: Ecu, sub: Int, routineId: Int, data: ByteArray = ByteArray(0)): ByteArray {
        val payload = ByteArray(4 + data.size)
        payload[0] = SVC_ROUTINE.toByte()
        payload[1] = sub.toByte()
        payload[2] = ((routineId ushr 8) and 0xFF).toByte()
        payload[3] = (routineId and 0xFF).toByte()
        System.arraycopy(data, 0, payload, 4, data.size)
        return checkPositive(request(ecu, payload), SVC_ROUTINE, ecu)
    }

    /** ReadDataByIdentifier: 22 <DID_hi> <DID_lo> -> 62 <DID> <data...>; returns the data bytes. */
    fun readDid(ecu: Ecu, did: Int): ByteArray {
        val payload = byteArrayOf(SVC_READ_DID.toByte(), ((did ushr 8) and 0xFF).toByte(), (did and 0xFF).toByte())
        val resp = checkPositive(request(ecu, payload), SVC_READ_DID, ecu)
        return if (resp.size > 3) resp.copyOfRange(3, resp.size) else ByteArray(0)
    }

    /** WriteDataByIdentifier: 2E <DID_hi> <DID_lo> <data...> -> 6E <DID>. */
    fun writeDid(ecu: Ecu, did: Int, data: ByteArray): ByteArray {
        val payload = ByteArray(3 + data.size)
        payload[0] = SVC_WRITE_DID.toByte()
        payload[1] = ((did ushr 8) and 0xFF).toByte()
        payload[2] = (did and 0xFF).toByte()
        System.arraycopy(data, 0, payload, 3, data.size)
        return checkPositive(request(ecu, payload), SVC_WRITE_DID, ecu)
    }
}
