package `in`.crossfire.s1diag.data

import android.content.Context
import `in`.crossfire.s1diag.uds.Ecu
import org.json.JSONObject

/**
 * Loads dtc_ecu_list.json from assets: { "BMS":[{DTC Code,Description}], "VCU":[...], "MCU":[...] }
 * into per-ECU maps of code(upper) -> description.
 */
class DtcCatalog private constructor(private val byEcu: Map<Ecu, Map<String, String>>) {

    fun table(ecu: Ecu): Map<String, String> = byEcu[ecu] ?: emptyMap()
    fun count(ecu: Ecu): Int = byEcu[ecu]?.size ?: 0

    companion object {
        fun load(ctx: Context): DtcCatalog {
            val text = ctx.assets.open("dtc_ecu_list.json").bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            val map = HashMap<Ecu, Map<String, String>>()
            for (ecu in Ecu.values()) {
                val arr = root.optJSONArray(ecu.name) ?: continue
                val m = HashMap<String, String>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val code = o.getString("DTC Code").uppercase()
                    m[code] = o.getString("Description")
                }
                map[ecu] = m
            }
            return DtcCatalog(map)
        }
    }
}
