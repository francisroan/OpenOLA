package `in`.crossfire.s1diag.data

import java.math.BigInteger
import kotlin.math.roundToLong

/**
 * Physical <-> raw byte codec for writable parameters, ported from the Python
 * backend (encode_setting / decode_setting). Little-endian; BigInteger so it
 * copes with structs wider than 8 bytes (e.g. B110's 14-byte torque block).
 */
object SettingCodec {

    private fun toBigLE(bytes: ByteArray): BigInteger {
        var v = BigInteger.ZERO
        for (i in bytes.indices) {
            v = v.or(BigInteger.valueOf(bytes[i].toLong() and 0xFF).shiftLeft(8 * i))
        }
        return v
    }

    private fun fromBigLE(value: BigInteger, length: Int): ByteArray {
        val out = ByteArray(length)
        var v = value
        val mask = BigInteger.valueOf(0xFF)
        for (i in 0 until length) {
            out[i] = v.and(mask).toInt().toByte()
            v = v.shiftRight(8)
        }
        return out
    }

    /** field name -> raw integer (pre-scaling). */
    fun rawFields(setting: Setting, bytes: ByteArray, reversed: Boolean): Map<String, Long> {
        val raw = toBigLE(if (reversed) bytes.reversedArray() else bytes)
        val out = LinkedHashMap<String, Long>()
        for (f in setting.fields) {
            val mask = BigInteger.ONE.shiftLeft(f.bits).subtract(BigInteger.ONE)
            out[f.name] = raw.shiftRight(f.startBit).and(mask).toLong()
        }
        return out
    }

    /**
     * field name -> physical value.
     * The diagnostic app reverses the config bytes before interpreting them, so
     * the correct byte order is UNVERIFIED here — [reversed] flips it. Calibrate
     * against a value you can sanity-check (a % field must land in its range).
     */
    fun decode(setting: Setting, bytes: ByteArray, reversed: Boolean = false): Map<String, Double> =
        rawFields(setting, bytes, reversed).mapValues { (name, r) ->
            val f = setting.fields.first { it.name == name }
            r.toDouble() * f.resolution + f.offset
        }

    /**
     * Patch [edits] (field name -> physical) into [original], preserving every
     * unedited field's bits. Throws on out-of-range or non-representable values.
     */
    fun encode(setting: Setting, original: ByteArray, edits: Map<String, Double>, reversed: Boolean = false): ByteArray {
        require(original.size == setting.lengthBytes) {
            "expected ${setting.lengthBytes} current bytes, got ${original.size}"
        }
        val base = if (reversed) original.reversedArray() else original
        var data = toBigLE(base)
        val byName = setting.fields.associateBy { it.name }
        for ((name, value) in edits) {
            val f = byName[name] ?: throw IllegalArgumentException("unknown field: $name")
            if (f.min != null && value < f.min) throw IllegalArgumentException("$name: below documented minimum ${f.min}")
            if (f.max != null && value > f.max) throw IllegalArgumentException("$name: above documented maximum ${f.max}")
            val rawD = (value - f.offset) / f.resolution
            val raw = rawD.roundToLong()
            if (kotlin.math.abs(rawD - raw) > 1e-6) throw IllegalArgumentException("$name: use increments of ${f.resolution}")
            if (raw < 0 || raw >= (1L shl f.bits)) throw IllegalArgumentException("$name: encoded value out of range")
            val mask = BigInteger.ONE.shiftLeft(f.bits).subtract(BigInteger.ONE).shiftLeft(f.startBit)
            data = data.and(mask.not()).or(BigInteger.valueOf(raw).shiftLeft(f.startBit))
        }
        val out = fromBigLE(data, setting.lengthBytes)
        return if (reversed) out.reversedArray() else out
    }
}
