package `in`.crossfire.s1diag.ui

import android.os.Build
import android.view.WindowManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogWindowProvider
import dev.chrisbanes.haze.*
import `in`.crossfire.s1diag.ui.theme.*

val LocalGlassState = staticCompositionLocalOf<HazeState?> { null }

/** Dialogs use native window blur so they also frost the foreground behind them. */
@Composable
fun GlassDialog(onDismissRequest: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    Dialog(onDismissRequest = onDismissRequest) {
        val view = LocalView.current
        SideEffect {
            (view.parent as? DialogWindowProvider)?.window?.let { window ->
                window.attributes = window.attributes.apply {
                    dimAmount = .22f
                    if (Build.VERSION.SDK_INT >= 31) blurBehindRadius = 28
                }
                if (Build.VERSION.SDK_INT >= 31) window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            }
        }
        // A dialog owns a different window; it never tries to reuse the main window's graphics layer.
        CompositionLocalProvider(LocalGlassState provides null) {
            GlassSurface(Modifier.widthIn(max = 420.dp).fillMaxWidth(), radius = 26.dp, strong = true, content = content)
        }
    }
}

/** One captured, static wallpaper. Only glass surfaces blur it; text remains crisp. */
@Composable
fun GlassWallpaper(state: HazeState, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val colors = if (p.dark) listOf(0xFF123A7A, 0xFF0D4A3A, 0xFF5A2A1A, 0xFF3A1F6A)
        else listOf(0xFFB7D4FF, 0xFFC9F2DC, 0xFFFFD9C2, 0xFFE5D4FF)
    Canvas(modifier.haze(state).background(p.background)) {
        val w = size.width
        val h = size.height
        fun glow(index: Int, x: Float, y: Float, radius: Float, alpha: Float = 1f) {
            val color = Color(colors[index]).copy(alpha = alpha)
            drawCircle(Brush.radialGradient(listOf(color, color.copy(alpha = alpha*.6f), Color.Transparent), Offset(x,y), radius),
                radius, Offset(x,y))
        }
        glow(0, w*.12f, h*.12f, w*.95f)
        glow(1, w*1.03f, h*.4f, w*.8f, .9f)
        glow(2, w*.28f, h*.95f, w*.85f, .7f)
        glow(3, w*.88f, h*.85f, w*.7f, .7f)
    }
}

/** Shared material follows the desktop GUI's tint, rim and blur tokens. */
@OptIn(ExperimentalHazeApi::class)
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    radius: Dp = 24.dp,
    strong: Boolean = false,
    content: @Composable BoxScope.() -> Unit,
) {
    val p = LocalPalette.current
    val state = LocalGlassState.current
    val shape = RoundedCornerShape(radius)
    val tint = if (strong) p.raised else p.surface
    val rim = Brush.linearGradient(listOf(
        Color.White.copy(alpha = if (p.dark) .20f else .92f),
        Color.White.copy(alpha = if (p.dark) .05f else .30f),
        Color.White.copy(alpha = if (p.dark) .12f else .72f),
    ))
    var material = modifier.shadow(14.dp, shape, clip = false,
        ambientColor = Color(0xFF1E2846).copy(alpha = if (p.dark) .3f else .09f),
        spotColor = Color.Black.copy(alpha = if (p.dark) .30f else .07f)).clip(shape)
    material = if (state != null) material.hazeChild(state, HazeStyle(
        backgroundColor = p.background,
        tints = listOf(HazeTint(tint)), blurRadius = 28.dp, noiseFactor = .015f,
        fallbackTint = HazeTint(tint.copy(alpha = if (p.dark) .85f else .82f)),
    )) { inputScale = HazeInputScale.Fixed(.8f) } else material.background(tint)
    Box(material.border(.8.dp, rim, shape), content = content)
}

@Composable
fun GlassToggle(title: String, checked: Boolean, enabled: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val reduced = LocalReduceMotion.current
    val track by animateColorAsState(if (checked) Color(0xFF34C759) else if (LocalPalette.current.dark) Color(0xFF474953) else Color(0xFFE3E5EA),
        tween(if (reduced) 0 else 180), label = "switchTrack")
    val offset by animateDpAsState(if (checked) 24.dp else 3.dp,
        if (reduced) tween(0) else spring(dampingRatio = .8f, stiffness = 650f), label = "switchThumb")
    Box(Modifier.size(56.dp, 48.dp).semantics { contentDescription = title }
        .toggleable(checked, enabled = enabled, role = Role.Switch, onValueChange = onCheckedChange),
        contentAlignment = Alignment.Center) {
        Box(Modifier.size(52.dp, 31.dp).clip(CircleShape).background(track.copy(alpha = if (enabled) 1f else .4f))
            .border(.5.dp, Line, CircleShape)) {
            Box(Modifier.padding(top = 3.dp).offset(x = offset).size(25.dp)
                .shadow(2.dp, CircleShape).background(Color.White, CircleShape))
        }
    }
}

/** Instantiated only during a real operation; there is no perpetual idle animation. */
@Composable
fun GlassSpinner(modifier: Modifier = Modifier, color: Color = Accent) {
    val reduced = LocalReduceMotion.current
    val rotation = if (reduced) 0f else {
        val transition = rememberInfiniteTransition(label = "loading")
        val angle by transition.animateFloat(0f, 360f,
            infiniteRepeatable(tween(1000, easing = LinearEasing)), label = "loadingAngle")
        angle
    }
    Canvas(modifier.size(18.dp).semantics { stateDescription = "Loading" }) {
        for (index in 0..11) {
            val angle = Math.toRadians((index*30f + rotation).toDouble())
            val cx = center.x
            val cy = center.y
            val radius = size.minDimension*.45f
            val x = kotlin.math.cos(angle).toFloat()
            val y = kotlin.math.sin(angle).toFloat()
            drawLine(color.copy(alpha = (index+1)/12f), Offset(cx+x*radius*.55f, cy+y*radius*.55f),
                Offset(cx+x*radius, cy+y*radius), size.minDimension*.09f, StrokeCap.Round)
        }
    }
}
