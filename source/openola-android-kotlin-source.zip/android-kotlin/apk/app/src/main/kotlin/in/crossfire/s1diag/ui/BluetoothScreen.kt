package `in`.crossfire.s1diag.ui

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.ble.BleDevice
import `in`.crossfire.s1diag.ble.BleLog
import `in`.crossfire.s1diag.ble.BleStatus
import `in`.crossfire.s1diag.ble.BleScanner
import `in`.crossfire.s1diag.ble.OlaBleClient
import `in`.crossfire.s1diag.ble.OlaBleProto
import `in`.crossfire.s1diag.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Warm BLE session so repeated taps don't re-pay connect+auth (~seconds). */
private object BleSession {
    private val mutex = Mutex()
    private var client: OlaBleClient? = null
    private var mac: String? = null
    private var lastOkAt = 0L
    private const val HARD_RECONNECT_MS = 25_000L

    private suspend fun dropClient() {
        val c = client
        client = null
        mac = null
        lastOkAt = 0L
        if (c != null) {
            try { c.closeSuspend() } catch (_: Exception) {
                try { c.close() } catch (_: Exception) {}
            }
        }
    }

    suspend fun <T> withAuthed(ctx: Context, address: String, block: suspend (OlaBleClient) -> T): T =
        mutex.withLock {
            val now = System.currentTimeMillis()
            var live = client != null && client!!.isReady() && mac.equals(address, true)
            if (live) {
                val idle = now - lastOkAt
                if (lastOkAt == 0L || idle > HARD_RECONNECT_MS) {
                    live = false
                } else {
                    // ColorOS "zombie" GATT: reports connected and accepts writes while the
                    // module is actually gone, so a command silently vanishes. Always prove
                    // the module answers (AES ping) BEFORE reusing the warm session. Nothing
                    // is sent on a link we haven't just verified — so no double-send risk.
                    try {
                        client!!.keepAlive()
                        lastOkAt = System.currentTimeMillis()
                    } catch (_: Exception) {
                        live = false
                    }
                }
            }
            if (!live) {
                dropClient()
                val c = OlaBleClient(ctx, address)
                try {
                    c.connect(scanFirst = true)
                    c.authenticate()
                } catch (e: Exception) {
                    try { c.closeSuspend() } catch (_: Exception) {}
                    throw e
                }
                client = c
                mac = address
                lastOkAt = System.currentTimeMillis()
            }
            try {
                val result = block(client!!)
                lastOkAt = System.currentTimeMillis()
                result
            } catch (e: Exception) {
                dropClient()
                val c = OlaBleClient(ctx, address)
                try {
                    c.connect(scanFirst = true)
                    c.authenticate()
                    client = c
                    mac = address
                    lastOkAt = System.currentTimeMillis()
                    val result = block(c)
                    lastOkAt = System.currentTimeMillis()
                    result
                } catch (e2: Exception) {
                    try { c.closeSuspend() } catch (_: Exception) {}
                    client = null
                    mac = null
                    throw e2
                }
            }
        }

    fun drop() {
        val c = client
        client = null
        mac = null
        lastOkAt = 0L
        try { c?.close() } catch (_: Exception) {}
    }
}

@SuppressLint("MissingPermission")
@Composable
fun BluetoothScreen(
    preferredMac: String,
    onMac: (String) -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    var mac by remember { mutableStateOf(preferredMac) }
    var status by remember { mutableStateOf("Scan → Pair & auth, then use the controls below.") }
    var busy by remember { mutableStateOf(false) }
    var granted by remember { mutableStateOf(false) }
    var devices by remember { mutableStateOf<List<BleDevice>>(emptyList()) }
    var pairedHint by remember { mutableStateOf(pairLabel(ctx, mac)) }
    var showDevice by remember { mutableStateOf(preferredMac.isBlank()) }
    var showDebug by remember { mutableStateOf(false) }
    // Gate the controls until a successful pair & auth this session.
    var authed by remember { mutableStateOf(false) }

    // Optimistic + broadcast lock state
    var lockedUi by remember { mutableStateOf(true) }
    var trunkOpen by remember { mutableStateOf(false) }
    var lockPhase by remember { mutableStateOf(ActionPhase.Idle) }
    var trunkPhase by remember { mutableStateOf(ActionPhase.Idle) }
    var flashPhase by remember { mutableStateOf(ActionPhase.Idle) }
    var flashHornPhase by remember { mutableStateOf(ActionPhase.Idle) }
    val inflight = remember { java.util.concurrent.atomic.AtomicInteger(0) }

    val bleBatt by BleStatus.state.collectAsStateWithLifecycle()
    LaunchedEffect(bleBatt?.locked, bleBatt?.ts) {
        val remote = bleBatt?.locked ?: return@LaunchedEffect
        if (lockPhase == ActionPhase.Idle) lockedUi = remote
    }

    DisposableEffect(Unit) { onDispose { BleSession.drop() } }

    val perms = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    val enableBt = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        granted = res.values.all { it }
    }
    LaunchedEffect(Unit) { launcher.launch(perms) }
    LaunchedEffect(mac) { pairedHint = pairLabel(ctx, mac); onMac(mac) }

    fun ensureBtOn(then: () -> Unit) {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (adapter == null) { status = "No Bluetooth adapter"; return }
        if (!adapter.isEnabled) {
            status = "Turning Bluetooth on…"
            enableBt.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            status = "Allow Bluetooth, then tap Scan again"
            return
        }
        then()
    }

    fun scan() {
        if (busy) return
        ensureBtOn {
            busy = true; status = "Scanning…"; devices = emptyList(); showDevice = true
            scope.launch {
                try {
                    val list = withContext(Dispatchers.IO) { BleScanner.scan(ctx, 6) }
                    devices = list
                    val ola = list.firstOrNull { it.name.equals("OLAS1", true) }
                    if (ola != null) {
                        mac = ola.address
                        status = "Found OLAS1 · ${ola.address}"
                    } else {
                        status = if (list.isEmpty()) "No devices found" else "Found ${list.size} — tap one"
                    }
                    pairedHint = pairLabel(ctx, mac)
                } catch (e: Exception) {
                    status = "Scan failed: ${e.message}"
                } finally { busy = false }
            }
        }
    }

    fun runCommand(
        label: String,
        value: Int?,
        onPhase: (ActionPhase) -> Unit = {},
        onSuccess: () -> Unit = {},
    ) {
        ensureBtOn {
            val addr = mac.trim()
            if (addr.isBlank()) {
                status = "Set an OLAS1 address first"
                showDevice = true
                return@ensureBtOn
            }
            val n = inflight.incrementAndGet()
            busy = true
            onPhase(ActionPhase.Pending)
            status = if (n > 1) "$label… (${n - 1} ahead)" else "$label…"
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        BleSession.withAuthed(ctx, addr) { client ->
                            if (value != null) client.command(value)
                        }
                    }
                    onPhase(ActionPhase.Success)
                    onSuccess()
                    authed = true
                    view.olaHaptic(true)
                    status = if (value == null) "Authorized ✓" else "$label done ✓"
                    pairedHint = pairLabel(ctx, addr)
                    delay(650)
                    onPhase(ActionPhase.Idle)
                } catch (e: Exception) {
                    onPhase(ActionPhase.Error)
                    view.olaHaptic(false)
                    status = "$label failed: ${e.message}"
                    pairedHint = pairLabel(ctx, addr)
                    delay(900)
                    onPhase(ActionPhase.Idle)
                } finally {
                    busy = inflight.decrementAndGet() > 0
                }
            }
        }
    }

    val scroll = rememberScrollState()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Accent) }
            Column(Modifier.weight(1f)) {
                Text("Proximity", style = MaterialTheme.typography.titleLarge, color = TextHi, fontWeight = FontWeight.Bold)
                Text("Bluetooth · own vehicle", style = MaterialTheme.typography.bodyMedium, color = TextMut)
            }
        }

        // Pair first: prominent call-to-action until authenticated this session.
        if (!authed) {
            Surface(
                color = Surface1,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Accent.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Pair with your scooter first", style = MaterialTheme.typography.titleMedium,
                        color = TextHi, fontWeight = FontWeight.Bold)
                    Text("Scan for OLAS1, then Pair & auth. Controls unlock once authenticated. " +
                        "Close the Ola app and PC GUI first — only one phone can hold BLE.",
                        color = TextMut, style = MaterialTheme.typography.bodyMedium)
                    Text(pairedHint,
                        color = if (pairedHint.startsWith("Already paired")) Ok else TextMut,
                        style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { scan() }, enabled = granted && !busy,
                            modifier = Modifier.weight(1f).height(52.dp)) { Text("Scan") }
                        Button(
                            onClick = { runCommand("Authenticate", null) },
                            enabled = granted && !busy && mac.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
                            modifier = Modifier.weight(1f).height(52.dp),
                        ) { Text("Pair & auth") }
                    }
                    // Scan results inline so the user can pick OLAS1 right here.
                    for (d in devices) {
                        val isOla = d.name.equals("OLAS1", ignoreCase = true)
                        val selected = mac.equals(d.address, true)
                        Surface(
                            color = if (selected) Accent.copy(alpha = 0.15f) else Surface2,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().clickableNoRipple { mac = d.address },
                        ) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(d.name.ifBlank { "(unnamed)" },
                                        color = if (isOla) Accent else TextHi,
                                        fontWeight = if (isOla) FontWeight.Bold else FontWeight.Normal)
                                    Text(d.address, color = TextMut, style = MaterialTheme.typography.bodySmall)
                                }
                                Text("${d.rssi} dBm", color = TextMut, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }

        // —— Ola-style vehicle home ——
        ScooterHero(locked = lockedUi)
        VehicleStatusHeader(locked = bleBatt?.locked, vehicleName = "Scooter")
        OlaControlCluster(
            locked = lockedUi,
            soc = bleBatt?.soc,
            rangeHint = bleBatt?.soc?.let { "$it%" },
            trunkOpen = trunkOpen,
            lockPhase = lockPhase,
            trunkPhase = trunkPhase,
            enabled = granted && mac.isNotBlank() && authed,
            onLockToggle = {
                val unlocking = lockedUi
                val label = if (unlocking) "Unlock" else "Lock"
                val cmd = OlaBleProto.COMMANDS[label] ?: return@OlaControlCluster
                runCommand(label, cmd, onPhase = { lockPhase = it }) {
                    lockedUi = !unlocking
                }
            },
            onTrunk = {
                val cmd = OlaBleProto.COMMANDS["Open trunk"] ?: return@OlaControlCluster
                runCommand("Trunk", cmd, onPhase = { trunkPhase = it }) {
                    trunkOpen = true
                    scope.launch {
                        delay(2500)
                        trunkOpen = false
                    }
                }
            },
        )

        Text(
            bleBatt?.let { "BLE status received: ${java.time.Instant.ofEpochMilli(it.ts)}" }
                ?: "No BLE status received. Controls reflect the last command until status arrives.",
            color = TextMut,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )

        // Secondary actions
        Text("More", style = MaterialTheme.typography.titleMedium, color = TextHi, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            ControlTile(
                title = "Flash",
                glyph = ControlGlyph.Drl,
                active = flashPhase == ActionPhase.Pending || flashPhase == ActionPhase.Success,
                subtitle = "BLE",
                enabled = granted && authed && OlaBleProto.COMMANDS["Flash lights"] != null,
                onClick = {
                    val v = OlaBleProto.COMMANDS["Flash lights"] ?: return@ControlTile
                    runCommand("Flash", v, onPhase = { flashPhase = it })
                },
                modifier = Modifier.weight(1f),
            )
            ControlTile(
                title = "Flash+horn",
                glyph = ControlGlyph.Horn,
                active = flashHornPhase == ActionPhase.Pending || flashHornPhase == ActionPhase.Success,
                subtitle = "BLE",
                enabled = granted && authed && OlaBleProto.COMMANDS["Flash + horn"] != null,
                onClick = {
                    val v = OlaBleProto.COMMANDS["Flash + horn"] ?: return@ControlTile
                    runCommand("Flash+horn", v, onPhase = { flashHornPhase = it })
                },
                modifier = Modifier.weight(1f),
            )
        }

        Surface(
            color = Surface1,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                if (busy) {
                    GlassSpinner(Modifier.size(18.dp), color = Accent)
                    Spacer(Modifier.width(10.dp))
                }
                Text(status, color = TextHi, style = MaterialTheme.typography.bodyMedium)
            }
        }

        // Device / pairing (collapsible)
        TextButton(onClick = { showDevice = !showDevice }) {
            Text(if (showDevice) "Hide device setup" else "Device setup · Scan & pair", color = Accent)
        }
        if (showDevice) {
            SectionCard("Device") {
                OutlinedTextField(
                    mac, { mac = it }, label = { Text("OLAS1 address") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    pairedHint,
                    color = if (pairedHint.startsWith("Already paired")) Ok else TextMut,
                    style = MaterialTheme.typography.bodyMedium,
                )
                if (!granted) {
                    Text("Grant Bluetooth permission to continue.", color = Warn, style = MaterialTheme.typography.bodySmall)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { scan() },
                        enabled = granted && !busy,
                        modifier = Modifier.weight(1f).height(48.dp),
                    ) { Text("Scan") }
                    Button(
                        onClick = { runCommand("Authenticate", null) },
                        enabled = granted && !busy,
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink),
                        modifier = Modifier.weight(1f).height(48.dp),
                    ) { Text("Pair & auth") }
                }
                for (d in devices) {
                    val isOla = d.name.equals("OLAS1", ignoreCase = true)
                    val selected = mac.equals(d.address, true)
                    Surface(
                        color = if (selected) Accent.copy(alpha = 0.15f) else Surface2,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().clickableNoRipple { mac = d.address },
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    d.name.ifBlank { "(unnamed)" },
                                    color = if (isOla) Accent else TextHi,
                                    fontWeight = if (isOla) FontWeight.Bold else FontWeight.Normal,
                                )
                                Text(d.address, color = TextMut, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("${d.rssi} dBm", color = TextMut, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }

        TextButton(onClick = { showDebug = !showDebug }) {
            Text(if (showDebug) "Hide debug log" else "Show debug log", color = TextMut)
        }
        if (showDebug) {
            val logLines by BleLog.lines.collectAsStateWithLifecycle()
            SectionCard("Debug log · ${logLines.size} lines") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "OpenOLA BLE log")
                            putExtra(Intent.EXTRA_TEXT, BleLog.text())
                        }
                        ctx.startActivity(Intent.createChooser(send, "Share BLE log"))
                    }, modifier = Modifier.weight(1f)) { Text("Share") }
                    OutlinedButton(onClick = { BleLog.clear() }, modifier = Modifier.weight(1f)) { Text("Clear") }
                }
                Surface(color = Ink, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.height(200.dp).verticalScroll(rememberScrollState()).padding(10.dp)) {
                        if (logLines.isEmpty()) {
                            Text(
                                "No log yet — Pair & auth or tap a control.",
                                color = TextMut,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        for (ln in logLines.takeLast(250)) {
                            Text(
                                ln, color = TextMut, fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall, softWrap = false,
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@SuppressLint("MissingPermission")
private fun pairLabel(ctx: Context, mac: String): String {
    return try {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
            ?: return "Bluetooth unavailable"
        if (!adapter.isEnabled) return "Bluetooth is off — will ask to turn on"
        if (mac.isBlank()) return "Enter or scan an OLAS1 address"
        val device = adapter.getRemoteDevice(mac.trim())
        when (device.bondState) {
            BluetoothDevice.BOND_BONDED -> "Already paired with this address"
            BluetoothDevice.BOND_BONDING -> "Pairing in progress…"
            else -> "Not paired yet — Pair & auth will bond (Just Works)"
        }
    } catch (_: Exception) {
        "Pairing status unknown"
    }
}
