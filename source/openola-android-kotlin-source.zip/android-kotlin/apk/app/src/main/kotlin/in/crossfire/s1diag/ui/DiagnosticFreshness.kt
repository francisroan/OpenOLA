package `in`.crossfire.s1diag.ui
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import `in`.crossfire.s1diag.vm.UiState
import `in`.crossfire.s1diag.vm.BatteryStatus

const val STALE_AFTER_MS = 10_000L
fun telemetryAgeMs(lastFrameAt: Long, now: Long): Long? =
    if (lastFrameAt <= 0L) null else (now - lastFrameAt).coerceAtLeast(0L)
fun freshnessText(lastFrameAt: Long, now: Long, demo: Boolean = false): String {
    if (demo) return "Simulated telemetry · demo"
    val age = telemetryAgeMs(lastFrameAt, now) ?: return "Waiting for received CAN frames"
    return if (age > STALE_AFTER_MS) "CAN data stale · last frame ${age / 1000}s ago"
    else "CAN receiving · last frame ${age / 1000}s ago"
}
@Composable
fun rememberUiClock(): State<Long> = produceState(System.currentTimeMillis()) {
    while (true) { delay(1000); value = System.currentTimeMillis() }
}

/** The legacy demo produces live rows only. Present those simulated rows on Home too. */
fun withDemoBattery(ui: UiState): UiState {
    if (!ui.demo || ui.battery != null || ui.live.isEmpty()) return ui
    fun signal(name: String) = ui.live.firstOrNull { it.signal == name }?.value
    return ui.copy(battery = BatteryStatus(
        soc = signal("Overall_SOC"), packVolts = signal("MCU_Voltage"), packAmps = signal("Pack_Current"),
        motorTemp = signal("Motor_Temprature"), mcuTemp = signal("MCU_Temperatute"),
        speedKmh = signal("Vehicle_Speed"), ts = ui.live.maxOf { it.ts },
    ))
}
