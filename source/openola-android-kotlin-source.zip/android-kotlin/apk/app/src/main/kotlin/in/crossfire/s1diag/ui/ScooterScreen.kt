package `in`.crossfire.s1diag.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.data.Actuator
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.DiagViewModel

private data class Featured(
    val title: String,
    val glyph: ControlGlyph,
    val pulse: Boolean = false,
    val did: Int? = null,
    val danger: Boolean = false,
    val wifiSpecial: String? = null, // lock | unlock | trunk
)

private val FEATURED = listOf(
    Featured("Horn", ControlGlyph.Horn, pulse = true, did = 0x0410),
    Featured("DRL", ControlGlyph.Drl, did = 0x0405),
    Featured("Low beam", ControlGlyph.LowBeam, did = 0x0406),
    Featured("High beam", ControlGlyph.HighBeam, did = 0x0407),
    Featured("Left ind.", ControlGlyph.LeftIndicator, did = 0x0409),
    Featured("Right ind.", ControlGlyph.RightIndicator, did = 0x0408),
    Featured("Brake light", ControlGlyph.BrakeLight, did = 0x040A),
    Featured("Lock", ControlGlyph.Lock, wifiSpecial = "lock", danger = true),
    Featured("Unlock", ControlGlyph.Unlock, wifiSpecial = "unlock", danger = true),
    Featured("Trunk", ControlGlyph.Trunk, wifiSpecial = "trunk", danger = true),
)

@Composable
fun ScooterScreen(vm: DiagViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf<Actuator?>(null) }
    var groupTab by remember { mutableStateOf(vm.catalog.actuatorGroups.firstOrNull() ?: "Lights & signals") }
    var featuredConfirm by remember { mutableStateOf<Featured?>(null) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            SectionCard("Operating mode") {
                val isService = ui.mode.equals("SERVICE", true)
                val isCust = ui.mode.startsWith("CUST", true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { vm.setMode("SERVICE") },
                        modifier = Modifier.weight(1f).height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isService) Accent else Surface2,
                            contentColor = if (isService) Ink else TextHi,
                        ),
                    ) { Text("Service") }
                    Button(
                        onClick = { vm.setMode("CUST") },
                        modifier = Modifier.weight(1f).height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCust) Accent else Surface2,
                            contentColor = if (isCust) Ink else TextHi,
                        ),
                    ) { Text("Customer") }
                    OutlinedButton(onClick = { vm.refreshInfo() }, modifier = Modifier.height(48.dp)) {
                        Text("↻")
                    }
                }
                StatusLine("Mode: ${ui.mode}" + if (ui.unlockedVcu) " · VCU unlocked" else "",
                    if (isService) Ok else TextMut)
                if (!ui.bench) {
                    Text("Tick the parked/charger-disconnected box in the header to enter Service " +
                        "automatically and run active tests.", color = Warn,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            Text("Quick controls", style = MaterialTheme.typography.titleMedium, color = TextHi, fontWeight = FontWeight.SemiBold)
            val lockLine = when (ui.vehicleLocked) {
                true -> "Scooter is LOCKED (from CAN) — only Unlock is offered." to Warn
                false -> "Scooter is UNLOCKED (from CAN) — only Lock is offered." to Ok
                null -> "Lock state unknown (waiting for 0x6BF) — both offered." to TextMut
            }
            StatusLine(lockLine.first, lockLine.second)
            Text(
                "Horn = short pulse. Lights & trunk latch until you tap again. Lock/Unlock send Wi‑Fi UDS (experimental).",
                style = MaterialTheme.typography.bodyMedium, color = TextMut,
            )
        }

        item {
            FeaturedGrid(ui.latched, ui.busy, ui.vehicleLocked) { f ->
                when {
                    f.wifiSpecial == "lock" || f.wifiSpecial == "unlock" || f.wifiSpecial == "trunk" ->
                        featuredConfirm = f
                    f.pulse -> {
                        val act = vm.actuatorByLabel("Horn") ?: Actuator("Horn", f.did!!, "Lights & signals", false)
                        vm.pulse(act)
                    }
                    f.danger -> featuredConfirm = f
                    else -> {
                        val label = catalogLabel(f)
                        val did = f.did ?: return@FeaturedGrid
                        vm.toggleLatch(label, did, false)
                    }
                }
            }
        }

        item {
            Text("All tests by group", style = MaterialTheme.typography.titleMedium, color = TextHi, fontWeight = FontWeight.SemiBold)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for (g in vm.catalog.actuatorGroups) {
                    val danger = g == "Power & HV"
                    Chip(if (danger) "⚠ $g" else g, groupTab == g) { groupTab = g }
                }
            }
        }

        item {
            AnimatedVisibility(visible = true) {
                val acts = vm.catalog.actuatorsIn(groupTab)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (groupTab == "Power & HV") {
                        Text(
                            "Contactors, locks, chargers, rails — hold-to-confirm required.",
                            style = MaterialTheme.typography.bodyMedium, color = Danger,
                        )
                    }
                    for (act in acts) {
                        val active = act.label in ui.latched ||
                            (act.label.equals("Seat Lock", true) && "Trunk" in ui.latched)
                        TextActuatorRow(act, active) {
                            if (act.danger) confirm = act
                            else if (isLatchable(act)) vm.toggleLatch(act.label, act.did, act.danger)
                            else vm.pulse(act)
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(20.dp)) }
    }

    confirm?.let { act ->
        ConfirmWithTimer(
            title = "Control ${act.label}?",
            message = "VCU DID ${"%04X".format(act.did)}. Hold confirms a live output.",
            confirmLabel = "Run",
            onConfirm = {
                if (isLatchable(act)) vm.toggleLatch(act.label, act.did, true)
                else vm.pulse(act)
                confirm = null
            },
            onDismiss = { confirm = null },
        )
    }

    featuredConfirm?.let { f ->
        ConfirmWithTimer(
            title = when (f.wifiSpecial) {
                "lock" -> "Wi‑Fi Lock?"
                "unlock" -> "Wi‑Fi Unlock?"
                "trunk" -> "Trunk (Seat Lock)?"
                else -> "${f.title}?"
            },
            message = when (f.wifiSpecial) {
                "lock" -> "Sends Steering Lock 0400 ON, then BF07 sequence. Experimental — check the scooter."
                "unlock" -> "Sends Steering Lock 0400 OFF, then BF07 sequence. Experimental — check the scooter."
                "trunk" -> "Toggles Seat Lock 0402 over Wi‑Fi (trunk). Latches until you tap again."
                else -> "Latches DID ${"%04X".format(f.did ?: 0)} until tapped again."
            },
            confirmLabel = "Send",
            onConfirm = {
                when (f.wifiSpecial) {
                    "lock" -> vm.wifiLock()
                    "unlock" -> vm.wifiUnlock()
                    "trunk" -> vm.wifiTrunkToggle()
                    else -> f.did?.let { vm.toggleLatch(catalogLabel(f), it, f.danger) }
                }
                featuredConfirm = null
            },
            onDismiss = { featuredConfirm = null },
        )
    }
}

private fun catalogLabel(f: Featured): String = when (f.glyph) {
    ControlGlyph.Drl -> "Front DRL"
    ControlGlyph.LowBeam -> "Front light low beam"
    ControlGlyph.HighBeam -> "Front light high beam"
    ControlGlyph.LeftIndicator -> "Left Indicators"
    ControlGlyph.RightIndicator -> "Right Indicators"
    ControlGlyph.BrakeLight -> "Rear Brake light"
    ControlGlyph.Horn -> "Horn"
    else -> f.title
}

private fun isLatchable(act: Actuator): Boolean {
    val n = act.label.lowercase()
    if (n == "horn") return false
    return n.contains("beam") || n.contains("drl") || n.contains("indicator") ||
        n.contains("brake") || n.contains("light") || n.contains("lock") ||
        n.contains("lamp") || n.contains("position")
}

@Composable
private fun FeaturedGrid(latched: Set<String>, busy: Boolean, vehicleLocked: Boolean?, onClick: (Featured) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FEATURED.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                for (f in row) {
                    // Lock/Unlock reflect the real physical state from CAN, not the assumed latch.
                    val active = when (f.wifiSpecial) {
                        "lock" -> vehicleLocked ?: ("Lock" in latched)
                        "unlock" -> vehicleLocked?.not() ?: ("Unlock" in latched)
                        "trunk" -> "Trunk" in latched
                        else -> catalogLabel(f) in latched
                    }
                    // Only offer the action that changes state: hide Lock when already locked, etc.
                    val enabled = when (f.wifiSpecial) {
                        "lock" -> (!busy) && vehicleLocked != true
                        "unlock" -> (!busy) && vehicleLocked != false
                        else -> !busy || f.pulse
                    }
                    ControlTile(
                        title = f.title,
                        glyph = f.glyph,
                        active = active,
                        subtitle = when {
                            f.wifiSpecial == "lock" && vehicleLocked == true -> "locked"
                            f.wifiSpecial == "unlock" && vehicleLocked == false -> "unlocked"
                            f.pulse -> if (busy) "…" else "pulse"
                            active -> "ON"
                            else -> "tap"
                        },
                        danger = f.danger,
                        enabled = enabled,
                        onClick = { onClick(f) },
                        modifier = Modifier.weight(1f),
                    )
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun TextActuatorRow(act: Actuator, active: Boolean, onClick: () -> Unit) {
    val border = when {
        active -> Accent
        act.danger -> Danger.copy(alpha = 0.5f)
        else -> Line
    }
    Surface(
        color = if (active) Accent.copy(alpha = 0.12f) else Surface1,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, border),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier.clickableNoRipple(onClick).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(act.label, style = MaterialTheme.typography.bodyLarge, color = if (act.danger) Danger else TextHi)
                Text(
                    "DID ${"%04X".format(act.did)} · ${if (isLatchable(act)) "latch" else "pulse"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMut,
                    fontFamily = Mono,
                )
            }
            Text(
                if (active) "ON" else if (act.danger) "HOLD" else "TEST",
                style = MaterialTheme.typography.labelLarge,
                color = if (active) Accent else if (act.danger) Danger else Accent,
            )
        }
    }
}
