package `in`.crossfire.s1diag.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.Conn
import `in`.crossfire.s1diag.vm.DiagViewModel

@Composable
fun ConnectScreen(vm: DiagViewModel, destination: String? = null) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var advanced by rememberSaveable { mutableStateOf(false) }
    var scanMessage by rememberSaveable { mutableStateOf<String?>(null) }
    val connecting = ui.conn == Conn.CONNECTING
    val validHost = ui.host.trim().isNotEmpty() && ui.host.none { it.isWhitespace() || it == '/' || it == ':' }
    val validPort = ui.port.toIntOrNull()?.let { it in 1..65535 } == true
    LazyColumn(
        modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(destination?.let { "Connect for $it" } ?: "Connect your scooter", style = MaterialTheme.typography.headlineLarge)
                Text("Join the scooter’s diagnostic Wi-Fi to inspect battery readings, understand faults and export reports.", color = TextMut, style = MaterialTheme.typography.bodyLarge)
            }
        }
        item {
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(color = AccentGlow, shape = RoundedCornerShape(14.dp)) {
                        Icon(GlassIcons.Wifi, null, tint = Accent, modifier = Modifier.padding(12.dp).size(26.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Wi-Fi diagnostics", style = MaterialTheme.typography.titleMedium)
                        Text("Join the scooter hotspot first", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                OutlinedTextField(
                    value = ui.host, onValueChange = vm::setHost,
                    label = { Text("Scooter address") }, singleLine = true, enabled = !connecting,
                    isError = !validHost,
                    supportingText = { Text(if (validHost) "Address is remembered after connecting." else "Enter an IP address or hostname.") },
                    trailingIcon = {
                        IconButton(enabled = !connecting, onClick = {
                            val options = com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions.Builder()
                                .setBarcodeFormats(com.google.mlkit.vision.barcode.common.Barcode.FORMAT_QR_CODE).build()
                            com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(context, options)
                                .startScan().addOnSuccessListener { barcode ->
                                    val raw = barcode.rawValue.orEmpty()
                                    val ip = Regex("\\b(?:[0-9]{1,3}\\.){3}[0-9]{1,3}\\b").find(raw)?.value
                                    if (ip != null) { vm.setHost(ip); scanMessage = "Address loaded from QR." }
                                    else scanMessage = "No diagnostic IP in this QR. Join its Wi-Fi hotspot, then enter the address."
                                }.addOnFailureListener { scanMessage = it.message ?: "QR scan unavailable. Enter the address manually." }
                        }) { Icon(Icons.Outlined.QrCodeScanner, "Scan scooter QR") }
                    }, modifier = Modifier.fillMaxWidth(),
                )
                scanMessage?.let { Text(it, color = TextMut, style = MaterialTheme.typography.bodySmall) }
                TextButton(onClick = { advanced = !advanced }, enabled = !connecting) {
                    Text(if (advanced) "Hide connection options" else "Connection options")
                    Icon(if (advanced) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, null)
                }
                AnimatedVisibility(advanced) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            ui.port, vm::setPort, label = { Text("Port") }, singleLine = true, isError = !validPort,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            supportingText = { Text("1–65535 · default 50005") }, modifier = Modifier.fillMaxWidth(),
                        )
                        SettingToggle("Secure connection (mTLS)", "Use only when the scooter requires mutual TLS.", ui.secure, onCheckedChange = vm::setSecure)
                    }
                }
                if (ui.conn == Conn.ERROR) {
                    Text("Could not connect. Check the scooter hotspot and address, then try again.", color = Danger, style = MaterialTheme.typography.bodyMedium)
                }
                Button(
                    onClick = { if (connecting) vm.cancelConnect() else { vm.setDemo(false); vm.connect() } },
                    enabled = connecting || (validHost && validPort),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp), shape = RoundedCornerShape(16.dp),
                ) {
                    if (connecting) { GlassSpinner(Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary); Spacer(Modifier.width(10.dp)) }
                    Text(if (connecting) "Cancel connection" else "Connect to scooter")
                    if (!connecting) { Spacer(Modifier.width(8.dp)); Icon(Icons.Outlined.ArrowForward, null, Modifier.size(18.dp)) }
                }
            }
        }
        item {
            SectionCard("Three steps to connect") {
                ConnectionStep("1", "Enable diagnostic Wi-Fi", "Use your existing method on the scooter.")
                ConnectionStep("2", "Join the scooter hotspot", "Connect this phone to that Wi-Fi network.")
                ConnectionStep("3", "Connect in OpenOLA", "Use the diagnostic address above.")
                OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                    Icon(GlassIcons.Wifi, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Open Wi-Fi settings")
                }
            }
        }
        item {
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Explore, null, tint = Accent)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Explore without a scooter", style = MaterialTheme.typography.titleMedium)
                        Text("Demo data is clearly labelled.", style = MaterialTheme.typography.bodyMedium, color = TextMut)
                    }
                }
                OutlinedButton(onClick = { vm.setDemo(true); vm.connect() }, enabled = !connecting, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Open demo") }
            }
        }
    }
}
@Composable
private fun ConnectionStep(number: String, title: String, description: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(color = Surface2, shape = RoundedCornerShape(10.dp)) {
            Text(number, color = Accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
        }
        Column { Text(title, style = MaterialTheme.typography.labelLarge); Text(description, color = TextMut, style = MaterialTheme.typography.bodyMedium) }
    }
}
