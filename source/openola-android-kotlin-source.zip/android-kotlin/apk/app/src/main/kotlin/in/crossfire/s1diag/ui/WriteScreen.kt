package `in`.crossfire.s1diag.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.data.Setting
import `in`.crossfire.s1diag.data.SettingCodec
import `in`.crossfire.s1diag.uds.Ecu
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.DiagViewModel

@Composable
fun WriteScreen(vm: DiagViewModel) {
    var ecuName by remember { mutableStateOf("MCU") }
    val ecu = Ecu.valueOf(ecuName)
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Setting?>(null) }

    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionCard("Parameters (2E write)") {
            EcuSelector(ecuName) { ecuName = it; selected = null }
            Text("These are the ECU's raw calibration values. Ranges are ODX encoding bounds, NOT verified safe limits. " +
                "Writing BMS/MCU config affects battery safety, range, thermal limits — one value at a time, record originals.",
                style = MaterialTheme.typography.bodyMedium, color = Warn)
        }
        if (selected == null) {
            OutlinedTextField(search, { search = it }, label = { Text("Search parameter") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            val list = vm.catalog.settingsFor(ecu).filter { search.isEmpty() || it.name.lowercase().contains(search.lowercase()) }
            Text("${list.size} parameters", style = MaterialTheme.typography.bodyMedium, color = TextMut)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                items(list) { s ->
                    Surface(color = Surface1, shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Line), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.clickableNoRipple { selected = s }.padding(13.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(s.name, color = TextHi, style = MaterialTheme.typography.bodyMedium)
                                Text("DID ${"%04X".format(s.did)} · ${s.fields.size} field(s)", color = TextMut, fontFamily = Mono, style = MaterialTheme.typography.bodyMedium)
                            }
                            Text("EDIT", color = Accent, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        } else {
            SettingEditor(vm, selected!!) { selected = null }
        }
    }
}

@Composable
private fun SettingEditor(vm: DiagViewModel, s: Setting, onBack: () -> Unit) {
    val values = remember(s) { mutableStateMapOf<String, String>() }
    val original = remember(s) { mutableStateMapOf<String, Double>() }
    var rawBytes by remember(s) { mutableStateOf<ByteArray?>(null) }
    var reversed by remember(s) { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }

    // (re)compute displayed values from the stored raw bytes + byte order.
    fun recompute() {
        val b = rawBytes ?: return
        val vals = SettingCodec.decode(s, b, reversed)
        vals.forEach { (k, v) -> values[k] = fmtNum(v); original[k] = v }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Back", color = TextMut) }
            Text(s.name, color = TextHi, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        }
        
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(color = Warn.copy(alpha = 0.12f), shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Warn.copy(alpha = 0.5f)), modifier = Modifier.fillMaxWidth()) {
                Text("UNVERIFIED decode. The diagnostic app reverses these config bytes; correct byte order is unconfirmed. " +
                    "Read, then flip 'Reverse byte order' and check which makes a % field land in 0–100. Verify before writing.",
                    color = Warn, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(12.dp))
            }
            SectionCard {
                Text("${s.ecu.name} DID ${"%04X".format(s.did)} · ${s.lengthBytes} bytes", color = TextMut, fontFamily = Mono, style = MaterialTheme.typography.bodyMedium)
                rawBytes?.let { Text("raw: ${it.joinToString(" ") { b -> "%02X".format(b) }}", color = TextHi, fontFamily = Mono, style = MaterialTheme.typography.bodyMedium) }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.readParam(s) { _, bytes -> rawBytes = bytes; recompute() } },
                        modifier = Modifier.heightIn(min = 52.dp).weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink)) { Text("Read current") }
                    Checkbox(reversed, { reversed = it; recompute() }, colors = CheckboxDefaults.colors(checkedColor = Accent))
                    Text("Reverse byte order", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (rawBytes != null && values.isNotEmpty()) {
                val raws = SettingCodec.rawFields(s, rawBytes!!, reversed)
                for (f in s.fields) {
                    SectionCard {
                        Text(f.name, color = TextHi, style = MaterialTheme.typography.bodyMedium)
                        Text("${f.unit.ifEmpty { "—" }}  ·  range ${f.min ?: "?"}–${f.max ?: "?"}  ·  step ${f.resolution}  ·  raw ${raws[f.name]}",
                            color = TextMut, style = MaterialTheme.typography.bodyMedium, fontFamily = Mono)
                        OutlinedTextField(values[f.name] ?: "", { values[f.name] = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                }
                Button(onClick = { confirm = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Danger, contentColor = MaterialTheme.colorScheme.onError),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Write ${s.name}") }
                Text("Write re-reads current bytes, patches only changed fields (same byte order), then verifies by read-back. " +
                    "No auto-retry/rollback. Reboot persistence unverified.", style = MaterialTheme.typography.bodyMedium, color = TextMut)
            }
        }
    }

    if (confirm) {
        val edits = buildEdits(values, original)
        ConfirmWithTimer(
            title = "Write ${s.name}?",
            message = if (edits.isEmpty()) "No values changed." else
                "Changing: " + edits.entries.joinToString("; ") { "${it.key}=${fmtNum(it.value)}" } +
                ".\nByte order: ${if (reversed) "reversed" else "as-is"}. This alters vehicle behaviour and may persist. " +
                "Ranges are not verified safe limits.",
            confirmLabel = "Write",
            onConfirm = { if (edits.isNotEmpty()) vm.writeParam(s, edits, reversed); confirm = false },
            onDismiss = { confirm = false },
        )
    }
}

private fun buildEdits(values: Map<String, String>, original: Map<String, Double>): Map<String, Double> {
    val out = LinkedHashMap<String, Double>()
    for ((k, txt) in values) {
        val v = txt.trim().toDoubleOrNull() ?: continue
        val o = original[k]
        if (o == null || kotlin.math.abs(v - o) > 1e-9) out[k] = v
    }
    return out
}

private fun fmtNum(v: Double): String = if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()
