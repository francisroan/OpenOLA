package `in`.crossfire.s1diag.uds

/**
 * Security-access seed -> key algorithm, ported from the app's SeedKeyAlgoHelper
 * and VERIFIED ON THE VEHICLE (firmware 5.0.0, 2026-09-11).
 *
 * Firmware 5.0.0 sends the seed as an 8-char ASCII hex string (e.g. the wire
 * bytes 46 37 44 36 41 32 45 33 = the text "F7D6A2E3"); those 8 ASCII bytes are
 * the input the transform expects.
 *
 *  * seed length != 8 -> "old key": per byte ((b xor 0x33) + 1) xor 0x96
 *  * seed length == 8 -> "new key": getKey grid transform. CRUCIAL: the wire key
 *    is the grid's ASCII values, NOT getKey()'s packed return. The app's
 *    onReceivedSeed sends getTypeSafeString(key) as NEW_SEED_DATA, and the write
 *    decodeHexString's it, which undoes getKey()'s parseInt(toHexString()) packing.
 *    Verified: seed "F7D6A2E3" -> key "48153568". Sending the packed bytes was
 *    rejected NRC 0x35; sending the grid ASCII unlocked the VCU.
 */
object SeedKey {

    // getKey() constant vectors, per ECU and security level ("01" vs other)
    private val KEY_CONST: Map<Ecu, Pair<IntArray, IntArray>> = mapOf(
        //                           level "01"                other levels
        Ecu.BMS to (intArrayOf(54, 43, 79, 19) to intArrayOf(77, 13, 53, 47)),
        Ecu.VCU to (intArrayOf(99, 61, 69, 19) to intArrayOf(30, 43, 5, 62)),
        Ecu.MCU to (intArrayOf(39, 67, 2, 23) to intArrayOf(39, 67, 2, 23)),
    )

    fun generateKey(seed: ByteArray, ecu: Ecu, level: String = "01"): ByteArray =
        if (seed.size != 8) oldKey(seed) else newKey(seed, ecu, level)

    private fun oldKey(seed: ByteArray): ByteArray {
        val out = ByteArray(seed.size)
        for (i in seed.indices) {
            val b = seed[i].toInt() and 0xFF
            out[i] = ((((b xor 0x33) + 1) xor 0x96) and 0xFF).toByte()
        }
        return out
    }

    private fun dec2hex(v: Int): IntArray {
        val lo0 = v % 16
        val lo = if (lo0 >= 10) lo0 + 55 else lo0 + 48
        val hi0 = (v / 16) % 16
        val hi = if (hi0 >= 10) hi0 + 55 else hi0 + 48
        return intArrayOf(lo, hi)
    }

    private fun hex2dec(pair: IntArray): Int {
        val c0 = pair[0]; val c1 = pair[1]
        var v = 0
        if (c0 in 48..57) v += (c0 - 48) * 1
        else if (c0 in 65..70) v += (c0 - 55) * 1
        if (c1 in 48..57) v += (c1 - 48) * 16
        else if (c1 in 65..70) v += (c1 - 55) * 16
        return v
    }

    private fun randomNumberTester(seedInts: IntArray, consts: IntArray): IntArray {
        val d = seedInts.copyOf()
        val m = Array(4) { IntArray(2) }
        m[0][0] = d[0]; m[0][1] = d[1]
        m[1][0] = d[2]; m[1][1] = d[3]
        m[2][0] = d[4]; m[2][1] = d[5]
        m[3][0] = d[6]; m[3][1] = d[7]
        val tmp = m[0][0]
        m[0][0] = m[1][0]; m[1][0] = m[2][0]; m[2][0] = m[3][0]; m[3][0] = tmp
        val x = intArrayOf(hex2dec(m[0]), hex2dec(m[1]), hex2dec(m[2]), hex2dec(m[3]))
        val y = IntArray(4) { ((x[it] - consts[it] + 127) % 127) }
        return IntArray(4) { (((y[it] * 91) + 75 + 127) % 127) }
    }

    private fun keyP(p: IntArray): Array<IntArray> {
        val a = ((((p[0] * 7) + 255) % 255) xor 23)
        val b = ((((p[1] * 5) + 255) % 255) xor 67)
        val c = ((((p[2] * 1) + 255) % 255) xor 8)
        val dd = ((((8 * p[3]) + 255) % 255) xor 45)
        val out = arrayOf(dec2hex(a xor b), dec2hex(b xor c), dec2hex(c xor dd), dec2hex(dd xor a))
        return out
    }

    private fun testerKey(seedInts: IntArray, consts: IntArray): IntArray {
        val grid = keyP(randomNumberTester(seedInts, consts))
        val key = IntArray(8)
        for (r in 0 until 4) for (col in 0 until 2) key[r * 2 + col] = grid[r][col]
        return key
    }

    private fun newKey(seed: ByteArray, ecu: Ecu, level: String): ByteArray {
        val seedInts = IntArray(8) { seed[it].toInt() and 0xFF }
        val pair = KEY_CONST[ecu]!!
        val consts = if (level == "01") pair.first else pair.second
        val keyInts = testerKey(seedInts, consts)
        // Wire key = the grid ASCII codes directly (getKey's packing is undone on
        // the wire by getTypeSafeString + decodeHexString). Do NOT re-pack here.
        return ByteArray(8) { (keyInts[it] and 0xFF).toByte() }
    }
}
