package `in`.crossfire.s1diag.vm

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import `in`.crossfire.s1diag.data.*
import `in`.crossfire.s1diag.net.WifiCanClient
import `in`.crossfire.s1diag.uds.Ecu
import `in`.crossfire.s1diag.uds.Fault
import `in`.crossfire.s1diag.uds.Uds
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import wifican.Wifican
import java.util.concurrent.ConcurrentHashMap

enum class Conn { IDLE, CONNECTING, CONNECTED, ERROR }

data class LiveRow(val id: Int, val message: String, val signal: String, val value: Double, val unit: String, val ts: Long)

/** Snapshot of the pack/vehicle status for the battery UI. */
data class BatteryStatus(
    val soc: Double? = null,        // %
    val rangeKm: Double? = null,    // km
    val packVolts: Double? = null,  // V
    val packAmps: Double? = null,   // A (+charge / −discharge sign per DBC)
    val motorTemp: Double? = null,  // °C
    val mcuTemp: Double? = null,    // °C
    val battTemp: Double? = null,   // °C
    val charging: Boolean = false,
    val chargerConnected: Boolean = false,
    val speedKmh: Double? = null,
    val ts: Long = 0L,
)
data class VehicleInfo(val vin: String, val sw: String, val aosp: String, val manifest: String)
data class WatchEvent(val ts: Long, val set: Boolean, val name: String)
data class ModeEvent(val ts: Long, val text: String)
data class NotifEvent(val ts: Long, val code: Int, val name: String, val alert: Boolean)
/** Extra charge fields decoded from the vehicle-CAN mirror (MoveOS 5). */
data class ChargeInfo(
    val type: String? = null,        // None/Fast/Slow/Boost
    val plugged: Boolean = false,
    val billing: Boolean = false,
    val connectorLatched: Boolean = false,
    val evseId: String? = null,
    val mode: String? = null,        // charging mode enum
)

/** Head-unit self-tests via RemoteRunTestCmd (all _TEST_START=1 / _TEST_STOP=2). */
enum class SelfTest(val label: String, val cmd: Wifican.RmtCmdList, val stop: Boolean) {
    LCD("LCD / display", Wifican.RmtCmdList.RMT_CMD_LCD_TEST, true),
    GPS("GPS", Wifican.RmtCmdList.RMT_CMD_GPS_TEST, true),
    BT("Bluetooth", Wifican.RmtCmdList.RMT_CMD_BT_TEST, true),
    BLE("BLE", Wifican.RmtCmdList.RMT_CMD_BLE_TEST, true),
    WIFI("Wi-Fi", Wifican.RmtCmdList.RMT_CMD_WIFI_TEST, true),
    SPKR("Speaker beep", Wifican.RmtCmdList.RMT_CMD_SPKR_TEST, true),
    MIC("Microphone", Wifican.RmtCmdList.RMT_CMD_MIC_TEST, true),
    ESIM("eSIM", Wifican.RmtCmdList.RMT_CMD_ESIM_TEST, true),
    VIN("Read VIN", Wifican.RmtCmdList.RMT_CMD_VIN, false),
}

data class UiState(
    val conn: Conn = Conn.IDLE,
    val host: String = "192.168.4.1",
    val port: String = "50005",
    val secure: Boolean = false,
    val bench: Boolean = false,
    val demo: Boolean = false,
    val mode: String = "unknown",
    val firmware: String = "unknown",
    val busy: Boolean = false,
    val message: String? = null,
    val unlockedVcu: Boolean = false,
    val faults: Map<Ecu, List<Fault>> = emptyMap(),
    val live: List<LiveRow> = emptyList(),
    val liveOn: Boolean = false,
    val info: VehicleInfo? = null,
    val watchOn: Boolean = false,
    val watchActive: List<String> = emptyList(),
    val watchLog: List<WatchEvent> = emptyList(),
    val modeOn: Boolean = false,
    val rideMode: String = "—",
    val modeLog: List<ModeEvent> = emptyList(),
    /** Labels of latched-ON actuators (lights, trunk, steering lock, …). */
    val latched: Set<String> = emptySet(),
    val bleMac: String = "00:00:00:00:00:00",
    // Auto status/fault monitor (Wi-Fi CAN broadcast, no per-ECU query).
    val battery: BatteryStatus? = null,
    /** UI observability only: latest frame arrival, not the time cached values were decoded. */
    val lastCanFrameAt: Long = 0L,
    val activeFaults: List<String> = emptyList(),
    val autoLogOn: Boolean = false,
    val chargeSnoopOn: Boolean = false,
    val chargeSnoopFile: String? = null,
    val motorAngleDeg: Double? = null,
    /** Last odometer read/write result, in km (VCU DID 0103). */
    val odometerKm: Int? = null,
    /** Absolute path / SAF display of the current activity log session file. */
    val activityLogPath: String? = null,
    val activityDirLabel: String = "",
    val chargeDirLabel: String = "",
    // ---- real vehicle state pulled from broadcast CAN (not assumed) ----
    /** Physical steering-lock state from 0x6BF Steering_Lock_12V supply (null = unknown). */
    val vehicleLocked: Boolean? = null,
    // ---- MoveOS 5 additions ----
    val chargeInfo: ChargeInfo? = null,
    val notifications: List<NotifEvent> = emptyList(),
    val featuresBool: List<Pair<String, Boolean>> = emptyList(),
    val featuresTp: List<Pair<String, Int>> = emptyList(),
)

class DiagViewModel(app: Application) : AndroidViewModel(app) {

    val dtc = DtcCatalog.load(app)
    val dbc = Dbc.load(app)
    val catalog = Catalog.load(app)

    // Broadcast IDs added to the filtered diag stream so live faults + battery
    // flow continuously without the write-starving dump stream.
    private val BATTERY_IDS = listOf(0x353, 0x120, 0x121, 0x11C, 0x62D, 0x640, 0x313, 0x130, 0x213, 0x143, 0x180, 0x190)
    // MoveOS 5: physical lock (0x6BF), feature status (0x660), notifications (0x6D0),
    // fast-charge + EVSE id (0x508/0x584/0x585), command ack (0x6C0).
    private val MOVEOS5_IDS = listOf(0x6BF, 0x660, 0x6D0, 0x508, 0x584, 0x585, 0x6C0)
    private fun streamIds(): List<Int> =
        (Ecu.values().flatMap { listOf(it.reqId, it.respId) }
            + FaultBits.REGISTER_IDS
            + BATTERY_IDS
            + MOVEOS5_IDS
            + ChargeSessionLog.WATCH_IDS).distinct()

    private var monitorTick: Job? = null
    private val loggedFaults = HashSet<String>()
    private var lastVitalsLogAt = 0L

    private var client: WifiCanClient? = null
    private var uds: Uds? = null
    private val unlocked = HashSet<Ecu>()
    private val securityFailed = HashSet<Ecu>()
    private var keepAlive: Job? = null
    private var liveTick: Job? = null
    private var watchTick: Job? = null
    private var modeTick: Job? = null
    private var connectJob: Job? = null
    private val watchState = HashSet<String>()
    private var lastRideRaw = ""
    private var lastNotifCode = -1
    private val latestRaw = ConcurrentHashMap<Int, Pair<Long, ByteArray>>()
    private val prefs = app.getSharedPreferences("s1diag", Context.MODE_PRIVATE)

    companion object {
        const val DID_STEERING_LOCK = 0x0400
        const val DID_SEAT_LOCK = 0x0402   // trunk over Wi‑Fi
        const val DID_HORN = 0x0410
        const val ODO_DID = 0x0103         // VCU odometer: 22 0103 read / 2E 0103 write, 4-byte LE km
    }

    private fun saveConn() {
        val s = _ui.value
        prefs.edit()
            .putString("host", s.host).putString("port", s.port).putBoolean("secure", s.secure)
            .putString("ble_mac", s.bleMac)
            .apply()
    }

    fun hideSelfTestWarningForever() = prefs.edit().putBoolean("never_selftest_warn", true).apply()
    fun showSelfTestWarning(): Boolean = !prefs.getBoolean("never_selftest_warn", false)

    private val mockFaults = mapOf(
        Ecu.MCU to listOf(Fault("P0560", "System Voltage Abnormal", true, 0x09, listOf("testFailed", "confirmedDTC"))),
        Ecu.BMS to listOf(Fault("P0A80", "Battery Pack Cell Imbalance / Aging", true, 0x05, listOf("testFailed", "pendingDTC"))),
        Ecu.VCU to emptyList()
    )

    private val _ui = MutableStateFlow(
        UiState(
            host = prefs.getString("host", "192.168.4.1") ?: "192.168.4.1",
            port = prefs.getString("port", "50005") ?: "50005",
            secure = prefs.getBoolean("secure", false),
            bleMac = prefs.getString("ble_mac", "00:00:00:00:00:00") ?: "00:00:00:00:00:00",
            activityDirLabel = LogStorage.activityLabel(app),
            chargeDirLabel = LogStorage.chargeLabel(app),
        )
    )
    val ui: StateFlow<UiState> = _ui.asStateFlow()
    private fun set(block: UiState.() -> UiState) { _ui.value = _ui.value.block() }

    init {
        // Must run after _ui is constructed — earlier set{} crashed on launch.
        AutoLog.init(app)
        ChargeSessionLog.bindDbc(dbc)
    }

    fun setHost(v: String) = set { copy(host = v) }
    fun setPort(v: String) = set { copy(port = v) }
    fun setSecure(v: Boolean) = set { copy(secure = v) }
    fun setBench(v: Boolean) {
        set { copy(bench = v) }
        // Per spec: once parked/charger-disconnected is confirmed, enter Service by default.
        if (v && _ui.value.conn == Conn.CONNECTED && !_ui.value.demo && _ui.value.mode != "SERVICE") {
            setMode("SERVICE")
        }
    }
    fun setDemo(v: Boolean) = set { copy(demo = v) }
    fun setBleMac(v: String) { set { copy(bleMac = v.trim()) }; saveConn() }
    fun dismissMessage() = set { copy(message = null) }

    fun actuatorByLabel(label: String): Actuator? =
        catalog.actuators.firstOrNull { it.label.equals(label, true) }

    // ---- generic op runner: serialises work off the main thread ----
    private fun op(label: String, requireService: Boolean = false, work: suspend () -> String?) {
        if (_ui.value.busy) { set { copy(message = "Busy — wait for the current action") }; return }
        set { copy(busy = true) }
        AutoLog.log(AutoLog.Cat.CMD, "START  $label")
        viewModelScope.launch {
            val msg = try {
                withContext(Dispatchers.IO) {
                    if (requireService) requireServiceMode()
                    work()
                }
            } catch (e: Exception) {
                "$label failed: ${e.message ?: e.javaClass.simpleName}"
            }
            val ok = msg != null && !msg.contains(" failed:")
            AutoLog.log(AutoLog.Cat.CMD, "${if (ok) "OK    " else "FAIL  "} $label → ${msg ?: "—"}")
            set { copy(busy = false, message = msg) }
        }
    }

    private fun requireBench() {
        if (!_ui.value.bench) throw IllegalStateException(
            "Confirm the scooter is parked and the charger is disconnected first (top checkbox)."
        )
    }

    private fun requireServiceMode() {
        requireBench()
        if (_ui.value.demo) return
        val c = client ?: throw IllegalStateException("Not connected")
        if (c.getMode().curMode != Wifican.VehicleOperationState.VEHICLE_OP_STATE_SERVICE)
            throw IllegalStateException("Enter Service mode first (Scooter tab)")
    }

    // ---- connection ----
    fun connect() {
        val s = _ui.value
        saveConn()
        if (s.demo) {
            set { copy(conn = Conn.CONNECTING, message = null) }
            connectJob?.cancel()
            connectJob = viewModelScope.launch {
                delay(300)
                AutoLog.beginSession(getApplication(), "demo")
                set {
                    copy(
                        conn = Conn.CONNECTED,
                        mode = "SERVICE",
                        firmware = "DEMO-MOCK-5.0.0",
                        bench = true,
                        unlockedVcu = true,
                        message = "Connected in Demo Mode (Mock)",
                        activityLogPath = AutoLog.currentSessionPath(),
                        activityDirLabel = LogStorage.activityLabel(getApplication()),
                        chargeDirLabel = LogStorage.chargeLabel(getApplication()),
                    )
                }
                startLive()
            }
            return
        }
        val port = s.port.toIntOrNull() ?: run { set { copy(message = "Port must be a number") }; return }
        set { copy(conn = Conn.CONNECTING, message = "Connecting… tap Cancel to stop") }
        connectJob?.cancel()
        connectJob = viewModelScope.launch {
            try {
                AutoLog.beginSession(getApplication(), "${s.host.trim()}:$port")
                set { copy(activityLogPath = AutoLog.currentSessionPath()) }
                val info = withContext(Dispatchers.IO) {
                    val c = WifiCanClient()
                    c.connect(getApplication(), s.host.trim(), port, s.secure)
                    c.frameListener = { id, data ->
                        latestRaw[id] = System.currentTimeMillis() to data
                        ChargeSessionLog.onFrame(id, data)
                    }
                    // Pre-rework working path: subscribe ECU CAN IDs + start filtered
                    // ReadCanStream immediately so UDS replies are received.
                    try {
                        c.init(streamIds())
                    } catch (_: Exception) {}
                    c.startReader(dump = false)
                    client = c
                    uds = Uds(c, dtc::table)
                    readInfo(c)
                }
                set {
                    copy(
                        conn = Conn.CONNECTED, mode = info.first, firmware = info.second, message = null,
                        activityLogPath = AutoLog.currentSessionPath(),
                    )
                }
                AutoLog.log(AutoLog.Cat.CONN, "connected mode=${info.first} fw=${info.second}")
                startAutoMonitor()
            } catch (e: CancellationException) {
                withContext(Dispatchers.IO) { try { client?.close() } catch (_: Exception) {} }
                client = null; uds = null
                AutoLog.endSession("cancelled")
                set { copy(conn = Conn.IDLE, message = "Connection cancelled") }
            } catch (e: Exception) {
                withContext(Dispatchers.IO) { try { client?.close() } catch (_: Exception) {} }
                client = null; uds = null
                AutoLog.log(AutoLog.Cat.CONN, "connect failed: ${e.message}")
                AutoLog.endSession("error")
                set { copy(conn = Conn.ERROR, message = "Connect failed: ${e.message}") }
            }
        }
    }

    /** Stop an in-flight connect, or force-drop a stuck/hung session. */
    fun cancelConnect() {
        connectJob?.cancel()
        connectJob = null
        viewModelScope.launch {
            stopKeepAlive(); stopLive(); stopWatch(); stopModeSniff(); stopAutoMonitor()
            if (ChargeSessionLog.isActive()) ChargeSessionLog.stop()
            AutoLog.endSession("cancelled")
            withContext(Dispatchers.IO) { try { client?.close() } catch (_: Exception) {} }
            client = null; uds = null; unlocked.clear(); securityFailed.clear()
            set {
                copy(
                    conn = Conn.IDLE, busy = false, unlockedVcu = false, latched = emptySet(),
                    liveOn = false, live = emptyList(), chargeSnoopOn = false,
                    message = "Connection terminated",
                )
            }
        }
    }

    private fun readInfo(c: WifiCanClient): Pair<String, String> {
        val mode = c.getMode().curMode.name.removePrefix("VEHICLE_OP_STATE_")
        val sw = c.swVersion()
        val fw = if (sw.status == Wifican.RespStatus.RESP_SUCCESS) sw.statusMsg.replace("\n", " / ") else "?"
        return mode to fw
    }

    fun refreshInfo() = op("Read mode") {
        if (_ui.value.demo) return@op "Demo mode: mode is ${_ui.value.mode}"
        val c = client ?: throw IllegalStateException("Not connected")
        val (m, fw) = readInfo(c); set { copy(mode = m, firmware = fw) }; "Mode: $m"
    }

    fun disconnect() {
        connectJob?.cancel()
        stopKeepAlive(); stopLive(); stopWatch(); stopModeSniff(); stopAutoMonitor()
        if (ChargeSessionLog.isActive()) ChargeSessionLog.stop()
        AutoLog.endSession("disconnect")
        viewModelScope.launch {
            // Best-effort: turn off any latched outputs before closing.
            releaseLatchedQuietly()
            withContext(Dispatchers.IO) { try { client?.close() } catch (_: Exception) {} }
            client = null; uds = null; unlocked.clear(); securityFailed.clear(); latestRaw.clear()
            set {
                copy(
                    conn = Conn.IDLE, mode = "unknown", firmware = "unknown",
                    unlockedVcu = false, liveOn = false, live = emptyList(), latched = emptySet(),
                    chargeSnoopOn = false,
                )
            }
        }
    }

    private suspend fun releaseLatchedQuietly() {
        val held = _ui.value.latched.toList()
        if (held.isEmpty() || _ui.value.demo) return
        try {
            val u = uds ?: return
            for (label in held) {
                val did = didForLabel(label) ?: continue
                try {
                    u.ioControl(Ecu.VCU, did, Uds.IO_SHORT_TERM, byteArrayOf(0x00))
                    u.ioControl(Ecu.VCU, did, Uds.IO_RETURN_TO_ECU)
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    private fun didForLabel(label: String): Int? = when {
        label.equals("Lock", true) -> DID_STEERING_LOCK
        label.equals("Unlock", true) -> DID_STEERING_LOCK
        label.equals("Trunk", true) || label.equals("Seat Lock", true) -> DID_SEAT_LOCK
        else -> actuatorByLabel(label)?.did
    }

    fun setMode(target: String) = op("Set $target") {
        requireBench()
        if (_ui.value.demo) {
            set { copy(mode = target) }
            return@op "Demo mode: now in $target mode"
        }
        val c = client ?: throw IllegalStateException("Not connected")
        stopKeepAlive(); unlocked.clear(); set { copy(unlockedVcu = false) }
        val enum = if (target == "SERVICE") Wifican.VehicleOperationState.VEHICLE_OP_STATE_SERVICE
                   else Wifican.VehicleOperationState.VEHICLE_OP_STATE_CUST
        val r = c.setMode(enum)
        if (r.status != Wifican.RespStatus.RESP_SUCCESS) throw IllegalStateException(r.statusMsg.ifEmpty { "mode change rejected" })
        // SOM drops the previous CAN filter/session on mode change — re-arm ReadCanStream.
        c.stopStream()
        try { c.init(streamIds()) } catch (_: Exception) {}
        c.startReader(dump = false)
        val (m, fw) = readInfo(c); set { copy(mode = m, firmware = fw) }
        "Now in $m mode"
    }

    // ---- stream management ----
    private fun diagStream(force: Boolean = false) {
        val c = client ?: throw IllegalStateException("Not connected")
        if (!force && c.streamMode == "diag" && c.readerAlive) return
        c.stopStream()
        try { c.init(streamIds()) } catch (_: Exception) {}
        c.startReader(dump = false)
    }

    // ---- unlock (once) + keepalive ----
    private fun ensureUnlocked(ecu: Ecu): Uds {
        diagStream()
        val u = uds ?: throw IllegalStateException("Not connected")
        if (ecu in unlocked && keepAlive?.isActive == true) return u
        try {
            u.enterExtendedSession(ecu)
        } catch (e: Exception) {
            // Zombie ReadCanStream after Service mode: re-init once and retry.
            diagStream(force = true)
            u.enterExtendedSession(ecu)
        }
        if (ecu in securityFailed) throw IllegalStateException(
            "${ecu.name}: a key was rejected on this connection. Reconnect (power-cycle the scooter if the ECU is in a lockout delay)."
        )
        try {
            u.securityAccess(ecu)
        } catch (e: Exception) {
            val m = e.message ?: ""
            if (m.contains("0x35") || m.contains("0x36") || m.contains("0x37")) securityFailed.add(ecu)
            throw e
        }
        unlocked.add(ecu)
        if (ecu == Ecu.VCU) set { copy(unlockedVcu = true) }
        startKeepAlive(ecu)
        return u
    }

    private fun startKeepAlive(ecu: Ecu) {
        stopKeepAlive()
        keepAlive = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(2000)
                try { uds?.testerPresent(ecu) } catch (_: Exception) {}
            }
        }
    }
    private fun stopKeepAlive() { keepAlive?.cancel(); keepAlive = null }

    // ---- actuators ----
    fun pulse(actuator: Actuator) = op("${actuator.label}", requireService = true) {
        if (_ui.value.demo) {
            delay(500)
            return@op "Demo mode: ${actuator.label} pulsed successfully"
        }
        val u = ensureUnlocked(Ecu.VCU)
        val hold = if (actuator.label.equals("Horn", true)) 750L else 2000L
        try {
            u.ioControl(Ecu.VCU, actuator.did, Uds.IO_SHORT_TERM, byteArrayOf(0x01))
            delay(hold)
        } catch (e: Exception) {
            if ((e.message ?: "").contains("0x33")) { unlocked.remove(Ecu.VCU); stopKeepAlive(); set { copy(unlockedVcu = false) } }
            throw e
        } finally {
            try { u.ioControl(Ecu.VCU, actuator.did, Uds.IO_SHORT_TERM, byteArrayOf(0x00)) } catch (_: Exception) {}
            try { u.ioControl(Ecu.VCU, actuator.did, Uds.IO_RETURN_TO_ECU) } catch (_: Exception) {}
        }
        "${actuator.label}: ON then OFF acknowledged"
    }

    /** Latchable ON/OFF for lights, trunk (Seat Lock), steering lock, etc. Horn stays pulse-only. */
    fun setLatched(label: String, did: Int, on: Boolean, danger: Boolean = false) =
        op(if (on) "$label ON" else "$label OFF", requireService = true) {
            if (_ui.value.demo) {
                set {
                    val next = latched.toMutableSet()
                    when {
                        label.equals("Lock", true) && on -> { next.add("Lock"); next.remove("Unlock") }
                        label.equals("Unlock", true) && on -> { next.add("Unlock"); next.remove("Lock") }
                        on -> next.add(label)
                        else -> next.remove(label)
                    }
                    if (!on) next.remove(label)
                    copy(latched = next)
                }
                delay(200)
                return@op "Demo: $label ${if (on) "ON" else "OFF"}"
            }
            val u = ensureUnlocked(Ecu.VCU)
            try {
                if (on) {
                    u.ioControl(Ecu.VCU, did, Uds.IO_SHORT_TERM, byteArrayOf(0x01))
                } else {
                    u.ioControl(Ecu.VCU, did, Uds.IO_SHORT_TERM, byteArrayOf(0x00))
                    try { u.ioControl(Ecu.VCU, did, Uds.IO_RETURN_TO_ECU) } catch (_: Exception) {}
                }
            } catch (e: Exception) {
                if ((e.message ?: "").contains("0x33")) {
                    unlocked.remove(Ecu.VCU); stopKeepAlive(); set { copy(unlockedVcu = false) }
                }
                throw e
            }
            set {
                val next = latched.toMutableSet()
                when {
                    label.equals("Lock", true) && on -> { next.add("Lock"); next.remove("Unlock") }
                    label.equals("Unlock", true) && on -> { next.add("Unlock"); next.remove("Lock") }
                    on -> next.add(label)
                    else -> next.remove(label)
                }
                if (!on) next.remove(label)
                copy(latched = next)
            }
            "$label ${if (on) "ON" else "OFF"} · DID ${"%04X".format(did)}"
        }

    fun toggleLatch(label: String, did: Int, danger: Boolean = false) {
        val on = label !in _ui.value.latched
        setLatched(label, did, on, danger)
    }

    /**
     * Wi‑Fi Lock — experimental: Steering Lock 0400 ON, then BF07 sequence.
     * Physical effect unverified; report ECU replies so we can learn what works.
     */
    fun wifiLock() = op("Wi‑Fi Lock", requireService = true) {
        if (_ui.value.demo) {
            set { copy(latched = latched + "Lock" - "Unlock") }
            return@op "Demo: Wi‑Fi Lock sent (0400 ON + BF07)"
        }
        val u = ensureUnlocked(Ecu.VCU)
        val parts = mutableListOf<String>()
        try {
            u.ioControl(Ecu.VCU, DID_STEERING_LOCK, Uds.IO_SHORT_TERM, byteArrayOf(0x01))
            parts += "0400 ON ok"
            set { copy(latched = latched + "Lock" - "Unlock") }
        } catch (e: Exception) {
            parts += "0400 ON: ${e.message}"
        }
        try {
            val r = u.routineControl(Ecu.VCU, Uds.ROUTINE_START, 0xBF07)
            val st = if (r.size > 4) "%02X".format(r[4]) else "?"
            parts += "BF07 ok status=$st"
        } catch (e: Exception) {
            parts += "BF07: ${e.message}"
        }
        parts.joinToString(" · ")
    }

    /**
     * Wi‑Fi Unlock — experimental: Steering Lock 0400 OFF, then BF07 sequence.
     */
    fun wifiUnlock() = op("Wi‑Fi Unlock", requireService = true) {
        if (_ui.value.demo) {
            set { copy(latched = latched + "Unlock" - "Lock") }
            return@op "Demo: Wi‑Fi Unlock sent (0400 OFF + BF07)"
        }
        val u = ensureUnlocked(Ecu.VCU)
        val parts = mutableListOf<String>()
        try {
            u.ioControl(Ecu.VCU, DID_STEERING_LOCK, Uds.IO_SHORT_TERM, byteArrayOf(0x00))
            try { u.ioControl(Ecu.VCU, DID_STEERING_LOCK, Uds.IO_RETURN_TO_ECU) } catch (_: Exception) {}
            parts += "0400 OFF ok"
            set { copy(latched = latched + "Unlock" - "Lock") }
        } catch (e: Exception) {
            parts += "0400 OFF: ${e.message}"
        }
        try {
            val r = u.routineControl(Ecu.VCU, Uds.ROUTINE_START, 0xBF07)
            val st = if (r.size > 4) "%02X".format(r[4]) else "?"
            parts += "BF07 ok status=$st"
        } catch (e: Exception) {
            parts += "BF07: ${e.message}"
        }
        parts.joinToString(" · ")
    }

    /** Wi‑Fi Trunk = Seat Lock DID 0402 (latchable). */
    fun wifiTrunkToggle() {
        val on = "Trunk" !in _ui.value.latched
        setLatched("Trunk", DID_SEAT_LOCK, on, danger = true)
    }

    // ---- scan all ECUs (auto-flag) + one-tap recover ----
    fun scanAll() = op("Scan all ECUs", requireService = true) {
        if (_ui.value.demo) { set { copy(faults = mockFaults) }; return@op "Demo: MCU 1 · BMS 1 · VCU 0" }
        diagStream()
        val u = uds ?: throw IllegalStateException("Not connected")
        val m = HashMap<Ecu, List<Fault>>()
        for (ecu in Ecu.values()) m[ecu] = try { u.readDtcs(ecu, unlock = false) } catch (_: Exception) { emptyList() }
        set { copy(faults = m) }
        "Scanned — " + Ecu.values().joinToString(" · ") { "${it.name} ${m[it]?.size ?: 0}" }
    }

    /**
     * One-tap recover for the "Scooter issue, please restart" state, without a
     * physical restart: enter Service → read DTCs on all ECUs → clear + ECU-reset
     * the ones with faults (or the VCU if none) → return to Customer mode.
     */
    fun recover() = op("Recover") {
        requireBench()
        if (_ui.value.demo) {
            delay(700)
            set { copy(faults = Ecu.values().associateWith { emptyList() }, mode = "CUST", unlockedVcu = false) }
            return@op "Demo: cleared DTCs, reset ECUs, back in Customer mode"
        }
        val c = client ?: throw IllegalStateException("Not connected")
        stopKeepAlive(); unlocked.clear()
        if (c.getMode().curMode != Wifican.VehicleOperationState.VEHICLE_OP_STATE_SERVICE)
            c.setMode(Wifican.VehicleOperationState.VEHICLE_OP_STATE_SERVICE)
        diagStream()
        val u = uds ?: throw IllegalStateException("Not connected")
        val scan = HashMap<Ecu, List<Fault>>()
        for (ecu in Ecu.values()) scan[ecu] = try { ensureUnlocked(ecu); u.readDtcs(ecu, unlock = false) } catch (_: Exception) { emptyList() }
        set { copy(faults = scan) }
        val targets = Ecu.values().filter { (scan[it]?.size ?: 0) > 0 }.ifEmpty { listOf(Ecu.VCU) }
        val report = StringBuilder()
        for (ecu in targets) {
            try {
                val uu = ensureUnlocked(ecu); uu.clearDtcs(ecu); uu.ecuReset(ecu)
                unlocked.remove(ecu)
                set { copy(faults = faults + (ecu to emptyList())) }
                report.append("${ecu.name} cleared+reset. ")
            } catch (e: Exception) { report.append("${ecu.name}: ${e.message}. ") }
        }
        stopKeepAlive(); unlocked.clear()
        c.setMode(Wifican.VehicleOperationState.VEHICLE_OP_STATE_CUST)
        val (m, fw) = readInfo(c); set { copy(mode = m, firmware = fw, unlockedVcu = false) }
        "Recover → $m. $report"
    }

    /**
     * Restart the head unit / SOM via RunSystemTestCmd(SYS_CMD_SOM). The SOM runs
     * this gRPC server, so a real restart DROPS our connection — that's expected
     * and treated as success; we tear down locally and go to IDLE so you reconnect
     * once it has rebooted (~30–60 s). UNVERIFIED on firmware 5.0.0.
     */
    fun restartHeadUnit() {
        if (_ui.value.busy) { set { copy(message = "Busy — wait for the current action") }; return }
        set { copy(busy = true) }
        viewModelScope.launch {
            if (_ui.value.demo) {
                withContext(Dispatchers.IO) { delay(600) }
                set { copy(busy = false, message = "Demo: SOM restart command sent") }
                return@launch
            }
            val msg = withContext(Dispatchers.IO) {
                try {
                    if (!_ui.value.bench) throw IllegalStateException("Confirm parked & charger disconnected first")
                    val c = client ?: throw IllegalStateException("Not connected")
                    stopKeepAlive()
                    try {
                        c.systemCmd(Wifican.SystemCmdList.SYS_CMD_SOM)
                        "SOM restart command sent — head unit rebooting. Wait ~30–60 s, then Connect."
                    } catch (e: Exception) {
                        "SOM restart sent; link dropped (expected). Wait ~30–60 s, then Connect."
                    }
                } catch (e: Exception) {
                    "Restart head unit failed: ${e.message}"
                }
            }
            // The link is gone after a real restart — tear down locally.
            stopKeepAlive(); stopLive(); stopWatch(); stopModeSniff(); stopAutoMonitor()
            withContext(Dispatchers.IO) { try { client?.close() } catch (_: Exception) {} }
            client = null; uds = null; unlocked.clear(); securityFailed.clear(); latestRaw.clear()
            set {
                copy(conn = Conn.IDLE, mode = "unknown", firmware = "unknown",
                    unlockedVcu = false, liveOn = false, live = emptyList(), busy = false, message = msg)
            }
        }
    }

    // ---- lock/unlock sequence over CAN (VCU routine BF07) ----
    fun lockUnlockSequence() = op("Lock/Unlock sequence", requireService = true) {
        if (_ui.value.demo) { delay(500); return@op "Demo: routine 71 01 BF 07 · status 00" }
        val u = ensureUnlocked(Ecu.VCU)
        // Prefer a clean extended session; some ECUs need a short settle before 31.
        delay(150)
        val r = try {
            u.routineControl(Ecu.VCU, Uds.ROUTINE_START, 0xBF07)
        } catch (e: Exception) {
            // One retry after re-unlock — matches intermittent GUI failures.
            unlocked.remove(Ecu.VCU); stopKeepAlive()
            val uu = ensureUnlocked(Ecu.VCU)
            delay(200)
            uu.routineControl(Ecu.VCU, Uds.ROUTINE_START, 0xBF07)
        }
        if (r.size < 5 || r[0].toInt() and 0xFF != 0x71 || r[1].toInt() and 0xFF != 0x01 ||
            r[2].toInt() and 0xFF != 0xBF || r[3].toInt() and 0xFF != 0x07
        ) {
            throw IllegalStateException(
                "Unexpected BF07 reply ${r.joinToString(" ") { "%02X".format(it) }}; final lock state unknown"
            )
        }
        val status = "%02X".format(r[4])
        "BF07 acknowledged · routine status $status (final lock state unverified — check scooter)"
    }

    // ---- vehicle info ----
    fun loadInfo() = op("Vehicle info") {
        if (_ui.value.demo) {
            set { copy(info = VehicleInfo("P53AFDCB7BCA06462", "DEMO 5.0.0 / 5.0.0", "DEMO 5.0.0", "{\"demo\":true}")) }
            return@op "Demo: vehicle info loaded"
        }
        val c = client ?: throw IllegalStateException("Not connected")
        // Retry flaky RPCs individually so one timeout doesn't blank the whole card.
        fun <T> retry(times: Int = 2, block: () -> T): T {
            var last: Exception? = null
            repeat(times) { i ->
                try { return block() } catch (e: Exception) {
                    last = e
                    if (i < times - 1) Thread.sleep(250)
                }
            }
            throw last ?: IllegalStateException("retry failed")
        }
        val sw = try {
            retry {
                c.swVersion().let {
                    if (it.status == Wifican.RespStatus.RESP_SUCCESS) it.statusMsg.replace("\n", " / ") else "?"
                }
            }
        } catch (e: Exception) { "(sw: ${e.message})" }
        val aosp = try {
            retry {
                c.aospVersion().let {
                    if (it.status == Wifican.RespStatus.RESP_SUCCESS) it.statusMsg else "?"
                }
            }
        } catch (e: Exception) { "(aosp: ${e.message})" }
        val manifest = try { retry { c.identifiers().manifestJson } }
            catch (e: Exception) { "(unavailable: ${e.message})" }
        val vin = try { retry { c.remoteTest(testReq(SelfTest.VIN, 1)).respStr } }
            catch (_: Exception) { "" }
        set { copy(info = VehicleInfo(vin.ifEmpty { "(see manifest)" }, sw, aosp, manifest)) }
        "Vehicle info loaded"
    }

    // ---- faults ----
    fun readFaults(ecu: Ecu) = op("${ecu.name} faults", requireService = true) {
        if (_ui.value.demo) {
            val f = mockFaults[ecu] ?: emptyList()
            set { copy(faults = faults + (ecu to f)) }
            return@op "Demo mode: read ${f.size} DTC(s) for ${ecu.name}"
        }
        diagStream()
        val u = uds ?: throw IllegalStateException("Not connected")
        val f = u.readDtcs(ecu, unlock = false)
        set { copy(faults = faults + (ecu to f)) }
        "${ecu.name}: ${f.size} DTC(s)"
    }
    fun clearFaults(ecu: Ecu) = op("Clear ${ecu.name} DTCs", requireService = true) {
        if (_ui.value.demo) {
            set { copy(faults = faults + (ecu to emptyList())) }
            return@op "Demo mode: cleared ${ecu.name} DTCs"
        }
        val u = ensureUnlocked(ecu); u.clearDtcs(ecu); set { copy(faults = faults + (ecu to emptyList())) }
        "${ecu.name}: DTCs cleared"
    }
    fun ecuReset(ecu: Ecu) = op("Reset ${ecu.name}", requireService = true) {
        if (_ui.value.demo) return@op "Demo mode: reset sent to ${ecu.name}"
        ensureUnlocked(ecu).ecuReset(ecu); "${ecu.name}: reset sent"
    }

    // ---- parameters ----
    var lastRead: Pair<Setting, ByteArray>? = null; private set
    fun readParam(setting: Setting, onResult: (Map<String, Double>, ByteArray) -> Unit) =
        op("Read ${setting.name}", requireService = true) {
            if (_ui.value.demo) {
                val values = setting.fields.associate { f -> f.name to ((f.min ?: 0.0) + (f.max ?: 100.0)) / 2.0 }
                val bytes = try { SettingCodec.encode(setting, ByteArray(setting.lengthBytes), values) }
                            catch (e: Exception) { ByteArray(setting.lengthBytes) { 0x55.toByte() } }
                lastRead = setting to bytes
                withContext(Dispatchers.Main) { onResult(values, bytes) }
                return@op "Demo mode: read ${setting.name}"
            }
            val u = ensureUnlocked(setting.ecu)
            val bytes = u.readDid(setting.ecu, setting.did)
            lastRead = setting to bytes
            val values = SettingCodec.decode(setting, bytes)
            withContext(Dispatchers.Main) { onResult(values, bytes) }
            "Read ${setting.name}: ${bytes.joinToString(" ") { "%02X".format(it) }}"
        }

    fun writeParam(setting: Setting, edits: Map<String, Double>, reversed: Boolean = false) = op("Write ${setting.name}", requireService = true) {
        if (_ui.value.demo) {
            delay(400)
            return@op "Demo mode: wrote ${setting.name} successfully"
        }
        val u = ensureUnlocked(setting.ecu)
        val current = u.readDid(setting.ecu, setting.did)          // re-read fresh
        val proposed = SettingCodec.encode(setting, current, edits, reversed)
        u.writeDid(setting.ecu, setting.did, proposed)
        val after = u.readDid(setting.ecu, setting.did)            // verify
        if (!after.contentEquals(proposed))
            throw IllegalStateException("write acknowledged but readback differs (${after.joinToString(" ") { "%02X".format(it) }}); no auto-retry")
        lastRead = setting to after
        "Wrote ${setting.name}. Readback matches. (Reboot persistence unverified.)"
    }

    // ---- live data ----
    fun startLive() {
        if (_ui.value.conn != Conn.CONNECTED) { set { copy(message = "Connect first") }; return }
        if (_ui.value.demo) {
            set { copy(liveOn = true) }
            liveTick?.cancel()
            liveTick = viewModelScope.launch {
                var counter = 0
                while (isActive) {
                    counter++
                    val now = System.currentTimeMillis()
                    val mockSignals = listOf(
                        LiveRow(0x101, "BMS_Status", "Overall_SOC", 82.5 + (counter % 5) * 0.1, "%", now),
                        LiveRow(0x101, "BMS_Status", "Pack_Current", 4.2 + (counter % 3) * 0.2, "A", now),
                        LiveRow(0x102, "BMS_Cell", "BMS0_Cell_Min_Voltage", 3.65, "V", now),
                        LiveRow(0x102, "BMS_Cell", "BMS0_Cell_Max_Voltage", 3.82, "V", now),
                        LiveRow(0x201, "MCU_Status", "MCU_Voltage", 52.4 + (counter % 2) * 0.1, "V", now),
                        LiveRow(0x202, "MCU_Temp", "Motor_Temprature", 32.0 + (counter % 4), "°C", now),
                        LiveRow(0x202, "MCU_Temp", "MCU_Temperatute", 35.0 + (counter % 3), "°C", now),
                        LiveRow(0x301, "Vehicle_State", "Vehicle_Speed", (counter % 10).toDouble(), "km/h", now),
                        LiveRow(0x301, "Vehicle_State", "Motor_RPM", (counter % 50 * 10).toDouble(), "rpm", now),
                        LiveRow(0x302, "Vehicle_Fault", "System_Fault_Code", 0.0, "", now),
                    )
                    set { copy(live = mockSignals) }
                    delay(600)
                }
            }
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                stopKeepAlive(); unlocked.clear()
                val c = client!!
                if (c.streamMode != "dump") c.startReader(dump = true)
            }
            set { copy(liveOn = true, unlockedVcu = false) }
            liveTick?.cancel()
            liveTick = viewModelScope.launch {
                while (isActive) {
                    publishLive(); delay(600)
                }
            }
        }
    }
    fun stopLive() {
        liveTick?.cancel(); liveTick = null
        // Leaving CanDumpStream running starves WriteCanFrame — restore diag stream.
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val c = client ?: return@launch
                if (c.streamMode == "dump") {
                    c.stopStream()
                    try { c.init(streamIds()) } catch (_: Exception) {}
                    c.startReader(dump = false)
                }
            } catch (_: Exception) {}
        }
        set { copy(liveOn = false) }
    }

    private fun publishLive() {
        val now = System.currentTimeMillis()
        val ecuIds = Ecu.values().flatMap { listOf(it.reqId, it.respId) }.toSet()
        val rows = ArrayList<LiveRow>()
        for ((id, tv) in latestRaw) {
            if (id in ecuIds) continue
            val (ts, data) = tv
            val msg = dbc.message(id) ?: continue
            for (sv in dbc.decode(id, data)) rows.add(LiveRow(id, msg.name, sv.name, sv.value, sv.units, ts))
        }
        rows.sortBy { it.signal }
        set { copy(live = rows) }
    }

    // ---- head-unit self-tests (RemoteRunTestCmd) ----
    private fun testReq(t: SelfTest, v: Int): Wifican.RmtCmdReq {
        val b = Wifican.RmtCmdReq.newBuilder().setCmdId(t.cmd)
        when (t) {
            SelfTest.LCD -> b.setSubCmdLcdValue(v)
            SelfTest.GPS -> b.setSubCmdGpsValue(v)
            SelfTest.BT -> b.setSubCmdBtValue(v)
            SelfTest.BLE -> b.setSubCmdBleValue(v)
            SelfTest.WIFI -> b.setSubCmdWifiValue(v)
            SelfTest.SPKR -> b.setSubCmdSpkrValue(v)
            SelfTest.MIC -> b.setSubCmdMicValue(v)
            SelfTest.ESIM -> b.setSubCmdEsimValue(v)
            SelfTest.VIN -> b.setSubCmdVinValue(v)
        }
        return b.build()
    }

    fun selfTest(t: SelfTest) = op(t.label) {
        requireBench()
        if (_ui.value.demo) { delay(400); return@op "Demo: ${t.label} ran OK" }
        val c = client ?: throw IllegalStateException("Not connected")
        val r = c.remoteTest(testReq(t, 1))            // START / GET
        if (t.stop) { delay(700); c.remoteTest(testReq(t, 2)) }   // STOP
        val info = r.respStr.ifEmpty { r.respStatus.name.removePrefix("RMT_CMD_RESP_") }
        if (t == SelfTest.VIN) "VIN: $info" else "${t.label}: $info"
    }

    /** Read MCU DID B113 — initial synchronous-motor angle (°). ODX scale 0.1. */
    fun readMotorAngle() = op("Read motor angle B113") {
        requireBench()
        if (_ui.value.demo) {
            set { copy(motorAngleDeg = 123.4) }
            return@op "Demo angle 123.4°"
        }
        val u = uds ?: throw IllegalStateException("Not connected")
        // Plain 22 B113 — no security required for read in ODX (ECUTest=0).
        val data = u.readDid(Ecu.MCU, 0xB113)
        if (data.size < 2) throw IllegalStateException(
            "B113 short: ${data.joinToString(" ") { "%02X".format(it) }}"
        )
        val raw = (data[0].toInt() and 0xff) or ((data[1].toInt() and 0xff) shl 8)
        val deg = raw * 0.1
        set { copy(motorAngleDeg = deg) }
        AutoLog.log(AutoLog.Cat.CAL, "B113 angle=$deg° raw=$raw")
        "Motor angle ${"%.1f".format(deg)}° (raw $raw)"
    }

    /**
     * Motor AutoTune via gRPC RMT_CMD_MCU_CAL (same as CLI mcu-cal / ODX 31 01 05 F1).
     * Centre-stand only — RED. Caller must have confirmed parked checkbox.
     */
    fun mcuCal(start: Boolean) = op(if (start) "MCU AutoTune START" else "MCU AutoTune STOP") {
        requireBench()
        if (_ui.value.demo) {
            delay(400)
            return@op "Demo: mcu-cal ${if (start) "start" else "stop"} OK"
        }
        val c = client ?: throw IllegalStateException("Not connected")
        val sub = if (start) Wifican.RmtSubCmdMcuCal.RMT_SUB_CMD_MCU_CAL_START
                  else Wifican.RmtSubCmdMcuCal.RMT_SUB_CMD_MCU_CAL_STOP
        val req = Wifican.RmtCmdReq.newBuilder()
            .setCmdId(Wifican.RmtCmdList.RMT_CMD_MCU_CAL)
            .setSubCmdMcuCal(sub)
            .build()
        val r = c.remoteTest(req)
        val info = r.respStr.ifEmpty { r.respStatus.name.removePrefix("RMT_CMD_RESP_") }
        if (r.respStatus != Wifican.RmtCmdRespStatus.RMT_CMD_RESP_SUCCESS) {
            throw IllegalStateException("mcu-cal rejected: $info")
        }
        AutoLog.log(AutoLog.Cat.CAL, "mcu-cal ${if (start) "start" else "stop"}: $info")
        "mcu-cal ${if (start) "start" else "stop"}: $info"
    }

    /**
     * Read the VCU odometer via UDS 22 0103 (exactly what the factory diag app's
     * VcuConfigParamsViewModel.readOdometerValue() sends). Value is 4-byte
     * little-endian, unit km. No security access needed for the read.
     */
    fun readOdometer() = op("Read odometer 0103") {
        if (_ui.value.demo) { set { copy(odometerKm = 12345) }; return@op "Demo odometer 12345 km" }
        val u = uds ?: throw IllegalStateException("Not connected")
        val d = u.readDid(Ecu.VCU, ODO_DID)
        if (d.size < 4) throw IllegalStateException(
            "0103 short: ${d.joinToString(" ") { "%02X".format(it) }}")
        val km = (d[0].toInt() and 0xff) or ((d[1].toInt() and 0xff) shl 8) or
                 ((d[2].toInt() and 0xff) shl 16) or ((d[3].toInt() and 0xff) shl 24)
        set { copy(odometerKm = km) }
        AutoLog.log(AutoLog.Cat.CAL, "odometer read = $km km (raw ${d.joinToString("") { "%02X".format(it) }})")
        "Odometer $km km"
    }

    /**
     * Write the VCU odometer via UDS 2E 0103 + 4-byte little-endian km — the exact
     * payload the factory diag app builds in setUpOdometerReading(int). This is a
     * REAL write to the vehicle: it exists to test whether the VCU accepts the value
     * or rejects it (NRC) offline, for the Ola disclosure. Legitimate only when
     * restoring the correct mileage to a replacement VCU board on your own scooter;
     * falsifying an odometer is illegal in most jurisdictions.
     */
    fun writeOdometer(km: Int) = op("Write odometer 0103 = $km km", requireService = true) {
        if (km < 0) throw IllegalArgumentException("odometer must be >= 0")
        if (_ui.value.demo) { set { copy(odometerKm = km) }; return@op "Demo: wrote odometer $km km" }
        val u = ensureUnlocked(Ecu.VCU)                       // extended session + 27 security access
        val le = byteArrayOf(
            (km and 0xff).toByte(),
            ((km ushr 8) and 0xff).toByte(),
            ((km ushr 16) and 0xff).toByte(),
            ((km ushr 24) and 0xff).toByte(),
        )
        AutoLog.log(AutoLog.Cat.CAL, "odometer write attempt = $km km (2E 0103 ${le.joinToString("") { "%02X".format(it) }})")
        u.writeDid(Ecu.VCU, ODO_DID, le)                      // throws with NRC if the VCU rejects it
        // Verify by reading back.
        val d = u.readDid(Ecu.VCU, ODO_DID)
        val back = if (d.size >= 4)
            (d[0].toInt() and 0xff) or ((d[1].toInt() and 0xff) shl 8) or
            ((d[2].toInt() and 0xff) shl 16) or ((d[3].toInt() and 0xff) shl 24) else -1
        set { copy(odometerKm = if (back >= 0) back else km) }
        AutoLog.log(AutoLog.Cat.CAL, "odometer write ACK; readback = $back km")
        if (back == km) "Odometer write ACCEPTED. Readback $back km matches. (Reboot persistence unverified.)"
        else "Odometer write acknowledged (6E) but readback = $back km (wrote $km). ECU may clamp/store differently."
    }

    // ---- auto status + fault monitor (always-on while connected) ----
    // Decodes battery + asserted fault bits from the broadcast CAN registers, no
    // per-ECU query. Fault transitions are always written to AutoLog; a vitals
    // heartbeat is logged only while autoLogOn. Charge vitals always go into
    // ChargeSessionLog while recording.
    fun startAutoMonitor() {
        stopAutoMonitor()
        loggedFaults.clear(); lastVitalsLogAt = 0L
        AutoLog.log(AutoLog.Cat.SYS, "monitor start (mode=${_ui.value.mode} fw=${_ui.value.firmware})")
        monitorTick = viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                try { tickMonitor() } catch (_: Exception) {}
                delay(1000)
            }
        }
    }
    fun stopAutoMonitor() { monitorTick?.cancel(); monitorTick = null }

    fun toggleAutoLog() {
        val on = !_ui.value.autoLogOn
        set { copy(autoLogOn = on) }
        AutoLog.log(AutoLog.Cat.LIVE, if (on) "vitals heartbeat ON" else "vitals heartbeat OFF")
    }
    fun autoLogText(): String = AutoLog.exportText()
    fun clearAutoLog() = AutoLog.clear()
    fun activityLogPath(): String? = AutoLog.currentSessionPath()
    fun logsDirPath(): String = LogStorage.activityLabel(getApplication())
    fun chargingDirPath(): String = LogStorage.chargeLabel(getApplication())

    fun setActivityLogFolder(uri: android.net.Uri) {
        LogStorage.setActivityTree(getApplication(), uri)
        set {
            copy(
                activityDirLabel = LogStorage.activityLabel(getApplication()),
                message = "Activity logs → ${LogStorage.activityLabel(getApplication())}",
            )
        }
        AutoLog.log(AutoLog.Cat.SYS, "activity folder → ${LogStorage.activityLabel(getApplication())}")
    }

    fun setChargeLogFolder(uri: android.net.Uri) {
        LogStorage.setChargeTree(getApplication(), uri)
        set {
            copy(
                chargeDirLabel = LogStorage.chargeLabel(getApplication()),
                message = "Charge logs → ${LogStorage.chargeLabel(getApplication())}",
            )
        }
        AutoLog.log(AutoLog.Cat.SYS, "charge folder → ${LogStorage.chargeLabel(getApplication())}")
    }

    fun resetActivityLogFolder() {
        LogStorage.resetActivity(getApplication())
        set {
            copy(
                activityDirLabel = LogStorage.activityLabel(getApplication()),
                message = "Activity logs reset to app default",
            )
        }
    }

    fun resetChargeLogFolder() {
        LogStorage.resetCharge(getApplication())
        set {
            copy(
                chargeDirLabel = LogStorage.chargeLabel(getApplication()),
                message = "Charge logs reset to app default",
            )
        }
    }

    fun toggleChargeSnoop() {
        if (_ui.value.conn != Conn.CONNECTED) {
            set { copy(message = "Connect over Wi-Fi first") }
            return
        }
        if (ChargeSessionLog.isActive()) {
            val f = ChargeSessionLog.stop()
            set {
                copy(
                    chargeSnoopOn = false,
                    chargeSnoopFile = f?.displayPath,
                    message = "Charge session saved: ${f?.displayPath}",
                )
            }
            return
        }
        // Prefer dump firehose while recording so bridged FC mirrors are not filtered out.
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    val c = client ?: return@withContext
                    if (c.streamMode != "dump") c.startReader(dump = true)
                } catch (_: Exception) {}
            }
            val f = ChargeSessionLog.start(getApplication())
            set {
                copy(
                    chargeSnoopOn = true,
                    chargeSnoopFile = f.displayPath,
                    message = "Recording charge session → ${f.displayPath}",
                )
            }
        }
    }

    private fun tickMonitor() {
        val snap = latestRaw.mapValues { it.value.second }
        if (snap.isEmpty()) return
        val active = FaultBits.active(dbc, snap).toList()
        val batt = decodeBattery(snap)
        for (f in active) if (f !in loggedFaults) AutoLog.log(AutoLog.Cat.FAULT, "SET   $f")
        for (f in loggedFaults) if (f !in active) AutoLog.log(AutoLog.Cat.FAULT, "CLEAR $f")
        loggedFaults.clear(); loggedFaults.addAll(active)
        val now = System.currentTimeMillis()
        if (_ui.value.autoLogOn && now - lastVitalsLogAt > 30_000L) {
            lastVitalsLogAt = now
            batt?.let {
                val connRaw = snap[0x62D]?.let { d ->
                    dbc.decode(0x62D, d).firstOrNull { s -> s.name == "Charger_Connected" }?.value
                }
                val ctype = when (connRaw?.toInt()) {
                    1 -> "Fast"
                    2 -> "Slow"
                    else -> if (it.chargerConnected) "Connected" else "None"
                }
                AutoLog.log(
                    AutoLog.Cat.LIVE,
                    "soc=${fmt1(it.soc)}% range=${fmt1(it.rangeKm)}km V=${fmt1(it.packVolts)} " +
                        "A=${fmt1(it.packAmps)} motT=${fmt1(it.motorTemp)} mcuT=${fmt1(it.mcuTemp)} " +
                        "chg=${it.charging} type=$ctype activeFaults=${active.size}",
                )
            }
        }
        if (ChargeSessionLog.isActive()) {
            ChargeSessionLog.onVitals(chargeVitalsMap(snap, batt, active.size))
        }
        // ---- MoveOS 5: real lock, charge info, features, notifications ----
        val locked = raw01(snap, 0x6BF, "Steering_Lock_12V_Supply_Control_Command")
        val charge = decodeChargeInfo(snap)
        val feats = decodeFeatures(snap)
        val newNotif = snap[0x6D0]?.let { it.getOrNull(0)?.toInt()?.and(0xFF) }?.let { code ->
            if (code != 0 && code != lastNotifCode) {
                lastNotifCode = code
                NotifEvent(now, code, MoveOs5.notifName(code), MoveOs5.notifAlert(code))
            } else { if (code == 0) lastNotifCode = 0; null }
        }
        set {
            val notifs = if (newNotif != null) (listOf(newNotif) + notifications).take(120) else notifications
            copy(
                activeFaults = active, battery = batt ?: battery,
                lastCanFrameAt = latestRaw.values.maxOfOrNull { it.first } ?: 0L,
                vehicleLocked = locked ?: vehicleLocked,
                chargeInfo = charge ?: chargeInfo,
                featuresBool = if (feats != null) feats.first else featuresBool,
                featuresTp = if (feats != null) feats.second else featuresTp,
                notifications = notifs,
            )
        }
    }

    /** Read a single 1-bit-ish signal as Boolean from a broadcast frame. */
    private fun raw01(snap: Map<Int, ByteArray>, id: Int, name: String): Boolean? {
        val data = snap[id] ?: return null
        val v = dbc.decode(id, data).firstOrNull { it.name.equals(name, true) }?.value ?: return null
        return v > 0.5
    }

    private fun decodeChargeInfo(snap: Map<Int, ByteArray>): ChargeInfo? {
        val d62d = snap[0x62D]
        val d213 = snap[0x213]
        val d508 = snap[0x508]
        if (d62d == null && d213 == null && d508 == null && snap[0x584] == null) return null
        val typeRaw = d62d?.getOrNull(0)?.toInt()?.and(0x03)
        val plugged = d62d?.getOrNull(0)?.let { (it.toInt() shr 2) and 1 } == 1
        val billing = d213 != null && d213.size > 6 && (d213[6].toInt() and 0x04) == 0x04
        val latched = d508 != null && d508.size > 1 && ((d508[1].toInt() shr 2) and 1) == 1
        val evseLo = snap[0x584]?.joinToString("") { "%02X".format(it) }
        val evseHi = snap[0x585]?.joinToString("") { "%02X".format(it) }
        val evse = listOfNotNull(evseLo, evseHi).joinToString(":").ifBlank { null }
        val modeRaw = snap[0x130]?.let { dbc.decode(0x130, it).firstOrNull { s -> s.name.contains("Charging_Mode", true) }?.value?.toInt() }
        return ChargeInfo(
            type = typeRaw?.let { MoveOs5.CHARGER_TYPE[it] },
            plugged = plugged, billing = billing, connectorLatched = latched,
            evseId = evse, mode = modeRaw?.let { MoveOs5.CHARGING_MODE[it] },
        )
    }

    private fun decodeFeatures(snap: Map<Int, ByteArray>): Pair<List<Pair<String, Boolean>>, List<Pair<String, Int>>>? {
        val d = snap[0x660] ?: return null
        if (d.size < 5) return null
        val bools = MoveOs5.FEATURE_BOOL.map { it.name to ((((d[it.byte].toInt() and 0xFF) shr it.bit) and 1) == 1) }
        val tps = MoveOs5.FEATURE_TP.map { it.name to (((d[it.byte].toInt() and 0xFF) shr it.bit) and 3) }
        return bools to tps
    }

    // ---- 0x6BC HMI command (feature toggles / stop charge) ----
    fun sendHmiCommand(ordinal: Int, label: String) = op(label, requireService = true) {
        if (_ui.value.demo) { delay(250); return@op "Demo: sent $label (0x6BC #$ordinal)" }
        val c = client ?: throw IllegalStateException("Not connected")
        val ack = ByteArray(8); ack[0] = ordinal.toByte()
        c.writeFrame(MoveOs5.CMD_TX_ID, ack)
        AutoLog.log(AutoLog.Cat.CMD, "0x6BC #$ordinal $label")
        // Best-effort: look for the 0x6C0 echo in the broadcast snapshot.
        delay(400)
        val echoed = latestRaw[MoveOs5.CMD_ACK_ID]?.second?.getOrNull(0)?.toInt()?.and(0xFF) == ordinal
        if (echoed) "$label: 0x6C0 echo seen (not proof of completion — check scooter)"
        else "$label: sent, no 0x6C0 echo within 400 ms (outcome unknown; no retry)"
    }

    fun stopCharge() = sendHmiCommand(MoveOs5.CMD_STOP_CHARGE, "Stop charge")
    fun clearNotifications() = set { copy(notifications = emptyList()) }

    /** Rich fields for the dedicated charge JSONL (battery + contactor + limits). */
    private fun chargeVitalsMap(
        snap: Map<Int, ByteArray>,
        batt: BatteryStatus?,
        faultCount: Int,
    ): Map<String, Any?> {
        fun sig(id: Int, vararg names: String): Double? {
            val data = snap[id] ?: return null
            val vals = dbc.decode(id, data)
            for (n in names) vals.firstOrNull { it.name.equals(n, true) }?.let { return it.value }
            for (n in names) vals.firstOrNull { it.name.contains(n, true) }?.let { return it.value }
            return null
        }
        fun enumLabel(raw: Double?, table: Map<Int, String>): String? {
            if (raw == null) return null
            return table[raw.toInt()] ?: "?${raw.toInt()}"
        }
        val chargerRaw = sig(0x62D, "Charger_Connected")
        val v = batt?.packVolts
        val a = batt?.packAmps
        val power = if (v != null && a != null) v * a else null
        return mapOf(
            "soc" to batt?.soc,
            "range_km" to batt?.rangeKm,
            "pack_v" to v,
            "pack_a" to a,
            "power_w" to power,
            "charging" to (batt?.charging ?: false),
            "charger_connected" to (batt?.chargerConnected ?: false),
            "charger_type" to enumLabel(
                chargerRaw,
                mapOf(0 to "None", 1 to "Fast", 2 to "Slow"),
            ),
            "plugged" to sig(0x62D, "Charger_Plugged_In"),
            "contactor" to sig(0x11C, "Contactor_state_00"),
            "charge_v_lim" to sig(0x120, "Overall_Charge_Voltage_limit"),
            "charge_i_lim" to sig(0x121, "Overall_Charge_current_limit"),
            "chg_avail_v" to sig(0x213, "Charging_Voltage_Available_range"),
            "chg_avail_i" to sig(0x213, "Charging_Current_Available_range"),
            "chg_mode" to enumLabel(
                sig(0x130, "Charging_Mode_00"),
                mapOf(
                    0 to "Disabled", 1 to "CC", 2 to "CV", 3 to "Complete",
                    4 to "CC End", 5 to "CV End", 6 to "Balancing", 7 to "Standby",
                ),
            ),
            "veh_l1" to enumLabel(
                sig(0x143, "Vehicle_Mode_Level_1"),
                mapOf(
                    0 to "SNA", 1 to "Idle", 2 to "Safe", 3 to "Slow Charge",
                    4 to "Fast Charge", 5 to "Discharge",
                ),
            ),
            "veh_l2" to enumLabel(
                sig(0x143, "Vehicle_Mode_Level_2"),
                mapOf(
                    0 to "SNA", 1 to "OFF", 2 to "VACATION", 3 to "SLEEP", 4 to "VEHICLE IDLE",
                    5 to "SC_CHARGE IDLE", 6 to "SC_CHARGE FAULT", 7 to "SC_CHARGE ACTIVE",
                    8 to "FC_CHARGE IDLE", 9 to "FC_CHARGE FAULT", 10 to "FC_CHARGE ACTIVE",
                    11 to "PARK", 12 to "DRIVE", 13 to "ALARM",
                ),
            ),
            "auth_err" to sig(0x213, "Authentication_Error"),
            "sc_fault" to sig(0x213, "Slow_Charger_Fault_Information"),
            "motor_t" to batt?.motorTemp,
            "mcu_t" to batt?.mcuTemp,
            "active_faults" to faultCount,
        )
    }

    private fun fmt1(v: Double?): String = if (v == null) "—" else String.format("%.1f", v)

    /** Keep v only when finite and within [lo, hi]; else null. Filters sentinel/stale values. */
    private fun bounded(v: Double?, lo: Double, hi: Double): Double? =
        if (v != null && !v.isNaN() && v in lo..hi) v else null

    /** Firmware-exact 0x313 temperature: LE16 at byteLo * 0.01 degC, plausibility-bounded. */
    private fun temp313(snap: Map<Int, ByteArray>, byteLo: Int): Double? {
        val d = snap[0x313] ?: return null
        if (d.size < byteLo + 2) return null
        val raw = (d[byteLo].toInt() and 0xFF) or ((d[byteLo + 1].toInt() and 0xFF) shl 8)
        return bounded(raw * 0.01, -40.0, 200.0)
    }

    private fun decodeBattery(snap: Map<Int, ByteArray>): BatteryStatus? {
        fun sig(id: Int, vararg names: String): Double? {
            val data = snap[id] ?: return null
            val vals = dbc.decode(id, data)
            for (n in names) vals.firstOrNull { it.name.equals(n, true) }?.let { return it.value }
            for (n in names) vals.firstOrNull { it.name.contains(n, true) }?.let { return it.value }
            return null
        }
        val soc = bounded(sig(0x353, "Display_SoC") ?: sig(0x11C, "Pack_SOC_00") ?: sig(0x120, "Overall_SOC"), 0.0, 100.0)
        val range = bounded(sig(0x353, "Vehicle_Range"), 0.0, 400.0)
        val amps = sig(0x120, "Overall_Battery_Current")
        val volts = bounded(sig(0x640, "Bus_Voltage_00_10ms") ?: sig(0x11C, "Battery_voltage_OCV_00"), 0.0, 200.0)
        // Temps/speed straight from 0x313 (MCU_Data_1) per firmware parserMcuData:
        //   MCU_temp = LE16(b2:4)*0.01, motor_temp = LE16(b4:6)*0.01. Bounded so a fault
        //   raw shows '—' instead of e.g. 386 degC.
        val mcuT = temp313(snap, 2)
        val motorT = temp313(snap, 4)
        val speed = bounded(sig(0x313, "Vehicle_speed_in_kmph", "Vehicle_Speed", "Motor_Speed"), 0.0, 200.0)
        val chgConn = ((sig(0x62D, "Charger_Connected") ?: 0.0) > 0.5) ||
            ((sig(0x62D, "Charger_Plugged_In") ?: 0.0) > 0.5)
        val charging = chgConn && (amps ?: 0.0) > 0.5
        if (soc == null && volts == null && range == null && amps == null) return null
        return BatteryStatus(soc, range, volts, amps, motorT, mcuT, null, charging, chgConn, speed, System.currentTimeMillis())
    }

    // ---- fault-watch (wiggle-test) : SET/CLEAR of broadcast fault bits ----
    fun startWatch() {
        if (_ui.value.conn != Conn.CONNECTED) { set { copy(message = "Connect first") }; return }
        watchState.clear()
        set { copy(watchOn = true, watchActive = emptyList(), watchLog = emptyList()) }
        if (_ui.value.demo) { startDemoWatch(); return }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                stopKeepAlive(); unlocked.clear(); val c = client!!; if (c.streamMode != "dump") c.startReader(dump = true)
            }
            set { copy(unlockedVcu = false) }
            watchTick?.cancel()
            watchTick = viewModelScope.launch { while (isActive) { tickWatch(); delay(300) } }
        }
    }
    private fun tickWatch() {
        val snapshot = latestRaw.mapValues { it.value.second }
        val active = FaultBits.active(dbc, snapshot)
        val now = System.currentTimeMillis()
        val events = ArrayList(_ui.value.watchLog)
        for (a in active) if (a !in watchState) events.add(0, WatchEvent(now, true, a))
        for (p in watchState) if (p !in active) events.add(0, WatchEvent(now, false, p))
        watchState.clear(); watchState.addAll(active)
        set { copy(watchActive = active.toList(), watchLog = events.take(120)) }
    }
    fun stopWatch() { watchTick?.cancel(); watchTick = null; set { copy(watchOn = false) } }

    private fun startDemoWatch() {
        watchTick?.cancel()
        watchTick = viewModelScope.launch {
            val bit = "0x333 / Motor_temperature_sensor_disconnection_fault_Grade_2"
            var on = false; var n = 0
            while (isActive) {
                delay(1500); n++
                if (n % 3 == 0) {
                    on = !on
                    val ev = WatchEvent(System.currentTimeMillis(), on, bit)
                    set { copy(watchActive = if (on) listOf(bit) else emptyList(), watchLog = (listOf(ev) + watchLog).take(120)) }
                }
            }
        }
    }

    // ---- ride-mode sniffer (0x143) ----
    fun startModeSniff() {
        if (_ui.value.conn != Conn.CONNECTED) { set { copy(message = "Connect first") }; return }
        lastRideRaw = ""
        set { copy(modeOn = true, modeLog = emptyList(), rideMode = "—") }
        if (_ui.value.demo) { startDemoMode(); return }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                stopKeepAlive(); unlocked.clear(); val c = client!!; if (c.streamMode != "dump") c.startReader(dump = true)
            }
            modeTick?.cancel()
            modeTick = viewModelScope.launch { while (isActive) { tickMode(); delay(300) } }
        }
    }
    private fun tickMode() {
        val data = latestRaw[0x143]?.second ?: return
        val vals = dbc.decode(0x143, data).associate { it.name to it.value }
        val l1 = vals["Vehicle_Mode_Level_1"]?.toInt() ?: return
        val dr = vals["Drive_Request"]?.toInt() ?: 0
        val text = "L1=$l1 ${rideModeName(l1)} · Drive=$dr"
        if (text != lastRideRaw) {
            lastRideRaw = text
            val ev = ModeEvent(System.currentTimeMillis(), text)
            set { copy(rideMode = "${rideModeName(l1)} (idx $l1)", modeLog = (listOf(ev) + modeLog).take(60)) }
        }
    }
    fun stopModeSniff() { modeTick?.cancel(); modeTick = null; set { copy(modeOn = false) } }
    private fun rideModeName(i: Int) = when (i) {
        0 -> "Eco"; 1 -> "Normal"; 2 -> "Sport"; 3 -> "Boost/Hyper"; 4 -> "Reverse"; 5 -> "Limp"; 6 -> "Turbo"; else -> "?"
    }
    private fun startDemoMode() {
        modeTick?.cancel()
        modeTick = viewModelScope.launch {
            val seq = listOf(0, 1, 2, 3); var i = 0
            while (isActive) {
                val idx = seq[i % seq.size]; i++
                val ev = ModeEvent(System.currentTimeMillis(), "L1=$idx ${rideModeName(idx)} · Drive=1")
                set { copy(rideMode = "${rideModeName(idx)} (idx $idx)", modeLog = (listOf(ev) + modeLog).take(60)) }
                delay(2000)
            }
        }
    }

    // ---- export (share sheet builds the intent in the UI) ----
    fun faultReport(): String = buildString {
        appendLine("S1 Diag — fault report")
        appendLine("Mode ${_ui.value.mode} · fw ${_ui.value.firmware}")
        _ui.value.info?.let { appendLine("VIN ${it.vin}") }
        appendLine()
        if (_ui.value.faults.isEmpty()) appendLine("(no ECU read yet)")
        for ((ecu, list) in _ui.value.faults) {
            appendLine("[$ecu] ${list.size} DTC(s)")
            for (f in list) appendLine("  ${f.code}  ${f.description}  status ${"%02X".format(f.status)}  ${f.statusFlags.joinToString(",")}")
        }
    }
    fun liveCsv(): String = buildString {
        appendLine("can_id,message,signal,value,unit")
        for (r in _ui.value.live) appendLine("%03X,%s,%s,%s,%s".format(r.id, r.message, r.signal, r.value, r.unit))
    }

    override fun onCleared() {
        stopKeepAlive(); stopLive(); stopWatch(); stopModeSniff(); stopAutoMonitor(); try { client?.close() } catch (_: Exception) {}
    }
}
