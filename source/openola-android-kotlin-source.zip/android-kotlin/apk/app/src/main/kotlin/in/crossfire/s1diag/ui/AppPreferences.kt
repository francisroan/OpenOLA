package `in`.crossfire.s1diag.ui

import android.content.Context
import androidx.compose.runtime.*

enum class Appearance(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }
enum class AdvancedFeature(val label: String, val description: String) {
    LIVE("Live signals", "Search and inspect decoded CAN signals."),
    CHARGING("Charging", "Charger status, session recording and stop control."),
    BLE("Bluetooth controls", "Owner BLE pairing, locks, trunk and lights."),
    ACTUATORS("Actuator tests", "Lights, switches, locks and service-mode tests."),
    PARAMETERS("Parameters", "Read and write ECU calibration values."),
    FEATURES("Vehicle features", "Inspect and change supported feature settings."),
    ENGINEERING("Engineering tools", "Vehicle identifiers, calibration, self-tests and fault watch."),
    FAULT_ACTIONS("Fault clearing & ECU restart", "Existing clear, restart and recovery actions. Deep-sleep BMS wake is unverified."),
}
data class ToolGroup(val title: String, val features: List<AdvancedFeature>)
val AdvancedGroups = listOf(
    ToolGroup("Monitoring", listOf(AdvancedFeature.LIVE, AdvancedFeature.CHARGING)),
    ToolGroup("Vehicle controls", listOf(AdvancedFeature.BLE, AdvancedFeature.FEATURES)),
    ToolGroup("Service & recovery", listOf(AdvancedFeature.ACTUATORS, AdvancedFeature.FAULT_ACTIONS)),
    ToolGroup("Calibration & engineering", listOf(AdvancedFeature.PARAMETERS, AdvancedFeature.ENGINEERING)),
)
@Stable
class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("openola_ui", Context.MODE_PRIVATE)
    var appearance by mutableStateOf(Appearance.entries.firstOrNull { it.name == prefs.getString("appearance", "SYSTEM") } ?: Appearance.SYSTEM)
        private set
    var reduceMotion by mutableStateOf(prefs.getBoolean("reduce_motion", false))
        private set
    var enabled by mutableStateOf(prefs.getStringSet("advanced", emptySet()).orEmpty().toSet())
        private set
    fun chooseAppearance(value: Appearance) { appearance = value; prefs.edit().putString("appearance", value.name).apply() }
    fun changeMotion(value: Boolean) { reduceMotion = value; prefs.edit().putBoolean("reduce_motion", value).apply() }
    fun isEnabled(feature: AdvancedFeature) = feature.name in enabled
    fun setEnabled(feature: AdvancedFeature, value: Boolean) {
        enabled = if (value) enabled + feature.name else enabled - feature.name
        prefs.edit().putStringSet("advanced", enabled).apply()
    }
}
