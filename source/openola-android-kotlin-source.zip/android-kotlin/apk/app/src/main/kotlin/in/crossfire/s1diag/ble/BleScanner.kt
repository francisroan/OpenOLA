package `in`.crossfire.s1diag.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import kotlinx.coroutines.delay

data class BleDevice(val name: String, val address: String, val rssi: Int)

/** Scan nearby BLE devices for [seconds] and return them, strongest signal first.
 *  Requires BLUETOOTH_SCAN (Android 12+) / location (older). */
@SuppressLint("MissingPermission")
object BleScanner {
    suspend fun scan(ctx: Context, seconds: Int = 6): List<BleDevice> {
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
            ?: return emptyList()
        val scanner = adapter.bluetoothLeScanner ?: return emptyList()
        val found = LinkedHashMap<String, BleDevice>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val addr = result.device.address ?: return
                val name = result.scanRecord?.deviceName ?: (try { result.device.name } catch (_: Exception) { null }) ?: ""
                val prev = found[addr]
                if (prev == null || result.rssi > prev.rssi) found[addr] = BleDevice(name, addr, result.rssi)
            }
        }
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner.startScan(null, settings, cb)
        try { delay(seconds * 1000L) } finally { try { scanner.stopScan(cb) } catch (_: Exception) {} }
        return found.values.sortedByDescending { it.rssi }
    }
}
