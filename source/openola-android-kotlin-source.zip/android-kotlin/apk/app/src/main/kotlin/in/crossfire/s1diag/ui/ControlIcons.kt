package `in`.crossfire.s1diag.ui
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import `in`.crossfire.s1diag.ui.theme.*

enum class ControlGlyph { Horn, Drl, LowBeam, HighBeam, LeftIndicator, RightIndicator, BrakeLight, Lock, Unlock, Trunk, Battery, Generic }
fun glyphForLabel(label: String): ControlGlyph {
    val n = label.lowercase()
    return when {
        n == "horn" -> ControlGlyph.Horn
        "drl" in n -> ControlGlyph.Drl
        "low beam" in n -> ControlGlyph.LowBeam
        "high beam" in n -> ControlGlyph.HighBeam
        "left indicator" in n -> ControlGlyph.LeftIndicator
        "right indicator" in n -> ControlGlyph.RightIndicator
        "brake" in n -> ControlGlyph.BrakeLight
        n == "lock" || "steering lock" in n -> ControlGlyph.Lock
        n == "unlock" -> ControlGlyph.Unlock
        "trunk" in n || "seat lock" in n -> ControlGlyph.Trunk
        else -> ControlGlyph.Generic
    }
}
@Composable
fun ControlIcon(glyph: ControlGlyph, active: Boolean, size: Dp = 40.dp) {
    val icon = when (glyph) {
        ControlGlyph.Horn -> Icons.Outlined.VolumeUp
        ControlGlyph.Drl -> Icons.Outlined.WbSunny
        ControlGlyph.LowBeam -> Icons.Outlined.LightMode
        ControlGlyph.HighBeam -> Icons.Outlined.Highlight
        ControlGlyph.LeftIndicator -> Icons.Outlined.ArrowBack
        ControlGlyph.RightIndicator -> Icons.Outlined.ArrowForward
        ControlGlyph.BrakeLight -> Icons.Outlined.Lightbulb
        ControlGlyph.Lock -> Icons.Outlined.Lock
        ControlGlyph.Unlock -> Icons.Outlined.LockOpen
        ControlGlyph.Trunk -> Icons.Outlined.Inventory2
        ControlGlyph.Battery -> Icons.Outlined.BatteryFull
        ControlGlyph.Generic -> Icons.Outlined.Tune
    }
    Icon(icon, contentDescription = glyph.name, tint = if (active) Accent else TextMut, modifier = Modifier.size(size))
}
