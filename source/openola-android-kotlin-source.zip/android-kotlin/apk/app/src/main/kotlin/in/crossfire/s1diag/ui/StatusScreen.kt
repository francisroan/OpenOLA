package `in`.crossfire.s1diag.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.DiagViewModel
import java.util.Locale

@Composable
fun StatusScreen(vm: DiagViewModel, onFaults: () -> Unit = {}, onReports: () -> Unit = {}) {
    val rawUi by vm.ui.collectAsStateWithLifecycle()
    val ui = remember(rawUi) { withDemoBattery(rawUi) }
    val now by rememberUiClock()
    val stale = !ui.demo && (telemetryAgeMs(ui.lastCanFrameAt, now)?.let { it > STALE_AFTER_MS } ?: true)
    val b = ui.battery
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { PageHeading("Overview", if (ui.demo) "Demo session · simulated scooter" else "Battery and diagnostic snapshot") }
        item {
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.BatteryFull, null, tint = Accent)
                    Spacer(Modifier.width(10.dp))
                    Text("Battery", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    val label = when { b == null -> "Waiting"; stale -> "Cached"; b.charging -> "Charging"; b.chargerConnected -> "Plugged in"; else -> "Snapshot" }
                    Surface(color = if (stale) Warn.copy(alpha = 0.1f) else AccentGlow, shape = RoundedCornerShape(10.dp)) {
                        Text(label, color = if (stale) Warn else Accent, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(b?.soc?.let { String.format(Locale.US, "%.0f", it) } ?: "—", style = MaterialTheme.typography.displayLarge, color = TextHi)
                    Text("%", style = MaterialTheme.typography.headlineMedium, color = TextMut, modifier = Modifier.padding(start = 4.dp, bottom = 10.dp))
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(bottom = 12.dp)) {
                        Text(b?.rangeKm?.let { String.format(Locale.US, "%.0f km", it) } ?: "— km", style = MaterialTheme.typography.titleLarge)
                        Text("Reported range", color = TextMut, style = MaterialTheme.typography.bodySmall)
                    }
                }
                val progress by animateFloatAsState(((b?.soc ?: 0.0) / 100).toFloat().coerceIn(0f, 1f), tween(if (LocalReduceMotion.current) 0 else 300), label = "batteryLevel")
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = if (stale) TextMut else Accent, trackColor = Surface2)
                Text(freshnessText(ui.lastCanFrameAt, now, ui.demo), color = if (stale) Warn else TextMut, style = MaterialTheme.typography.bodySmall)
                if (stale) Text("These values may be cached. A connected link does not guarantee fresh readings.", color = TextMut, style = MaterialTheme.typography.bodySmall)
                BoxWithConstraints {
                    val metrics = listOf(
                        "Pack voltage" to diagnosticValue(b?.packVolts, "V"),
                        "Pack current" to diagnosticValue(b?.packAmps, "A"),
                        "Battery temp" to diagnosticValue(b?.battTemp, "°C"),
                        "Motor temp" to diagnosticValue(b?.motorTemp, "°C"),
                        "Controller temp" to diagnosticValue(b?.mcuTemp, "°C"),
                        "Vehicle speed" to diagnosticValue(b?.speedKmh, "km/h"),
                    )
                    val columns = if (maxWidth >= 600.dp) 3 else 2
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        metrics.chunked(columns).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                row.forEach { (label, value) -> MetricTile(label, value, Modifier.weight(1f)) }
                                repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
                Text("— means the value is unavailable. State of charge alone does not establish battery health.", color = TextMut, style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("Fault overview") {
                val received = ui.demo || ui.lastCanFrameAt > 0L
                val stored = ui.faults.values.sumOf { it.size }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricTile("Broadcast flags", if (received) ui.activeFaults.size.toString() else "—", Modifier.weight(1f))
                    MetricTile("Stored codes", if (ui.faults.isEmpty()) "Not scanned" else stored.toString(), Modifier.weight(1f))
                }
                Text(when {
                    !received -> "Waiting for broadcast fault data."
                    stale -> "Broadcast flags are cached. Read stored codes for a diagnostic scan."
                    ui.activeFaults.isEmpty() -> "No active broadcast flags detected. Stored faults need a separate scan."
                    else -> "Active broadcast flags detected. Open Faults for details."
                }, color = if (ui.activeFaults.isNotEmpty()) Danger else TextMut, style = MaterialTheme.typography.bodyMedium)
                ui.activeFaults.take(4).forEach { Text(it, color = Danger, style = MaterialTheme.typography.bodyMedium) }
                Button(onClick = onFaults, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                    Icon(Icons.Outlined.HealthAndSafety, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Inspect faults")
                }
            }
        }
        item {
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.Description, null, tint = Accent)
                    Column(Modifier.weight(1f)) {
                        Text("Keep a diagnostic record", style = MaterialTheme.typography.titleMedium)
                        Text("Review and export the current snapshot.", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                OutlinedButton(onClick = onReports, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Create report") }
            }
        }
        if (ui.notifications.isNotEmpty()) item {
            SectionCard("Vehicle messages") {
                ui.notifications.take(8).forEach { Text(it.name, color = if (it.alert) Danger else TextMut, style = MaterialTheme.typography.bodyMedium) }
                TextButton(onClick = vm::clearNotifications) { Text("Clear message list") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Mode: ${ui.mode}", color = TextMut, style = MaterialTheme.typography.bodySmall)
                Text("Firmware: ${ui.firmware}", color = TextMut, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
fun diagnosticValue(value: Double?, unit: String): String =
    if (value == null || !value.isFinite()) "—" else String.format(Locale.US, "%.1f %s", value, unit)
