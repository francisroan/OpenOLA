package `in`.crossfire.s1diag.data

import android.content.Context
import org.json.JSONObject

data class DbcSignal(
    val name: String,
    val startBit: Int,
    val bitLength: Int,
    val intel: Boolean,       // true = little-endian, false = motorola/big-endian
    val scaling: Double,
    val offset: Double,
    val signed: Boolean,
    val units: String,
)

data class DbcMessage(val name: String, val id: Int, val dlc: Int, val signals: List<DbcSignal>)

data class SignalValue(val name: String, val value: Double, val units: String)

/**
 * CAN DBC catalog (da_can_dbc.json) for decoding live signal frames.
 * Bit extraction supports both Intel (little-endian) and Motorola (big-endian, sawtooth).
 */
class Dbc private constructor(private val byId: Map<Int, DbcMessage>) {

    fun message(id: Int): DbcMessage? = byId[id]
    val messageCount: Int get() = byId.size

    fun decode(id: Int, data: ByteArray): List<SignalValue> {
        val msg = byId[id] ?: return emptyList()
        val out = ArrayList<SignalValue>(msg.signals.size)
        for (s in msg.signals) {
            val raw = if (s.intel) extractIntel(data, s.startBit, s.bitLength)
                      else extractMotorola(data, s.startBit, s.bitLength)
            var v = raw
            if (s.signed && s.bitLength < 64) {
                val signBit = 1L shl (s.bitLength - 1)
                if (raw and signBit != 0L) v = raw - (1L shl s.bitLength)
            }
            val phys = v.toDouble() * s.scaling + s.offset
            out.add(SignalValue(s.name, phys, s.units))
        }
        return out
    }

    private fun extractIntel(data: ByteArray, startBit: Int, len: Int): Long {
        var raw = 0L
        for (i in 0 until minOf(8, data.size)) {
            raw = raw or ((data[i].toLong() and 0xFF) shl (8 * i))
        }
        val mask = if (len >= 64) -1L else (1L shl len) - 1
        return (raw ushr startBit) and mask
    }

    private fun extractMotorola(data: ByteArray, startBit: Int, len: Int): Long {
        // cantools-style sawtooth bit walk
        var value = 0L
        var index = startBit
        for (k in 0 until len) {
            val byteIdx = index / 8
            val bitIdx = index % 8
            val bit = if (byteIdx < data.size) (data[byteIdx].toInt() ushr bitIdx) and 1 else 0
            value = (value shl 1) or bit.toLong()
            index = if (bitIdx == 0) index + 15 else index - 1
        }
        return value
    }

    companion object {
        fun load(ctx: Context): Dbc {
            val text = ctx.assets.open("da_can_dbc.json").bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            val msgs = root.getJSONArray("messages")
            val map = HashMap<Int, DbcMessage>(msgs.length())
            for (i in 0 until msgs.length()) {
                val m = msgs.getJSONObject(i)
                val sigsArr = m.optJSONArray("signals")
                val sigs = ArrayList<DbcSignal>()
                if (sigsArr != null) for (j in 0 until sigsArr.length()) {
                    val s = sigsArr.getJSONObject(j)
                    sigs.add(
                        DbcSignal(
                            name = s.getString("name"),
                            startBit = s.getInt("startbit"),
                            bitLength = s.getInt("bitlength"),
                            intel = s.optString("endianess", "intel").equals("intel", true),
                            scaling = s.optDouble("scaling", 1.0),
                            offset = s.optDouble("offset", 0.0),
                            signed = s.optBoolean("signed", false),
                            units = s.optString("units", ""),
                        )
                    )
                }
                val id = m.getInt("id")
                map[id] = DbcMessage(m.optString("name", "MSG_$id"), id, m.optInt("dlc", 8), sigs)
            }
            return Dbc(map)
        }
    }
}
