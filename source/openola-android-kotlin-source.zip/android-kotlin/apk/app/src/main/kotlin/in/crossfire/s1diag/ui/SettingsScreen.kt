package `in`.crossfire.s1diag.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.selection.selectable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.platform.LocalContext
import `in`.crossfire.s1diag.data.AutoLog
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.crossfire.s1diag.ui.theme.*
import `in`.crossfire.s1diag.vm.DiagViewModel

@Composable
fun SettingsScreen(vm: DiagViewModel, prefs: AppPreferences) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showLog by remember { mutableStateOf(false) }
    val activityPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? -> uri?.let(vm::setActivityLogFolder) }
    val chargePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? -> uri?.let(vm::setChargeLogFolder) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageHeading("Settings", "Make this workspace yours.") }
        item {
            SectionCard("Appearance") {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface2).padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Appearance.entries.forEach { appearance ->
                        val selected = appearance == prefs.appearance
                        val shape = RoundedCornerShape(12.dp)
                        val fill = if (LocalPalette.current.dark) Color.White.copy(alpha = .15f) else Color.White.copy(alpha = .9f)
                        Column(Modifier.weight(1f)
                            .clip(shape).background(if (selected) fill else Color.Transparent)
                            .selectable(selected = selected, role = Role.RadioButton) { prefs.chooseAppearance(appearance) }
                            .heightIn(min = 60.dp).padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(when (appearance) { Appearance.LIGHT -> GlassIcons.Sun; Appearance.DARK -> GlassIcons.Moon; else -> GlassIcons.Auto },
                                null, modifier = Modifier.size(19.dp), tint = if (selected) TextHi else TextMut)
                            Text(appearance.label, color = if (selected) TextHi else TextMut, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
                SettingToggle("Reduce motion", "Keep transitions and control feedback simple.", prefs.reduceMotion, onCheckedChange = prefs::changeMotion)
            }
        }
        item { PageHeading("Advanced tools", "Enable the tools you use. Find them in the top-right tools menu.") }
        AdvancedGroups.forEach { group ->
            item(key = group.title) {
                SectionCard(group.title) {
                    group.features.forEachIndexed { index, feature ->
                        val active = when (feature) {
                            AdvancedFeature.LIVE -> ui.liveOn
                            AdvancedFeature.CHARGING -> ui.chargeSnoopOn
                            AdvancedFeature.ACTUATORS -> ui.latched.isNotEmpty()
                            AdvancedFeature.ENGINEERING -> ui.watchOn || ui.modeOn
                            else -> false
                        }
                        if (index > 0) HorizontalDivider(color = Line)
                        val selected = prefs.isEnabled(feature)
                        SettingToggle(feature.label,
                            if (active && selected) "Stop the active operation before disabling this tool." else feature.description,
                            selected, enabled = !ui.busy && (!active || !selected)) { prefs.setEnabled(feature, it) }
                    }
                }
            }
        }
        item {
            SectionCard("Log storage") {
                Text("Activity logs record commands and faults once connected. Folder changes apply to the next session.", style = MaterialTheme.typography.bodyMedium, color = TextMut)
                Text("Activity", style = MaterialTheme.typography.labelLarge)
                Text(ui.activityDirLabel.ifBlank { vm.logsDirPath() }, color = TextMut, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { activityPicker.launch(null) }, modifier = Modifier.weight(1f)) { Text("Choose folder") }
                    TextButton(onClick = vm::resetActivityLogFolder) { Text("Default") }
                }
                HorizontalDivider(color = Line)
                Text("Charging", style = MaterialTheme.typography.labelLarge)
                Text(ui.chargeDirLabel.ifBlank { vm.chargingDirPath() }, color = TextMut, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { chargePicker.launch(null) }, modifier = Modifier.weight(1f)) { Text("Choose folder") }
                    TextButton(onClick = vm::resetChargeLogFolder) { Text("Default") }
                }
                SettingToggle("Extra battery logging", "Add a battery snapshot every 30 seconds while connected.", ui.autoLogOn) { vm.toggleAutoLog() }
            }
        }
        item {
            SectionCard("Activity log") {
                Text("Commands and faults are logged while connected.", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                ui.activityLogPath?.let { Text(it, color = TextMut, style = MaterialTheme.typography.bodySmall) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { shareText(context, "OpenOLA activity log", vm.autoLogText()) }, modifier = Modifier.weight(1f)) { Text("Share log") }
                    TextButton(onClick = vm::clearAutoLog) { Text("Clear view") }
                }
                TextButton(onClick = { showLog = !showLog }) { Text(if (showLog) "Hide recent entries" else "Show recent entries") }
                if (showLog) {
                    val lines by AutoLog.lines.collectAsStateWithLifecycle()
                    SelectionContainer {
                        Text(lines.takeLast(40).joinToString("\n").ifBlank { "No activity yet." }, color = TextMut, style = MaterialTheme.typography.bodySmall, fontFamily = Mono)
                    }
                }
            }
        }
        item {
            SectionCard("About OpenOLA") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OpenOlaMark()
                    Text("Open diagnostics for your scooter.", style = MaterialTheme.typography.titleMedium)
                }
                Text("Designed for owners and independent technicians. Works locally without a cloud account.", color = TextMut, style = MaterialTheme.typography.bodyMedium)
                Text("Deep-sleep BMS wake has not been validated. Existing ECU restart and fault recovery are different operations.", color = TextMut, style = MaterialTheme.typography.bodySmall)
                Text("Version 0.2.1", color = TextMut, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
@Composable
fun SettingToggle(title: String, description: String, checked: Boolean, enabled: Boolean = true, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = TextHi)
            Text(description, style = MaterialTheme.typography.bodyMedium, color = TextMut)
        }
        GlassToggle(title, checked, enabled, onCheckedChange)
    }
}
@Composable
fun PageHeading(title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, color = TextHi)
        subtitle?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = TextMut) }
    }
}
