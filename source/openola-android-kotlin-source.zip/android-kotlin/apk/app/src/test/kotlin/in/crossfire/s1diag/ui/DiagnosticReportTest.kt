package `in`.crossfire.s1diag.ui

import org.junit.Assert.*
import org.junit.Test
import `in`.crossfire.s1diag.vm.*
import `in`.crossfire.s1diag.uds.*
import java.io.File

class DiagnosticReportTest {
    @Test fun demoPresentationCannotInventRealVehicleReadings() {
        val rows = listOf(LiveRow(1, "demo", "Overall_SOC", 82.5, "%", 1000))
        assertNull(withDemoBattery(UiState(live = rows)).battery)
        val demo = withDemoBattery(UiState(demo = true, live = rows))
        assertEquals(82.5, demo.battery!!.soc!!, 0.001)
        assertNull(demo.battery!!.rangeKm)
        assertTrue(DiagnosticReport.capture(demo, 2000).text.contains("SIMULATED DATA"))
    }
    @Test fun unscannedAndUnavailableAreExplicit() {
        val report = DiagnosticReport.capture(UiState(), 20000)
        assertTrue(report.text.contains("BMS: NOT SCANNED"))
        assertTrue(report.text.contains("State of charge (%): Unavailable"))
        assertTrue(report.json.contains("\"scanned\":false"))
        assertTrue(report.json.contains("\"State of charge (%)\": null"))
        assertTrue(report.json.contains("\"broadcast_faults_available\": false"))
    }
    @Test fun zeroCodesAreDifferentFromUnscanned() {
        val report = DiagnosticReport.capture(UiState(faults = mapOf(Ecu.BMS to emptyList())), 20000)
        assertTrue(report.text.contains("BMS: 0 codes returned"))
        assertTrue(report.text.contains("MCU: NOT SCANNED"))
        assertTrue(report.text.contains("not proof of battery health"))
    }
    @Test fun demoCannotMasqueradeAsVehicleEvidence() {
        val report = DiagnosticReport.capture(UiState(demo = true, conn = Conn.CONNECTED), 20000)
        assertTrue(report.text.contains("DEMO — SIMULATED DATA"))
        assertTrue(report.json.contains("\"demo\": true"))
        assertTrue(report.json.contains("\"deep_sleep_bms_wake_validated\": false"))
    }
    @Test fun vinAndActivityRequireSelection() {
        val ui = UiState(info = VehicleInfo("OWNER-VIN-SECRET", "sw", "aosp", "manifest"))
        val privateReport = DiagnosticReport.capture(ui, 20000)
        assertFalse(privateReport.text.contains("OWNER-VIN-SECRET"))
        assertFalse(privateReport.json.contains("OWNER-VIN-SECRET"))
        assertTrue(privateReport.json.contains("\"activity_log\": null"))
        val selected = DiagnosticReport.capture(ui, 20000, true, "selected activity")
        assertTrue(selected.text.contains("OWNER-VIN-SECRET"))
        assertTrue(selected.json.contains("selected activity"))
    }
    @Test fun staleAndDisconnectedSnapshotsAreLabelled() {
        val report = DiagnosticReport.capture(UiState(conn = Conn.CONNECTED, lastCanFrameAt = 1000), 20000)
        assertTrue(report.text.contains("STALE"))
        val offline = DiagnosticReport.capture(UiState(conn = Conn.IDLE, lastCanFrameAt = 19999), 20000)
        assertTrue(offline.text.contains("DISCONNECTED — cached"))
        assertNull(telemetryAgeMs(0, 20000))
        assertEquals(0L, telemetryAgeMs(30000, 20000))
    }
    @Test fun jsonEscapingAndNonFiniteMetricsStayValid() {
        val ui = UiState(
            conn = Conn.CONNECTED, lastCanFrameAt = 19900,
            battery = BatteryStatus(soc = Double.NaN, packVolts = Double.POSITIVE_INFINITY),
            faults = mapOf(Ecu.BMS to listOf(Fault("P1234", "quote \" slash \\ newline\n tab\t", false, 1, listOf("testFailed")))),
        )
        val report = DiagnosticReport.capture(ui, 20000)
        assertFalse(report.json.contains("NaN"))
        assertFalse(report.json.contains("Infinity"))
        assertTrue(report.json.contains("\\n"))
        assertEquals("\"line\\nquote\\\"slash\\\\\"", jsonString("line\nquote\"slash\\"))
        File("build/outputs/openola-report-test.json").apply { parentFile?.mkdirs(); writeText(report.json) }
    }
    @Test fun snapshotsDoNotChangeWhenSourceStateChanges() {
        val source = UiState(battery = BatteryStatus(soc = 70.0))
        val snapshot = DiagnosticReport.capture(source, 20000)
        source.copy(battery = BatteryStatus(soc = 10.0))
        assertTrue(snapshot.text.contains("State of charge (%): 70.0"))
        assertFalse(snapshot.text.contains("State of charge (%): 10.0"))
    }
}
