# gRPC / protobuf-lite
-keep class io.grpc.** { *; }
-keep class wifican.** { *; }
-dontwarn io.grpc.**
-dontwarn com.google.protobuf.**
-keep class * extends com.google.protobuf.GeneratedMessageLite { *; }
# Conscrypt
-keep class org.conscrypt.** { *; }
-dontwarn org.conscrypt.**
# OkHttp used by grpc-okhttp
-dontwarn okhttp3.**
-dontwarn okio.**
