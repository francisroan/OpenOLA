import com.google.protobuf.gradle.id

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.protobuf")
}

android {
    namespace = "in.crossfire.s1diag"
    compileSdk = 34

    defaultConfig {
        applicationId = "in.crossfire.s1diag"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "0.2.1-openola"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables { useSupportLibrary = true }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    // Compose compiler is supplied by the org.jetbrains.kotlin.plugin.compose plugin (Kotlin 2.0+).

    packaging {
        resources {
            // gRPC / netty / okhttp bring duplicate meta files
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/INDEX.LIST"
            excludes += "/META-INF/io.netty.versions.properties"
            pickFirsts += "META-INF/*"
        }
    }
    sourceSets["main"].java.srcDirs("src/main/kotlin")
}

protobuf {
    protoc { artifact = "com.google.protobuf:protoc:3.25.3" }
    plugins {
        id("grpc") { artifact = "io.grpc:protoc-gen-grpc-java:1.66.0" }
    }
    generateProtoTasks {
        all().forEach { task ->
            task.plugins { id("grpc") { option("lite") } }
            task.builtins { id("java") { option("lite") } }
        }
    }
}

dependencies {
    // Compose
    val composeBom = platform("androidx.compose:compose-bom:2024.09.02")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    // Hardware backdrop blur for glass surfaces; older Android uses a translucent fallback.
    implementation("dev.chrisbanes.haze:haze:1.1.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.navigation:navigation-compose:2.8.1")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.documentfile:documentfile:1.0.1")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // gRPC (protobuf-lite for Android)
    implementation("io.grpc:grpc-okhttp:1.66.0")
    implementation("io.grpc:grpc-protobuf-lite:1.66.0")
    implementation("io.grpc:grpc-stub:1.66.0")
    implementation("com.google.protobuf:protobuf-javalite:3.25.3")
    compileOnly("org.apache.tomcat:annotations-api:6.0.53")

    // TLS provider for mTLS on older Android
    // 2.5.2's native ELF segments are only 4 KB aligned and trigger Android's compat warning.
    implementation("org.conscrypt:conscrypt-android:2.6.3")

    // QR Code scanning
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")

    // DTC/DBC/ODX catalogs are parsed with Android's built-in org.json (no extra dep).
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation(composeBom)
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("androidx.test.ext:junit:1.3.0")
    androidTestImplementation("androidx.test:runner:1.7.0")
    // Older Espresso reflects InputManager.getInstance, removed on Android 17.
    androidTestImplementation("androidx.test.espresso:espresso-core:3.7.0")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
