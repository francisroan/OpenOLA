# OpenOLA UI dependencies and assets

The glass UI uses [Haze 1.1.1](https://github.com/chrisbanes/haze/tree/1.1.1), copyright Christopher Banes and the Haze project contributors, licensed under [Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0). It renders captured background blur on supported Android versions and a translucent fallback on older versions. No Haze source was copied into this project.

The UI palette and line-path language follow this workspace's desktop glass implementation (`tool/glass/web/style.css` and `app.js`). `GlassIcons.kt` contains code-native paths; it includes no SF Symbols font or Apple artwork. The supplied scooter render is reused from the existing app resources for the local development icon. Its redistribution provenance remains part of the project's existing asset inventory.

[Conscrypt 2.6.3](https://github.com/google/conscrypt/releases/tag/2.6.3) replaces 2.5.2 to support 16 KB native page alignment. Conscrypt is Apache 2.0 licensed and bundles BoringSSL under its included licences. Existing certificate loading and scooter transport source are unchanged; the provider upgrade requires runtime TLS verification and subsequent scooter testing.

Other existing AndroidX, gRPC, protobuf and QR dependencies remain governed by their respective licences. This document describes the additions in this rebuild; it is not a complete project redistribution audit.
