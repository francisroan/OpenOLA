# Flutter port provenance

The port references `../apk/app/src/main/kotlin/in/crossfire/s1diag/` for CAN/UDS, seed/key, HMI ordinals and BLE wire/crypto/session behaviour. `proto/wifican.proto` is unchanged from `../apk/app/src/main/proto/wifican.proto`. Catalogs are from `../apk/app/src/main/assets/`. The scooter render is the existing Kotlin app asset. Credentials are the existing workspace identity/trust root; iOS PKCS12 is a format conversion, not a new identity.

The new Dart source and native scaffold are separate from those references. Rights to rendered imagery, extracted catalogs, protocol source and credential redistribution have not been established by this port.

For 0.3.1, `../tool/glass/web/style.css` and `index.html` are the explicit visual reference: color/material tokens, proportions, ring and colored icon tiles were adapted to Flutter widgets. Live demo screenshots were captured locally for comparison. No desktop files were edited.

Inter variable font is from the [Google Fonts Inter directory](https://github.com/google/fonts/tree/main/ofl/inter), SIL Open Font License 1.1; bundled license: `assets/INTER-LICENSE.txt`. Cupertino icons come from Flutter's package. No SF Symbols binary or proprietary Apple font was copied.

| Package | Purpose |
|---|---|
| Flutter, cupertino_icons | Rendering/widgets/icons |
| grpc, protobuf, fixnum, async | Existing gRPC wire protocol |
| shared_preferences | Theme, tool and connection defaults |
| flutter_reactive_ble, permission_handler | Free BLE and Android permissions |
| pointycastle, crypto | Existing BLE crypto formats |
| file_picker, share_plus | Native document export/share |
| mobile_scanner | QR address scan |
| flutter_test, flutter_lints | Local validation |
| protoc_plugin, flutter_launcher_icons | Source generation |

Resolved versions/transitive dependencies are in `pubspec.lock` and the QA inventory. Flutter generates dependency license notices; retain them for distribution. No commercial BLE package or paid cloud service is used. Audit full notices and existing asset ownership when preparing the public repository.

`proto/google/protobuf/empty.proto` retains its upstream notice; it is the protobuf include used by the old build. Generated stubs retain generator headers.

For 0.4.0, updated desktop references are `tool/glass/battery.py`, `session_recorder.py`, `ecu_report.py`, `vehicle_info.py`, `controller.py` and the glass web files. Their cell gauge language, OCV estimate curve, configuration reference bytes and recording schema are adapted into Dart. `tool/status_monitor.py` supplies reconstructed feature/notification interpretation; `tool/moveos5_catalog.json` is copied unchanged into assets. These are source-derived interpretations, not newly validated hardware behavior. `path_provider` 2.1.6 was already in the lockfile and is now a direct dependency for app-local recording storage. No desktop files were edited.
