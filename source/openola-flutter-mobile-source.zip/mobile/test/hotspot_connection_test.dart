import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:openola/diagnostics/controller.dart';
import 'package:openola/screens/core.dart';
import 'vehicle_profile_test.dart' as fixtures;

class ConnectionSpy extends Diagnostics {
  ConnectionSpy(super.catalog, super.prefs);
  bool? requestedHotspot;
  @override
  Future<void> connect(String host, int port, {
    bool secure = false, bool simulated = false, bool phoneHotspot = false,
  }) async {
    requestedHotspot = phoneHotspot;
  }
}

void main() {
  for (final saved in [false, true]) {
    testWidgets('hotspot routing restores $saved and forwards user selection', (tester) async {
      final original = (await tester.runAsync(() => fixtures.fixture(3, '5.0.0')))!;
      await original.prefs.store.setBool('phoneHotspot', saved);
      await original.prefs.store.setString('host', '192.168.43.50');
      final d = ConnectionSpy(original.catalog, original.prefs);
      addTearDown(original.dispose);
      addTearDown(d.dispose);
      tester.view.physicalSize = const Size(500, 1400);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(MaterialApp(home: Scaffold(body: ConnectPage(d: d))));
      final button = find.text('Connect to scooter');
      await tester.ensureVisible(button);
      await tester.tap(button);
      await tester.pump();
      expect(d.requestedHotspot, saved);
      final toggle = find.byType(CupertinoSwitch);
      await tester.ensureVisible(toggle);
      await tester.tap(toggle);
      await tester.pump();
      await tester.ensureVisible(button);
      await tester.tap(button);
      await tester.pump();
      expect(d.requestedHotspot, !saved);
      expect(tester.takeException(), isNull);
    });
  }
}
