/// Compile-time edition switches. The public build keeps both disabled; the
/// separately packaged Super build enables both. These are packaging controls,
/// not scooter-side authorization.
const _superFlavor = String.fromEnvironment('FLUTTER_APP_FLAVOR') == 'super';

const identityWritesAvailable = _superFlavor && bool.fromEnvironment(
  'OPENOLA_IDENTITY_WRITES',
  defaultValue: false,
);

const blePairingAvailable = _superFlavor && bool.fromEnvironment(
  'OPENOLA_BLE_PAIRING',
  defaultValue: false,
);
