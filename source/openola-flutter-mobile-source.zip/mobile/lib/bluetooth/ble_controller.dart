import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';
import 'package:permission_handler/permission_handler.dart';
import 'ble_protocol.dart';

class ScooterBle extends ChangeNotifier {
  late final radio = FlutterReactiveBle();
  final devices = <String, DiscoveredDevice>{};
  StreamSubscription<DiscoveredDevice>? _scan;
  StreamSubscription<ConnectionStateUpdate>? _connection;
  StreamSubscription<List<int>>? _notifications;
  final _frames = StreamController<List<int>>.broadcast();
  final protocol = BleProtocol();
  BleAssembler _assembler = BleAssembler();
  QualifiedCharacteristic? _write;
  List<int>? _key;
  bool scanning = false, busy = false, ready = false, disposed = false;
  String message = '', selectedName = '';
  int? soc;
  bool? locked;
  DateTime? receivedAt;
  void emit() {
    if (!disposed) notifyListeners();
  }

  Future<void> scan() async {
    if (busy) return;
    try {
      final permissions = Platform.isAndroid
          ? [
              Permission.bluetoothScan,
              Permission.bluetoothConnect,
              Permission.locationWhenInUse,
            ]
          : <
              Permission
            >[]; // CoreBluetooth requests iOS permission through the BLE plugin.
      final results = await permissions.request();
      if (results.values.any((p) => p.isPermanentlyDenied)) {
        throw StateError(
          'Bluetooth permission denied. Enable it in system settings.',
        );
      }
      await _scan?.cancel();
      devices.clear();
      scanning = true;
      message = 'Looking for nearby scooters';
      emit();
      _scan = radio
          .scanForDevices(withServices: [], scanMode: ScanMode.lowLatency)
          .listen(
            (device) {
              if (device.name.toUpperCase().contains('OLA') ||
                  device.serviceUuids.any(
                    (s) => s.toString().startsWith('6e400001'),
                  )) {
                devices[device.id] = device;
                emit();
              }
            },
            onError: (Object e) {
              message = 'Scan failed: $e';
              scanning = false;
              emit();
            },
          );
    } catch (e) {
      message = e.toString();
      scanning = false;
      emit();
    }
  }

  Future<void> stopScan() async {
    await _scan?.cancel();
    _scan = null;
    scanning = false;
    emit();
  }

  Future<void> connect(DiscoveredDevice device) async {
    if (busy) return;
    busy = true;
    message = 'Pairing ${device.name}';
    emit();
    try {
      await stopScan();
      await _close();
      _assembler = BleAssembler();
      final connected = Completer<void>();
      _connection = radio
          .connectToDevice(
            id: device.id,
            connectionTimeout: const Duration(seconds: 15),
          )
          .listen(
            (state) {
              if (state.connectionState == DeviceConnectionState.connected &&
                  !connected.isCompleted) {
                connected.complete();
              }
              if (state.connectionState == DeviceConnectionState.disconnected) {
                ready = false;
                _key = null;
                message = 'Bluetooth disconnected';
                if (!connected.isCompleted) {
                  connected.completeError(StateError(message));
                }
                emit();
              }
            },
            onError: (Object e) {
              if (!connected.isCompleted) connected.completeError(e);
              message = '$e';
              ready = false;
              emit();
            },
          );
      await connected.future.timeout(const Duration(seconds: 15));
      await radio.discoverAllServices(device.id);
      final services = await radio.getDiscoveredServices(device.id);
      final service = services.firstWhere(
        (s) => s.id.toString().startsWith('6e400001'),
      );
      final tx = service.characteristics
          .firstWhere((c) => c.id.toString().startsWith('6e400003'))
          .id;
      final rx = service.characteristics
          .firstWhere((c) => c.id.toString().startsWith('6e400002'))
          .id;
      _write = QualifiedCharacteristic(
        characteristicId: tx,
        serviceId: service.id,
        deviceId: device.id,
      );
      _notifications = radio
          .subscribeToCharacteristic(
            QualifiedCharacteristic(
              characteristicId: rx,
              serviceId: service.id,
              deviceId: device.id,
            ),
          )
          .listen(
            (chunk) {
              for (final frame in _assembler.feed(chunk)) {
                _frames.add(frame);
                if (frame[6] == 1 &&
                    frame[7] == 2 &&
                    ![0x70, 0x71, 0x72].contains(frame[8]) &&
                    frame.length >= 16) {
                  final value = frame[12];
                  if (value <= 100) {
                    soc = value;
                    locked = frame[11] != 0;
                    receivedAt = DateTime.now();
                    emit();
                  }
                }
              }
            },
            onError: (Object e) {
              ready = false;
              message = 'Notification error: $e';
              emit();
            },
          );
      await Future<void>.delayed(const Duration(milliseconds: 250));
      final seed = (await _exchange(protocol.plain(48), 0x70)).take(8).toList();
      if (seed.length != 8) throw StateError('Invalid seed reply');
      final key = BleProtocol.seedKey(seed);
      _key = BleProtocol.sessionKey(seed, key);
      final ack = await _exchange(protocol.plain(49, key), 0x71);
      if (ack.isEmpty || ack[0] != 1) {
        throw StateError('Scooter did not authorize this session');
      }
      await _exchange(protocol.encrypted(_key!, 50, 'D_ALIVE'.codeUnits), 0x72);
      selectedName = device.name;
      ready = true;
      message =
          'Authenticated. Pairing and commands still require hardware testing.';
    } catch (e) {
      message = 'Pairing failed: $e';
      await _close();
    } finally {
      busy = false;
      emit();
    }
  }

  Future<List<int>> _reply(int type, Duration timeout) async {
    final frame = await _frames.stream
        .firstWhere((f) => f[8] == type)
        .timeout(timeout);
    return frame.sublist(9, frame.length - 3);
  }

  Future<List<int>> _exchange(List<int> frame, int reply) async {
    final response = _reply(reply, const Duration(seconds: 5));
    final results = await Future.wait<List<int>>([
      response,
      _send(frame).then((_) => <int>[]),
    ]);
    return results.first;
  }

  Future<void> _send(List<int> frame) async {
    final characteristic =
        _write ?? (throw StateError('Bluetooth disconnected'));
    for (var i = 0; i < frame.length; i += 20) {
      await radio.writeCharacteristicWithResponse(
        characteristic,
        value: frame.skip(i).take(20).toList(),
      );
      await Future<void>.delayed(const Duration(milliseconds: 20));
    }
  }

  Future<void> command(int command, String label) async {
    if (busy || !ready) return;
    busy = true;
    emit();
    try {
      await _send(protocol.encrypted(_key!, 1, [command]));
      await Future<void>.delayed(const Duration(milliseconds: 300));
      message =
          '$label sent; verify the scooter. Status reflects received broadcasts.';
    } catch (e) {
      ready = false;
      message = '$label failed: $e';
    } finally {
      busy = false;
      emit();
    }
  }

  Future<void> _close() async {
    ready = false;
    _key = null;
    _write = null;
    await _notifications?.cancel();
    await _connection?.cancel();
    _notifications = null;
    _connection = null;
  }

  Future<void> disconnect() async {
    await stopScan();
    await _close();
    soc = null;
    locked = null;
    receivedAt = null;
    emit();
  }

  @override
  void dispose() {
    disposed = true;
    unawaited(_scan?.cancel());
    unawaited(_close());
    unawaited(_frames.close());
    super.dispose();
  }
}
