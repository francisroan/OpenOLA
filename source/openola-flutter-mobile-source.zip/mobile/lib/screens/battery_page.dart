import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../diagnostics/controller.dart';
import '../diagnostics/battery.dart';
import '../design/glass.dart';
import '../design/dashboard.dart';
import '../design/signal_chart.dart';
import 'core.dart';
import 'identifiers_page.dart';

class BatteryPage extends StatefulWidget {
  const BatteryPage({super.key, required this.d});
  final Diagnostics d;
  @override
  State<BatteryPage> createState() => _BatteryPageState();
}

class _BatteryPageState extends State<BatteryPage> {
  int tab = 0;
  String signal = 'batt_soc', status = '';
  static const graphSignals = {
    'batt_soc': ('Charge', '%'),
    'batt_volts': ('Voltage', 'V'),
    'batt_amps': ('Current', 'A'),
    'power_w': ('Power', 'W'),
    'batt_motor_t': ('Motor', '°C'),
    'batt_mcu_t': ('Controller', '°C'),
  };
  @override
  Widget build(BuildContext context) {
    // Prefer the UDS deep read when present; otherwise fall back to the passive
    // CAN-derived snapshot (SoH, per-cell voltages, cycles, temp) that the
    // known-working community tools rely on. The battery card now populates
    // from the live stream without needing the UDS read.
    final d = widget.d, b = d.battery ?? d.canBattery;
    return PageStack([
      Heading(
        'Battery',
        d.demo
            ? 'Simulated battery · explore every cell.'
            : 'Health, individual cells and live pack trends.',
      ),
      GlassSegment<int>(
        values: const [0, 1, 2],
        selected: tab,
        label: (v) => ['Overview', 'Graphs', 'Settings'][v],
        onChanged: (v) => setState(() => tab = v),
      ),
      if (tab == 0) ...[
        Section(
          'Battery health',
          icon: CupertinoIcons.heart,
          children: [
            MetricGrid([
              ('SoH reading', number(b?.healthValue('soh'), 1), '%'),
              ('Cycles', number(b?.healthValue('cycle'), 0), ''),
              (
                'Temperature',
                number(b?.healthValue('effective temp'), 1),
                '°C',
              ),
              ('Charge', number(d.metrics['State of charge (%)'], 1), '%'),
              ('Usable capacity', number(b?.usableAh, 1), 'Ah'),
              ('Estimated pack energy', number(b?.estimatedPackWh, 0), 'Wh'),
            ]),
            if (d.vehicleAsleep)
              Text(
                'Scooter asleep — press the start button or plug in the charger '
                'to wake the battery, then values appear here.',
                style: const TextStyle(color: orange, fontSize: 12, height: 1.4),
              )
            else if (b == null)
              Text(
                'Waiting for battery frames from the pack…',
                style: TextStyle(color: muted(context), fontSize: 12),
              ),
            // Live SoH, cell voltages, cycles and temperature come from CAN with
            // no action needed. The deeper read adds per-cell resistance and Ah
            // capacity; it needs Service mode, and tapping prompts the user to
            // enter it rather than silently disabling the button.
            GlassButton(
              d.battery == null
                  ? 'Read battery & cells'
                  : 'Refresh battery & cells',
              primary: true,
              icon: CupertinoIcons.arrow_clockwise,
              onPressed: d.busy
                  ? null
                  : () async {
                      final dd = widget.d;
                      if (!dd.readReady) {
                        final ok = await requireServiceMode(context, dd);
                        if (!ok || !dd.readReady) return;
                      }
                      await dd.readBattery();
                    },
            ),
            ReadContext(d: d),
            Text(
              'The deep read adds per-cell resistance and Ah capacity. SoH, cell '
              'voltages, cycles and temperature already come from CAN above.',
              style: TextStyle(color: muted(context), fontSize: 11, height: 1.4),
            ),
            if (b != null)
              Text(
                b.demo
                    ? 'Demo snapshot · simulated values'
                    : d.battery != null
                    ? 'UDS snapshot from ${b.time.toLocal().toString().split('.').first}'
                    : 'Live from CAN',
                style: TextStyle(color: muted(context), fontSize: 11),
              ),
          ],
        ),
        if (d.readingIdentifiers) ReadProgress(d: d),
        if (!d.demo)
          Section(
            'Read status',
            icon: CupertinoIcons.ant,
            children: [
              Text(
                'connected=${d.connected}  mode=${d.mode}  bench=${d.bench}\n'
                'readReady=${d.readReady}  busy=${d.busy}\n'
                'model=${d.identity.model}\n'
                'profile=${d.identity.profileLabel}',
                style: TextStyle(
                  color: muted(context),
                  fontSize: 11,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 6),
              if (b == null)
                Text(
                  'snapshot: none — read has not run (or returned nothing). '
                  'Tap "Read battery & cells".',
                  style: TextStyle(color: muted(context), fontSize: 11),
                )
              else ...[
                Text(
                  'snapshot: cells=${b.cells.length}  '
                  'healthRows=${b.health.length}  errors=${b.errors.length}',
                  style: TextStyle(color: muted(context), fontSize: 11),
                ),
                if (b.health.isNotEmpty)
                  Text(
                    'rows: ${b.health.map((h) => '${h.name}=${h.value}${h.unit}').join(' · ')}',
                    style: TextStyle(
                      color: muted(context),
                      fontSize: 10,
                      height: 1.4,
                    ),
                  ),
              ],
              if (d.message.isNotEmpty)
                Text(
                  'last message: ${d.message}',
                  style: TextStyle(color: muted(context), fontSize: 10),
                ),
            ],
          ),
        if (b != null && b.errors.isNotEmpty)
          Section(
            'Some data unavailable',
            children: [
              for (final error in b.errors)
                Text(
                  error,
                  style: TextStyle(color: muted(context), fontSize: 12),
                ),
            ],
          ),
        Section(
          'Individual cells',
          icon: CupertinoIcons.battery_100,
          children: [
            if (b == null || b.cells.isEmpty)
              const Text(
                'Read the battery to see voltage, resistance and capacity for each cell group.',
              )
            else ...[
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  StatusChip('${b.cells.length} groups', color: teal),
                  StatusChip(
                    '${b.spreadMv.toStringAsFixed(1)} mV spread',
                    color: b.spreadMv > 30 ? orange : green,
                  ),
                  StatusChip('Lowest #${b.lowestCell}', color: muted(context)),
                ],
              ),
              const SizedBox(height: 4),
              LayoutBuilder(
                builder: (context, box) {
                  final large = MediaQuery.textScalerOf(context).scale(12) > 16;
                  final count = (box.maxWidth / (large ? 120 : 74))
                      .floor()
                      .clamp(3, 8);
                  final width = (box.maxWidth - (count - 1) * 8) / count;
                  return Wrap(
                    spacing: 8,
                    runSpacing: 12,
                    children: [
                      for (final c in b.cells)
                        SizedBox(
                          width: width,
                          child: CellGauge(
                            cell: c,
                            snapshot: b,
                            onTap: () => _details(c, b),
                          ),
                        ),
                    ],
                  );
                },
              ),
              Wrap(
                spacing: 12,
                runSpacing: 6,
                children: [
                  for (final (label, color) in [
                    ('Typical', green),
                    ('Watch', orange),
                    ('Check', danger),
                  ])
                    StatusChip(label, color: color),
                ],
              ),
            ],
            Text(
              'Fill is a voltage-based charge estimate. Ah is BMS-derived capacity; Wh is estimated as Ah × present voltage. Temperature uses the nearest shared pack sensor. Tap a cell for details.',
              style: TextStyle(
                color: muted(context),
                fontSize: 11,
                height: 1.5,
              ),
            ),
          ],
        ),
        Section(
          'Live pack',
          icon: CupertinoIcons.waveform,
          children: [
            MetricGrid([
              ('Voltage', number(d.metrics['Pack voltage (V)']), 'V'),
              ('Current', number(d.metrics['Pack current (A)']), 'A'),
              ('Power', number(d.telemetryValues['power_w'], 0), 'W'),
              ('Charger', chargerLabel(d), ''),
            ]),
            Text(
              d.freshness,
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
            GlassButton(
              d.live ? 'Pause monitor' : 'Start monitor',
              onPressed: !d.connected || d.busy
                  ? null
                  : () => d.liveMode(!d.live),
            ),
          ],
        ),
      ],
      if (tab == 1) ...[
        Section(
          'Live trends',
          icon: CupertinoIcons.chart_bar,
          children: [
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final e in graphSignals.entries)
                  GlassButton(
                    e.value.$1,
                    compact: true,
                    primary: signal == e.key,
                    onPressed: () => setState(() => signal = e.key),
                  ),
              ],
            ),
            SignalChart(
              [
                for (final sample in d.graph)
                  if (sample.values[signal] != null)
                    (sample.time, sample.values[signal]!),
              ],
              unit: graphSignals[signal]!.$2,
              color: teal,
            ),
            Text(
              'Up to 600 foreground samples. Missing updates leave gaps. Each chart keeps its own physical unit.',
              style: TextStyle(
                color: muted(context),
                fontSize: 12,
                height: 1.4,
              ),
            ),
            GlassButton(
              d.live ? 'Pause monitor' : 'Start monitor',
              onPressed: !d.connected || d.busy
                  ? null
                  : () => d.liveMode(!d.live),
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                GlassButton(
                  'Export graph CSV',
                  compact: true,
                  onPressed: d.graph.isEmpty ? null : _exportGraph,
                ),
                GlassButton(
                  'Clear graph',
                  compact: true,
                  onPressed: d.graph.isEmpty ? null : d.clearGraph,
                ),
              ],
            ),
            if (status.isNotEmpty) Text(status),
          ],
        ),
        if (b != null && b.cells.isNotEmpty)
          Section(
            'Cell voltages',
            icon: CupertinoIcons.chart_bar_alt_fill,
            children: [
              SizedBox(height: 130, child: CellBars(b.cells)),
              Text(
                '${b.cells.length} groups · spread ${b.spreadMv.toStringAsFixed(0)} '
                'mV · lowest #${b.lowestCell}',
                style: TextStyle(color: muted(context), fontSize: 11),
              ),
            ],
          ),
        Section(
          'Health history',
          icon: CupertinoIcons.graph_square,
          children: [
            if (d.history.points.isEmpty)
              Text(
                'No history yet. SoH and cell spread are logged over time while '
                'connected, and kept across sessions.',
                style: TextStyle(color: muted(context), fontSize: 12),
              )
            else ...[
              Text(
                'State of health (%)',
                style: TextStyle(color: muted(context), fontSize: 12),
              ),
              SignalChart(
                d.history.series((p) => p.soh),
                unit: '%',
                color: green,
              ),
              const SizedBox(height: 12),
              Text(
                'Cell spread (mV)',
                style: TextStyle(color: muted(context), fontSize: 12),
              ),
              SignalChart(
                d.history.series((p) => p.spreadMv),
                unit: 'mV',
                color: orange,
              ),
              Text(
                '${d.history.points.length} samples over time, persisted across '
                'sessions. A rising spread or falling SoH points at ageing.',
                style: TextStyle(color: muted(context), fontSize: 11, height: 1.4),
              ),
              GlassButton(
                'Clear history',
                compact: true,
                onPressed: () async {
                  await d.history.clear();
                  if (mounted) setState(() {});
                },
              ),
            ],
          ],
        ),
      ],
      if (tab == 2) ...[
        Section(
          'Cell balancing',
          icon: CupertinoIcons.bolt_horizontal,
          children: [
            Text(
              'Balancing is managed by the BMS and normally runs only while '
              'charging with the cells imbalanced. This requests the routine; '
              'the pack decides whether to act. Live balancing status is a BMS '
              'read (not broadcast), so it is not shown here — check the cell '
              'voltage spread above as a proxy.',
              style: TextStyle(
                color: muted(context),
                fontSize: 12,
                height: 1.4,
              ),
            ),
            GlassButton(
              'Request cell balancing',
              icon: CupertinoIcons.bolt_horizontal,
              onPressed: d.busy || !d.legacyMethodsAvailable
                  ? null
                  : () async {
                      if (await confirmGlass(
                        context,
                        'Request cell balancing?',
                        'Starts the BMS cell-balancing routine (needs Service mode). '
                            'Keep the scooter parked, ideally on charge. The BMS '
                            'balances only when conditions allow.',
                      )) {
                        await d.forceBalance();
                      }
                    },
            ),
          ],
        ),
        IdentifiersPage(
          d: d,
          kind: IdentifierWorkspace.bmsSettings,
          embedded: true,
        ),
      ],
    ]);
  }

  Future<void> _exportGraph() async {
    final keys = graphSignals.keys.toList();
    final text = StringBuffer('\uFEFFtime_s,${keys.join(',')}\r\n');
    for (final s in widget.d.graph) {
      text.writeln('${s.time},${keys.map((k) => s.values[k] ?? '').join(',')}');
    }
    try {
      final path = await FilePicker.saveFile(
        fileName: 'OpenOLA-battery.csv',
        bytes: Uint8List.fromList(utf8.encode(text.toString())),
      );
      if (mounted) {
        setState(
          () => status = path == null ? 'Export cancelled.' : 'Graph saved.',
        );
      }
    } catch (e) {
      if (mounted) setState(() => status = 'Export failed: $e');
    }
  }

  Future<void> _details(BatteryCell c, BatterySnapshot b) => glassSheet(
    context,
    PageStack([
      Heading(
        'Cell group ${c.index}',
        b.demo ? 'Simulated reading' : 'Battery snapshot',
      ),
      MetricGrid([
        ('Voltage', c.volts.toStringAsFixed(3), 'V'),
        ('Resistance', number(c.ir, 2), 'mΩ'),
        if (c.index - 1 < widget.d.cellDcir.length &&
            widget.d.cellDcir[c.index - 1] != null)
          (
            'Live DCIR',
            widget.d.cellDcir[c.index - 1]!.toStringAsFixed(2),
            'mΩ',
          ),
        ('Capacity', number(c.ah, 2), 'Ah'),
        ('Estimated energy', number(c.estimatedWh, 2), 'Wh'),
        ('Shared sensor', number(c.temperature, 1), '°C'),
        ('Charge estimate', c.chargePercent.toStringAsFixed(0), '%'),
      ]),
      Text(
        '${b.observation(c)} relative to this pack. This is a comparison of readings, not a cell-health diagnosis. Series-cell Ah is not added to obtain pack capacity.',
        style: TextStyle(color: muted(context), height: 1.5),
      ),
      GlassButton(
        'Done',
        primary: true,
        onPressed: () => Navigator.pop(context),
      ),
    ]),
  );
}

String chargerLabel(Diagnostics d) {
  final data = d.raw[0x62d];
  return data == null || data.isEmpty
      ? 'Unknown'
      : ['None', 'Fast', 'Slow', 'Boost'][data[0] & 3];
}

class MetricGrid extends StatelessWidget {
  const MetricGrid(this.metrics, {super.key});
  final List<(String, String, String)> metrics;
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final columns = box.maxWidth > 650 ? 4 : 2,
          width = (box.maxWidth - (columns - 1) * 16) / columns;
      return Wrap(
        spacing: 16,
        runSpacing: 18,
        children: [
          for (final (label, value, unit) in metrics)
            SizedBox(
              width: width,
              child: MetricValue(label, value, unit: unit, compact: true),
            ),
        ],
      );
    },
  );
}

class CellGauge extends StatelessWidget {
  const CellGauge({
    super.key,
    required this.cell,
    required this.snapshot,
    required this.onTap,
  });
  final BatteryCell cell;
  final BatterySnapshot snapshot;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final observation = snapshot.observation(cell),
        color = observation == 'Check'
            ? danger
            : observation == 'Watch'
            ? orange
            : green;
    final c = cell;
    return Semantics(
      button: true,
      label:
          'Cell group ${c.index}, ${c.volts.toStringAsFixed(3)} volts, ${number(c.ir, 2)} milliohms, ${number(c.ah, 2)} amp hours, $observation',
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(
          children: [
            Text(
              '#${c.index}',
              style: TextStyle(
                color: muted(context),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Container(
              width: 18,
              height: 3,
              decoration: BoxDecoration(
                color: color.withValues(alpha: .45),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(height: 2),
            Container(
              width: 48,
              height: 84,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: color.withValues(alpha: .12),
                    blurRadius: 18,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: fill(context),
                          border: Border.all(
                            color: color.withValues(alpha: .32),
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: TweenAnimationBuilder<double>(
                        tween: Tween(begin: 0, end: c.chargePercent / 100),
                        duration: reduced(context)
                            ? Duration.zero
                            : const Duration(milliseconds: 650),
                        curve: Curves.easeOutCubic,
                        builder: (context, fill, _) => Align(
                          alignment: Alignment.bottomCenter,
                          child: FractionallySizedBox(
                            heightFactor: fill.clamp(.02, 1),
                            widthFactor: 1,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    Color.lerp(
                                      color,
                                      Colors.white,
                                      .32,
                                    )!.withValues(alpha: .8),
                                    color.withValues(alpha: .65),
                                    Color.lerp(
                                      color,
                                      Colors.black,
                                      .12,
                                    )!.withValues(alpha: .45),
                                  ],
                                ),
                                border: Border(
                                  top: BorderSide(
                                    color: Colors.white.withValues(alpha: .45),
                                    width: 2,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.white.withValues(
                              alpha: dark(context) ? .16 : .38,
                            ),
                            width: .6,
                          ),
                          gradient: RadialGradient(
                            center: const Alignment(-.4, -.8),
                            radius: .8,
                            colors: [
                              Colors.white.withValues(
                                alpha: dark(context) ? .35 : .55,
                              ),
                              Colors.white.withValues(alpha: 0),
                            ],
                            stops: const [0, .85],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 8,
                      bottom: 14,
                      left: 8,
                      width: 6,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: LinearGradient(
                            colors: [
                              Colors.white.withValues(alpha: .4),
                              Colors.white.withValues(alpha: .04),
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                    ),
                    Center(
                      child: Text(
                        '${c.chargePercent.round()}%',
                        style: TextStyle(
                          color: ink(context),
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${c.volts.toStringAsFixed(2)}V',
              style: TextStyle(
                color: ink(context),
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              '${number(c.ir, 1)}mΩ · ${number(c.ah, 1)}Ah',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: muted(context),
                fontSize: 9.5,
                height: 1.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Bar chart of per-cell voltages, lowest cell highlighted. Bars are scaled
/// within the pack's own min/max so small differences are visible.
class CellBars extends StatelessWidget {
  const CellBars(this.cells, {super.key});
  final List<BatteryCell> cells;
  @override
  Widget build(BuildContext context) => CustomPaint(
    size: Size.infinite,
    painter: _CellBarsPainter(
      cells,
      bar: accent,
      low: orange,
      label: muted(context),
    ),
  );
}

class _CellBarsPainter extends CustomPainter {
  _CellBarsPainter(
    this.cells, {
    required this.bar,
    required this.low,
    required this.label,
  });
  final List<BatteryCell> cells;
  final Color bar, low, label;

  @override
  void paint(Canvas canvas, Size size) {
    if (cells.isEmpty) return;
    final vs = cells.map((c) => c.volts).toList();
    final lo = vs.reduce(math.min), hi = vs.reduce(math.max);
    final span = (hi - lo) < 0.001 ? 0.05 : (hi - lo);
    final lowest = cells.reduce((a, b) => a.volts <= b.volts ? a : b).index;
    final n = cells.length;
    const gap = 3.0;
    final barW = (size.width - gap * (n - 1)) / n;
    final bottom = size.height - 14; // room for index labels
    for (var i = 0; i < n; i++) {
      final v = cells[i].volts;
      final norm = ((v - (lo - span * 0.15)) / (span * 1.15)).clamp(0.08, 1.0);
      final h = norm * (bottom - 4);
      final x = i * (barW + gap);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, bottom - h, barW, h),
          const Radius.circular(3),
        ),
        Paint()..color = cells[i].index == lowest ? low : bar,
      );
      final tp = TextPainter(
        text: TextSpan(
          text: '${cells[i].index}',
          style: TextStyle(color: label, fontSize: 8),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(x + (barW - tp.width) / 2, bottom + 2));
    }
  }

  @override
  bool shouldRepaint(_CellBarsPainter old) => old.cells != cells;
}
