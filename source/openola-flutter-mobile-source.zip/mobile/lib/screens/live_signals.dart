import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../design/glass.dart';
import '../diagnostics/controller.dart';
import 'core.dart';

/// Slivers for the page's primary scroll view, never a nested signal viewport.
class LiveSignalsSlivers extends StatefulWidget {
  const LiveSignalsSlivers({super.key, required this.d});
  final Diagnostics d;

  @override
  State<LiveSignalsSlivers> createState() => _LiveSignalsSliversState();
}

class _LiveSignalsSliversState extends State<LiveSignalsSlivers> {
  final search = TextEditingController();

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: widget.d,
    builder: (context, _) {
      final d = widget.d;
      final query = search.text.trim().toLowerCase();
      final rows =
          d.readings.entries
              .where(
                (entry) =>
                    '${entry.key} ${entry.value.unit} ${entry.value.id.toRadixString(16)}'
                        .toLowerCase()
                        .contains(query),
              )
              .toList()
            ..sort((a, b) => a.key.compareTo(b.key));
      final indices = {
        for (var i = 0; i < rows.length; i++) 'signal:${rows[i].key}': i,
      };

      return SliverMainAxisGroup(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Heading(
                    'Live signals',
                    '${rows.length} signals${query.isEmpty ? '' : ' matching'} · ${d.demo
                        ? 'Demo readings'
                        : d.live
                        ? 'Streaming'
                        : 'Stream paused'}',
                  ),
                  const SizedBox(height: 14),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: GlassField(
                          controller: search,
                          label: 'Search signals',
                          onChanged: (_) => setState(() {}),
                          suffix: IconButton(
                            tooltip: query.isEmpty
                                ? 'Search signals'
                                : 'Clear search',
                            onPressed: query.isEmpty
                                ? null
                                : () => setState(search.clear),
                            icon: Icon(
                              query.isEmpty
                                  ? CupertinoIcons.search
                                  : CupertinoIcons.xmark_circle_fill,
                              size: 19,
                              color: muted(context),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      GlassButton(
                        d.live ? 'Pause' : 'Start',
                        compact: true,
                        icon: d.live
                            ? CupertinoIcons.pause
                            : CupertinoIcons.play,
                        onPressed: d.busy ? null : () => d.liveMode(!d.live),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (rows.isEmpty)
            SliverToBoxAdapter(
              child: Section(
                query.isEmpty ? 'No signals yet' : 'No matching signals',
                children: [
                  Text(
                    query.isEmpty
                        ? 'Start the stream and wait for CAN frames. Missing data is not a zero reading.'
                        : 'Try a different signal name, unit or CAN ID.',
                  ),
                ],
              ),
            ),
          SliverList.builder(
            itemCount: rows.length,
            findChildIndexCallback: (key) =>
                key is ValueKey<String> ? indices[key.value] : null,
            itemBuilder: (context, index) {
              final row = rows[index];
              final age = DateTime.now()
                  .difference(row.value.receivedAt)
                  .inSeconds;
              return Padding(
                key: ValueKey('signal:${row.key}'),
                padding: const EdgeInsets.only(bottom: 10),
                child: Glass(
                  radius: 18,
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              row.key.split(':').last,
                              style: Theme.of(context).textTheme.labelLarge,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              d.demo
                                  ? 'Demo reading'
                                  : '0x${row.value.id.toRadixString(16)} · ${age < 0 ? 0 : age}s ago',
                              style: TextStyle(
                                color: muted(context),
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        flex: 2,
                        child: Text(
                          '${number(row.value.value)} ${row.value.unit}'.trim(),
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            color: ink(context),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 18)),
        ],
      );
    },
  );
}
