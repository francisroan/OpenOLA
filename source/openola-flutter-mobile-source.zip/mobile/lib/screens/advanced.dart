import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../bluetooth/ble_controller.dart';
import '../data/catalog.dart';
import '../diagnostics/controller.dart';
import '../diagnostics/preferences.dart';
import '../design/glass.dart';
import '../design/dashboard.dart';
import '../protocol/can.dart';
import 'core.dart';
import 'live_signals.dart';
import 'recorder_page.dart';
import 'identifiers_page.dart';
import 'status_page.dart';
import 'battery_page.dart';

class AdvancedPage extends StatefulWidget {
  const AdvancedPage({
    super.key,
    required this.tool,
    required this.d,
    required this.ble,
  });
  final Tool tool;
  final Diagnostics d;
  final ScooterBle ble;
  @override
  State<AdvancedPage> createState() => _AdvancedPageState();
}

class _AdvancedPageState extends State<AdvancedPage> {
  final search = TextEditingController();
  int limit = 40;
  String group = 'All';
  int? runningTest;
  String runningLabel = '';
  final _adbCtl = TextEditingController();
  String? _otaFile;
  List<int>? _otaBytes;
  String _otaTarget = 'ALL';
  @override
  void didUpdateWidget(AdvancedPage old) {
    super.didUpdateWidget(old);
    if (old.tool != widget.tool) {
      search.clear();
      limit = 40;
      group = 'All';
    }
  }

  @override
  void dispose() {
    search.dispose();
    _adbCtl.dispose();
    super.dispose();
  }

  bool match(String value) =>
      value.toLowerCase().contains(search.text.toLowerCase());
  Widget filter() => GlassField(
    controller: search,
    onChanged: (_) => setState(() => limit = 40),
    label: 'Search',
    suffix: IconButton(
      tooltip: 'Apply search',
      onPressed: () => setState(() => limit = 40),
      icon: const Icon(CupertinoIcons.search),
    ),
  );
  @override
  Widget build(BuildContext context) {
    if (widget.tool == Tool.bluetooth) return _BluetoothPage(widget.ble);
    if (widget.tool == Tool.recorder) return RecorderPage(d: widget.d);
    if (widget.tool == Tool.status) return StatusPage(d: widget.d);
    if (widget.tool == Tool.software) return SoftwarePage(d: widget.d);
    if (widget.tool == Tool.components || widget.tool == Tool.firmware) {
      return IdentifiersPage(
        d: widget.d,
        kind: widget.tool == Tool.components
            ? IdentifierWorkspace.components
            : IdentifierWorkspace.firmware,
      );
    }
    if (!widget.d.connected) return ConnectPage(d: widget.d);
    if (widget.tool == Tool.parameters &&
        Catalog.isS1xModel(widget.d.identity.modelCode)) {
      return _s1xParameterMap();
    }
    if (!widget.d.legacyMethodsAvailable &&
        const [
          Tool.actuators,
          Tool.parameters,
          Tool.features,
          Tool.engineering,
        ].contains(widget.tool)) {
      return PageStack([
        const Heading('Service functions', 'Controller-specific methods'),
        Section(
          widget.d.identity.model,
          children: [
            Text(widget.d.identity.reason),
            const Text(
              'The older service procedures are unavailable for this profile. Vehicle status contains the supported read-only diagnostics.',
            ),
          ],
        ),
      ]);
    }
    return switch (widget.tool) {
      Tool.live => _live(),
      Tool.charging => _charging(),
      Tool.actuators => _actuators(),
      Tool.parameters => _parameters(),
      Tool.performance => _performance(),
      Tool.controls => _controls(),
      Tool.features => _features(),
      Tool.engineering => _engineering(),
      _ => FaultsPage(d: widget.d),
    };
  }

  Widget _live() =>
      CustomScrollView(slivers: [LiveSignalsSlivers(d: widget.d)]);

  Widget _charging() {
    final d = widget.d;
    final connected = d.raw[0x62d];
    final type = connected == null
        ? 'Unknown'
        : ['None', 'Fast', 'Slow', 'Boost'][connected[0] & 3];
    return PageStack([
      const Heading(
        'Charging',
        'Received charger state and a local session record.',
      ),
      Section(
        'Charger snapshot',
        icon: CupertinoIcons.bolt,
        children: [
          Text('Charger: ${d.demo ? 'Demo · unknown' : type}'),
          Text('Pack current: ${number(d.metrics['Pack current (A)'])} A'),
          Text('Pack voltage: ${number(d.metrics['Pack voltage (V)'])} V'),
          Text(
            d.freshness,
            style: TextStyle(color: muted(context), fontSize: 12),
          ),
        ],
      ),
      Section(
        'Charge path',
        icon: CupertinoIcons.bolt,
        children: [
          MetricGrid([
            ('Power', number(d.telemetryValues['power_w'], 0), 'W'),
            (
              'Plugged',
              d.profileValue(0x62d, 'Charger_Plugged_In') == null
                  ? 'Unknown'
                  : d.profileValue(0x62d, 'Charger_Plugged_In') == 1
                  ? 'Yes'
                  : 'No',
              '',
            ),
            (
              'Connector latch',
              d.profileValue(0x508, 'Vehicle_connector_latched') == null
                  ? 'Unknown'
                  : d.profileValue(0x508, 'Vehicle_connector_latched') == 1
                  ? 'Latched'
                  : 'Not latched',
              '',
            ),
            (
              'Charger status',
              d.profileValue(0x213, 'Charger_Status_Signal') == null
                  ? 'Unknown'
                  : d.profileValue(0x213, 'Charger_Status_Signal') == 1
                  ? 'Set'
                  : 'Clear',
              '',
            ),
          ]),
          Text(
            'Received CAN state; not a confirmation of payment or permission to charge.',
            style: TextStyle(color: muted(context), fontSize: 12),
          ),
          GlassButton(
            d.live ? 'Pause monitor' : 'Start monitor',
            onPressed: d.busy ? null : () => d.liveMode(!d.live),
          ),
        ],
      ),
      Section(
        'Session recording',
        children: [
          Text(
            'Use Recorder in the left menu for the full signal log, plots, JSONL and CSV.',
            style: TextStyle(color: muted(context), fontSize: 12),
          ),
          GlassButton(
            d.session.active ? 'Stop & save session' : 'Record charge session',
            onPressed: d.busy || d.session.closing
                ? null
                : () async {
                    if (d.session.active) {
                      await d.stopSession();
                    } else {
                      await d.startSession();
                    }
                  },
          ),
        ],
      ),
      GlassButton(
        'Stop charge',
        destructive: true,
        onPressed: d.busy
            ? null
            : () async {
                if (await confirmGlass(
                  context,
                  'Stop charging?',
                  'Sends the existing HMI stop-charge command. Verify the charging state on the scooter.',
                )) {
                  await d.hmi(13, 'Stop charge');
                }
              },
      ),
    ]);
  }

  Widget _actuators() {
    final d = widget.d;
    final groups = d.catalog.actuators.map((a) => a.group).toSet();
    final rows = d.catalog.actuators
        .where((a) => (group == 'All' || a.group == group) && match(a.label))
        .toList();
    return PageStack([
      const Heading(
        'Actuator tests',
        'Park the scooter and disconnect the charger. Active controls use the existing service protocol.',
      ),
      filter(),
      GlassButton(
        'Category: $group',
        icon: CupertinoIcons.chevron_down,
        onPressed: () async {
          final value = await glassSheet<String>(
            context,
            PageStack([
              for (final g in ['All', ...groups])
                GlassButton(g, onPressed: () => Navigator.pop(context, g)),
            ]),
          );
          if (value != null && mounted) {
            setState(() {
              group = value;
              limit = 40;
            });
          }
        },
      ),
      for (final a in rows.take(limit))
        Section(
          a.label,
          children: [
            Text(
              '${a.group} · DID ${a.did.toRadixString(16).toUpperCase()}${a.danger ? ' · review required' : ''}',
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
            GlassButton(
              'Pulse test',
              onPressed: d.busy || !d.legacyMethodsAvailable
                  ? null
                  : () async {
                      if (await confirmGlass(
                        context,
                        'Test ${a.label}?',
                        'Runs this actuator briefly, then sends OFF and returns control to the ECU. Keep the scooter parked.',
                      )) {
                        await d.actuator(a);
                      }
                    },
            ),
            if (a.label.toLowerCase() != 'horn')
              GlassButton(
                d.latched.containsKey(a.did)
                    ? 'Turn OFF and release'
                    : 'Latch ON',
                destructive: a.danger,
                onPressed: d.busy || !d.legacyMethodsAvailable
                    ? null
                    : () async {
                        final on = !d.latched.containsKey(a.did);
                        if (!on ||
                            await confirmGlass(
                              context,
                              'Latch ${a.label} ON?',
                              'This control remains ON until you switch it off. Check the scooter before confirming.',
                            )) {
                          await d.actuator(a, latch: on);
                        }
                      },
              ),
          ],
        ),
      if (rows.length > limit)
        GlassButton(
          'Show more controls',
          onPressed: () => setState(() => limit += 40),
        ),
    ]);
  }

  Widget _parameters() {
    final rows = widget.d.catalog.parameters
        .where(
          (p) => match('${p.name} ${p.ecu.label} ${p.did.toRadixString(16)}'),
        )
        .toList();
    return PageStack([
      const Heading(
        'Parameters',
        'Documented ranges describe encoding limits. They are not verified safe calibration limits.',
      ),
      filter(),
      for (final p in rows.take(limit))
        Section(
          p.name,
          children: [
            Text(
              '${p.ecu.label} · DID ${p.did.toRadixString(16).toUpperCase()} · ${p.length} bytes',
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
            GlassButton(
              'Read and inspect',
              onPressed: widget.d.busy || !widget.d.legacyMethodsAvailable
                  ? null
                  : () => glassSheet(context, _ParameterEditor(p, widget.d)),
            ),
          ],
        ),
      if (rows.length > limit)
        GlassButton(
          'Show 40 more (${rows.length} total)',
          onPressed: () => setState(() => limit += 40),
        ),
    ]);
  }

  // Icon-based quick controls for the common actuators (lights, horn, locks).
  // Each maps to an ODX IO-control actuator by label; horn pulses, the rest
  // latch on/off. Service mode is prompted on tap rather than disabling.
  Widget _controls() {
    final d = widget.d;
    Actuator? find(List<String> keys) {
      for (final a in d.catalog.actuators) {
        final n = a.label.toLowerCase();
        if (keys.every(n.contains)) return a;
      }
      return null;
    }

    final items = <(String, IconData, Actuator?, bool)>[
      ('Horn', CupertinoIcons.speaker_3_fill, find(['horn']), true),
      ('Low beam', CupertinoIcons.lightbulb, find(['low', 'beam']), false),
      ('High beam', CupertinoIcons.lightbulb_fill, find(['high', 'beam']), false),
      ('DRL', CupertinoIcons.sun_min, find(['drl']), false),
      (
        'Left indicator',
        CupertinoIcons.arrow_turn_up_left,
        find(['left', 'indicator']),
        false,
      ),
      (
        'Right indicator',
        CupertinoIcons.arrow_turn_up_right,
        find(['right', 'indicator']),
        false,
      ),
      ('Brake light', CupertinoIcons.car_detailed, find(['brake']), false),
      ('Seat / boot', CupertinoIcons.lock_open, find(['seat', 'lock']), false),
      ('Steering lock', CupertinoIcons.lock, find(['steering']), false),
    ];
    return PageStack([
      const Heading(
        'Vehicle controls',
        'Tap a control to pulse or latch it. Keep the scooter parked and the '
            'charger unplugged — these drive real lights, horn and locks.',
      ),
      Wrap(
        spacing: 10,
        runSpacing: 10,
        children: [for (final i in items) _controlTile(i.$1, i.$2, i.$3, i.$4)],
      ),
      const SizedBox(height: 10),
      Text(
        'Controls shown dim when the loaded ODX has no matching actuator for '
        'your model. The full list is under Actuator tests.',
        style: TextStyle(color: muted(context), fontSize: 11, height: 1.4),
      ),
    ]);
  }

  Widget _controlTile(String name, IconData icon, Actuator? a, bool pulse) {
    final d = widget.d;
    final on = a != null && d.latched.containsKey(a.did);
    final tint = a == null
        ? muted(context)
        : on
        ? accent
        : purple;
    return GestureDetector(
      onTap: a == null || d.busy ? null : () => _runControl(a, pulse, on),
      child: Opacity(
        opacity: a == null ? 0.4 : 1,
        child: Container(
          width: 104,
          height: 96,
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: (on ? accent : muted(context)).withValues(
              alpha: on ? .16 : .07,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: on ? accent : separator(context),
              width: on ? 1.5 : 1,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: tint, size: 26),
              const SizedBox(height: 8),
              Text(
                name,
                textAlign: TextAlign.center,
                maxLines: 2,
                style: TextStyle(fontSize: 11.5, height: 1.1),
              ),
              if (on)
                const Text(
                  'ON',
                  style: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    color: accent,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _runControl(Actuator a, bool pulse, bool on) async {
    final d = widget.d;
    if (!await requireServiceMode(context, d)) return;
    if (!mounted) return;
    if (pulse) {
      if (await confirmGlass(
        context,
        'Test ${a.label}?',
        'Pulses this control briefly, then returns control to the ECU. Keep the '
            'scooter parked.',
      )) {
        await d.actuator(a);
      }
    } else {
      final turnOn = !on;
      if (!turnOn ||
          await confirmGlass(
            context,
            'Turn ${a.label} ON?',
            'Stays ON until you turn it off here. Check the scooter before '
                'confirming.',
          )) {
        await d.actuator(a, latch: turnOn);
      }
    }
    if (mounted) setState(() {});
  }

  Widget _selfTestTile(String label, int cmd, IconData icon) {
    final d = widget.d;
    final active = runningTest == cmd;
    return GestureDetector(
      onTap: d.busy
          ? null
          : () async {
              if (await confirmGlass(
                context,
                'Run $label test?',
                'Runs on the scooter\'s head unit (its diagnostic screen must be '
                    'open). Can interrupt the display, sound or connectivity. '
                    'Keep the scooter parked.',
              )) {
                await d.test(cmd, label, true);
                if (mounted) {
                  setState(() {
                    runningTest = cmd;
                    runningLabel = label;
                  });
                }
              }
            },
      child: Container(
        width: 104,
        height: 96,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: (active ? accent : muted(context)).withValues(
            alpha: active ? .16 : .07,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: active ? accent : separator(context),
            width: active ? 1.5 : 1,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 26, color: active ? accent : purple),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 2,
              style: const TextStyle(fontSize: 11.5, height: 1.1),
            ),
            if (active)
              const Text(
                'RUNNING',
                style: TextStyle(
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                  color: accent,
                ),
              ),
          ],
        ),
      ),
    );
  }

  // Curated performance-limit parameters: MCU torque/speed/throttle/regen plus
  // the BMS discharge-current derate. All are UDS 0x2E config writes —
  // reversible, no firmware reflash — surfaced here with live guard rails and a
  // typed-CONFIRM write instead of being buried in the full Parameters list.
  static const _perfDids = {
    0xb110, 0xb103, 0xb112, 0xb111, 0xb10b, 0xb10d, // MCU
    0xe431, 0xe4bc, 0xe485, 0xe486, 0xe487, // BMS
  };

  static const _perfNames = {
    0xb110: 'Vehicle mode torque limit',
    0xb103: 'Torque setting',
    0xb112: 'Limp-home speed limit',
    0xb111: 'Acceleration time',
    0xb10b: 'Regen current limit',
    0xb10d: 'Throttle sampling limit',
    0xe431: 'BMS discharge-current derate',
    0xe4bc: 'Regen limit enable / disable',
    0xe485: 'Regen start (mV)',
    0xe486: 'Regen capacity (%)',
    0xe487: 'Regen stop (mV)',
  };

  Widget _performance() {
    final d = widget.d;
    final rows = d.catalog.parameters
        .where((p) => _perfDids.contains(p.did))
        .toList();
    final b = d.canBattery;
    return PageStack([
      const Heading(
        'Performance limits',
        'Factory speed, torque, power and regen caps. These are real controller '
            'limits — changing them reduces safety margins.',
      ),
      Glass(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(
              CupertinoIcons.exclamationmark_triangle_fill,
              color: danger,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Raising these can overheat the battery or motor, reduce braking '
                'margin, void your warranty and be illegal on public roads. The '
                'BMS current derate (0xE431) and the MCU torque/speed caps must '
                'move together — raise one alone and the pack still clamps power '
                'or trips a fault. Only on a parked scooter, and watch the guard '
                'rails below.',
                style: TextStyle(
                  color: muted(context),
                  fontSize: 12.5,
                  height: 1.45,
                ),
              ),
            ),
          ],
        ),
      ),
      Section(
        'Live guard rails',
        icon: CupertinoIcons.gauge,
        children: [
          MetricGrid([
            ('Pack current', number(d.metrics['Pack current (A)'], 1), 'A'),
            ('Pack temp', number(b?.healthValue('effective temp'), 1), '°C'),
            ('Cell spread', number(b?.spreadMv, 0), 'mV'),
          ]),
          Text(
            'Watch these while testing. Rising temperature, high sustained '
            'current, or a widening cell spread under load means back off.',
            style: TextStyle(color: muted(context), fontSize: 11, height: 1.4),
          ),
        ],
      ),
      if (!d.legacyMethodsAvailable)
        Section(
          'Writes unavailable here',
          children: [
            Text(
              'Reading and writing these needs a connected scooter in Service '
              'mode with a verified profile. You can still review the list.',
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
          ],
        ),
      if (rows.isEmpty)
        const Section(
          'No parameters',
          children: [
            Text(
              'No performance parameters are present in this vehicle\'s loaded '
              'ODX.',
            ),
          ],
        )
      else
        for (final p in rows)
          Section(
            _perfNames[p.did] ?? p.name,
            children: [
              Text(
                '${p.ecu.label} · DID ${p.did.toRadixString(16).toUpperCase()} · '
                '${p.length} bytes',
                style: TextStyle(color: muted(context), fontSize: 12),
              ),
              GlassButton(
                'Read & edit',
                destructive: true,
                onPressed: d.busy || !d.legacyMethodsAvailable
                    ? null
                    : () => glassSheet(
                        context,
                        _ParameterEditor(p, d, typedConfirm: true),
                      ),
              ),
            ],
          ),
    ]);
  }

  Widget _s1xParameterMap() {
    final d = widget.d;
    final code = d.identity.modelCode;
    final phase = Catalog.s1xPhaseForModel(code);
    final rows = d.catalog
        .s1xParametersForModel(code)
        .where(
          (row) => match(
            '${row.name} ${row.ecu} ${row.source} ${row.dbcName ?? ''} ${row.canId ?? ''}',
          ),
        )
        .toList();
    return SingleChildScrollView(
      child: PageStack([
        Heading(
          'S1X parameter reference',
          phase == null
              ? 'Showing entries common to both imported phase maps. This model code does not establish a phase.'
              : 'Imported Phase $phase map for ${d.identity.model}. Map entries are references; they do not establish live availability.',
        ),
        const Section(
          'Read-only mapping',
          children: [
            Text(
              'CAN values appear only when the active decoder already reports the exact CAN ID and DBC signal. UDS entries are not requested: these map rows do not provide an explicit request identifier.',
            ),
            Text(
              'Documented ranges are encoding metadata, not verified safe repair or calibration limits.',
            ),
          ],
        ),
        filter(),
        for (final row in rows.take(limit))
          Section(
            row.name.isEmpty ? 'Unnamed parameter' : row.name,
            children: [
              Text(
                '${row.ecu} · ${row.source} · ${row.dbcName ?? 'no DBC name'}',
              ),
              if (row.hasCanMapping)
                Builder(
                  builder: (context) {
                    final reading = d.readings['${row.canId}:${row.dbcName}'];
                    return Text(
                      reading == null
                          ? 'Not available in the active decoder or not received yet'
                          : 'Current decoded value: ${number(reading.value)} ${row.unit}'
                                .trim(),
                      style: TextStyle(color: muted(context), fontSize: 12),
                    );
                  },
                )
              else
                Text(
                  'Reference only · no UDS read attempted',
                  style: TextStyle(color: muted(context), fontSize: 12),
                ),
              if (row.canId != null)
                Text('CAN ID 0x${row.canId!.toRadixString(16).toUpperCase()}'),
              if (row.minimum != null || row.maximum != null)
                Text(
                  'Documented range: ${row.minimum ?? '—'} to ${row.maximum ?? '—'} ${row.unit}'
                      .trim(),
                ),
            ],
          ),
        if (rows.length > limit)
          GlassButton(
            'Show 40 more (${rows.length} total)',
            onPressed: () => setState(() => limit += 40),
          ),
      ]),
    );
  }

  // label, enable ordinal, disable ordinal, icon, accent colour, one-line help
  static const _featureList = <(String, int, int, IconData, Color, String)>[
    (
      'Boost mode',
      48,
      49,
      CupertinoIcons.bolt_fill,
      orange,
      'Extra power on demand',
    ),
    (
      'Hill hold',
      66,
      67,
      CupertinoIcons.arrow_up_circle_fill,
      accent,
      'Hold still on inclines',
    ),
    (
      'Vacation mode',
      68,
      69,
      CupertinoIcons.moon_stars_fill,
      purple,
      'Low-drain long storage',
    ),
    (
      'Proximity lock',
      54,
      55,
      CupertinoIcons.lock_shield_fill,
      teal,
      'Auto-lock when you step away',
    ),
    (
      'Motor cutoff delay',
      64,
      65,
      CupertinoIcons.time,
      accent,
      'Delay the motor cutoff',
    ),
    (
      'Park assist',
      103,
      104,
      CupertinoIcons.car_fill,
      green,
      'Low-speed park manoeuvring',
    ),
    (
      'Accident detection',
      50,
      51,
      CupertinoIcons.exclamationmark_triangle_fill,
      danger,
      'Crash alerting',
    ),
    (
      'Tow / tamper alert',
      52,
      53,
      CupertinoIcons.shield_lefthalf_fill,
      orange,
      'Movement alerts when parked',
    ),
    (
      'Smart DRL',
      56,
      57,
      CupertinoIcons.lightbulb_fill,
      green,
      'Daytime running lights',
    ),
    (
      'Hazard lights',
      60,
      61,
      CupertinoIcons.exclamationmark_octagon_fill,
      danger,
      'Blinker hazard mode',
    ),
  ];

  Widget _features() {
    final busy = widget.d.busy || !widget.d.legacyMethodsAvailable;
    return PageStack([
      const Heading(
        'Vehicle features',
        'Send a feature command to the scooter. Sending does not prove it was '
            'accepted or that your scooter has the entitlement.',
      ),
      Glass(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (var i = 0; i < _featureList.length; i++) ...[
              if (i > 0) Divider(color: separator(context), height: 22),
              _featureRow(_featureList[i], busy),
            ],
          ],
        ),
      ),
      Section(
        'Regeneration',
        icon: CupertinoIcons.arrow_2_circlepath,
        children: [
          Text(
            'Send a regen braking profile.',
            style: TextStyle(color: muted(context), fontSize: 12),
          ),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final f in const [
                ('Default', 41),
                ('City', 42),
                ('Highway', 43),
              ])
                SizedBox(
                  width: 104,
                  child: GlassButton(
                    f.$1,
                    compact: true,
                    onPressed: busy
                        ? null
                        : () => _feature(f.$2, '${f.$1} regeneration'),
                  ),
                ),
            ],
          ),
        ],
      ),
    ]);
  }

  Widget _featureRow(
    (String, int, int, IconData, Color, String) f,
    bool busy,
  ) => Row(
    children: [
      IconTile(f.$4, f.$5, size: 34),
      const SizedBox(width: 12),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              f.$1,
              style: TextStyle(
                color: ink(context),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              f.$6,
              style: TextStyle(
                color: muted(context),
                fontSize: 12,
                height: 1.3,
              ),
            ),
          ],
        ),
      ),
      const SizedBox(width: 10),
      SizedBox(
        width: 62,
        child: GlassButton(
          'On',
          compact: true,
          primary: true,
          onPressed: busy ? null : () => _feature(f.$2, '${f.$1} enable'),
        ),
      ),
      const SizedBox(width: 8),
      SizedBox(
        width: 58,
        child: GlassButton(
          'Off',
          compact: true,
          onPressed: busy ? null : () => _feature(f.$3, '${f.$1} disable'),
        ),
      ),
    ],
  );

  Future<void> _feature(int ordinal, String label) async {
    if (await confirmGlass(
      context,
      'Change $label?',
      'Sends the existing feature command. Check availability and outcome on the scooter; no automatic retry.',
    )) {
      await widget.d.hmi(ordinal, label);
    }
  }

  Widget _engineering() {
    final d = widget.d;
    const tests = <(String, int, IconData)>[
      ('LCD', 1, CupertinoIcons.device_phone_portrait),
      ('GPS', 2, CupertinoIcons.location_solid),
      ('Bluetooth', 3, CupertinoIcons.bluetooth),
      ('BLE', 4, CupertinoIcons.dot_radiowaves_left_right),
      ('Wi-Fi', 5, CupertinoIcons.wifi),
      ('Speaker', 6, CupertinoIcons.speaker_2_fill),
      ('Microphone', 7, CupertinoIcons.mic_fill),
      ('eSIM', 12, CupertinoIcons.antenna_radiowaves_left_right),
    ];
    return PageStack([
      const Heading(
        'Engineering tools',
        'Identifiers, existing self-tests and received fault transitions.',
      ),
      Section(
        'Vehicle identifiers',
        children: [
          GlassButton(
            'Read identifiers',
            onPressed: d.busy ? null : d.loadInfo,
          ),
          Text('Firmware: ${d.firmware}'),
          if (d.manifest.isNotEmpty)
            SelectableText(d.manifest, style: const TextStyle(fontSize: 12)),
        ],
      ),
      Section(
        'Diagnostic identity',
        icon: CupertinoIcons.checkmark_shield,
        children: [
          Text(
            'Read-only check of the scooter\'s diagnostic certificate status. '
            'Generating or reinstalling certs can break the scooter\'s trust, so '
            'those are not exposed here.',
            style: TextStyle(color: muted(context), fontSize: 12, height: 1.4),
          ),
          GlassButton(
            'Validate identity',
            onPressed: d.busy || !d.connected ? null : d.validateCerts,
          ),
          if (d.certStatus.isNotEmpty)
            Text(
              d.certStatus,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
        ],
      ),
      Section(
        'Firmware update (OTA)',
        icon: CupertinoIcons.cloud_download,
        children: [
          Text(
            'EXPERIMENTAL and brick-capable. The checksum format the scooter '
            'expects is UNVERIFIED (assumed SHA-256) — do NOT flash a scooter '
            'you cannot risk until this is validated on a test unit. Needs '
            'Service mode.',
            style: const TextStyle(color: danger, fontSize: 12, height: 1.4),
          ),
          GlassButton(
            'Check update status',
            onPressed: d.busy || !d.connected ? null : d.otaStatus,
          ),
          if (d.otaState.isNotEmpty)
            Text(
              'Status: ${d.otaState}',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
          const SizedBox(height: 6),
          GlassButton(
            _otaFile == null ? 'Choose firmware file' : 'File: $_otaFile',
            icon: CupertinoIcons.doc,
            onPressed: d.busy
                ? null
                : () async {
                    final picked = await FilePicker.pickFiles();
                    if (picked.isNotEmpty &&
                        picked.single.path != null &&
                        mounted) {
                      final bytes = await File(
                        picked.single.path!,
                      ).readAsBytes();
                      if (!mounted) return;
                      setState(() {
                        _otaFile = picked.single.name;
                        _otaBytes = bytes;
                      });
                    }
                  },
          ),
          GlassButton(
            'Target: $_otaTarget',
            icon: CupertinoIcons.chevron_down,
            onPressed: d.busy
                ? null
                : () async {
                    final v = await glassSheet<String>(
                      context,
                      PageStack([
                        for (final t in const [
                          'ALL',
                          'AOSP',
                          'BCM',
                          'BLE',
                          'BMS',
                          'HU',
                          'MCU',
                        ])
                          GlassButton(t, onPressed: () => Navigator.pop(context, t)),
                      ]),
                    );
                    if (v != null && mounted) setState(() => _otaTarget = v);
                  },
          ),
          if (d.otaProgress > 0 && d.otaProgress < 1)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: d.otaProgress,
                  minHeight: 6,
                  backgroundColor: fill(context),
                  color: accent,
                ),
              ),
            ),
          GlassButton(
            'Flash firmware',
            destructive: true,
            onPressed: d.busy || _otaBytes == null
                ? null
                : () async {
                    if (!await requireServiceMode(context, d)) return;
                    if (!mounted) return;
                    if (await confirmTyped(
                      context,
                      title: 'Flash $_otaFile to $_otaTarget?',
                      message:
                          'EXPERIMENTAL and BRICK-CAPABLE. The checksum format is '
                          'unverified; a wrong file or an interrupted write can '
                          'permanently brick the $_otaTarget. Keep the scooter '
                          'parked and on charge, and do not disconnect. Type '
                          'CONFIRM.',
                    )) {
                      await d.otaFlash(_otaBytes!, _otaFile!, _otaTarget);
                      if (mounted) setState(() {});
                    }
                  },
          ),
        ],
      ),
      Section(
        'Motor calibration',
        children: [
          Text(
            'Centre stand only. Existing MCU calibration may move the motor. Hardware validation is pending.',
            style: TextStyle(color: muted(context)),
          ),
          GlassButton(
            'Read motor angle (B113)',
            onPressed: d.busy
                ? null
                : () => d.operation('Read motor angle', () async {
                    if (d.demo) {
                      d.message = 'Demo motor angle: unavailable';
                      return;
                    }
                    final u = d.uds!;
                    final bytes = await u.read(Ecu.mcu, 0xb113);
                    d.message = 'Motor angle raw: ${hex(bytes)}';
                  }),
          ),
          GlassButton(
            'Start AutoTune',
            destructive: true,
            onPressed: d.busy
                ? null
                : () async {
                    if (await confirmGlass(
                      context,
                      'Start MCU AutoTune?',
                      'Centre stand, rear wheel clear, scooter parked and charger disconnected. Sends the existing motor calibration command.',
                    )) {
                      await d.test(8, 'MCU AutoTune', true);
                    }
                  },
          ),
          GlassButton(
            'Stop AutoTune',
            onPressed: d.busy ? null : () => d.test(8, 'MCU AutoTune', false),
          ),
        ],
      ),
      Section(
        'Root shell (ADB)',
        icon: CupertinoIcons.chevron_left_slash_chevron_right,
        children: [
          Text(
            'Runs a shell command on the head unit as root via ExecuteADBCommand. '
            'Powerful and unguarded — e.g. `getprop ro.build.fingerprint`, or '
            '`find / -name "*.crt" 2>/dev/null` to locate the diagnostic identity, '
            'then `base64 <path>` to read it out.',
            style: TextStyle(color: muted(context), fontSize: 11.5, height: 1.4),
          ),
          GlassField(controller: _adbCtl, label: 'Shell command', enabled: !d.busy),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              GlassButton(
                'Run',
                primary: true,
                onPressed: d.busy || !d.connected
                    ? null
                    : () async {
                        final cmd = _adbCtl.text.trim();
                        if (cmd.isEmpty) return;
                        if (await confirmTyped(
                          context,
                          title: 'Run as root on the head unit?',
                          message:
                              'Runs `$cmd` as uid 0 on the scooter. Root shell '
                              'access can change system state. Type CONFIRM.',
                        )) {
                          await d.adbCommand(cmd);
                          if (mounted) setState(() {});
                        }
                      },
              ),
              GlassButton(
                'Bring diag app to front',
                compact: true,
                onPressed: d.busy || !d.connected
                    ? null
                    : () async {
                        await d.adbCommand(
                          'monkey -p com.olaelectric.udstestapp '
                          '-c android.intent.category.LAUNCHER 1',
                        );
                        if (mounted) setState(() {});
                      },
              ),
            ],
          ),
          if (d.adbOutput.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: fill(context),
                borderRadius: BorderRadius.circular(10),
              ),
              child: SelectableText(
                d.adbOutput,
                style: const TextStyle(fontSize: 11, fontFamily: 'monospace'),
              ),
            ),
        ],
      ),
      Section(
        'Self-tests',
        children: [
          Text(
            'These run on the scooter\'s head unit. The diagnostic app '
            '(com.olaelectric.udstestapp) is now brought to the front '
            'automatically when a test starts, so the result is visible on the '
            'scooter.',
            style: TextStyle(color: muted(context), fontSize: 11.5, height: 1.4),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [for (final t in tests) _selfTestTile(t.$1, t.$2, t.$3)],
          ),
          if (runningTest != null) ...[
            const SizedBox(height: 10),
            GlassButton(
              'Stop $runningLabel test',
              destructive: true,
              onPressed: d.busy
                  ? null
                  : () async {
                      await d.test(runningTest!, runningLabel, false);
                      if (mounted) setState(() => runningTest = null);
                    },
            ),
          ],
        ],
      ),
      Section(
        'Fault transitions',
        children: [
          Text(
            'SET/CLEAR from received CAN frames; no injected commands.',
            style: TextStyle(color: muted(context)),
          ),
          if (d.watchEvents.isEmpty)
            const Text('No transitions received this session.'),
          for (final event in d.watchEvents.take(30))
            Text(event, style: const TextStyle(fontSize: 12)),
        ],
      ),
      Section(
        'Ride-mode frame',
        children: [
          Text(
            d.raw[0x143] == null
                ? 'No 0x143 frame received.'
                : '0x143 raw: ${hex(d.raw[0x143]!)}',
          ),
          const Text(
            'Mode mapping depends on firmware; raw bytes are not a confirmed mode.',
          ),
        ],
      ),
      Section(
        'Manufacturing configuration',
        icon: CupertinoIcons.wrench_fill,
        children: [
          Text(
            'Factory ECU-write commands from the production app. JTAG toggles '
            'hardware debug ports — reference only; OpenOLA does not send the '
            'BCM writes (BCM is not UDS-addressable here).',
            style: TextStyle(color: muted(context), fontSize: 12, height: 1.4),
          ),
          for (final cmd in d.catalog.somCommands)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    cmd.isJtag
                        ? CupertinoIcons.lock_shield
                        : CupertinoIcons.doc_text,
                    size: 16,
                    color: cmd.isJtag ? danger : muted(context),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          cmd.name,
                          style: TextStyle(
                            color: ink(context),
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          '${cmd.ecu} · DID ${cmd.didHex} · ${cmd.data} · ${cmd.vehType}',
                          style: TextStyle(color: muted(context), fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          if (d.catalog.somResetBms) ...[
            const SizedBox(height: 12),
            GlassButton(
              'BMS reset',
              icon: CupertinoIcons.arrow_clockwise,
              destructive: true,
              onPressed: d.busy
                  ? null
                  : () async {
                      if (await confirmGlass(
                        context,
                        'Reset the BMS?',
                        'Resets the battery management controller. Can clear a '
                            'latched state such as a stuck "charging" flag. Keep '
                            'the scooter parked, charger disconnected. Deep-sleep '
                            'wake is unvalidated.',
                      )) {
                        await d.faultAction(Ecu.bms, true);
                      }
                    },
            ),
          ],
        ],
      ),
    ]);
  }
}

class _ParameterEditor extends StatefulWidget {
  const _ParameterEditor(this.p, this.d, {this.typedConfirm = false});
  final Parameter p;
  final Diagnostics d;

  /// When true the write requires typing CONFIRM (used for the higher-stakes
  /// performance-limit writes) instead of a plain confirm dialog.
  final bool typedConfirm;
  @override
  State<_ParameterEditor> createState() => _ParameterEditorState();
}

class _ParameterEditorState extends State<_ParameterEditor> {
  List<int>? bytes;
  bool reversed = false, loading = false;
  String status = '';
  final edits = <String, TextEditingController>{};
  @override
  void initState() {
    super.initState();
    for (final f in widget.p.fields) {
      edits[f.name] = TextEditingController();
    }
  }

  @override
  void dispose() {
    for (final c in edits.values) {
      c.dispose();
    }
    super.dispose();
  }

  void decoded() {
    if (bytes != null) {
      for (final entry in widget.p.decode(bytes!, reversed: reversed).entries) {
        edits[entry.key]!.text = entry.value.toString();
      }
    }
  }

  Future<void> read() async {
    setState(() => loading = true);
    final result = await widget.d.readParameter(widget.p);
    if (!mounted) return;
    setState(() {
      bytes = result;
      loading = false;
      status = result == null ? widget.d.message : 'Current values received.';
      decoded();
    });
  }

  @override
  Widget build(BuildContext context) => PageStack([
    Heading(
      widget.p.name,
      '${widget.p.ecu.label} · current values are reread before writing.',
    ),
    GlassToggle(
      'Reverse byte order',
      'Original configuration byte order remains unverified. Validate against known values.',
      reversed,
      loading
          ? null
          : (v) => setState(() {
              reversed = v;
              decoded();
            }),
    ),
    GlassButton('Read current values', onPressed: loading ? null : read),
    if (bytes != null) ...[
      SelectableText(
        'Raw: ${hex(bytes!)}',
        style: const TextStyle(fontSize: 12),
      ),
      for (final f in widget.p.fields)
        GlassField(
          controller: edits[f.name]!,
          label:
              '${f.name} ${f.unit} (${f.minimum ?? '—'}…${f.maximum ?? '—'})',
          keyboard: const TextInputType.numberWithOptions(
            decimal: true,
            signed: true,
          ),
        ),
    ],
    if (bytes != null)
      GlassButton(
        'Write with readback verification',
        destructive: true,
        onPressed: loading
            ? null
            : () async {
                final values = <String, double>{};
                try {
                  for (final edit in edits.entries) {
                    values[edit.key] = double.parse(edit.value.text);
                  }
                  widget.p.encode(bytes!, values, reversed: reversed);
                } catch (e) {
                  setState(() => status = 'Check values: $e');
                  return;
                }
                final ok = widget.typedConfirm
                    ? await confirmTyped(
                        context,
                        title: 'Write ${widget.p.name}?',
                        message:
                            'This changes a real controller limit. Bounds shown '
                            'are encoding limits, NOT verified-safe calibration '
                            'limits. Keep the scooter parked and watch pack '
                            'temperature, current and cell spread. Type CONFIRM '
                            'to write.',
                      )
                    : await confirmGlass(
                        context,
                        'Write ${widget.p.name}?',
                        'Changes calibration data. Bounds are encoding limits, not verified safe limits. Fresh bytes are reread, patched and checked after the write.',
                      );
                if (!ok) {
                  return;
                }
                setState(() => loading = true);
                await widget.d.writeParameter(
                  widget.p,
                  values,
                  reversed: reversed,
                );
                if (mounted) {
                  setState(() {
                    loading = false;
                    status = widget.d.message;
                  });
                }
              },
      ),
    if (status.isNotEmpty)
      Text(status, style: TextStyle(color: muted(context))),
  ]);
}

class _BluetoothPage extends StatelessWidget {
  const _BluetoothPage(this.ble);
  final ScooterBle ble;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: ble,
    builder: (context, _) => PageStack([
      const Heading(
        'Bluetooth controls',
        'Discover your scooter nearby. iPhone uses the discovered device, not a MAC address.',
      ),
      Section(
        'Connection',
        icon: CupertinoIcons.bluetooth,
        children: [
          GlassButton(
            ble.scanning ? 'Stop scan' : 'Find my scooter',
            onPressed: ble.busy
                ? null
                : ble.scanning
                ? ble.stopScan
                : ble.scan,
          ),
          if (ble.scanning) const Text('Scanning nearby scooters…'),
          for (final device in ble.devices.values)
            GlassButton(
              '${device.name.isEmpty ? 'Scooter' : device.name} · ${device.rssi} dBm',
              onPressed: ble.busy ? null : () => ble.connect(device),
            ),
          if (ble.ready)
            GlassButton(
              'Disconnect Bluetooth',
              onPressed: ble.busy ? null : ble.disconnect,
            ),
          if (ble.message.isNotEmpty)
            Text(ble.message, style: TextStyle(color: muted(context))),
        ],
      ),
      if (ble.ready) ...[
        Section(
          'Received status',
          children: [
            Text('Battery: ${ble.soc ?? '—'} %'),
            Text(
              'Lock: ${ble.locked == null
                  ? 'Unknown'
                  : ble.locked!
                  ? 'Locked'
                  : 'Unlocked'}',
            ),
            Text(
              ble.receivedAt == null
                  ? 'No status broadcast yet.'
                  : 'Received ${DateTime.now().difference(ble.receivedAt!).inSeconds}s ago.',
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
          ],
        ),
        Section(
          'Vehicle controls',
          children: [
            for (final command in [
              ('Unlock', 2, CupertinoIcons.lock_open),
              ('Lock', 1, CupertinoIcons.lock),
              ('Open trunk', 3, CupertinoIcons.archivebox),
              ('Flash lights', 6, CupertinoIcons.lightbulb),
              ('Flash + horn', 7, CupertinoIcons.speaker_2),
            ])
              GlassButton(
                command.$1,
                icon: command.$3,
                onPressed: ble.busy
                    ? null
                    : () async {
                        if (await confirmGlass(
                          context,
                          '${command.$1}?',
                          'Sends an active command to the selected scooter. Confirm it is yours and parked.',
                        )) {
                          await ble.command(command.$2, command.$1);
                        }
                      },
              ),
          ],
        ),
      ],
    ]),
  );
}
