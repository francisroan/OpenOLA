import 'model_diagnostics.dart';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'identifiers_page.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../design/glass.dart';
import '../design/glass_quality.dart';
import '../design/dashboard.dart';
import '../diagnostics/controller.dart';
import '../diagnostics/preferences.dart';
import '../diagnostics/report.dart';
import '../protocol/can.dart';

class PageStack extends StatelessWidget {
  const PageStack(this.children, {super.key});
  final List<Widget> children;
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      for (var i = 0; i < children.length; i++) ...[
        if (i > 0) const SizedBox(height: 16),
        children[i],
      ],
    ],
  );
}

String number(double? value, [int digits = 1]) =>
    value == null ? '—' : value.toStringAsFixed(digits);
String codeCount(int count) => '$count ${count == 1 ? 'code' : 'codes'}';

class ConnectPage extends StatefulWidget {
  const ConnectPage({super.key, required this.d});
  final Diagnostics d;
  @override
  State<ConnectPage> createState() => _ConnectPageState();
}

class _ConnectPageState extends State<ConnectPage> {
  late final TextEditingController host = TextEditingController(
    // No baked-in address — scan the scooter QR or type it; the last one used
    // is remembered. (Never ship a personal scooter IP in the source.)
    text: widget.d.prefs.store.getString('host') ?? '',
  );
  late final TextEditingController port = TextEditingController(
    text: '${widget.d.prefs.store.getInt('port') ?? 50005}',
  );
  late bool secure = widget.d.prefs.store.getBool('secure') ?? false;
  late bool phoneHotspot =
      widget.d.prefs.store.getBool('phoneHotspot') ?? false;
  bool options = false;
  String error = '';
  @override
  void dispose() {
    host.dispose();
    port.dispose();
    super.dispose();
  }

  Future<void> connect(bool demo) async {
    final p = int.tryParse(port.text);
    if (host.text.trim().isEmpty ||
        host.text.contains(RegExp(r'\s')) ||
        p == null ||
        p < 1 ||
        p > 65535) {
      setState(() => error = 'Enter a valid address and port (1–65535).');
      return;
    }
    setState(() => error = '');
    await widget.d.connect(
      host.text,
      p,
      secure: secure,
      simulated: demo,
      phoneHotspot: phoneHotspot,
    );
  }

  @override
  Widget build(BuildContext context) {
    final connecting = widget.d.connection == Connection.connecting;
    return PageStack([
      const Heading(
        'Connect your scooter',
        'A simple workspace for battery data, faults and reports.',
      ),
      Glass(
        child: Row(
          children: [
            const AppMark(size: 60),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'OpenOLA',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Join its diagnostic Wi-Fi in your phone’s Settings, then connect here.',
                    style: TextStyle(color: muted(context), height: 1.4),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      Section(
        'Wi-Fi diagnostics',
        icon: CupertinoIcons.wifi,
        children: [
          GlassField(
            controller: host,
            label: 'Scooter address',
            enabled: !connecting,
            suffix: IconButton(
              tooltip: 'Scan scooter QR',
              icon: const Icon(CupertinoIcons.qrcode_viewfinder, color: accent),
              onPressed: connecting
                  ? null
                  : () async {
                      final result = await Navigator.push<String>(
                        context,
                        MaterialPageRoute(builder: (_) => const _QrScanner()),
                      );
                      if (!mounted || result == null) return;
                      final ip = RegExp(
                        r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
                      ).firstMatch(result)?.group(0);
                      setState(() {
                        if (ip != null &&
                            ip.split('.').every((p) => int.parse(p) <= 255)) {
                          host.text = ip;
                          error = '';
                        } else {
                          error =
                              'No valid diagnostic IP in this QR. Enter the address manually.';
                        }
                      });
                    },
            ),
          ),
          GlassToggle(
            'This phone hosts the hotspot',
            'Turn on when the scooter is connected to this phone\'s hotspot. Leave off for a separate Wi-Fi network.',
            phoneHotspot,
            connecting ? null : (v) => setState(() => phoneHotspot = v),
          ),
          GlassButton(
            options ? 'Hide connection options' : 'Connection options',
            compact: true,
            icon: CupertinoIcons.chevron_down,
            onPressed: connecting
                ? null
                : () => setState(() => options = !options),
          ),
          if (options) ...[
            GlassField(
              controller: port,
              label: 'Port',
              keyboard: TextInputType.number,
              enabled: !connecting,
            ),
            GlassToggle(
              'Secure connection',
              'Use mutual TLS when required by your scooter.',
              secure,
              connecting ? null : (v) => setState(() => secure = v),
            ),
          ],
          if (error.isNotEmpty)
            Text(error, style: const TextStyle(color: danger)),
          GlassButton(
            connecting ? 'Connecting…' : 'Connect to scooter',
            primary: true,
            icon: CupertinoIcons.link,
            onPressed: connecting ? null : () => connect(false),
          ),
          if (connecting)
            GlassButton(
              'Cancel connection',
              onPressed: () => widget.d.disconnect(),
            ),
        ],
      ),
      Section(
        'Explore first',
        icon: CupertinoIcons.play_circle,
        children: [
          Text(
            'Preview the full workspace with simulated readings. No scooter connection or commands.',
            style: TextStyle(color: muted(context)),
          ),
          GlassButton(
            'Try Demo',
            onPressed: connecting ? null : () => connect(true),
          ),
        ],
      ),
    ]);
  }
}

class _QrScanner extends StatefulWidget {
  const _QrScanner();
  @override
  State<_QrScanner> createState() => _QrScannerState();
}

class _QrScannerState extends State<_QrScanner> {
  final scanner = MobileScannerController(formats: [BarcodeFormat.qrCode]);
  bool returned = false;
  @override
  void dispose() {
    scanner.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Stack(
      children: [
        const Positioned.fill(child: GlassWallpaper()),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Glass(
                  chrome: true,
                  child: Row(
                    children: [
                      IconButton(
                        tooltip: 'Back',
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(CupertinoIcons.chevron_left),
                      ),
                      const Expanded(child: Text('Scan scooter QR')),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(28),
                    child: MobileScanner(
                      controller: scanner,
                      onDetect: (capture) {
                        for (final code in capture.barcodes) {
                          if (code.rawValue != null && !returned) {
                            returned = true;
                            Navigator.pop(context, code.rawValue);
                            break;
                          }
                        }
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Glass(
                  child: Text(
                    'Align the scooter QR in the camera. You can enter its address manually if scanning is unavailable.',
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.d, required this.navigate});
  final Diagnostics d;
  final ValueChanged<int> navigate;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool details = false;
  Diagnostics get d => widget.d;
  Widget disclosure(Widget child) => reduced(context)
      ? child
      : AnimatedSize(
          duration: motion(context),
          curve: Curves.easeOutCubic,
          alignment: Alignment.topCenter,
          child: child,
        );
  @override
  Widget build(BuildContext context) {
    final m = d.metrics;
    final total = d.faults.values.fold<int>(0, (n, f) => n + f.length);
    final scanned = d.faults.length;
    return PageStack([
      const Heading('Your scooter', 'Battery overview'),
      Glass(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LayoutBuilder(
              builder: (context, box) {
                final bigText = MediaQuery.textScalerOf(context).scale(14) > 20;
                final stats = Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    MetricValue(
                      'Reported range',
                      number(m['Reported range (km)'], 0),
                      unit: 'km',
                      compact: true,
                    ),
                    const SizedBox(height: 14),
                    MetricValue(
                      'Pack voltage',
                      number(m['Pack voltage (V)']),
                      unit: 'V',
                      compact: true,
                    ),
                    const SizedBox(height: 14),
                    MetricValue(
                      'Pack current',
                      number(m['Pack current (A)']),
                      unit: 'A',
                      compact: true,
                    ),
                  ],
                );
                if (bigText && box.maxWidth < 350) {
                  return Column(
                    children: [
                      BatteryRing(m['State of charge (%)'], size: 154),
                      const SizedBox(height: 18),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: MetricValue(
                              'Range',
                              number(m['Reported range (km)'], 0),
                              unit: 'km',
                              compact: true,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: MetricValue(
                              'Pack voltage',
                              number(m['Pack voltage (V)']),
                              unit: 'V',
                              compact: true,
                            ),
                          ),
                        ],
                      ),
                    ],
                  );
                }
                return Row(
                  children: [
                    BatteryRing(
                      m['State of charge (%)'],
                      size: box.maxWidth > 650 ? 168 : 144,
                    ),
                    const SizedBox(width: 24),
                    Expanded(
                      child: box.maxWidth > 650
                          ? Row(
                              children: [
                                Expanded(
                                  child: MetricValue(
                                    'Reported range',
                                    number(m['Reported range (km)'], 0),
                                    unit: 'km',
                                  ),
                                ),
                                Expanded(
                                  child: MetricValue(
                                    'Pack voltage',
                                    number(m['Pack voltage (V)']),
                                    unit: 'V',
                                  ),
                                ),
                                Expanded(
                                  child: MetricValue(
                                    'Pack current',
                                    number(m['Pack current (A)']),
                                    unit: 'A',
                                  ),
                                ),
                              ],
                            )
                          : stats,
                    ),
                  ],
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Divider(height: 1, color: separator(context)),
            ),
            Text(
              d.demo ? 'Simulated readings' : d.freshness,
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
          ],
        ),
      ),
      Glass(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Column(
          children: [
            WorkspaceRow(
              'Inspect faults',
              scanned == 0
                  ? 'Not scanned yet'
                  : '${codeCount(total)} · $scanned/3 scanned',
              CupertinoIcons.waveform_path_ecg,
              green,
              onTap: () => widget.navigate(2),
            ),
            Divider(height: 1, color: separator(context)),
            WorkspaceRow(
              'Create a report',
              'Save a diagnostic snapshot',
              CupertinoIcons.doc_text,
              purple,
              onTap: () => widget.navigate(3),
            ),
          ],
        ),
      ),
      ModelDiagnostics(d: d, identityOnly: true),
      Glass(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: disclosure(
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Semantics(
                expanded: details,
                child: WorkspaceRow(
                  'Battery details',
                  details ? '' : 'Current and temperatures',
                  CupertinoIcons.battery_100,
                  teal,
                  trailing: Icon(
                    details
                        ? CupertinoIcons.chevron_up
                        : CupertinoIcons.chevron_down,
                    color: muted(context),
                    size: 16,
                  ),
                  onTap: () => setState(() => details = !details),
                ),
              ),
              if (details)
                Padding(
                  padding: const EdgeInsets.only(top: 12, bottom: 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      LayoutBuilder(
                        builder: (_, box) {
                          final cols = box.maxWidth > 650 ? 3 : 2;
                          const fields = [
                            ('Pack voltage (V)', 'Voltage', 'V'),
                            ('Pack current (A)', 'Current', 'A'),
                            ('Battery temperature (°C)', 'Battery temp', '°C'),
                            ('Motor temperature (°C)', 'Motor temp', '°C'),
                            (
                              'Controller temperature (°C)',
                              'Controller temp',
                              '°C',
                            ),
                            ('Vehicle speed (km/h)', 'Speed', 'km/h'),
                          ];
                          return Wrap(
                            spacing: 14,
                            runSpacing: 20,
                            children: [
                              for (final f in fields)
                                SizedBox(
                                  width:
                                      (box.maxWidth - 14 * (cols - 1)) / cols,
                                  child: MetricValue(
                                    f.$2,
                                    number(m[f.$1]),
                                    unit: f.$3,
                                    compact: true,
                                  ),
                                ),
                            ],
                          );
                        },
                      ),
                      Text(
                        '— means unavailable. State of charge is not a battery-health result. Per-signal freshness is unknown.',
                        style: TextStyle(color: muted(context), fontSize: 11),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    ]);
  }
}

class FaultsPage extends StatefulWidget {
  const FaultsPage({super.key, required this.d});
  final Diagnostics d;
  @override
  State<FaultsPage> createState() => _FaultsPageState();
}

class _FaultsPageState extends State<FaultsPage> {
  Ecu ecu = Ecu.bms;
  bool attempted = false, scheduled = false, loading = false;
  String? readError;
  bool get permitted =>
      widget.d.connected &&
      (widget.d.demo || widget.d.bench && widget.d.mode == 'SERVICE');

  @override
  void initState() {
    super.initState();
    widget.d.addListener(changed);
    queueRead();
  }

  @override
  void didUpdateWidget(FaultsPage old) {
    super.didUpdateWidget(old);
    if (old.d != widget.d) {
      old.d.removeListener(changed);
      attempted = false;
      scheduled = false;
      loading = false;
      readError = null;
      widget.d.addListener(changed);
      queueRead();
    }
  }

  @override
  void dispose() {
    widget.d.removeListener(changed);
    super.dispose();
  }

  void changed() {
    if (!mounted) return;
    if (!widget.d.connected) attempted = false;
    setState(() {});
    queueRead();
  }

  void queueRead() {
    if (attempted || scheduled || loading || !permitted || widget.d.busy) {
      return;
    }
    scheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      scheduled = false;
      if (!mounted || attempted || loading || !permitted || widget.d.busy) {
        return;
      }
      readFaults();
    });
  }

  Future<void> readFaults() async {
    if (!permitted || widget.d.busy || loading) return;
    final d = widget.d;
    setState(() {
      attempted = true;
      loading = true;
      readError = null;
    });
    String? error;
    try {
      await d.scan();
      if (!d.message.startsWith('Fault scan complete')) {
        error = d.message.isEmpty
            ? 'Faults could not be refreshed. Tap Refresh faults to try again.'
            : d.message;
      }
    } catch (e) {
      error = 'Fault read failed: $e';
    }
    if (!mounted || widget.d != d) return;
    setState(() {
      loading = false;
      readError = error;
    });
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.d;
    final hasCodes = d.faults.values.any((codes) => codes.isNotEmpty);
    final allRead = Ecu.values.every(d.faults.containsKey);
    final live = d.liveFaults();
    final faultSeen = d.activeFaultFrames.any((f) => d.frameFresh(f.id));
    return PageStack([
      const Heading('Faults', 'Stored codes from your scooter’s controllers.'),
      Section(
        'Stored faults',
        icon: CupertinoIcons.waveform_path_ecg,
        children: [
          Row(
            children: [
              if (loading) ...[
                CupertinoActivityIndicator(animating: !reduced(context)),
                const SizedBox(width: 10),
              ],
              Expanded(
                child: Text(
                  !d.connected
                      ? 'Connect to load faults automatically.'
                      : !permitted
                      ? 'Tap Connected, then Enter Service after parking and disconnecting the charger. Faults will load automatically.'
                      : loading
                      ? 'Reading stored faults…'
                      : !attempted && d.busy
                      ? 'Waiting for the current operation to finish.'
                      : readError != null
                      ? 'The latest fault read did not complete.'
                      : allRead
                      ? 'All three controllers read${d.demo ? ' · simulated' : ''}.'
                      : 'Faults load automatically when this page opens.',
                  style: TextStyle(color: muted(context)),
                ),
              ),
            ],
          ),
          GlassButton(
            'Refresh faults',
            compact: true,
            icon: CupertinoIcons.arrow_clockwise,
            onPressed: !permitted || d.busy || loading ? null : readFaults,
          ),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: [
              for (final target in Ecu.values)
                StatusChip(
                  '${target.label} · ${d.faults.containsKey(target) ? codeCount(d.faults[target]!.length) : 'Not read'}',
                  color: d.faults[target]?.isNotEmpty == true ? danger : null,
                ),
            ],
          ),
          if (readError != null)
            Text(readError!, style: const TextStyle(color: danger)),
          if (d.faults.isNotEmpty && (loading || readError != null))
            Text(
              'Last returned controller results; the latest read is ${loading ? 'in progress' : 'incomplete'}.',
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
          if (hasCodes) ...[
            for (final target in Ecu.values)
              if (d.faults[target]?.isNotEmpty == true) ...[
                Text(
                  target.description,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                for (final fault in d.faults[target]!)
                  Glass(
                    radius: 18,
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          fault.code,
                          style: const TextStyle(
                            color: danger,
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(fault.description),
                        const SizedBox(height: 8),
                        Text(
                          'Status 0x${fault.status.toRadixString(16).padLeft(2, '0')} · latest returned code in this session',
                          style: TextStyle(color: muted(context), fontSize: 12),
                        ),
                      ],
                    ),
                  ),
              ],
          ] else if (!loading && readError == null && allRead) ...[
            const Text('No stored faults returned.'),
            Text(
              'This does not prove battery health or repair.',
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
          ] else if (!loading)
            Text(
              readError == null
                  ? 'Faults have not been read for all controllers.'
                  : 'The latest read is incomplete. Refresh to try again.',
            ),
        ],
      ),
      if (d.connected)
        Section(
          'Live fault flags',
          icon: CupertinoIcons.exclamationmark_triangle,
          children: [
            Text(
              live.isNotEmpty
                  ? '${d.demo ? 'Simulated — d' : 'D'}ecoded live from the BMS / MCU / VCU broadcast frames.'
                  : faultSeen
                  ? 'No active fault flags in the frames received.'
                  : 'Fault frames not received yet — start the live stream and wait. This is not the same as "no faults".',
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
            for (final entry in live.entries) ...[
              const SizedBox(height: 8),
              Text(
                entry.key,
                style: TextStyle(
                  color: muted(context),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: .6,
                ),
              ),
              for (final f in entry.value.toSet())
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(top: 5),
                        child: Icon(
                          CupertinoIcons.circle_fill,
                          color: danger,
                          size: 7,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          f,
                          style: const TextStyle(color: danger, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ],
        ),
      if (d.broadcast.isNotEmpty)
        Section(
          'Broadcast fault flags',
          children: [
            for (final flag in d.broadcast)
              Text(flag, style: const TextStyle(color: danger)),
          ],
        ),
      if (d.prefs.has(Tool.recovery))
        Section(
          'Service & recovery',
          children: [
            GlassSegment<Ecu>(
              values: Ecu.values,
              selected: ecu,
              label: (e) => e.label,
              onChanged: (e) => setState(() => ecu = e),
            ),
            Text(
              'Choose the controller for clearing or restart.',
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
            Text(
              'Export a report first. ECU restart is separate from unvalidated deep-sleep BMS wake.',
              style: TextStyle(color: muted(context), fontSize: 13),
            ),
            GlassButton(
              'Clear ${ecu.label} fault history',
              destructive: true,
              onPressed: !d.connected || d.busy
                  ? null
                  : () async {
                      if (await confirmGlass(
                        context,
                        'Clear ${ecu.label} history?',
                        'Erases stored trouble codes. Save a report first; history will be lost.',
                      )) {
                        await d.faultAction(ecu, false);
                      }
                    },
            ),
            GlassButton(
              'Restart ${ecu.label}',
              destructive: true,
              onPressed: !d.connected || d.busy
                  ? null
                  : () async {
                      if (await confirmGlass(
                        context,
                        'Restart ${ecu.label}?',
                        'Sends the existing hard ECU reset (11 01). Deep-sleep BMS wake has not been validated.',
                      )) {
                        await d.faultAction(ecu, true);
                      }
                    },
            ),
            GlassButton(
              'Existing fault recovery',
              destructive: true,
              onPressed: !d.connected || d.busy
                  ? null
                  : () async {
                      if (await confirmGlass(
                        context,
                        'Run fault recovery?',
                        'Save a report first. Reads all controllers, clears and resets controllers with faults (or VCU if none), then returns to Customer mode. Deep-sleep wake is unvalidated.',
                      )) {
                        await d.recover();
                      }
                    },
            ),
            GlassButton(
              'Restart head unit',
              destructive: true,
              onPressed: !d.connected || d.busy
                  ? null
                  : () async {
                      if (await confirmGlass(
                        context,
                        'Restart head unit?',
                        'Ends this connection. Reconnect manually when the head unit is ready. A dropped connection does not prove the restart completed.',
                      )) {
                        await d.restartHeadUnit();
                      }
                    },
            ),
          ],
        ),
    ]);
  }
}

class GlassSegment<T> extends StatelessWidget {
  const GlassSegment({
    super.key,
    required this.values,
    required this.selected,
    required this.label,
    required this.onChanged,
  });
  final List<T> values;
  final T selected;
  final String Function(T) label;
  final ValueChanged<T> onChanged;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(4),
    decoration: BoxDecoration(
      color: fill(context),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Row(
      children: [
        for (final value in values)
          Expanded(
            child: Semantics(
              selected: value == selected,
              button: true,
              child: GestureDetector(
                onTap: () => onChanged(value),
                child: AnimatedContainer(
                  duration: motion(context),
                  constraints: const BoxConstraints(minHeight: 48),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 12,
                  ),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(9),
                    color: value == selected
                        ? Colors.white.withValues(
                            alpha: dark(context) ? .10 : .86,
                          )
                        : Colors.transparent,
                    border: Border.all(
                      color: value == selected
                          ? Colors.white.withValues(
                              alpha: dark(context) ? .06 : .45,
                            )
                          : Colors.transparent,
                    ),
                  ),
                  child: Text(
                    label(value),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: value == selected ? ink(context) : muted(context),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    ),
  );
}

class ReportState {
  DiagnosticReport? report;
  bool identifiers = false, activity = false, ecuExpanded = false;
}

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key, required this.d, required this.state});
  final Diagnostics d;
  final ReportState state;
  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  String status = '';
  bool exporting = false;
  Future<void> save(String extension) async {
    final report = widget.state.report;
    if (report == null || exporting) return;
    setState(() => exporting = true);
    try {
      final result = await FilePicker.saveFile(
        dialogTitle: 'Save diagnostic report',
        fileName: report.filename(extension),
        bytes: Uint8List.fromList(
          utf8.encode(extension == 'json' ? report.json : report.text),
        ),
      );
      if (mounted) {
        setState(
          () => status = result == null ? 'Save cancelled.' : 'Report saved.',
        );
      }
    } catch (e) {
      if (mounted) setState(() => status = 'Save failed: $e');
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.state;
    return PageStack([
      const Heading(
        'Diagnostic reports',
        'A clear snapshot of this diagnostic session.',
      ),
      Glass(
        child: Column(
          children: [
            WorkspaceRow(
              'Read ECU health report',
              'Battery, drive inputs and component data',
              CupertinoIcons.doc_text_search,
              teal,
              trailing: Icon(
                state.ecuExpanded
                    ? CupertinoIcons.chevron_up
                    : CupertinoIcons.chevron_down,
                size: 16,
                color: muted(context),
              ),
              onTap: () =>
                  setState(() => state.ecuExpanded = !state.ecuExpanded),
            ),
            if (state.ecuExpanded)
              IdentifiersPage(
                d: widget.d,
                kind: IdentifierWorkspace.healthReport,
                embedded: true,
              ),
          ],
        ),
      ),
      Section(
        'Capture',
        icon: CupertinoIcons.doc_text,
        children: [
          GlassToggle(
            'Include identifiers / VIN',
            'Off by default. Read identifiers in Engineering tools first.',
            state.identifiers,
            (v) => setState(() {
              state.identifiers = v;
              state.report = null;
            }),
          ),
          GlassToggle(
            'Include activity log',
            'Command history can contain identifying information.',
            state.activity,
            (v) => setState(() {
              state.activity = v;
              state.report = null;
            }),
          ),
          GlassButton(
            state.report == null ? 'Capture report' : 'Capture a new snapshot',
            primary: true,
            icon: CupertinoIcons.camera,
            onPressed: widget.d.busy
                ? null
                : () => setState(() {
                    state.report = DiagnosticReport.capture(
                      widget.d,
                      includeVin: state.identifiers,
                      includeActivity: state.activity,
                    );
                    status = 'Snapshot captured.';
                  }),
          ),
          Text(
            'Unknown fields and unscanned controllers remain explicit. Demo reports are labelled simulated.',
            style: TextStyle(color: muted(context), fontSize: 12),
          ),
        ],
      ),
      if (state.report != null) ...[
        Section(
          'Export snapshot',
          children: [
            Text(
              state.report!.data['captured_at'].toString(),
              style: TextStyle(color: muted(context), fontSize: 12),
            ),
            GlassButton(
              'Save JSON',
              onPressed: exporting ? null : () => save('json'),
            ),
            GlassButton(
              'Save TXT',
              onPressed: exporting ? null : () => save('txt'),
            ),
            GlassButton(
              'Share report',
              icon: CupertinoIcons.square_arrow_up,
              onPressed: exporting
                  ? null
                  : () async {
                      try {
                        final box = context.findRenderObject() as RenderBox?;
                        await SharePlus.instance.share(
                          ShareParams(
                            text: state.report!.text,
                            subject: 'OpenOLA diagnostic report',
                            sharePositionOrigin: box == null
                                ? null
                                : box.localToGlobal(Offset.zero) & box.size,
                          ),
                        );
                      } catch (e) {
                        if (mounted) {
                          setState(() => status = 'Share unavailable: $e');
                        }
                      }
                    },
            ),
            if (status.isNotEmpty)
              Text(status, style: TextStyle(color: muted(context))),
          ],
        ),
        Section(
          'Preview',
          children: [
            SelectableText(
              state.report!.text,
              style: TextStyle(
                color: muted(context),
                fontSize: 12,
                height: 1.5,
              ),
            ),
          ],
        ),
      ],
    ]);
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({
    super.key,
    required this.d,
    required this.prefs,
    required this.onShowTutorial,
    required this.onEnterDeveloper,
  });
  final Diagnostics d;
  final Preferences prefs;
  final VoidCallback onShowTutorial;
  final Future<bool> Function() onEnterDeveloper;
  @override
  Widget build(BuildContext context) => PageStack([
    const Heading(
      'Settings',
      'Appearance, feedback and access to advanced tools.',
    ),
    Section(
      'Appearance',
      icon: CupertinoIcons.circle_lefthalf_fill,
      children: [
        GlassSegment<ThemeMode>(
          values: ThemeMode.values,
          selected: prefs.theme,
          label: (m) => switch (m) {
            ThemeMode.system => 'System',
            ThemeMode.light => 'Light',
            ThemeMode.dark => 'Dark',
          },
          onChanged: prefs.appearance,
        ),
        GlassToggle(
          'Reduce motion',
          'Keep transitions and control feedback simple.',
          prefs.reduceMotion,
          prefs.motion,
        ),
      ],
    ),
    Section(
      'Feedback',
      icon: CupertinoIcons.hand_draw,
      children: [
        GlassToggle(
          'Haptics',
          'Vibrate on taps, confirmations and slide-to-verify.',
          prefs.haptics,
          prefs.setHaptics,
        ),
      ],
    ),
    // Glass quality listens to its own notifier so the segment reflects
    // auto-downgrades live.
    ListenableBuilder(
      listenable: prefs.quality,
      builder: (context, _) => Section(
        'Display quality',
        icon: CupertinoIcons.sparkles,
        children: [
          GlassToggle(
            'Adapt automatically',
            'Full glass on capable phones; lighten the blur automatically when '
                'frames drop. Now: ${prefs.quality.tier.label}.',
            prefs.quality.auto,
            (v) => prefs.quality.setAuto(v),
          ),
          if (!prefs.quality.auto)
            GlassSegment<GlassTier>(
              values: GlassTier.values,
              selected: prefs.quality.manual,
              label: (t) => t.label,
              onChanged: prefs.quality.setManual,
            ),
        ],
      ),
    ),
    Section(
      'Advanced',
      icon: CupertinoIcons.wrench,
      children: [
        GlassToggle(
          'Developer Mode',
          prefs.developerMode
              ? 'Advanced windows are available in the Tools sidebar.'
              : 'Unlock actuator tests, parameter writes, ECU restart and '
                    'Bluetooth control. Requires slide-to-confirm.',
          prefs.developerMode,
          (v) {
            if (v) {
              onEnterDeveloper();
            } else {
              prefs.setDeveloperMode(false);
            }
          },
        ),
      ],
    ),
    Section(
      'Help',
      icon: CupertinoIcons.question_circle,
      children: [
        GlassButton(
          'Show tutorial',
          icon: CupertinoIcons.sparkles,
          onPressed: onShowTutorial,
        ),
      ],
    ),
    Section(
      'Activity',
      children: [
        Text(
          '${d.activity.length} entries in this session. Reports include them only when selected.',
          style: TextStyle(color: muted(context)),
        ),
        GlassButton(
          'View activity',
          onPressed: () => glassSheet(
            context,
            SelectableText(
              d.activity.join('\n').isEmpty
                  ? 'No activity yet.'
                  : d.activity.join('\n'),
              style: const TextStyle(fontSize: 12),
            ),
          ),
        ),
        GlassButton(
          'Clear view',
          onPressed: () {
            d.activity.clear();
            d.emit();
          },
        ),
      ],
    ),
    Section(
      'OpenOLA',
      children: [
        const AppMark(size: 64),
        const Text('Open diagnostics for owners and independent technicians.'),
        Text(
          'Local Android & iPhone workspace. Deep-sleep BMS wake remains unvalidated. Version 0.4.2. Developer: ola hecker.',
          style: TextStyle(color: muted(context), fontSize: 12),
        ),
      ],
    ),
  ]);
}
