import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../design/glass.dart';
import '../design/haptics.dart';

/// One step of the first-run tour. [anchor] names a UI target (a key in the
/// anchors map passed to [showTour]); when present the overlay spotlights that
/// element and places the caption beside it, otherwise the caption is centered.
class TourStep {
  const TourStep(this.icon, this.color, this.title, this.body, {this.anchor});
  final IconData icon;
  final Color color;
  final String title;
  final String body;
  final String? anchor;
}

const tourSteps = <TourStep>[
  TourStep(
    CupertinoIcons.sparkles,
    accent,
    'Welcome to OpenOLA',
    'A local diagnostics workspace for your scooter — fully offline. Here is a '
        'quick tour of each part.',
  ),
  TourStep(
    CupertinoIcons.wifi,
    Color(0xff34c759),
    'Connect or try Demo',
    'Join the scooter Wi-Fi and connect here — or tap Try Demo to explore the '
        'whole app with simulated data, no scooter needed.',
  ),
  TourStep(
    CupertinoIcons.square_grid_2x2,
    Color(0xff30d158),
    'Your main screens',
    'Home, Battery, Health and Reports — the everyday, high-level tools live '
        'here on the bottom bar.',
    anchor: 'tabs',
  ),
  TourStep(
    CupertinoIcons.sidebar_left,
    accent,
    'Tools sidebar',
    'Tap Tools any time to jump straight to a window — live signals, charging, '
        'components, firmware and more.',
    anchor: 'tools',
  ),
  TourStep(
    CupertinoIcons.wrench,
    Color(0xffff453a),
    'Developer Mode',
    'Advanced, riskier tools (actuator tests, parameter writes, ECU restart, '
        'Bluetooth control) stay hidden until you open Tools and slide to enter '
        'Developer Mode. Use them only on a parked scooter.',
    anchor: 'tools',
  ),
  TourStep(
    CupertinoIcons.slider_horizontal_3,
    Color(0xff5856d6),
    'Settings',
    'Appearance, haptics, display quality and this tour live here. You can '
        'replay the tour any time.',
    anchor: 'settings',
  ),
];

/// Shows the guided tour. [anchors] maps a step's `anchor` to the live widget's
/// GlobalKey so the overlay can spotlight it. Resolves when finished or skipped.
Future<void> showTour(
  BuildContext context, {
  Map<String, GlobalKey> anchors = const {},
}) => showGeneralDialog<void>(
  context: context,
  barrierDismissible: false,
  barrierLabel: 'Tutorial',
  barrierColor: Colors.transparent,
  transitionDuration: const Duration(milliseconds: 220),
  pageBuilder: (_, _, _) => _Tour(anchors: anchors),
  transitionBuilder: (_, anim, _, child) => FadeTransition(
    opacity: CurvedAnimation(parent: anim, curve: Curves.easeOut),
    child: child,
  ),
);

class _Tour extends StatefulWidget {
  const _Tour({required this.anchors});
  final Map<String, GlobalKey> anchors;
  @override
  State<_Tour> createState() => _TourState();
}

class _TourState extends State<_Tour> {
  int index = 0;

  Rect? _anchorRect(String? id) {
    if (id == null) return null;
    final ctx = widget.anchors[id]?.currentContext;
    final box = ctx?.findRenderObject();
    if (box is! RenderBox || !box.attached) return null;
    final topLeft = box.localToGlobal(Offset.zero);
    return topLeft & box.size;
  }

  void _next() {
    if (index >= tourSteps.length - 1) {
      Navigator.of(context).pop();
      return;
    }
    AppHaptics.selection();
    setState(() => index++);
  }

  void _back() {
    if (index == 0) return;
    AppHaptics.selection();
    setState(() => index--);
  }

  @override
  Widget build(BuildContext context) {
    final step = tourSteps[index];
    final screen = MediaQuery.sizeOf(context);
    final pad = MediaQuery.paddingOf(context);
    final rawRect = _anchorRect(step.anchor);
    // Inflate a touch so the highlight breathes around the target.
    final rect = rawRect?.inflate(8);
    // Place the caption on whichever side of the target has more room.
    final below = rect == null || rect.bottom < screen.height * .5;

    return Material(
      type: MaterialType.transparency,
      child: Stack(
        children: [
          // Dimmed scrim with a rounded hole over the target.
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(painter: _Spotlight(rect)),
            ),
          ),
          // Caption card.
          Positioned(
            left: 16,
            right: 16,
            top: rect != null && below ? rect.bottom + 14 : null,
            bottom: rect != null && !below
                ? screen.height - rect.top + 14
                : (rect == null ? null : null),
            child: rect == null
                ? Padding(
                    padding: EdgeInsets.only(
                      top: screen.height * .28,
                      bottom: pad.bottom,
                    ),
                    child: Align(child: _card(step)),
                  )
                : Align(child: _card(step)),
          ),
        ],
      ),
    );
  }

  Widget _card(TourStep step) {
    final last = index == tourSteps.length - 1;
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420),
      child: Glass(
        grouped: false,
        chrome: true,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: step.color.withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Icon(step.icon, color: step.color, size: 22),
                ),
                const Spacer(),
                Text(
                  '${index + 1} / ${tourSteps.length}',
                  style: TextStyle(
                    color: muted(context),
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(step.title, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Text(
              step.body,
              style: TextStyle(
                color: muted(context),
                fontSize: 13.5,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < tourSteps.length; i++)
                  AnimatedContainer(
                    duration: motion(context),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: i == index ? 16 : 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: i == index
                          ? accent
                          : muted(context).withValues(alpha: .3),
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: index > 0
                      ? GlassButton('Back', onPressed: _back)
                      : GlassButton(
                          'Skip',
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: GlassButton(
                    last ? 'Get started' : 'Next',
                    primary: true,
                    onPressed: _next,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Paints a dark scrim with a rounded-rectangle hole punched over [hole].
class _Spotlight extends CustomPainter {
  const _Spotlight(this.hole);
  final Rect? hole;

  @override
  void paint(Canvas canvas, Size size) {
    final full = Offset.zero & size;
    final scrim = Paint()..color = Colors.black.withValues(alpha: .62);
    if (hole == null) {
      canvas.drawRect(full, scrim);
      return;
    }
    final rr = RRect.fromRectAndRadius(hole!, const Radius.circular(18));
    final path = Path.combine(
      PathOperation.difference,
      Path()..addRect(full),
      Path()..addRRect(rr),
    );
    canvas.drawPath(path, scrim);
    // Accent ring around the spotlight.
    canvas.drawRRect(
      rr,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = accent.withValues(alpha: .9),
    );
  }

  @override
  bool shouldRepaint(_Spotlight old) => old.hole != hole;
}
