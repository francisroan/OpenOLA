import 'package:flutter/services.dart';

/// Thin wrapper over [HapticFeedback] that honours the user's Haptics setting.
///
/// [enabled] is mirrored from `Preferences.haptics` so any call site can fire
/// feedback without plumbing the preference through the widget tree. Each
/// method is a no-op when haptics are off, and failures (e.g. a device with no
/// vibrator) are swallowed so callers never need a try/catch.
class AppHaptics {
  AppHaptics._();

  static bool enabled = true;

  static void _run(Future<void> Function() action) {
    if (!enabled) return;
    action().catchError((_) {});
  }

  /// Light tick for navigation / selection changes.
  static void selection() => _run(HapticFeedback.selectionClick);

  /// Small bump for a primary tap or toggle.
  static void light() => _run(HapticFeedback.lightImpact);

  /// Confirmation of a completed action (e.g. slide-to-verify success).
  static void success() => _run(HapticFeedback.mediumImpact);

  /// Stronger feedback for entering a guarded/dangerous mode or an error.
  static void warning() => _run(HapticFeedback.heavyImpact);
}
