import 'dart:convert';
import 'package:flutter/services.dart';
import '../protocol/can.dart';
import 'identifiers.dart';

class Fault {
  const Fault(this.code, this.description, this.status);
  final String code, description;
  final int status;
  Map<String, Object> toJson() => {
    'code': code,
    'description': description,
    'status': status,
  };
}

class Signal {
  Signal(Map<String, dynamic> json)
    : name = json['name'] as String,
      start = json['startbit'] as int,
      bits = json['bitlength'] as int,
      intel =
          (json['endianess'] ?? 'intel').toString().toLowerCase() == 'intel',
      signed = json['signed'] == true,
      factor = (json['scaling'] as num?)?.toDouble() ?? 1,
      offset = (json['offset'] as num?)?.toDouble() ?? 0,
      unit = json['units']?.toString() ?? '';
  final String name, unit;
  final int start, bits;
  final bool intel, signed;
  final double factor, offset;
  double decode(List<int> data) {
    var raw = BigInt.zero;
    if (intel) {
      for (var i = 0; i < data.length; i++) {
        raw |= BigInt.from(data[i]) << (i * 8);
      }
      raw = (raw >> start) & ((BigInt.one << bits) - BigInt.one);
    } else {
      var index = start;
      for (var i = 0; i < bits; i++) {
        final byte = index ~/ 8;
        final value = byte < data.length ? (data[byte] >> (index % 8)) & 1 : 0;
        raw = (raw << 1) | BigInt.from(value);
        index = index % 8 == 0 ? index + 15 : index - 1;
      }
    }
    if (signed && (raw & (BigInt.one << (bits - 1))) != BigInt.zero) {
      raw -= BigInt.one << bits;
    }
    return raw.toDouble() * factor + offset;
  }
}

class ParamField {
  ParamField(Map<String, dynamic> json)
    : name = json['Parameter'].toString().trim(),
      unit = json['Unit']?.toString() ?? '',
      bits = int.tryParse('${json['Size (Bits)']}') ?? 0,
      start = int.tryParse('${json['StartBit']}') ?? 0,
      resolution = double.tryParse('${json['Resolution']}') ?? 1,
      offset = double.tryParse('${json['Offset']}') ?? 0,
      minimum = double.tryParse('${json['Physical Minimum']}'),
      maximum = double.tryParse('${json['Physical Maximum']}');
  final String name, unit;
  final int bits, start;
  final double resolution, offset;
  final double? minimum, maximum;
}

class Parameter {
  Parameter(this.ecu, Map<String, dynamic> json)
    : name = json['Command'].toString(),
      did = int.parse(
        json['RequestFormat'].toString().replaceAll(' ', '').substring(2, 6),
        radix: 16,
      ),
      length = json['AttachedDatalength (Bytes)'] as int? ?? 0,
      fields = (json['Parameters'] as List? ?? [])
          .map((j) => ParamField(j as Map<String, dynamic>))
          .toList();
  final Ecu ecu;
  final String name;
  final int did, length;
  final List<ParamField> fields;
  Map<String, double> decode(List<int> bytes, {bool reversed = false}) {
    final input = reversed ? bytes.reversed.toList() : bytes;
    var raw = BigInt.zero;
    for (var i = 0; i < input.length; i++) {
      raw |= BigInt.from(input[i]) << (8 * i);
    }
    return {
      for (final f in fields)
        f.name:
            ((raw >> f.start) & ((BigInt.one << f.bits) - BigInt.one))
                    .toDouble() *
                f.resolution +
            f.offset,
    };
  }

  List<int> encode(
    List<int> original,
    Map<String, double> edits, {
    bool reversed = false,
  }) {
    if (original.length != length) {
      throw ArgumentError('Expected $length current bytes');
    }
    final base = reversed ? original.reversed.toList() : original;
    var raw = BigInt.zero;
    for (var i = 0; i < base.length; i++) {
      raw |= BigInt.from(base[i]) << (i * 8);
    }
    for (final edit in edits.entries) {
      final f = fields.firstWhere((f) => f.name == edit.key);
      final v = edit.value;
      if (!v.isFinite ||
          f.resolution == 0 ||
          (f.minimum != null && v < f.minimum!) ||
          (f.maximum != null && v > f.maximum!)) {
        throw ArgumentError('${f.name}: outside documented encoding bounds');
      }
      final scaled = (v - f.offset) / f.resolution;
      final value = BigInt.from(scaled.round());
      if ((scaled - scaled.round()).abs() > 1e-6 ||
          value < BigInt.zero ||
          value >= BigInt.one << f.bits) {
        throw ArgumentError('${f.name}: not representable');
      }
      final mask = ((BigInt.one << f.bits) - BigInt.one) << f.start;
      raw = (raw & ~mask) | (value << f.start);
    }
    final out = List.generate(
      length,
      (i) => ((raw >> (i * 8)) & BigInt.from(255)).toInt(),
    );
    return reversed ? out.reversed.toList() : out;
  }
}

class Actuator {
  Actuator(this.label, this.did, this.group, this.danger);
  final String label, group;
  final int did;
  final bool danger;
}

class Catalog {
  final signals = <int, List<Signal>>{};
  final messageNames = <int, String>{};
  final dtcs = <Ecu, Map<String, String>>{};
  final actuators = <Actuator>[];
  final parameters = <Parameter>[];
  final identifiers = <ReadIdentifier>[];
  final bmsConfiguration = <ReadIdentifier>[];
  final notifications = <int, String>{};
  static Future<Catalog> load() async {
    final c = Catalog();
    final vehicle =
        jsonDecode(
              await rootBundle.loadString('assets/data/moveos5_catalog.json'),
            )
            as Map<String, dynamic>;
    for (final e in (vehicle['CommandFromVehicle'] as Map).entries) {
      final code = int.tryParse(e.key.toString());
      if (code != null) c.notifications[code] = e.value.toString();
    }
    final dbc =
        jsonDecode(await rootBundle.loadString('assets/data/da_can_dbc.json'))
            as Map<String, dynamic>;
    for (final j in dbc['messages'] as List) {
      final id = j['id'] as int;
      c.messageNames[id] = j['name'] as String;
      c.signals[id] = (j['signals'] as List? ?? [])
          .map((s) => Signal(s as Map<String, dynamic>))
          .toList();
    }
    final dtc =
        jsonDecode(await rootBundle.loadString('assets/data/dtc_ecu_list.json'))
            as Map<String, dynamic>;
    var text = await rootBundle.loadString('assets/data/odx.json');
    if (text.startsWith('\uFEFF')) text = text.substring(1);
    final odx = jsonDecode(text) as Map<String, dynamic>;
    final seen = <String>{};
    for (final ecu in Ecu.values) {
      c.dtcs[ecu] = {
        for (final row in dtc[ecu.label] as List? ?? [])
          row['DTC Code'].toString().toUpperCase(): row['Description']
              .toString(),
      };
      for (final raw in odx[ecu.label] as List? ?? []) {
        final j = raw as Map<String, dynamic>;
        final request = j['RequestFormat']
            .toString()
            .replaceAll(' ', '')
            .toUpperCase();
        if (request.length < 6) continue;
        if (request.startsWith('22') &&
            request.length == 6 &&
            !c.identifiers.any(
              (r) =>
                  r.ecu == ecu &&
                  r.did == int.parse(request.substring(2), radix: 16),
            )) {
          c.identifiers.add(ReadIdentifier(ecu, j));
        }
        if (request.startsWith('2E')) {
          c.parameters.add(Parameter(ecu, j));
          if (ecu == Ecu.bms &&
              request.length == 6 &&
              request.substring(2).startsWith('E') &&
              !c.bmsConfiguration.any(
                (r) => r.did == int.parse(request.substring(2), radix: 16),
              )) {
            c.bmsConfiguration.add(
              ReadIdentifier(ecu, {
                ...j,
                'RequestFormat': '22${request.substring(2)}',
              }),
            );
          }
        }
        if (ecu != Ecu.vcu || !request.startsWith('2F') || j['ECUTest'] != 1) {
          continue;
        }
        var label = j['Command'].toString();
        if (label.startsWith('IO')) {
          label = label.substring(label.indexOf('_') + 1);
        }
        label = label
            .replaceFirst(
              RegExp(
                r' (12V supply control|supply control|supply|control|Control|12V supply Control)? ?[Cc]ommand$',
              ),
              '',
            )
            .trim();
        if (!seen.add(label)) continue;
        final n = label.toLowerCase();
        bool has(List<String> words) => words.any(n.contains);
        final group = has(['beam', 'indicator', 'light', 'drl', 'lamp', 'horn'])
            ? 'Lights & signals'
            : has([
                'contactor',
                'cpw',
                'control pilot',
                'charger',
                'aux battery',
                'dc-dc',
                'dcdc',
                '3.8v',
                '3v3',
                'level shifter',
              ])
            ? 'Power & HV'
            : has(['lock', 'alarm', 'seat occupant'])
            ? 'Locks & security'
            : has([
                'switch',
                'sensor',
                'stand',
                'pad wear',
                'brake sup',
                'occupant',
                'ssb',
              ])
            ? 'Switches & sensors'
            : 'System & module';
        c.actuators.add(
          Actuator(
            label,
            int.parse(request.substring(2, 6), radix: 16),
            group,
            group == 'Power & HV' ||
                has([
                  'lock',
                  'alarm',
                  'contactor',
                  'fault reset',
                  'power',
                  'boot',
                  'reset',
                  'brake supply',
                  'brake suppy',
                ]),
          ),
        );
      }
    }
    return c;
  }

  List<Fault> parseFaults(Ecu ecu, List<int> payload) {
    final body = payload.skip(3).toList();
    final out = <Fault>[];
    for (var i = 0; i + 4 <= body.length; i += 4) {
      final code = hex(body.sublist(i, i + 3));
      if (code == '000000') continue;
      out.add(
        Fault(
          code,
          dtcs[ecu]?[code] ?? 'Unknown code — absent from catalog',
          body[i + 3],
        ),
      );
    }
    return out;
  }

  Map<String, double> decode(int id, List<int> bytes) => {
    for (final s in signals[id] ?? <Signal>[]) s.name: s.decode(bytes),
  };
}
