import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../design/glass_quality.dart';
import '../design/haptics.dart';

enum Tool {
  status('Vehicle status', 'Monitoring'),
  recorder('Recorder', 'Monitoring'),
  components('Components', 'ECU information'),
  firmware('Firmware', 'ECU information'),
  software('Software', 'ECU information'),
  live('Live signals', 'Monitoring'),
  charging('Charging', 'Monitoring'),
  bluetooth('Bluetooth controls', 'Vehicle controls'),
  features('Vehicle features', 'Vehicle controls'),
  actuators('Actuator tests', 'Service & recovery'),
  recovery('Fault clearing & ECU restart', 'Service & recovery'),
  parameters('Parameters', 'Calibration & engineering'),
  engineering('Engineering tools', 'Calibration & engineering');

  const Tool(this.label, this.group);
  final String label, group;

  /// Developer (advanced / potentially dangerous) windows. These are hidden
  /// until the user explicitly enters Developer Mode (warning + slide-to-verify)
  /// and are then surfaced in the Tools sidebar. Everything else is a basic,
  /// high-level troubleshooting window that is always available.
  bool get dev =>
      this == Tool.bluetooth ||
      this == Tool.features ||
      this == Tool.actuators ||
      this == Tool.recovery ||
      this == Tool.parameters ||
      this == Tool.engineering;

  /// Basic windows are always reachable without Developer Mode.
  bool get basic => !dev;
}

class Preferences extends ChangeNotifier {
  Preferences(this.store) {
    theme = ThemeMode.values.firstWhere(
      (m) => m.name == store.getString('theme'),
      orElse: () => ThemeMode.system,
    );
    reduceMotion = store.getBool('reduceMotion') ?? false;
    developerMode = store.getBool('developerMode') ?? false;
    haptics = store.getBool('haptics') ?? true;
    AppHaptics.enabled = haptics;
    tutorialSeen = store.getBool('tutorialSeen') ?? false;
    quality = GlassQuality(
      auto: store.getBool('glassAuto') ?? true,
      manual: GlassTier.values.firstWhere(
        (t) => t.name == store.getString('glassTier'),
        orElse: () => GlassTier.high,
      ),
    );
    quality.addListener(_saveQuality);
  }
  final SharedPreferences store;
  ThemeMode theme = ThemeMode.system;
  bool reduceMotion = false;
  bool developerMode = false;
  bool haptics = true;
  bool tutorialSeen = false;
  late final GlassQuality quality;

  void _saveQuality() {
    store.setBool('glassAuto', quality.auto);
    store.setString('glassTier', quality.manual.name);
  }

  Future<void> appearance(ThemeMode value) async {
    theme = value;
    notifyListeners();
    await store.setString('theme', value.name);
  }

  Future<void> motion(bool value) async {
    reduceMotion = value;
    notifyListeners();
    await store.setBool('reduceMotion', value);
  }

  Future<void> setHaptics(bool value) async {
    haptics = value;
    AppHaptics.enabled = value;
    notifyListeners();
    await store.setBool('haptics', value);
    if (value) AppHaptics.success(); // noticeable confirmation buzz
  }

  /// Enters or leaves Developer Mode. Entering should only be called after the
  /// warning + slide-to-verify gate in the UI.
  Future<void> setDeveloperMode(bool value) async {
    developerMode = value;
    notifyListeners();
    await store.setBool('developerMode', value);
  }

  /// Marks the first-run tutorial as seen (or resets it when [value] is false).
  Future<void> setTutorialSeen(bool value) async {
    tutorialSeen = value;
    notifyListeners();
    await store.setBool('tutorialSeen', value);
  }

  @override
  void dispose() {
    quality.removeListener(_saveQuality);
    quality.dispose();
    super.dispose();
  }

  /// A window is available when it is basic, or when Developer Mode is active.
  bool has(Tool tool) => tool.basic || developerMode;
}
