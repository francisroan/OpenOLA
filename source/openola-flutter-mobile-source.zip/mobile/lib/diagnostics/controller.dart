import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../data/catalog.dart';
import '../protocol/can.dart';
import '../protocol/uds.dart';
import '../protocol/wifi_can.dart';
import '../diagnostics/preferences.dart';
import '../data/identifiers.dart';
import '../data/vehicle_status.dart';
import 'package:grpc/grpc.dart';
import 'package:protobuf/well_known_types/google/protobuf/empty.pb.dart';
import '../generated/wifican.pbgrpc.dart' as rpc;
import 'battery.dart';
import 'session.dart';

enum Connection { disconnected, connecting, connected, error }

class Reading {
  const Reading(this.value, this.unit, this.receivedAt, this.id);
  final double value;
  final String unit;
  final DateTime receivedAt;
  final int id;
}

class Diagnostics extends ChangeNotifier {
  Diagnostics(this.catalog, this.prefs, {SessionRecorder? recorder})
    : session = recorder ?? SessionRecorder() {
    session.addListener(emit);
  }
  final Catalog catalog;
  final Preferences prefs;
  final SessionRecorder session;
  SessionSummary? openedSession;
  BatterySnapshot? battery;
  final identifierResults = <String, IdentifierResult>{};
  final graph = <SessionSample>[];
  DateTime? _graphStart;
  bool readCancelled = false;
  bool foreground = true;
  int readDone = 0, readTotal = 0;
  String readLabel = '';
  bool get readReady =>
      connected && !busy && (demo || (bench && mode == 'SERVICE'));
  bool get readingIdentifiers => busy && readTotal > 0;
  Connection connection = Connection.disconnected;
  bool demo = false,
      busy = false,
      bench = false,
      live = false,
      recording = false,
      disposed = false;
  String mode = 'Unknown', firmware = 'Unknown', manifest = '', message = '';
  WifiCan? link;
  Uds? uds;
  DateTime? lastFrame;
  final raw = <int, List<int>>{};
  final readings = <String, Reading>{};
  final faults = <Ecu, List<Fault>>{};
  final activity = <String>[];
  final chargeLog = <Map<String, Object?>>[];
  final latched = <int, Actuator>{};
  final unlocked = <Ecu>{}, rejectedKeys = <Ecu>{};
  final watchEvents = <String>[];
  final notifications = <VehicleNotification>[];
  int? _notificationCode;
  final softwareResponses = <String, String>{};
  final broadcast = <String>{};
  Timer? _tick, _keepAlive;
  bool _keepingAlive = false;
  int _generation = 0;
  bool get connected => connection == Connection.connected;
  String get freshness => demo
      ? 'Simulated telemetry'
      : !connected
      ? 'Disconnected'
      : lastFrame == null
      ? 'Waiting for CAN data'
      : DateTime.now().difference(lastFrame!).inSeconds > 10
      ? 'CAN updates paused'
      : 'Receiving CAN data';
  void emit() {
    if (!disposed) notifyListeners();
  }

  void log(String text) {
    activity.add('${DateTime.now().toUtc().toIso8601String()} $text');
    if (activity.length > 2000) activity.removeAt(0);
  }

  static const ids = [
    0x78e,
    0x7b1,
    0x786,
    0x7b0,
    0x7a6,
    0x7b4,
    0x410,
    0x411,
    0x122,
    0x430,
    0x431,
    0x333,
    0x213,
    0x210,
    0x642,
    0x11c,
    0x353,
    0x640,
    0x120,
    0x121,
    0x62d,
    0x313,
    0x130,
    0x143,
    0x180,
    0x190,
    0x6bf,
    0x660,
    0x6d0,
    0x508,
    0x584,
    0x585,
    0x6c0,
  ];
  Future<void> connect(
    String host,
    int port, {
    bool secure = false,
    bool simulated = false,
  }) async {
    if (busy || connection == Connection.connecting) return;
    if (host.trim().isEmpty || port < 1 || port > 65535) {
      throw ArgumentError('Enter a valid host and port');
    }
    final token = ++_generation;
    demo = simulated;
    connection = Connection.connecting;
    message = '';
    emit();
    await prefs.store.setString('host', host.trim());
    await prefs.store.setInt('port', port);
    await prefs.store.setBool('secure', secure);
    WifiCan? candidate;
    try {
      if (simulated) {
        mode = 'SERVICE';
        firmware = 'DEMO-MOCK-5.0.0';
        bench = true;
        _demoReadings();
      } else {
        candidate = WifiCan();
        link = candidate;
        candidate.onFrame = (frame) {
          if (token == _generation) _receive(frame);
        };
        candidate.onStreamError = (error) {
          if (token == _generation) {
            message = 'CAN stream stopped: $error';
            log(message);
            emit();
          }
        };
        await candidate.connect(host.trim(), port, secure);
        await candidate.init(ids);
        await candidate.reader();
        mode = await candidate.mode();
        firmware = await candidate.firmware();
        uds = Uds(candidate);
      }
      if (token != _generation) {
        await candidate?.close();
        return;
      }
      connection = Connection.connected;
      log('Connected ${simulated ? 'DEMO' : '$host:$port'}');
      _tick = Timer.periodic(const Duration(seconds: 1), (_) {
        if (demo) _demoReadings();
        sampleTelemetry();
        if (recording) {
          chargeLog.add({
            'captured_at': DateTime.now().toUtc().toIso8601String(),
            'demo': demo,
            'metrics': metrics,
          });
        }
        if (chargeLog.length >= 3600) {
          recording = false;
          message =
              'Recording reached 3,600 samples. Export before starting another.';
        }
        emit();
      });
    } catch (error) {
      await candidate?.close();
      if (token != _generation) return;
      link = null;
      uds = null;
      connection = Connection.error;
      message = 'Connection failed: $error';
      log(message);
    }
    emit();
  }

  void _receive(CanPacket frame) {
    final now = DateTime.now();
    lastFrame = now;
    raw[frame.id] = frame.data;
    if (frame.id == 0x6d0) observeNotification(frame.data);
    for (final signal in catalog.signals[frame.id] ?? <Signal>[]) {
      readings['${frame.id}:${signal.name}'] = Reading(
        signal.decode(frame.data),
        signal.unit,
        now,
        frame.id,
      );
      final isFault =
          signal.bits == 1 &&
          RegExp(
            'fault|error|fail|warn|protect|abnormal|overcurrent|overvolt|undervolt|overtemp|short|disconnect|timeout|corrupt|stall|deviation',
            caseSensitive: false,
          ).hasMatch(signal.name) &&
          !RegExp(
            'demand|status_signal|counter|calibration|balancing|indicator_ttl',
            caseSensitive: false,
          ).hasMatch(signal.name);
      if (isFault) {
        final name = '0x${frame.id.toRadixString(16)} / ${signal.name}';
        final active = signal.decode(frame.data).toInt() == 1;
        if (active != broadcast.contains(name)) {
          active ? broadcast.add(name) : broadcast.remove(name);
          watchEvents.insert(
            0,
            '${now.toIso8601String()} ${active ? 'SET' : 'CLEAR'} $name',
          );
          if (watchEvents.length > 300) watchEvents.removeLast();
        }
      }
    }
  }

  void _demoReadings() {
    final now = DateTime.now();
    final values = {
      'Display_SoC': 82.5,
      'Bus_Voltage_00_10ms': 52.4,
      'Overall_Battery_Current': 4.4,
      'Vehicle_speed_in_kmph': 0.0,
    };
    for (final entry in values.entries) {
      readings['demo:${entry.key}'] = Reading(entry.value, '', now, 0);
    }
  }

  void observeNotification(List<int> data) {
    if (data.isEmpty) return;
    final code = data[0];
    if (code == _notificationCode) return;
    _notificationCode = code;
    if (code == 0) return;
    notifications.insert(
      0,
      VehicleNotification(
        code,
        catalog.notifications[code] ?? 'Unknown notification $code',
        DateTime.now(),
      ),
    );
    if (notifications.length > 200) notifications.removeLast();
  }

  void clearNotifications() {
    notifications.clear();
    emit();
  }

  Future<void> readSoftware(String kind) => operation('Read $kind', () async {
    final token = _generation;
    String result;
    if (demo) {
      result = 'Demo · simulated $kind response. Firmware DEMO-MOCK-5.0.0';
    } else if (kind == 'Identifiers') {
      result = await link!.identifiers();
    } else if (kind == 'Update status') {
      result = const JsonEncoder.withIndent('  ').convert(
        (await link!.client.swUpdateCheckStatus(
          Empty(),
          options: CallOptions(timeout: const Duration(seconds: 10)),
        )).toProto3Json(),
      );
    } else {
      final reply = kind == 'Android version'
          ? await link!.client.getAospVersion(
              Empty(),
              options: CallOptions(timeout: const Duration(seconds: 10)),
            )
          : await link!.client.getSwVersion(
              Empty(),
              options: CallOptions(timeout: const Duration(seconds: 10)),
            );
      if (reply.status != rpc.RespStatus.RESP_SUCCESS) {
        throw StateError(reply.statusMsg);
      }
      result = reply.statusMsg;
    }
    if (token == _generation && connected) {
      softwareResponses[kind] = result;
      message = '$kind received';
    }
  });
  double? signal(List<String> names, {List<int>? ids}) {
    for (final name in names) {
      for (final entry in readings.entries) {
        if ((ids == null || demo || ids.contains(entry.value.id)) &&
            entry.key.split(':').last.toLowerCase() == name.toLowerCase()) {
          return entry.value.value;
        }
      }
    }
    return null;
  }

  double? _bounded(double? value, double min, double max) =>
      value != null && value.isFinite && value >= min && value <= max
      ? value
      : null;
  double? _temp(int index) {
    if (demo) return index == 2 ? 36 : 32;
    final data = raw[0x313];
    return data == null
        ? null
        : _bounded((data[index] | data[index + 1] << 8) * .01, -40, 200);
  }

  Map<String, double?> get metrics => {
    'State of charge (%)': _bounded(
      signal(
        ['Display_SoC', 'Pack_SOC_00', 'Overall_SOC'],
        ids: [0x353, 0x11c, 0x120],
      ),
      0,
      100,
    ),
    'Reported range (km)': _bounded(
      signal(['Vehicle_Range'], ids: [0x353]),
      0,
      400,
    ),
    'Pack voltage (V)': _bounded(
      signal(
        ['Bus_Voltage_00_10ms', 'Battery_voltage_OCV_00'],
        ids: [0x640, 0x11c],
      ),
      0,
      200,
    ),
    'Pack current (A)': signal(['Overall_Battery_Current'], ids: [0x120]),
    'Battery temperature (°C)': battery?.healthValue('effective temp'),
    'Motor temperature (°C)': _temp(4),
    'Controller temperature (°C)': _temp(2),
    'Vehicle speed (km/h)': _bounded(
      signal(
        ['Vehicle_speed_in_kmph', 'Vehicle_Speed', 'Motor_Speed'],
        ids: [0x313],
      ),
      0,
      200,
    ),
  };
  Map<String, double> get telemetryValues {
    final now = DateTime.now();
    final values = <String, double>{};
    for (final entry in readings.entries) {
      if (!demo && now.difference(entry.value.receivedAt).inSeconds >= 3) {
        continue;
      }
      values.putIfAbsent(entry.key.split(':').last, () => entry.value.value);
    }
    if (!connected) return {};
    double? freshSignal(List<String> names, List<int> ids) {
      for (final name in names) {
        for (final e in readings.entries) {
          if ((demo || ids.contains(e.value.id)) &&
              e.key.split(':').last == name &&
              (demo || now.difference(e.value.receivedAt).inSeconds < 3)) {
            return e.value.value;
          }
        }
      }
      return null;
    }

    final fresh = <String, double?>{
      'batt_soc': freshSignal(
        ['Display_SoC', 'Pack_SOC_00', 'Overall_SOC'],
        [0x353, 0x11c, 0x120],
      ),
      'batt_range_km': freshSignal(['Vehicle_Range'], [0x353]),
      'batt_volts': freshSignal(
        ['Bus_Voltage_00_10ms', 'Battery_voltage_OCV_00'],
        [0x640, 0x11c],
      ),
      'batt_amps': freshSignal(['Overall_Battery_Current'], [0x120]),
      'batt_speed': freshSignal(
        ['Vehicle_speed_in_kmph', 'Vehicle_Speed', 'Motor_Speed'],
        [0x313],
      ),
    };
    if (demo ||
        readings.values.any(
          (r) => r.id == 0x313 && now.difference(r.receivedAt).inSeconds < 3,
        )) {
      fresh['batt_motor_t'] = _temp(4);
      fresh['batt_mcu_t'] = _temp(2);
    }
    for (final e in fresh.entries) {
      if (e.value != null && e.value!.isFinite) values[e.key] = e.value!;
    }
    if (fresh['batt_volts'] != null && fresh['batt_amps'] != null) {
      values['power_w'] = fresh['batt_volts']! * fresh['batt_amps']!;
    }
    return values;
  }

  void sampleTelemetry({DateTime? now}) {
    if (!foreground) return;
    final values = telemetryValues;
    if (values.isEmpty) return;
    now ??= DateTime.now();
    _graphStart ??= now;
    graph.add(
      SessionSample(
        now.difference(_graphStart!).inMilliseconds / 1000,
        Map.unmodifiable(values),
      ),
    );
    if (graph.length > 600) graph.removeAt(0);
    session.sample(values, now: now);
  }

  void clearGraph() {
    graph.clear();
    _graphStart = null;
    emit();
  }

  Future<void> startSession() async {
    if (busy || !connected || session.active || session.closing) return;
    if (!live) await liveMode(true);
    if (!live || !connected) return;
    await operation('Start session recording', () async {
      final token = _generation;
      await session.start({
        'demo': demo,
        'firmware': firmware,
        'platform': 'OpenOLA mobile',
        'foreground_only': true,
        'units': {
          'batt_soc': '%',
          'batt_range_km': 'km',
          'batt_volts': 'V',
          'batt_amps': 'A',
          'batt_speed': 'km/h',
          'batt_motor_t': '°C',
          'batt_mcu_t': '°C',
          'power_w': 'W',
          for (final e in readings.entries) e.key.split(':').last: e.value.unit,
        },
      });
      message = 'Recording all fresh signals. Keep OpenOLA in the foreground.';
      if (token != _generation || !connected || !foreground) {
        await session.stop();
        return;
      }
    });
  }

  Future<void> stopSession({String? reason}) async {
    await session.stop();
    message =
        session.error ??
        reason ??
        'Recording saved · ${session.samples} samples';
    emit();
  }

  void cancelRead() {
    readCancelled = true;
    emit();
  }

  /// A test seam for read-only UDS, deliberately without security unlock/session change.
  Future<List<int>> readIdentifierBytes(ReadIdentifier definition) async => demo
      ? _demoIdentifier(definition)
      : await uds!.read(definition.ecu, definition.did);
  Future<void> identifierStream(bool monitor) async {
    if (demo) return;
    await link!.init(ids);
    await link!.reader(dump: monitor);
  }

  Future<List<IdentifierResult>> readIdentifiers(
    List<ReadIdentifier> definitions,
  ) async {
    final result = <IdentifierResult>[];
    final token = _generation;
    await operation('Read ECU data', () async {
      final resume = live;
      readDone = 0;
      readTotal = definitions.length;
      readCancelled = false;
      try {
        if (!demo) {
          live = false;
          await identifierStream(false);
        }
        for (final definition in definitions) {
          if (readCancelled || !connected || token != _generation) break;
          readLabel = '${definition.ecu.label} · ${definition.title}';
          emit();
          IdentifierResult row;
          try {
            final bytes = await readIdentifierBytes(definition);
            row = IdentifierResult(definition, bytes: bytes);
          } catch (e) {
            row = IdentifierResult(definition, error: e.toString());
          }
          if (!connected || token != _generation) break;
          result.add(row);
          identifierResults[definition.key] = row;
          readDone++;
          emit();
        }
        message =
            '${readCancelled ? 'Read cancelled' : 'Read complete'} · ${result.length}/${definitions.length} identifiers${demo ? ' · simulated' : ''}';
      } finally {
        readTotal = 0;
        readLabel = '';
        if (resume && connected && token == _generation) {
          if (demo) {
            live = true;
          } else {
            try {
              await identifierStream(true);
              live = true;
            } catch (e) {
              live = false;
              message = '$message · Live monitor could not resume: $e';
            }
          }
        }
      }
    }, service: true);
    return result;
  }

  List<int> _demoIdentifier(ReadIdentifier d) {
    final length = d.fields.fold(0, (int end, f) {
      final n =
          (int.tryParse('${f['StartBit']}') ?? 0) +
          (int.tryParse('${f['Size (Bits)']}') ?? 0);
      return n > end ? n : end;
    });
    final data = List<int>.filled((length + 7) ~/ 8, 0);
    for (var i = 0; i < d.fields.length; i++) {
      final f = d.fields[i];
      final bits = int.tryParse('${f['Size (Bits)']}') ?? 0,
          start = int.tryParse('${f['StartBit']}') ?? 0;
      if (bits <= 0) continue;
      if ('${f['Encoding']}'.toLowerCase() == 'ascii') {
        final text = 'DEMO ${d.ecu.label}';
        for (var j = 0; j < bits ~/ 8; j++) {
          data[start ~/ 8 + j] = j < text.length ? text.codeUnitAt(j) : 0;
        }
        continue;
      }
      final name = '${f['Parameter']}'.toLowerCase();
      final physical = switch (d.did) {
        0xe100 =>
          name == 'pack voltage' || name == 'bus voltage'
              ? 54724.0
              : name.contains('temperature')
              ? 33.0
              : name.contains('minimum')
              ? 3858.0
              : name.contains('maximum')
              ? 3916.0
              : name.contains('current')
              ? 4.4
              : 0.0,
        0xe103 => name.contains('soc') ? 82.5 : 96.0,
        0xe106 => i == 8 ? 3.858 : 3.90 + (i % 5) * .004,
        0xe109 => i == 8 ? 3.1 : 1.8 + (i % 3) * .1,
        0xe108 => 3.2,
        0xe107 => 31.0 + i,
        0xe102 => 1.2,
        0xe434 => 57.6,
        _ =>
          name.contains('soh')
              ? 96.0
              : name.contains('cycle')
              ? 148.0
              : name.contains('temp')
              ? 33.0
              : 0.0,
      };
      final resolution = double.tryParse('${f['Resolution']}') ?? 1,
          offset = double.tryParse('${f['Offset']}') ?? 0;
      if (resolution == 0) continue;
      final value = BigInt.from(((physical - offset) / resolution).round());
      for (var bit = 0; bit < bits; bit++) {
        if ((value & (BigInt.one << bit)) != BigInt.zero) {
          data[(start + bit) ~/ 8] |= 1 << ((start + bit) % 8);
        }
      }
    }
    return data;
  }

  Future<void> readBattery() async {
    if (!readReady) return;
    final token = _generation;
    final rows = await readIdentifiers(
      catalog.identifiers
          .where(
            (r) =>
                r.ecu == Ecu.bms &&
                [
                  0xe100,
                  0xe101,
                  0xe102,
                  0xe103,
                  0xe434,
                  0xe106,
                  0xe107,
                  0xe108,
                  0xe109,
                ].contains(r.did),
          )
          .toList(),
    );
    if (rows.isNotEmpty && connected && token == _generation) {
      battery = BatterySnapshot.fromResults(rows, demo: demo);
      emit();
    }
  }

  Future<void> operation(
    String name,
    Future<void> Function() work, {
    bool service = false,
  }) async {
    if (busy) return;
    if (!connected) {
      message = 'Connect to a scooter first.';
      emit();
      return;
    }
    if (service && !demo && (!bench || mode != 'SERVICE')) {
      message =
          'Confirm parked, charger disconnected and enter Service mode first.';
      emit();
      return;
    }
    busy = true;
    message = '';
    emit();
    log(name);
    try {
      await work();
    } catch (error) {
      message = '$name: $error';
      log(message);
    } finally {
      busy = false;
      emit();
    }
  }

  Future<void> serviceMode(bool value) =>
      operation(value ? 'Enter Service mode' : 'Return to Customer', () async {
        if (!demo) await link!.setMode(value);
        mode = value ? 'SERVICE' : 'CUST';
        bench = value;
        unlocked.clear();
        _keepAlive?.cancel();
        message = value
            ? 'Service mode acknowledged'
            : 'Customer mode acknowledged';
      });
  Future<void> _unlock(Ecu ecu) async {
    if (demo) return;
    if (link!.streamMode != 'diag') {
      live = false;
      await link!.init(ids);
      await link!.reader();
    }
    if (rejectedKeys.contains(ecu)) {
      throw StateError(
        'Key rejected on this connection. Reconnect after checking ECU lockout.',
      );
    }
    if (!unlocked.contains(ecu)) {
      try {
        await uds!.unlock(ecu);
      } catch (error) {
        if (RegExp('0x35|0x36|0x37').hasMatch(error.toString())) {
          rejectedKeys.add(ecu);
        }
        rethrow;
      }
      unlocked.add(ecu);
    }
    _keepAlive?.cancel();
    _keepAlive = Timer.periodic(const Duration(seconds: 2), (_) async {
      if (busy || _keepingAlive || disposed || !connected) return;
      _keepingAlive = true;
      try {
        await uds!.testerPresent(ecu);
      } catch (error) {
        log('Tester present: $error');
      } finally {
        _keepingAlive = false;
      }
    });
  }

  Future<void> scan({Ecu? ecu}) => operation('Read stored faults', () async {
    for (final target in ecu == null ? Ecu.values : [ecu]) {
      if (demo) {
        faults[target] = target == Ecu.bms
            ? [const Fault('P0A80', 'Demo: battery pack fault example', 9)]
            : [];
      } else {
        await _unlock(target);
        faults[target] = catalog.parseFaults(target, await uds!.dtcs(target));
      }
    }
    message = 'Fault scan complete${demo ? ' · simulated' : ''}';
  }, service: true);
  Future<void> faultAction(Ecu ecu, bool reset) => operation(
    reset ? 'Restart ${ecu.label}' : 'Clear ${ecu.label} history',
    () async {
      if (!demo) {
        await _unlock(ecu);
        reset ? await uds!.reset(ecu) : await uds!.clear(ecu);
      }
      if (reset) {
        unlocked.remove(ecu);
      } else {
        faults.remove(ecu);
      }
      message =
          '${demo ? 'Demo: ' : ''}${reset ? 'Restart' : 'Clear'} acknowledged. Deep-sleep wake is unvalidated.';
    },
    service: true,
  );
  Future<void> recover() => operation('Existing fault recovery', () async {
    // Finish every read before issuing a destructive command. A failed read is
    // not evidence of an empty fault list.
    for (final ecu in Ecu.values) {
      if (demo) {
        faults[ecu] = ecu == Ecu.bms
            ? [const Fault('P0A80', 'Demo fault', 9)]
            : [];
      } else {
        await _unlock(ecu);
        faults[ecu] = catalog.parseFaults(ecu, await uds!.dtcs(ecu));
      }
    }
    var targets = Ecu.values.where((e) => faults[e]!.isNotEmpty).toList();
    if (targets.isEmpty) targets = [Ecu.vcu];
    for (final ecu in targets) {
      if (!demo) {
        await _unlock(ecu);
        await uds!.clear(ecu);
        faults.remove(ecu);
        await uds!.reset(ecu);
      } else {
        faults.remove(ecu);
      }
      unlocked.remove(ecu);
    }
    _keepAlive?.cancel();
    unlocked.clear();
    if (!demo) await link!.setMode(false);
    mode = 'CUST';
    bench = false;
    message =
        '${demo ? 'Demo: ' : ''}Recovery commands acknowledged. Rescan after reconnecting; deep-sleep wake is unvalidated.';
  }, service: true);

  Future<void> restartHeadUnit() => operation('Restart head unit', () async {
    String result;
    try {
      if (!demo) await link!.restartHeadUnit();
      result =
          '${demo ? 'Demo: ' : ''}Restart acknowledged. Wait for the head unit, then reconnect manually.';
    } catch (error) {
      result =
          'Restart outcome unknown: $error. Check the head unit before reconnecting; no retry.';
    }
    await disconnect();
    message = result;
    log(result);
  }, service: true);

  Future<void> liveMode(bool value) =>
      operation(value ? 'Start live signals' : 'Stop live signals', () async {
        if (!demo) {
          await link!.init(ids);
          await link!.reader(dump: value);
        }
        live = value;
        message = value
            ? 'Live CAN stream started'
            : 'Filtered diagnostic stream restored';
      });
  Future<void> actuator(Actuator a, {bool? latch}) =>
      operation(a.label, () async {
        if (!demo) {
          await _unlock(Ecu.vcu);
          if (latch != null) {
            await uds!.io(a.did, latch);
            if (!latch) await uds!.io(a.did, false, release: true);
          } else {
            try {
              await uds!.io(a.did, true);
              await Future<void>.delayed(
                Duration(
                  milliseconds: a.label.toLowerCase() == 'horn' ? 750 : 2000,
                ),
              );
            } finally {
              await uds!.io(a.did, false);
              await uds!.io(a.did, false, release: true);
            }
          }
        }
        if (latch != null) {
          latch ? latched[a.did] = a : latched.remove(a.did);
        }
        message =
            '${demo ? 'Demo: ' : ''}${a.label}: ${latch == null
                ? 'pulse'
                : latch
                ? 'ON'
                : 'OFF'} acknowledged';
      }, service: true);
  Future<List<int>?> readParameter(Parameter p) async {
    List<int>? result;
    await operation('Read ${p.name}', () async {
      if (!demo) await _unlock(p.ecu);
      result = demo ? List.filled(p.length, 0) : await uds!.read(p.ecu, p.did);
      message = 'Read ${p.name}';
    }, service: true);
    return result;
  }

  Future<void> writeParameter(
    Parameter p,
    Map<String, double> edits, {
    bool reversed = false,
  }) => operation('Write ${p.name}', () async {
    if (!demo) await _unlock(p.ecu);
    final current = demo
        ? List.filled(p.length, 0)
        : await uds!.read(p.ecu, p.did);
    final proposed = p.encode(current, edits, reversed: reversed);
    if (!demo) {
      await uds!.writeDid(p.ecu, p.did, proposed);
      final after = await uds!.read(p.ecu, p.did);
      if (!listEquals(after, proposed)) {
        throw StateError('Readback differs; no automatic retry');
      }
    }
    message =
        '${demo ? 'Demo: ' : ''}Write acknowledged and readback matches. Reboot persistence unverified.';
  }, service: true);
  Future<void> hmi(int ordinal, String label) => operation(label, () async {
    if (!demo) {
      await link!.write(0x6bc, [ordinal, 0, 0, 0, 0, 0, 0, 0]);
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    message = demo
        ? 'Demo: $label'
        : raw[0x6c0]?[0] == ordinal
        ? '$label: echo seen; physical completion unverified'
        : '$label: sent, no echo within 400 ms. Outcome unknown; no retry.';
  }, service: true);
  Future<void> loadInfo() => operation('Read identifiers', () async {
    manifest = demo
        ? jsonEncode({'demo': true, 'firmware': firmware})
        : await link!.identifiers();
    message = 'Identifiers received';
  });
  Future<void> test(int command, String label, bool start) =>
      operation(label, () async {
        message = demo
            ? 'Demo: $label ${start ? 'start' : 'stop'}'
            : await link!.remoteTest(command, start);
      }, service: true);
  bool toolActive(Tool tool) =>
      tool == Tool.live && live ||
      tool == Tool.charging && recording ||
      tool == Tool.actuators && latched.isNotEmpty;
  Future<void> disconnect() async {
    ++_generation;
    _tick?.cancel();
    _keepAlive?.cancel();
    readCancelled = true;
    await session.stop();
    final old = link;
    link = null;
    if (!demo && old != null && latched.isNotEmpty) {
      try {
        final u = Uds(old);
        for (final a in latched.values) {
          await u.io(a.did, false);
          await u.io(a.did, false, release: true);
        }
      } catch (error) {
        log('Release failed: $error');
        message =
            'Some latched controls could not be released. Check the scooter.';
      }
    }
    await old?.close();
    uds = null;
    unlocked.clear();
    rejectedKeys.clear();
    latched.clear();
    connection = Connection.disconnected;
    busy = false;
    demo = false;
    bench = false;
    mode = 'Unknown';
    live = false;
    recording = false;
    raw.clear();
    readings.clear();
    faults.clear();
    notifications.clear();
    _notificationCode = null;
    softwareResponses.clear();
    identifierResults.clear();
    battery = null;
    clearGraph();
    broadcast.clear();
    lastFrame = null;
    emit();
  }

  @override
  void dispose() {
    disposed = true;
    _tick?.cancel();
    _keepAlive?.cancel();
    session.removeListener(emit);
    unawaited(session.stop());
    session.dispose();
    unawaited(link?.close() ?? Future<void>.value());
    super.dispose();
  }
}
