import 'dart:async';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import '../data/catalog.dart';
import '../protocol/can.dart';
import '../protocol/uds.dart';
import '../protocol/wifi_can.dart';
import '../diagnostics/preferences.dart';
import '../data/identifiers.dart';
import '../data/vehicle_status.dart';
import '../data/vehicle_profile.dart';
import 'package:grpc/grpc.dart';
import 'package:protobuf/well_known_types/google/protobuf/empty.pb.dart';
import '../generated/wifican.pbgrpc.dart' as rpc;
import 'battery.dart';
import 'battery_history.dart';
import 'session.dart';

enum Connection { disconnected, connecting, connected, error }

class Reading {
  const Reading(this.value, this.unit, this.receivedAt, this.id);
  final double value;
  final String unit;
  final DateTime receivedAt;
  final int id;
}

class Diagnostics extends ChangeNotifier {
  Diagnostics(this.catalog, this.prefs, {SessionRecorder? recorder})
    : session = recorder ?? SessionRecorder() {
    session.addListener(emit);
    history.load();
  }
  final Catalog catalog;
  final Preferences prefs;
  final SessionRecorder session;
  final BatteryHistory history = BatteryHistory();
  SessionSummary? openedSession;
  BatterySnapshot? battery;
  final identifierResults = <String, IdentifierResult>{};
  final graph = <SessionSample>[];
  DateTime? _graphStart;
  bool readCancelled = false;
  bool foreground = true;
  int readDone = 0, readTotal = 0;
  String readLabel = '';
  // Reading ECU/BMS identifiers is non-destructive (UDS 0x22 DID reads, no
  // security access, no writes), so it is gated only on a live connection in
  // SERVICE mode — NOT on the narrow `legacy` profile fingerprint. Destructive
  // actuator/flash/reset paths keep their legacyMethods + typed-CONFIRM gates.
  bool get readReady =>
      connected && !busy && (demo || (bench && mode == 'SERVICE'));
  bool get readingIdentifiers => busy && readTotal > 0;
  Connection connection = Connection.disconnected;
  bool demo = false,
      busy = false,
      bench = false,
      live = false,
      recording = false,
      disposed = false;
  String mode = 'Unknown', firmware = 'Unknown', manifest = '', message = '';
  String certStatus = '';
  WifiCan? link;
  Uds? uds;
  DateTime? lastFrame;
  final frameTimes = <int, DateTime>{};
  VehicleProfile _decodedProfile = VehicleProfile.common;
  String aospVersion = '';
  VehicleIdentity get identity =>
      VehicleIdentity.detect(raw, firmware, aosp: aospVersion);
  Iterable<FaultFrame> get activeFaultFrames =>
      catalog.faultsFor(identity.profile);
  bool frameFresh(int id, {DateTime? now}) {
    final time = frameTimes[id];
    return connected &&
        time != null &&
        (now ?? DateTime.now()).difference(time) < const Duration(seconds: 10);
  }

  /// The five IDs the telematics unit keeps alive while the vehicle sleeps —
  /// GPS/LTE/Wi-Fi state, no battery or motor data. (Adopted from ola-s1-rea.)
  static const sleepTrickleIds = {0x6d2, 0x643, 0x6db, 0x66d, 0x65d};

  /// True when frames are arriving but only the telematics sleep trickle — the
  /// scooter is asleep. The UI tells the user to press start or plug in, instead
  /// of showing a blank or stale battery card as if it were live data.
  bool get vehicleAsleep {
    if (!connected || demo) return false;
    final now = DateTime.now();
    var trickleFresh = false, vehicleFresh = false;
    for (final e in frameTimes.entries) {
      if (now.difference(e.value) >= const Duration(seconds: 6)) continue;
      if (sleepTrickleIds.contains(e.key)) {
        trickleFresh = true;
      } else {
        vehicleFresh = true;
      }
    }
    return trickleFresh && !vehicleFresh;
  }

  bool get legacyMethodsAvailable =>
      demo ||
      (identity.legacyMethods && frameFresh(0x211) && frameFresh(0x610));
  void requireLegacyMethod(String method) {
    if (!legacyMethodsAvailable) {
      throw StateError(
        '$method is unavailable for ${identity.model}: no matching legacy method or fresh identity. Passive diagnostics remain available.',
      );
    }
  }

  double? profileValue(int id, String name) {
    if (!frameFresh(id)) return null;
    for (final s in catalog.signalsFor(identity.profile, id)) {
      if (s.name == name) return s.decode(raw[id]!);
    }
    return null;
  }

  Map<String, int?> get receivedFeatures {
    if (identity.profile == VehicleProfile.moveos561) {
      return {
        for (final s in catalog.signalsFor(identity.profile, 0x664))
          s.name.replaceAll('_', ' '): frameFresh(0x664)
              ? s.decode(raw[0x664]!).toInt()
              : null,
      };
    }
    if (identity.profile == VehicleProfile.legacy) {
      return featureStatus(frameFresh(0x660) ? raw[0x660] : null);
    }
    return const {};
  }

  /// Read-only, freshness-aware snapshot; does not infer fitted hardware from a model name.
  Map<String, Object?> get modelDiagnostics => {
    'identity': identity.toJson(),
    'signals': {
      for (final id in modelDiagnosticIds)
        if (raw[id] != null)
          '0x${id.toRadixString(16)}': {
            'fresh': frameFresh(id),
            'received_at': frameTimes[id]?.toUtc().toIso8601String(),
            'raw': hex(raw[id]!),
            'values': {
              for (final s in catalog.signalsFor(identity.profile, id))
                s.name: frameFresh(id) ? s.decode(raw[id]!) : null,
            },
          },
    },
  };
  static const modelDiagnosticIds = [
    0x270,
    0x271,
    0x272,
    0x273,
    0x305,
    0x321,
    0x322,
    0x6df,
    0x6dd,
    0x6e8,
    0x68a,
    0x68b,
    0x664,
    0x417,
    0x419,
  ];
  void refreshVehicleProfile() {
    final selected = identity.profile;
    if (selected == _decodedProfile) return;
    _decodedProfile = selected;
    readings.clear();
    clearGraph();
    broadcast.clear();
    faults.clear();
    identifierResults.clear();
    battery = null;
    unlocked.clear();
    _keepAlive?.cancel();
    log('Diagnostic profile: ${identity.profileLabel} — ${identity.reason}');
    for (final entry in raw.entries) {
      final time = frameTimes[entry.key];
      if (time != null) _decodeFrame(CanPacket(entry.key, entry.value), time);
    }
  }

  final raw = <int, List<int>>{};
  final readings = <String, Reading>{};
  final faults = <Ecu, List<Fault>>{};
  final activity = <String>[];
  final chargeLog = <Map<String, Object?>>[];
  final latched = <int, Actuator>{};
  final unlocked = <Ecu>{}, rejectedKeys = <Ecu>{};
  final watchEvents = <String>[];
  final notifications = <VehicleNotification>[];
  int? _notificationCode;
  final softwareResponses = <String, String>{};
  final broadcast = <String>{};
  Timer? _tick, _keepAlive;
  bool _keepingAlive = false;
  int _generation = 0;
  bool get connected => connection == Connection.connected;
  String get freshness => demo
      ? 'Simulated telemetry'
      : !connected
      ? 'Disconnected'
      : lastFrame == null
      ? 'Waiting for CAN data'
      : DateTime.now().difference(lastFrame!).inSeconds > 10
      ? 'CAN updates paused'
      : 'Receiving CAN data';
  void emit() {
    if (!disposed) notifyListeners();
  }

  void log(String text) {
    activity.add('${DateTime.now().toUtc().toIso8601String()} $text');
    if (activity.length > 2000) activity.removeAt(0);
  }

  static const ids = [
    ...modelDiagnosticIds,
    0x78e,
    0x7b1,
    0x786,
    0x7b0,
    0x7a6,
    0x7b4,
    0x410,
    0x411,
    0x122,
    0x430,
    0x431,
    0x333,
    0x213,
    0x210,
    0x642,
    0x11c,
    0x353,
    0x640,
    0x120,
    0x121,
    0x62d,
    0x313,
    0x130,
    0x143,
    0x180,
    0x190,
    0x6bf,
    0x660,
    0x6d0,
    0x508,
    0x584,
    0x585,
    0x6c0,
    0x334, // MCU fault data 2
    0x66e, // VCU faults
    0x352, // Display_Info_4: Display_SoC + SOH_Disp (SoC moved here from 0x353)
    0x6d8, // BMS balancing temperature (broadcast)
    0x211, // Vehicle_Config_Data_1: Vehicle_Variant
    0x610, // Vehicle_Hardware_Variant (BCM/BMS/MCU/Charger/Motor gen)
    0x678, // SOM_Hardware variant
    0x1ab, 0x1ac, 0x1ad, 0x1ae, // per-cell DCIR (14 cells, uohm)
    0x1a5, 0x1a6, 0x1a9, 0x1aa, // per-cell voltages (14S) — broadcast on CAN
    0x1a4, 0x1a7, 0x1a8, // extra battery frames (cell balancing temp, per olamate)
    0x150, // BMS00_Parameter_3: Pack_SoH, Bus_Voltage_00, Available_Capacity_00
    0x160, // BMS00_Parameter_4: Effective_Battery_Temperature_00
    0x170, // BMS0_Cell_Status: min/max cell voltage + per-cell balancing
    0x643, 0x6db, 0x66d, 0x65d, // telematics sleep-trickle (asleep detection)
    0x113, // Vehicle_Discharge_Mode (drive mode) + Throttle_Value1
    0x224, // DC_Current_MCU + Motor_Frequency
    0x225, // Regen_torque_perc
    0x683, // Safety state: fall / tow-theft / regen availability / hill-hold
  ];

  int? _byte(int id, int index) {
    final d = raw[id];
    return d != null && index < d.length ? d[index] : null;
  }

  /// Vehicle variant code (0x211 byte 0). Raw; see FIRMWARE_RULES for names.
  int? get vehicleVariant => _byte(0x211, 0);

  /// Per-ECU hardware-variant codes (0x610 / 0x678). Used to match firmware.
  Map<String, int?> get hardwareVariants => {
    'BCM': _byte(0x610, 0),
    'BMS': _byte(0x610, 1),
    'BMS DipSwitch': _byte(0x610, 2),
    'MCU': _byte(0x610, 3),
    'Charger': _byte(0x610, 4),
    'Motor': _byte(0x610, 5),
    'SOM': _byte(0x678, 0),
    'Display': _byte(0x678, 1),
  };

  /// Per-cell DC internal resistance in mΩ (CAN 0x1AB–0x1AE, 14 cells, uohm).
  List<double?> get cellDcir {
    final out = <double?>[];
    for (final (id, count) in const [
      (0x1ab, 4),
      (0x1ac, 4),
      (0x1ad, 4),
      (0x1ae, 2),
    ]) {
      final d = raw[id];
      for (var i = 0; i < count; i++) {
        final lo = d == null || i * 2 + 1 >= d.length ? null : d[i * 2];
        final hi = d == null || i * 2 + 1 >= d.length ? null : d[i * 2 + 1];
        out.add(lo == null ? null : (lo | hi! << 8) / 1000.0); // uohm -> mOhm
      }
    }
    return out;
  }

  /// Per-cell voltages (V) from CAN 0x1A5/0x1A6/0x1A9/0x1AA (14S pack, 16-bit
  /// little-endian, 0.001 V). Confirmed identical across two independent
  /// working community tools (ola-s1-rea, olamate) and our own DBC. These are
  /// broadcast passively — no UDS read, security access or Service mode needed.
  List<double?> get cellVoltages {
    final out = <double?>[];
    for (final (id, count) in const [
      (0x1a5, 4), // cells 1-4
      (0x1a6, 4), // cells 5-8
      (0x1a9, 4), // cells 9-12
      (0x1aa, 2), // cells 13-14
    ]) {
      final d = frameFresh(id) ? raw[id] : null;
      for (var i = 0; i < count; i++) {
        final lo = d == null || i * 2 + 1 >= d.length ? null : d[i * 2];
        final hi = d == null || i * 2 + 1 >= d.length ? null : d[i * 2 + 1];
        out.add(lo == null ? null : (lo | hi! << 8) / 1000.0); // mV -> V
      }
    }
    return out;
  }

  /// Passive battery snapshot assembled from the live CAN stream — the approach
  /// the known-working community tools use. SoH, per-cell voltages, cycle count
  /// and pack temperature are all broadcast on CAN, so this populates without
  /// the UDS deep read (which stays as an optional enhancement). Returns null
  /// until at least one battery frame has been seen.
  BatterySnapshot? get canBattery {
    final volts = cellVoltages, dcir = cellDcir;
    final cells = <BatteryCell>[];
    for (var i = 0; i < volts.length; i++) {
      final v = volts[i];
      if (v == null || v <= 0) continue;
      cells.add(BatteryCell(i + 1, v, ir: i < dcir.length ? dcir[i] : null));
    }
    final health = <DecodedValue>[];
    void add(String name, double? value, String unit) {
      if (value != null) health.add(DecodedValue(name, value, unit));
    }

    add('SOH', profileValue(0x352, 'SOH_Disp') ?? profileValue(0x150, 'Pack_SoH'),
        '%');
    add('Cycle count', profileValue(0x6d8, 'Cycle_Number'), '');
    add('Effective temperature',
        profileValue(0x160, 'Effective_Battery_Temperature_00'), '°C');
    // Available_Capacity_00 is a percentage on CAN, not amp-hours — true usable
    // Ah / pack-Wh come only from the UDS deep read, so they stay blank here.
    add('Available capacity', profileValue(0x150, 'Available_Capacity_00'), '%');
    if (cells.isEmpty && health.isEmpty) return null;
    return BatterySnapshot(cells, health, const [], DateTime.now(), false);
  }

  /// Friendly vehicle-state readout decoded from CAN: drive mode, safety states
  /// (0x683), motor and charge-time signals. Values are '—' when not reported.
  /// Enum decoding mirrors the known-working community tools.
  Map<String, String> get vehicleState {
    String driveMode() {
      final v = profileValue(0x113, 'Vehicle_Discharge_Mode');
      if (v == null) return '—';
      return switch (v.toInt()) {
        0 => 'Parked',
        2 => 'Normal',
        3 => 'Sport',
        4 => 'Custom',
        5 || 10 || 13 => 'Reverse',
        6 => 'Eco',
        7 => 'Hyper',
        _ => 'Mode ${v.toInt()}',
      };
    }

    String enumOf(int id, String name, Map<int, String> m) {
      final v = profileValue(id, name);
      if (v == null) return '—';
      return m[v.toInt()] ?? 'state ${v.toInt()}';
    }

    String num1(int id, String name, String unit) {
      final v = profileValue(id, name);
      return v == null ? '—' : '${v.toStringAsFixed(1)}${unit.isEmpty ? '' : ' $unit'}';
    }

    return {
      'Drive mode': driveMode(),
      'Fall detection': enumOf(0x683, 'Fall_Detection_State',
          {0: 'off', 1: 'active', 2: 'inactive', 3: 'recovered'}),
      'Tow / theft': enumOf(
          0x683, 'Tow_Theft_Detection', {0: 'off', 1: 'active', 2: 'inactive'}),
      'Regen': enumOf(0x683, 'Regen_Availability',
          {0: 'not available', 1: 'available', 2: 'throttle limited'}),
      'Hill hold': enumOf(0x683, 'Hill_Hold_Availability',
          {1: 'unavailable', 2: 'active', 3: 'not active', 6: 'activated'}),
      'Motor current': num1(0x224, 'DC_Current_MCU', 'A'),
      'Motor frequency': num1(0x224, 'Motor_Frequency', 'Hz'),
      'Regen torque': num1(0x225, 'Regen_torque_perc', '%'),
      'Charge time (full)': num1(0x190, 'Time_to_Full_chargeSC_00', 'min'),
    };
  }

  /// Live fault flags decoded from the per-ECU *_fault_dbc maps, grouped by
  /// source (BMS/MCU/VCU/IMCU). Empty when nothing is asserted.
  Map<String, List<String>> liveFaults() {
    final out = <String, List<String>>{};
    for (final frame in activeFaultFrames) {
      final active = frame.active(frameFresh(frame.id) ? raw[frame.id] : null);
      if (active.isNotEmpty) (out[frame.ecu] ??= []).addAll(active);
    }
    return out;
  }

  Future<void> connect(
    String host,
    int port, {
    bool secure = false,
    bool simulated = false,
    bool phoneHotspot = false,
  }) async {
    if (busy || connection == Connection.connecting) return;
    // Demo/simulated runs need no scooter address.
    if (!simulated && (host.trim().isEmpty || port < 1 || port > 65535)) {
      throw ArgumentError('Enter a valid host and port');
    }
    if (connected) return;
    await disconnect();
    final token = ++_generation;
    firmware = 'Unknown';
    manifest = '';
    aospVersion = '';
    demo = simulated;
    connection = Connection.connecting;
    message = '';
    emit();
    await prefs.store.setString('host', host.trim());
    await prefs.store.setInt('port', port);
    await prefs.store.setBool('secure', secure);
    await prefs.store.setBool('phoneHotspot', phoneHotspot);
    WifiCan? candidate;
    try {
      if (simulated) {
        mode = 'SERVICE';
        firmware = 'DEMO-MOCK-5.0.0';
        bench = true;
        _demoReadings();
      } else {
        candidate = WifiCan();
        link = candidate;
        candidate.onFrame = (frame) {
          if (token == _generation) _receive(frame);
        };
        candidate.onStreamError = (error) {
          if (token == _generation) {
            message = 'CAN stream stopped: $error';
            log(message);
            emit();
          }
        };
        await candidate.connect(
          host.trim(),
          port,
          secure,
          phoneHotspot: phoneHotspot,
        );
        await candidate.init(ids);
        await candidate.reader();
        // Vehicle mode / firmware are metadata RPCs that some generations answer
        // differently (seen on Gen2/Gen3). A difference here must NOT drop the
        // whole connection — live CAN + UDS still work. Keep them best-effort.
        try {
          final receivedMode = await candidate.mode();
          if (token != _generation) {
            await candidate.close();
            return;
          }
          mode = receivedMode;
          // A scooter can already be in SERVICE when we connect (entered on the
          // vehicle, or left in service from a prior session). `bench` gates the
          // read flow but was previously only set by the in-app Enter Service
          // toggle, so an already-service scooter showed "Leave Service mode"
          // yet kept the battery/cell read disabled. Mirror the detected mode.
          bench = mode == 'SERVICE';
        } catch (error) {
          if (token != _generation) return;
          mode = 'UNKNOWN';
          bench = false;
          log('Vehicle mode RPC unavailable: $error');
        }
        try {
          final receivedFirmware = await candidate.firmware();
          if (token != _generation) {
            await candidate.close();
            return;
          }
          firmware = receivedFirmware;
        } catch (error) {
          if (token != _generation) return;
          firmware = 'Unknown';
          log('Firmware RPC unavailable: $error');
        }
        try {
          final response = await candidate.client.getAospVersion(
            Empty(),
            options: CallOptions(timeout: const Duration(seconds: 4)),
          );
          if (token != _generation) {
            await candidate.close();
            return;
          }
          if (response.status == rpc.RespStatus.RESP_SUCCESS) {
            aospVersion = response.statusMsg;
          }
        } catch (error) {
          log('Platform identification unavailable: $error');
        }
        if (token != _generation) {
          await candidate.close();
          return;
        }
        refreshVehicleProfile();
        uds = Uds(candidate);
      }
      if (token != _generation) {
        await candidate?.close();
        return;
      }
      connection = Connection.connected;
      log('Connected ${simulated ? 'DEMO' : '$host:$port'}');
      _tick = Timer.periodic(const Duration(seconds: 1), (_) {
        if (demo) _demoReadings();
        sampleTelemetry();
        if (recording) {
          chargeLog.add({
            'captured_at': DateTime.now().toUtc().toIso8601String(),
            'demo': demo,
            'metrics': metrics,
          });
        }
        if (chargeLog.length >= 3600) {
          recording = false;
          message =
              'Recording reached 3,600 samples. Export before starting another.';
        }
        emit();
      });
    } catch (error) {
      await candidate?.close();
      if (token != _generation) return;
      link = null;
      uds = null;
      connection = Connection.error;
      message = 'Connection failed: $error';
      log(message);
    }
    emit();
  }

  void _receive(CanPacket frame) => acceptFrame(frame);

  /// Shared receive path for live traffic and deterministic capture tests.
  void acceptFrame(CanPacket frame, {DateTime? receivedAt}) {
    if (frame.data.length != 8 || frame.data.any((b) => b < 0 || b > 255)) {
      return;
    }
    final now = receivedAt ?? DateTime.now();
    lastFrame = now;
    raw[frame.id] = List<int>.unmodifiable(frame.data);
    frameTimes[frame.id] = now;
    refreshVehicleProfile();
    if (frame.id == 0x6d0 && identity.profile == VehicleProfile.legacy) {
      observeNotification(frame.data);
    }
    _decodeFrame(frame, now);
  }

  void _decodeFrame(CanPacket frame, DateTime now) {
    for (final signal in catalog.signalsFor(identity.profile, frame.id)) {
      readings['${frame.id}:${signal.name}'] = Reading(
        signal.decode(frame.data),
        signal.unit,
        now,
        frame.id,
      );
      final isFault =
          signal.bits == 1 &&
          RegExp(
            'fault|error|fail|warn|protect|abnormal|overcurrent|overvolt|undervolt|overtemp|short|disconnect|timeout|corrupt|stall|deviation',
            caseSensitive: false,
          ).hasMatch(signal.name) &&
          !RegExp(
            'demand|status_signal|counter|calibration|balancing|indicator_ttl',
            caseSensitive: false,
          ).hasMatch(signal.name);
      if (isFault) {
        final name = '0x${frame.id.toRadixString(16)} / ${signal.name}';
        final active = signal.decode(frame.data).toInt() == 1;
        if (active != broadcast.contains(name)) {
          active ? broadcast.add(name) : broadcast.remove(name);
          watchEvents.insert(
            0,
            '${now.toIso8601String()} ${active ? 'SET' : 'CLEAR'} $name',
          );
          if (watchEvents.length > 300) watchEvents.removeLast();
        }
      }
    }
  }

  void _demoReadings() {
    final now = DateTime.now();
    final values = {
      'Display_SoC': 82.5,
      'Bus_Voltage_00_10ms': 52.4,
      'Overall_Battery_Current': 4.4,
      'Vehicle_speed_in_kmph': 0.0,
    };
    for (final entry in values.entries) {
      readings['demo:${entry.key}'] = Reading(entry.value, '', now, 0);
    }
    for (final id in raw.keys) {
      frameTimes[id] = now;
    }
    // Sample live fault flags so the Faults page is reviewable in demo.
    raw[0x66e] = [0x05, 0, 0, 0, 0, 0, 0, 0]; // VCU: two sample flags
    raw[0x410] = [0, 0, 0, 0, 0, 0, 0, 0x02]; // BMS: one sample flag
    // Sample variant + DCIR so Vehicle/hardware + cell DCIR render in demo.
    raw[0x211] = [0x03, 1, 1, 1, 1, 0, 1, 0]; // Vehicle_Variant = 3
    raw[0x610] = [0, 0, 0, 0, 0, 0, 0, 0];
    raw[0x678] = [0x11, 0x07, 0, 0, 0, 0, 0, 0];
    for (final (i, id) in const [0x1ab, 0x1ac, 0x1ad, 0x1ae].indexed) {
      final b = <int>[];
      for (var c = 0; c < 4; c++) {
        final v = 850 + (i * 4 + c) * 12; // ~0.85–1.0 mΩ
        b
          ..add(v & 0xff)
          ..add(v >> 8);
      }
      raw[id] = b;
    }
  }

  void observeNotification(List<int> data) {
    if (data.isEmpty) return;
    final code = data[0];
    if (code == _notificationCode) return;
    _notificationCode = code;
    if (code == 0) return;
    notifications.insert(
      0,
      VehicleNotification(
        code,
        catalog.notifications[code] ?? 'Unknown notification $code',
        DateTime.now(),
      ),
    );
    if (notifications.length > 200) notifications.removeLast();
  }

  void clearNotifications() {
    notifications.clear();
    emit();
  }

  Future<void> readSoftware(String kind) => operation('Read $kind', () async {
    final token = _generation;
    String result;
    if (demo) {
      result = 'Demo · simulated $kind response. Firmware DEMO-MOCK-5.0.0';
    } else if (kind == 'Identifiers') {
      result = await link!.identifiers();
    } else if (kind == 'Update status') {
      result = const JsonEncoder.withIndent('  ').convert(
        (await link!.client.swUpdateCheckStatus(
          Empty(),
          options: CallOptions(timeout: const Duration(seconds: 10)),
        )).toProto3Json(),
      );
    } else {
      final reply = kind == 'Android version'
          ? await link!.client.getAospVersion(
              Empty(),
              options: CallOptions(timeout: const Duration(seconds: 10)),
            )
          : await link!.client.getSwVersion(
              Empty(),
              options: CallOptions(timeout: const Duration(seconds: 10)),
            );
      if (reply.status != rpc.RespStatus.RESP_SUCCESS) {
        throw StateError(reply.statusMsg);
      }
      result = reply.statusMsg;
    }
    if (token == _generation && connected) {
      softwareResponses[kind] = result;
      if (kind == 'Software version') firmware = result;
      if (kind == 'Android version') aospVersion = result;
      refreshVehicleProfile();
      message = '$kind received';
    }
  });
  double? signal(List<String> names, {List<int>? ids}) {
    for (final name in names) {
      for (final entry in readings.entries) {
        if ((ids == null || demo || ids.contains(entry.value.id)) &&
            entry.key.split(':').last.toLowerCase() == name.toLowerCase()) {
          return entry.value.value;
        }
      }
    }
    return null;
  }

  double? _bounded(double? value, double min, double max) =>
      value != null && value.isFinite && value >= min && value <= max
      ? value
      : null;
  double? _temp(int index) {
    if (demo) return index == 2 ? 36 : 32;
    final data = raw[0x313];
    return data == null
        ? null
        : _bounded((data[index] | data[index + 1] << 8) * .01, -40, 200);
  }

  Map<String, double?> get metrics => {
    'State of charge (%)': _bounded(
      signal(
        ['Display_SoC', 'Pack_SOC_00', 'Overall_SOC'],
        ids: [0x352, 0x11c, 0x120],
      ),
      0,
      100,
    ),
    'Reported range (km)': _bounded(
      signal(['Vehicle_Range'], ids: [0x353]),
      0,
      400,
    ),
    'Pack voltage (V)': _bounded(
      signal(
        ['Bus_Voltage_00_10ms', 'Battery_voltage_OCV_00'],
        ids: [0x640, 0x11c],
      ),
      0,
      200,
    ),
    'Pack current (A)': signal(['Overall_Battery_Current'], ids: [0x120]),
    'Battery temperature (°C)': battery?.healthValue('effective temp'),
    'Motor temperature (°C)': _temp(4),
    'Controller temperature (°C)': _temp(2),
    'Vehicle speed (km/h)': _bounded(
      signal(
        ['Vehicle_speed_in_kmph', 'Vehicle_Speed', 'Motor_Speed'],
        ids: [0x313],
      ),
      0,
      200,
    ),
  };
  Map<String, double> get telemetryValues {
    final now = DateTime.now();
    final values = <String, double>{};
    for (final entry in readings.entries) {
      if (!demo && now.difference(entry.value.receivedAt).inSeconds >= 3) {
        continue;
      }
      values.putIfAbsent(entry.key.split(':').last, () => entry.value.value);
    }
    if (!connected) return {};
    double? freshSignal(List<String> names, List<int> ids) {
      for (final name in names) {
        for (final e in readings.entries) {
          if ((demo || ids.contains(e.value.id)) &&
              e.key.split(':').last == name &&
              (demo || now.difference(e.value.receivedAt).inSeconds < 3)) {
            return e.value.value;
          }
        }
      }
      return null;
    }

    final fresh = <String, double?>{
      'batt_soc': freshSignal(
        ['Display_SoC', 'Pack_SOC_00', 'Overall_SOC'],
        [0x352, 0x11c, 0x120],
      ),
      'batt_range_km': freshSignal(['Vehicle_Range'], [0x353]),
      'batt_volts': freshSignal(
        ['Bus_Voltage_00_10ms', 'Battery_voltage_OCV_00'],
        [0x640, 0x11c],
      ),
      'batt_amps': freshSignal(['Overall_Battery_Current'], [0x120]),
      'batt_speed': freshSignal(
        ['Vehicle_speed_in_kmph', 'Vehicle_Speed', 'Motor_Speed'],
        [0x313],
      ),
    };
    if (demo ||
        readings.values.any(
          (r) => r.id == 0x313 && now.difference(r.receivedAt).inSeconds < 3,
        )) {
      fresh['batt_motor_t'] = _temp(4);
      fresh['batt_mcu_t'] = _temp(2);
    }
    for (final e in fresh.entries) {
      if (e.value != null && e.value!.isFinite) values[e.key] = e.value!;
    }
    if (fresh['batt_volts'] != null && fresh['batt_amps'] != null) {
      values['power_w'] = fresh['batt_volts']! * fresh['batt_amps']!;
    }
    return values;
  }

  void sampleTelemetry({DateTime? now}) {
    if (!foreground) return;
    final values = telemetryValues;
    if (values.isEmpty) return;
    now ??= DateTime.now();
    _graphStart ??= now;
    graph.add(
      SessionSample(
        now.difference(_graphStart!).inMilliseconds / 1000,
        Map.unmodifiable(values),
      ),
    );
    if (graph.length > 600) graph.removeAt(0);
    session.sample(values, now: now);
    // Persist a battery-health trend point (throttled inside record()).
    final cb = canBattery;
    if (cb != null) {
      final spread = cb.spreadMv;
      history.record(
        cb.healthValue('soh'),
        spread > 0 ? spread : null,
        cb.usableAh ?? battery?.usableAh,
      );
    }
  }

  void clearGraph() {
    graph.clear();
    _graphStart = null;
    emit();
  }

  Future<void> startSession() async {
    if (busy || !connected || session.active || session.closing) return;
    if (!live) await liveMode(true);
    if (!live || !connected) return;
    await operation('Start session recording', () async {
      final token = _generation;
      await session.start({
        'demo': demo,
        'firmware': firmware,
        'platform': 'OpenOLA mobile',
        'foreground_only': true,
        'units': {
          'batt_soc': '%',
          'batt_range_km': 'km',
          'batt_volts': 'V',
          'batt_amps': 'A',
          'batt_speed': 'km/h',
          'batt_motor_t': '°C',
          'batt_mcu_t': '°C',
          'power_w': 'W',
          for (final e in readings.entries) e.key.split(':').last: e.value.unit,
        },
      });
      message = 'Recording all fresh signals. Keep OpenOLA in the foreground.';
      if (token != _generation || !connected || !foreground) {
        await session.stop();
        return;
      }
    });
  }

  Future<void> stopSession({String? reason}) async {
    await session.stop();
    message =
        session.error ??
        reason ??
        'Recording saved · ${session.samples} samples';
    emit();
  }

  void cancelRead() {
    readCancelled = true;
    emit();
  }

  /// A test seam for read-only UDS, deliberately without security unlock/session change.
  Future<List<int>> readIdentifierBytes(ReadIdentifier definition) async => demo
      ? _demoIdentifier(definition)
      : await uds!.read(definition.ecu, definition.did);
  Future<void> identifierStream(bool monitor) async {
    if (demo) return;
    await link!.init(ids);
    await link!.reader(dump: monitor);
  }

  Future<List<IdentifierResult>> readIdentifiers(
    List<ReadIdentifier> definitions,
  ) async {
    final result = <IdentifierResult>[];
    final token = _generation;
    await operation('Read ECU data', () async {
      // DID reads are non-destructive and the ODX identifier layout is shared
      // across generations, so no legacy-profile gate here. Reads that an ECU
      // refuses simply surface as per-row NRC errors.
      final resume = live;
      readDone = 0;
      readTotal = definitions.length;
      readCancelled = false;
      try {
        if (!demo) {
          live = false;
          await identifierStream(false);
        }
        for (final definition in definitions) {
          if (readCancelled || !connected || token != _generation) break;
          readLabel = '${definition.ecu.label} · ${definition.title}';
          emit();
          IdentifierResult row;
          try {
            final bytes = await readIdentifierBytes(definition);
            row = IdentifierResult(definition, bytes: bytes);
          } catch (e) {
            row = IdentifierResult(definition, error: e.toString());
          }
          if (!connected || token != _generation) break;
          result.add(row);
          identifierResults[definition.key] = row;
          readDone++;
          emit();
        }
        message =
            '${readCancelled ? 'Read cancelled' : 'Read complete'} · ${result.length}/${definitions.length} identifiers${demo ? ' · simulated' : ''}';
      } finally {
        readTotal = 0;
        readLabel = '';
        if (resume && connected && token == _generation) {
          if (demo) {
            live = true;
          } else {
            try {
              await identifierStream(true);
              live = true;
            } catch (e) {
              live = false;
              message = '$message · Live monitor could not resume: $e';
            }
          }
        }
      }
    }, service: true);
    return result;
  }

  List<int> _demoIdentifier(ReadIdentifier d) {
    final length = d.fields.fold(0, (int end, f) {
      final n =
          (int.tryParse('${f['StartBit']}') ?? 0) +
          (int.tryParse('${f['Size (Bits)']}') ?? 0);
      return n > end ? n : end;
    });
    final data = List<int>.filled((length + 7) ~/ 8, 0);
    for (var i = 0; i < d.fields.length; i++) {
      final f = d.fields[i];
      final bits = int.tryParse('${f['Size (Bits)']}') ?? 0,
          start = int.tryParse('${f['StartBit']}') ?? 0;
      if (bits <= 0) continue;
      if ('${f['Encoding']}'.toLowerCase() == 'ascii') {
        final text = 'DEMO ${d.ecu.label}';
        for (var j = 0; j < bits ~/ 8; j++) {
          data[start ~/ 8 + j] = j < text.length ? text.codeUnitAt(j) : 0;
        }
        continue;
      }
      final name = '${f['Parameter']}'.toLowerCase();
      final physical = switch (d.did) {
        0xe100 =>
          name == 'pack voltage' || name == 'bus voltage'
              ? 54724.0
              : name.contains('temperature')
              ? 33.0
              : name.contains('minimum')
              ? 3858.0
              : name.contains('maximum')
              ? 3916.0
              : name.contains('current')
              ? 4.4
              : 0.0,
        0xe103 => name.contains('soc') ? 82.5 : 96.0,
        0xe106 => i == 8 ? 3.858 : 3.90 + (i % 5) * .004,
        0xe109 => i == 8 ? 3.1 : 1.8 + (i % 3) * .1,
        0xe108 => 3.2,
        0xe107 => 31.0 + i,
        0xe102 => 1.2,
        0xe434 => 57.6,
        _ =>
          name.contains('soh')
              ? 96.0
              : name.contains('cycle')
              ? 148.0
              : name.contains('temp')
              ? 33.0
              : 0.0,
      };
      final resolution = double.tryParse('${f['Resolution']}') ?? 1,
          offset = double.tryParse('${f['Offset']}') ?? 0;
      if (resolution == 0) continue;
      final value = BigInt.from(((physical - offset) / resolution).round());
      for (var bit = 0; bit < bits; bit++) {
        if ((value & (BigInt.one << bit)) != BigInt.zero) {
          data[(start + bit) ~/ 8] |= 1 << ((start + bit) % 8);
        }
      }
    }
    return data;
  }

  Future<void> readBattery() async {
    if (!readReady) return;
    final token = _generation;
    final rows = await readIdentifiers(
      catalog.identifiers
          .where(
            (r) =>
                r.ecu == Ecu.bms &&
                [
                  0xe100,
                  0xe101,
                  0xe102,
                  0xe103,
                  0xe434,
                  0xe106,
                  0xe107,
                  0xe108,
                  0xe109,
                ].contains(r.did),
          )
          .toList(),
    );
    if (rows.isNotEmpty && connected && token == _generation) {
      battery = BatterySnapshot.fromResults(rows, demo: demo);
      emit();
    }
  }

  Future<void> operation(
    String name,
    Future<void> Function() work, {
    bool service = false,
  }) async {
    if (busy) return;
    if (!connected) {
      message = 'Connect to a scooter first.';
      emit();
      return;
    }
    if (service && !demo && (!bench || mode != 'SERVICE')) {
      message =
          'Confirm parked, charger disconnected and enter Service mode first.';
      emit();
      return;
    }
    busy = true;
    message = '';
    emit();
    log(name);
    try {
      await work();
    } catch (error) {
      message = '$name: $error';
      log(message);
    } finally {
      busy = false;
      emit();
    }
  }

  Future<void> serviceMode(bool value) =>
      operation(value ? 'Enter Service mode' : 'Return to Customer', () async {
        if (!demo) await link!.setMode(value);
        mode = value ? 'SERVICE' : 'CUST';
        bench = value;
        unlocked.clear();
        _keepAlive?.cancel();
        message = value
            ? 'Service mode acknowledged'
            : 'Customer mode acknowledged';
      });
  Future<void> _unlock(Ecu ecu) async {
    if (demo) return;
    requireLegacyMethod('ECU security/session sequence');
    if (link!.streamMode != 'diag') {
      live = false;
      await link!.init(ids);
      await link!.reader();
    }
    if (rejectedKeys.contains(ecu)) {
      throw StateError(
        'Key rejected on this connection. Reconnect after checking ECU lockout.',
      );
    }
    if (!unlocked.contains(ecu)) {
      try {
        await uds!.unlock(ecu);
      } catch (error) {
        if (RegExp('0x35|0x36|0x37').hasMatch(error.toString())) {
          rejectedKeys.add(ecu);
        }
        rethrow;
      }
      unlocked.add(ecu);
    }
    _keepAlive?.cancel();
    _keepAlive = Timer.periodic(const Duration(seconds: 2), (_) async {
      if (busy || _keepingAlive || disposed || !connected) return;
      _keepingAlive = true;
      try {
        await uds!.testerPresent(ecu);
      } catch (error) {
        log('Tester present: $error');
      } finally {
        _keepingAlive = false;
      }
    });
  }

  Future<void> scan({Ecu? ecu}) => operation('Read stored faults', () async {
    for (final target in ecu == null ? Ecu.values : [ecu]) {
      if (demo) {
        faults[target] = target == Ecu.bms
            ? [const Fault('P0A80', 'Demo: battery pack fault example', 9)]
            : [];
      } else {
        if (!identity.matched) {
          throw StateError('Waiting for a matching scooter profile.');
        }
        // New profile: standard read only. Never reuse the older security key
        // or session sequence when a controller rejects the request.
        if (identity.legacyMethods) await _unlock(target);
        final response = await uds!.dtcs(target);
        faults[target] = catalog
            .parseFaults(target, response)
            .map(
              (f) => identity.legacyMethods
                  ? f
                  : Fault(
                      f.code,
                      'Controller code (model-specific description unavailable)',
                      f.status,
                    ),
            )
            .toList();
      }
    }
    message = 'Fault scan complete${demo ? ' · simulated' : ''}';
  }, service: true);
  Future<void> faultAction(Ecu ecu, bool reset) => operation(
    reset ? 'Restart ${ecu.label}' : 'Clear ${ecu.label} history',
    () async {
      if (!demo) {
        await _unlock(ecu);
        reset ? await uds!.reset(ecu) : await uds!.clear(ecu);
      }
      if (reset) {
        unlocked.remove(ecu);
      } else {
        faults.remove(ecu);
      }
      message =
          '${demo ? 'Demo: ' : ''}${reset ? 'Restart' : 'Clear'} acknowledged. Deep-sleep wake is unvalidated.';
    },
    service: true,
  );

  /// Requests BMS cell balancing (RoutineControl 0x05F8). Balancing is
  /// BMS-governed — these packs normally balance only while charging with the
  /// cells imbalanced — so this asks for it; the pack decides. This app does
  /// not expose a live status signal; use the cell-voltage spread as a proxy.
  Future<void> forceBalance() => operation('Cell balancing', () async {
    if (!demo) {
      await _unlock(Ecu.bms);
      final resp = await uds!.routine(Ecu.bms, 0x05f8);
      // Require the BMS to echo the routine (0x71 01 05 F8) before claiming
      // success — the service byte alone is not enough.
      if (resp.length < 4 ||
          resp[1] != 0x01 ||
          resp[2] != 0x05 ||
          resp[3] != 0xf8) {
        throw StateError('BMS did not acknowledge the balancing routine.');
      }
    }
    message =
        '${demo ? 'Demo: ' : ''}Balancing requested. The BMS balances during '
        'charging when the cells are imbalanced — it decides whether to act.';
  }, service: true);

  Future<void> recover() => operation('Existing fault recovery', () async {
    // Finish every read before issuing a destructive command. A failed read is
    // not evidence of an empty fault list.
    for (final ecu in Ecu.values) {
      if (demo) {
        faults[ecu] = ecu == Ecu.bms
            ? [const Fault('P0A80', 'Demo fault', 9)]
            : [];
      } else {
        await _unlock(ecu);
        faults[ecu] = catalog.parseFaults(ecu, await uds!.dtcs(ecu));
      }
    }
    var targets = Ecu.values.where((e) => faults[e]!.isNotEmpty).toList();
    if (targets.isEmpty) targets = [Ecu.vcu];
    for (final ecu in targets) {
      if (!demo) {
        await _unlock(ecu);
        await uds!.clear(ecu);
        faults.remove(ecu);
        await uds!.reset(ecu);
      } else {
        faults.remove(ecu);
      }
      unlocked.remove(ecu);
    }
    _keepAlive?.cancel();
    unlocked.clear();
    if (!demo) await link!.setMode(false);
    mode = 'CUST';
    bench = false;
    message =
        '${demo ? 'Demo: ' : ''}Recovery commands acknowledged. Rescan after reconnecting; deep-sleep wake is unvalidated.';
  }, service: true);

  Future<void> restartHeadUnit() => operation('Restart head unit', () async {
    String result;
    try {
      if (!demo) await link!.restartHeadUnit();
      result =
          '${demo ? 'Demo: ' : ''}Restart acknowledged. Wait for the head unit, then reconnect manually.';
    } catch (error) {
      result =
          'Restart outcome unknown: $error. Check the head unit before reconnecting; no retry.';
    }
    await disconnect();
    message = result;
    log(result);
  }, service: true);

  Future<void> liveMode(bool value) =>
      operation(value ? 'Start live signals' : 'Stop live signals', () async {
        if (!demo) {
          await link!.init(ids);
          await link!.reader(dump: value);
        }
        live = value;
        message = value
            ? 'Live CAN stream started'
            : 'Filtered diagnostic stream restored';
      });
  Future<void> actuator(Actuator a, {bool? latch}) =>
      operation(a.label, () async {
        if (!demo) {
          await _unlock(Ecu.vcu);
          if (latch != null) {
            await uds!.io(a.did, latch);
            if (!latch) await uds!.io(a.did, false, release: true);
          } else {
            try {
              await uds!.io(a.did, true);
              await Future<void>.delayed(
                Duration(
                  milliseconds: a.label.toLowerCase() == 'horn' ? 750 : 2000,
                ),
              );
            } finally {
              await uds!.io(a.did, false);
              await uds!.io(a.did, false, release: true);
            }
          }
        }
        if (latch != null) {
          latch ? latched[a.did] = a : latched.remove(a.did);
        }
        message =
            '${demo ? 'Demo: ' : ''}${a.label}: ${latch == null
                ? 'pulse'
                : latch
                ? 'ON'
                : 'OFF'} acknowledged';
      }, service: true);
  Future<List<int>?> readParameter(Parameter p) async {
    List<int>? result;
    await operation('Read ${p.name}', () async {
      if (!demo) await _unlock(p.ecu);
      result = demo ? List.filled(p.length, 0) : await uds!.read(p.ecu, p.did);
      message = 'Read ${p.name}';
    }, service: true);
    return result;
  }

  Future<void> writeParameter(
    Parameter p,
    Map<String, double> edits, {
    bool reversed = false,
  }) => operation('Write ${p.name}', () async {
    if (!demo) await _unlock(p.ecu);
    final current = demo
        ? List.filled(p.length, 0)
        : await uds!.read(p.ecu, p.did);
    final proposed = p.encode(current, edits, reversed: reversed);
    if (!demo) {
      await uds!.writeDid(p.ecu, p.did, proposed);
      final after = await uds!.read(p.ecu, p.did);
      if (!listEquals(after, proposed)) {
        throw StateError('Readback differs; no automatic retry');
      }
    }
    message =
        '${demo ? 'Demo: ' : ''}Write acknowledged and readback matches. Reboot persistence unverified.';
  }, service: true);
  Future<void> hmi(int ordinal, String label) => operation(label, () async {
    if (!demo) {
      requireLegacyMethod('HMI command');
      await link!.write(0x6bc, [ordinal, 0, 0, 0, 0, 0, 0, 0]);
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    message = demo
        ? 'Demo: $label'
        : raw[0x6c0]?[0] == ordinal
        ? '$label: echo seen; physical completion unverified'
        : '$label: sent, no echo within 400 ms. Outcome unknown; no retry.';
  }, service: true);
  /// Read-only diagnostic-identity (certificate) status check. Does not
  /// generate or install certs — those server-side operations are brick-risky
  /// and deliberately not exposed.
  Future<void> validateCerts() => operation('Validate identity', () async {
    certStatus = demo
        ? 'Demo: diagnostic identity valid'
        : await link!.validateCerts();
    message = certStatus;
  });

  // --- Firmware OTA (gRPC SwUpdate). otaStatus is read-only/safe; otaFlash is
  // brick-capable and EXPERIMENTAL (the checksum format is unverified). ---
  String otaState = '';
  double otaProgress = 0; // 0..1 during upload

  Future<void> otaStatus() => operation('Update status', () async {
    otaState = demo ? 'IDLE (demo)' : await link!.swStatus();
    message = otaState;
  });

  // --- Root shell on the head unit (ExecuteADBCommand). Dev-mode gated in the
  // UI. Runs as uid 0, so powerful; used for self-test foregrounding and to
  // read the on-device diagnostic identity. ---
  String adbOutput = '';

  Future<void> adbCommand(String cmd) => operation('ADB', () async {
    adbOutput = demo ? 'Demo: `$cmd` was not executed.' : await link!.adb(cmd);
    message = 'ADB command ran';
  });

  /// Brings the scooter's diagnostic app (com.olaelectric.udstestapp) to the
  /// foreground so head-unit self-tests actually display. Best-effort.
  Future<String> foregroundDiagApp() async => demo
      ? 'Demo'
      : link!.adb(
          'monkey -p com.olaelectric.udstestapp '
          '-c android.intent.category.LAUNCHER 1',
        );

  /// EXPERIMENTAL firmware OTA. Brick-capable. The scooter's expected checksum
  /// format is UNVERIFIED (assumed SHA-256 hex). Gated by `service: true`; the
  /// UI additionally requires Developer Mode + typed-CONFIRM. [target] is a
  /// component name (ALL/AOSP/BCM/BLE/BMS/HU/MCU).
  Future<void> otaFlash(List<int> bytes, String name, String target) =>
      operation('Firmware OTA', () async {
        if (demo) {
          for (var p = 0.0; p <= 1.0; p += 0.2) {
            otaProgress = p;
            emit();
            await Future<void>.delayed(const Duration(milliseconds: 150));
          }
          otaState = 'SUCCESS (demo — nothing was written)';
          message = otaState;
          otaProgress = 0;
          return;
        }
        final csum = sha256.convert(bytes).toString();
        otaProgress = 0;
        otaState = 'Clearing cache';
        emit();
        await link!.swClearCache();
        otaState = 'Sending metadata';
        emit();
        await link!.swSendMeta(name, bytes.length, csum);
        otaState = 'Uploading';
        emit();
        await link!.swTransfer(
          bytes,
          onProgress: (sent) {
            otaProgress = sent / bytes.length;
            emit();
          },
        );
        otaProgress = 1;
        otaState = 'Triggering install';
        emit();
        await link!.swTrigger(target);
        otaState = await link!.swStatus();
        message =
            'OTA triggered · $otaState. Poll status; the scooter reboots during install.';
        otaProgress = 0;
      }, service: true);
  Future<void> loadInfo() => operation('Read identifiers', () async {
    manifest = demo
        ? jsonEncode({'demo': true, 'firmware': firmware})
        : await link!.identifiers();
    message = 'Identifiers received';
  });
  Future<void> test(int command, String label, bool start) =>
      operation(label, () async {
        if (!demo) requireLegacyMethod('Head-unit self-test');
        if (!demo && start) {
          // Best-effort: bring the diagnostic app to the front so the test is
          // visible on the head unit (self-tests are no-ops without it).
          try {
            await foregroundDiagApp();
          } catch (_) {
            /* foregrounding is optional — continue with the test */
          }
        }
        message = demo
            ? 'Demo: $label ${start ? 'start' : 'stop'}'
            : await link!.remoteTest(command, start);
      }, service: true);
  bool toolActive(Tool tool) =>
      tool == Tool.live && live ||
      tool == Tool.charging && recording ||
      tool == Tool.actuators && latched.isNotEmpty;
  Future<void> disconnect() async {
    ++_generation;
    _tick?.cancel();
    _keepAlive?.cancel();
    readCancelled = true;
    await session.stop();
    final old = link;
    link = null;
    if (!demo && old != null && latched.isNotEmpty) {
      try {
        final u = Uds(old);
        for (final a in latched.values) {
          await u.io(a.did, false);
          await u.io(a.did, false, release: true);
        }
      } catch (error) {
        log('Release failed: $error');
        message =
            'Some latched controls could not be released. Check the scooter.';
      }
    }
    await old?.close();
    uds = null;
    unlocked.clear();
    rejectedKeys.clear();
    latched.clear();
    connection = Connection.disconnected;
    busy = false;
    demo = false;
    bench = false;
    mode = 'Unknown';
    live = false;
    recording = false;
    raw.clear();
    frameTimes.clear();
    _decodedProfile = VehicleProfile.common;
    firmware = 'Unknown';
    aospVersion = '';
    manifest = '';
    readings.clear();
    faults.clear();
    notifications.clear();
    _notificationCode = null;
    softwareResponses.clear();
    identifierResults.clear();
    battery = null;
    clearGraph();
    broadcast.clear();
    lastFrame = null;
    emit();
  }

  @override
  void dispose() {
    disposed = true;
    _tick?.cancel();
    _keepAlive?.cancel();
    session.removeListener(emit);
    unawaited(session.stop());
    session.dispose();
    unawaited(link?.close() ?? Future<void>.value());
    super.dispose();
  }
}
