package `in`.crossfire.openola

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
