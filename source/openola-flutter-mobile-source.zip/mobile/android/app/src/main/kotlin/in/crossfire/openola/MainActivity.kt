package `in`.crossfire.openola

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val networkChannel = "in.crossfire.openola/network"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, networkChannel)
            .setMethodCallHandler { call, result ->
                val connectivity = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                when (call.method) {
                    "bindProcessToWifi" -> {
                        val phoneHotspot = call.argument<Boolean>("phoneHotspot") == true
                        val wifi: Network? = if (phoneHotspot) null else connectivity.allNetworks.firstOrNull { network ->
                            connectivity.getNetworkCapabilities(network)
                                ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                        }
                        if (wifi == null) {
                            // A phone hosting the scooter's hotspot has no Wi-Fi
                            // client Network. Leave sockets unbound so Android
                            // can use its local tethering route to the scooter.
                            // Binding to the cellular upstream would bypass it.
                            if (connectivity.bindProcessToNetwork(null)) {
                                result.success(true)
                            } else {
                                result.error("network_restore_failed", "Android could not restore local routing for the hotspot.", null)
                            }
                        } else if (connectivity.bindProcessToNetwork(wifi)) {
                            result.success(true)
                        } else {
                            result.error("wifi_bind_failed", "Android could not route the app over Wi-Fi.", null)
                        }
                    }
                    "restoreDefaultNetwork" -> result.success(connectivity.bindProcessToNetwork(null))
                    else -> result.notImplemented()
                }
            }
    }
}
