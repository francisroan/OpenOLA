package `in`.crossfire.openola

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : FlutterActivity() {
    private val networkChannel = "in.crossfire.openola/network"
    private val hapticsChannel = "in.crossfire.openola/haptics"
    private val mainHandler = Handler(Looper.getMainLooper())

    // Held for the lifetime of a Wi-Fi session. Holding the NetworkRequest is
    // what keeps a no-internet scooter AP alive; without it Android validates
    // the network, finds no upstream, and is free to drop or replace the
    // Network object, which kills the bound socket mid-stream (HTTP/2
    // CONNECT_ERROR / "connection forcefully terminated").
    private var wifiCallback: ConnectivityManager.NetworkCallback? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // Native vibrator: HapticFeedback is muted by many Android skins
        // (ColorOS/MIUI) unless the app drives the Vibrator service directly.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, hapticsChannel)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "vibrate" -> {
                        val ms = (call.argument<Int>("ms") ?: 20).toLong()
                        val amp = call.argument<Int>("amplitude") ?: -1
                        vibrate(ms, amp)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, networkChannel)
            .setMethodCallHandler { call, result ->
                val connectivity = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                when (call.method) {
                    "bindProcessToWifi" -> {
                        val phoneHotspot = call.argument<Boolean>("phoneHotspot") == true
                        if (phoneHotspot) {
                            // Phone hosts the scooter's hotspot: there is no Wi-Fi
                            // client network to bind. Clear any binding so Android
                            // uses its local tethering route to the scooter instead
                            // of the cellular upstream.
                            releaseWifiRequest(connectivity)
                            if (connectivity.bindProcessToNetwork(null)) {
                                result.success(true)
                            } else {
                                result.error(
                                    "network_restore_failed",
                                    "Android could not restore local routing for the hotspot.",
                                    null,
                                )
                            }
                        } else {
                            requestAndBindWifi(connectivity, result)
                        }
                    }
                    "restoreDefaultNetwork" -> {
                        releaseWifiRequest(connectivity)
                        result.success(connectivity.bindProcessToNetwork(null))
                    }
                    "enableBluetooth" -> {
                        // Shows the system "turn on Bluetooth?" dialog. Needs the
                        // BLUETOOTH_CONNECT runtime permission on API 31+, which
                        // the BLE flow requests before calling this.
                        try {
                            startActivity(
                                Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),
                            )
                            result.success(true)
                        } catch (error: Exception) {
                            result.error(
                                "bt_enable_failed",
                                error.message ?: "Could not request Bluetooth enable.",
                                null,
                            )
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun requestAndBindWifi(connectivity: ConnectivityManager, result: MethodChannel.Result) {
        // Drop any prior request so reconnects do not leak callbacks.
        releaseWifiRequest(connectivity)

        // Request a Wi-Fi network WITHOUT requiring internet. The default builder
        // demands NET_CAPABILITY_INTERNET, which a scooter AP never has, so it
        // would never match. Removing it lets us hold (and keep alive) the
        // local-only network for the whole session.
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        val replied = AtomicBoolean(false)
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                // Fires on first match and again if Android swaps the Network
                // object; re-bind each time so the process always points at the
                // live scooter network.
                val bound = connectivity.bindProcessToNetwork(network)
                if (replied.compareAndSet(false, true)) {
                    mainHandler.post {
                        if (bound) {
                            result.success(true)
                        } else {
                            result.error(
                                "wifi_bind_failed",
                                "Android could not route the app over Wi-Fi.",
                                null,
                            )
                        }
                    }
                }
            }

            override fun onUnavailable() {
                if (replied.compareAndSet(false, true)) {
                    mainHandler.post {
                        result.error(
                            "wifi_unavailable",
                            "No scooter Wi-Fi was found. Join the scooter's Wi-Fi, then retry.",
                            null,
                        )
                    }
                }
            }
        }
        wifiCallback = callback
        try {
            // 6s < the 8s Dart-side timeout, so onUnavailable surfaces a clean
            // error before Dart times the channel call out.
            connectivity.requestNetwork(request, callback, 6_000)
        } catch (e: SecurityException) {
            wifiCallback = null
            if (replied.compareAndSet(false, true)) {
                result.error(
                    "wifi_request_failed",
                    e.message ?: "Android denied the Wi-Fi network request.",
                    null,
                )
            }
        }
    }

    private fun releaseWifiRequest(connectivity: ConnectivityManager) {
        wifiCallback?.let {
            try {
                connectivity.unregisterNetworkCallback(it)
            } catch (_: Exception) {
                // Already unregistered or never registered; ignore.
            }
        }
        wifiCallback = null
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long, amplitude: Int) {
        val vib = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                .defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (!vib.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val amp = if (amplitude in 1..255) amplitude else VibrationEffect.DEFAULT_AMPLITUDE
            vib.vibrate(VibrationEffect.createOneShot(ms, amp))
        } else {
            vib.vibrate(ms)
        }
    }

    override fun onDestroy() {
        val connectivity = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        releaseWifiRequest(connectivity)
        super.onDestroy()
    }
}
