package `in`.crossfire.openola

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val networkChannel = "in.crossfire.openola/network"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, networkChannel)
            .setMethodCallHandler { call, result ->
                val connectivity = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                when (call.method) {
                    "bindProcessToWifi" -> {
                        val wifi: Network? = connectivity.allNetworks.firstOrNull { network ->
                            connectivity.getNetworkCapabilities(network)
                                ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                        }
                        if (wifi == null) {
                            result.error("wifi_unavailable", "Join the scooter's Wi-Fi network first.", null)
                        } else if (connectivity.bindProcessToNetwork(wifi)) {
                            result.success(true)
                        } else {
                            result.error("wifi_bind_failed", "Android could not route the app over Wi-Fi.", null)
                        }
                    }
                    "restoreDefaultNetwork" -> result.success(connectivity.bindProcessToNetwork(null))
                    else -> result.notImplemented()
                }
            }
    }
}
